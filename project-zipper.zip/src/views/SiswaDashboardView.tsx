import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { useTenant } from '../context/TenantContext';
import { GradeRecord, AttendanceRecord, SMKPklJournal, SMKPklAttendance } from '../types';
import { academicRepository } from '../repositories/academicRepository';
import {
  GraduationCap,
  CalendarCheck,
  FileSpreadsheet,
  Award,
  BookOpen,
  CheckCircle2,
  Clock,
  Building,
  Briefcase,
  Plus,
  Send,
  Check,
} from 'lucide-react';

export const SiswaDashboardView: React.FC = () => {
  const { currentUser } = useAuth();
  const { currentTenant } = useTenant();

  const [grades, setGrades] = useState<GradeRecord[]>([]);
  const [attendance, setAttendance] = useState<AttendanceRecord[]>([]);
  const [activeTab, setActiveTab] = useState<'jadwal' | 'raport' | 'presensi' | 'pkl'>('jadwal');
  const [isLoading, setIsLoading] = useState(true);

  // PKL State (SMK students)
  const [pklJournals, setPklJournals] = useState<SMKPklJournal[]>([]);
  const [pklAttendance, setPklAttendance] = useState<SMKPklAttendance[]>([]);
  const [journalActivity, setJournalActivity] = useState('');
  const [journalCompetency, setJournalCompetency] = useState('');
  const [attStatus, setAttStatus] = useState<'HADIR' | 'IZIN' | 'SAKIT'>('HADIR');
  const [attNotes, setAttNotes] = useState('Bekerja on-site di industri');
  const [actionMsg, setActionMsg] = useState<string | null>(null);

  const fetchData = async () => {
    if (!currentUser || !currentTenant) return;
    setIsLoading(true);
    try {
      const [grd, att, journals, pklAtt] = await Promise.all([
        academicRepository.getGrades(currentTenant.id, currentUser, { student_id: currentUser.id }),
        academicRepository.getAttendance(currentTenant.id, currentUser, { student_id: currentUser.id }),
        academicRepository.getSmkPklJournals(currentTenant.id, currentUser),
        academicRepository.getSmkPklAttendance(currentTenant.id, currentUser),
      ]);
      setGrades(grd as GradeRecord[]);
      setAttendance(att);
      setPklJournals(journals);
      setPklAttendance(pklAtt);
    } catch (err) {
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, [currentUser?.id, currentTenant?.id]);

  const countStatus = (st: string) => attendance.filter((a) => a.status === st).length;
  const hadirCount = countStatus('HADIR');
  const sakitCount = countStatus('SAKIT');
  const izinCount = countStatus('IZIN');
  const alpaCount = countStatus('ALPA');

  const handleAddJournal = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentTenant || !currentUser) return;
    try {
      await academicRepository.addSmkPklJournal(
        {
          tenant_id: currentTenant.id,
          placement_id: 'pkl-1',
          date: new Date().toISOString().split('T')[0],
          activity_summary: journalActivity,
          competencies_learned: journalCompetency,
          supervisor_verified: false,
        },
        currentUser
      );
      setJournalActivity('');
      setJournalCompetency('');
      setActionMsg('Jurnal harian PKL berhasil dikirim untuk diverifikasi pembimbing!');
      setTimeout(() => setActionMsg(null), 4000);
      await fetchData();
    } catch (err: any) {
      alert(err.message || 'Gagal menyimpan jurnal');
    }
  };

  const handleAddPklAttendance = async () => {
    if (!currentTenant || !currentUser) return;
    try {
      await academicRepository.addSmkPklAttendance(
        {
          tenant_id: currentTenant.id,
          placement_id: 'pkl-1',
          date: new Date().toISOString().split('T')[0],
          check_in_time: '08:00',
          check_out_time: '17:00',
          status: attStatus,
          notes: attNotes,
        },
        currentUser
      );
      setActionMsg('Presensi PKL industri hari ini berhasil dicatat!');
      setTimeout(() => setActionMsg(null), 4000);
      await fetchData();
    } catch (err: any) {
      alert(err.message || 'Gagal mencatat presensi');
    }
  };

  // Sample schedule
  const sampleSchedule = [
    { day: 'Senin', time: '07:00 - 08:30', subject: 'Matematika Wajib', teacher: 'Dra. Sri Wahyuni, M.Pd.', room: 'R. 10-1' },
    { day: 'Senin', time: '08:45 - 10:15', subject: 'Bahasa Indonesia', teacher: 'Ahmad Dahlan, S.Pd.', room: 'R. 10-1' },
    { day: 'Senin', time: '10:30 - 12:00', subject: 'Pendidikan Agama & Budi Pekerti', teacher: 'Ust. Mansur, M.Ag.', room: 'R. 10-1' },
    { day: 'Selasa', time: '07:00 - 09:15', subject: currentTenant?.type === 'SMK' ? 'Pemrograman Web (Produktif)' : 'Fisika Peminatan', teacher: 'Ir. Hendra Gunawan', room: 'Lab Komputer 1' },
    { day: 'Selasa', time: '09:30 - 11:45', subject: 'Bahasa Inggris', teacher: 'Sarah Jenkins, M.Ed.', room: 'R. 10-1' },
    { day: 'Rabu', time: '07:00 - 09:15', subject: 'Sejarah Indonesia & Pancasila', teacher: 'Dra. Sri Wahyuni, M.Pd.', room: 'R. 10-1' },
    { day: 'Rabu', time: '09:30 - 11:45', subject: 'Kimia / Basis Data', teacher: 'Dr. Budi Santoso, M.Kom.', room: 'Lab Kimia' },
  ];

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-emerald-900 to-teal-900 text-white rounded-3xl p-6 shadow-xl relative overflow-hidden">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2 text-emerald-300 text-xs font-semibold uppercase tracking-wider">
              <GraduationCap className="w-4 h-4" />
              <span>Portal Siswa • {currentTenant?.name}</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-black tracking-tight">
              Halo, {currentUser?.full_name}
            </h1>
            <p className="text-xs text-emerald-200 max-w-2xl leading-relaxed">
              Pantau jadwal harian sekolah, rekap presensi kehadiran, buku rapor hasil belajar digital, serta modul PKL industri.
            </p>
          </div>

          <div className="flex items-center gap-2 bg-emerald-950/60 p-2.5 rounded-2xl border border-emerald-700/50 text-xs">
            <div className="flex flex-col">
              <span className="text-[10px] text-emerald-300 uppercase font-semibold">Tahun Ajaran</span>
              <span className="font-bold text-white">2024/2025 (Ganjil)</span>
            </div>
          </div>
        </div>
      </div>

      {actionMsg && (
        <div className="p-3.5 rounded-2xl bg-emerald-50 text-emerald-800 border border-emerald-200 text-xs font-bold flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>{actionMsg}</span>
        </div>
      )}

      {/* Attendance Summary Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-1">
          <span className="text-xs font-bold text-slate-500 uppercase">Hadir</span>
          <div className="text-2xl font-black text-emerald-600 dark:text-emerald-400">
            {hadirCount} Hari
          </div>
          <p className="text-[11px] text-slate-400">Presensi tercatat</p>
        </div>
        <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-1">
          <span className="text-xs font-bold text-slate-500 uppercase">Sakit</span>
          <div className="text-2xl font-black text-amber-500">
            {sakitCount} Hari
          </div>
          <p className="text-[11px] text-slate-400">Surat dokter</p>
        </div>
        <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-1">
          <span className="text-xs font-bold text-slate-500 uppercase">Izin</span>
          <div className="text-2xl font-black text-blue-600 dark:text-blue-400">
            {izinCount} Hari
          </div>
          <p className="text-[11px] text-slate-400">Disetujui wali kelas</p>
        </div>
        <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-1">
          <span className="text-xs font-bold text-slate-500 uppercase">Alpa</span>
          <div className="text-2xl font-black text-rose-600 dark:text-rose-400">
            {alpaCount} Hari
          </div>
          <p className="text-[11px] text-slate-400">Tanpa keterangan</p>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-1 bg-white dark:bg-slate-900 p-1.5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs text-xs overflow-x-auto">
        <button
          type="button"
          onClick={() => setActiveTab('jadwal')}
          className={`flex-1 min-w-[120px] py-2 rounded-xl font-bold transition-all cursor-pointer flex items-center justify-center gap-2 ${
            activeTab === 'jadwal'
              ? 'bg-emerald-600 text-white shadow-xs'
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
          }`}
        >
          <Clock className="w-4 h-4" />
          <span>Jadwal Pelajaran</span>
        </button>
        <button
          type="button"
          onClick={() => setActiveTab('raport')}
          className={`flex-1 min-w-[120px] py-2 rounded-xl font-bold transition-all cursor-pointer flex items-center justify-center gap-2 ${
            activeTab === 'raport'
              ? 'bg-emerald-600 text-white shadow-xs'
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
          }`}
        >
          <FileSpreadsheet className="w-4 h-4" />
          <span>Nilai & Rapor Digital</span>
        </button>
        <button
          type="button"
          onClick={() => setActiveTab('presensi')}
          className={`flex-1 min-w-[120px] py-2 rounded-xl font-bold transition-all cursor-pointer flex items-center justify-center gap-2 ${
            activeTab === 'presensi'
              ? 'bg-emerald-600 text-white shadow-xs'
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
          }`}
        >
          <CalendarCheck className="w-4 h-4" />
          <span>Riwayat Presensi</span>
        </button>
        {currentTenant?.type === 'SMK' && (
          <button
            type="button"
            onClick={() => setActiveTab('pkl')}
            className={`flex-1 min-w-[150px] py-2 rounded-xl font-bold transition-all cursor-pointer flex items-center justify-center gap-2 ${
              activeTab === 'pkl'
                ? 'bg-amber-600 text-white shadow-xs'
                : 'text-amber-700 dark:text-amber-400 hover:text-amber-900'
            }`}
          >
            <Briefcase className="w-4 h-4" />
            <span>Modul PKL & Magang</span>
          </button>
        )}
      </div>

      {/* Tab Content 1: Jadwal */}
      {activeTab === 'jadwal' && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-5 shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <Clock className="w-5 h-5 text-emerald-600" />
              <span>Jadwal Belajar Mingguan</span>
            </h2>
            <span className="text-xs font-semibold text-slate-500">
              Kelas X-1 • Semester Ganjil
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
            {sampleSchedule.map((item, idx) => (
              <div
                key={idx}
                className="p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-850 space-y-2"
              >
                <div className="flex items-center justify-between">
                  <span className="px-2.5 py-0.5 rounded-full bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300 font-bold text-[10px]">
                    {item.day}
                  </span>
                  <span className="font-mono text-xs text-slate-400 font-medium">
                    {item.time}
                  </span>
                </div>
                <div>
                  <h3 className="font-bold text-slate-900 dark:text-white text-sm">
                    {item.subject}
                  </h3>
                  <p className="text-xs text-slate-500">{item.teacher}</p>
                </div>
                <div className="pt-2 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between text-[11px] text-slate-400">
                  <span>Ruang: {item.room}</span>
                  <span className="text-emerald-600 font-semibold">Tatap Muka</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tab Content 2: Nilai & Raport */}
      {activeTab === 'raport' && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl overflow-hidden shadow-xs space-y-4">
          <div className="p-5 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
            <div>
              <h2 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <Award className="w-5 h-5 text-emerald-600" />
                <span>Buku Nilai & Rapor Hasil Belajar Digital</span>
              </h2>
              <p className="text-xs text-slate-500">
                Nilai yang telah diverifikasi dan disahkan oleh guru mata pelajaran
              </p>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-slate-700 dark:text-slate-300">
              <thead className="bg-slate-50 dark:bg-slate-850 text-[11px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider border-b border-slate-200 dark:border-slate-800">
                <tr>
                  <th className="py-3.5 px-4">Mata Pelajaran</th>
                  <th className="py-3.5 px-4 text-center">Tugas (30%)</th>
                  <th className="py-3.5 px-4 text-center">UTS (30%)</th>
                  <th className="py-3.5 px-4 text-center">UAS (40%)</th>
                  <th className="py-3.5 px-4 text-center">Nilai Akhir</th>
                  <th className="py-3.5 px-4 text-center">Predikat</th>
                  <th className="py-3.5 px-4">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800 font-medium">
                {grades.length === 0 ? (
                  <tr>
                    <td colSpan={7} className="py-8 text-center text-slate-400">
                      Belum ada nilai yang dipublikasikan oleh guru pengajar.
                    </td>
                  </tr>
                ) : (
                  grades.map((g) => (
                    <tr key={g.id} className="hover:bg-slate-50/70 dark:hover:bg-slate-800/50">
                      <td className="py-3.5 px-4 font-bold text-slate-900 dark:text-white">
                        {g.subject_name}
                      </td>
                      <td className="py-3.5 px-4 text-center font-mono">{g.tugas_score}</td>
                      <td className="py-3.5 px-4 text-center font-mono">{g.uts_score}</td>
                      <td className="py-3.5 px-4 text-center font-mono">{g.uas_score}</td>
                      <td className="py-3.5 px-4 text-center font-mono font-black text-slate-900 dark:text-white">
                        {g.final_score}
                      </td>
                      <td className="py-3.5 px-4 text-center">
                        <span className="px-2 py-0.5 rounded font-bold text-xs bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300">
                          {g.predicate}
                        </span>
                      </td>
                      <td className="py-3.5 px-4">
                        <span className="text-emerald-600 font-bold text-[11px] flex items-center gap-1">
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          <span>Tuntas (KKM 75)</span>
                        </span>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Tab Content 3: Presensi */}
      {activeTab === 'presensi' && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-5 shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <CalendarCheck className="w-5 h-5 text-emerald-600" />
              <span>Log Kehadiran Harian</span>
            </h2>
            <span className="text-xs text-slate-500 font-semibold">
              Persentase Kehadiran: 100%
            </span>
          </div>

          <div className="space-y-2">
            {attendance.map((rec) => (
              <div
                key={rec.id}
                className="p-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-850 flex items-center justify-between text-xs"
              >
                <div className="flex items-center gap-3">
                  <span className="font-mono text-slate-500 font-semibold">{rec.date}</span>
                  <span className="font-bold text-slate-800 dark:text-slate-200">
                    Presensi Reguler Sekolah
                  </span>
                </div>
                <span
                  className={`px-2.5 py-0.5 rounded-full font-bold text-[11px] ${
                    rec.status === 'HADIR'
                      ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                      : rec.status === 'SAKIT'
                      ? 'bg-amber-100 text-amber-800'
                      : 'bg-rose-100 text-rose-800'
                  }`}
                >
                  {rec.status}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tab Content 4: PKL Magang (Khusus SMK) */}
      {activeTab === 'pkl' && currentTenant?.type === 'SMK' && (
        <div className="space-y-6">
          {/* Industry Placement Card */}
          <div className="p-5 rounded-3xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-900/50 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <span className="text-[10px] font-bold text-amber-700 dark:text-amber-400 uppercase">
                Tempat Praktik Kerja Lapangan (PKL) Anda
              </span>
              <h3 className="text-base font-black text-slate-900 dark:text-white">
                PT Telkom Akses Regional 2
              </h3>
              <p className="text-xs text-slate-600 dark:text-slate-400">
                Pembimbing Sekolah: Ir. Hendra Gunawan • Pembimbing Industri: Bpk. Kurniawan, S.T.
              </p>
            </div>
            <div className="flex items-center gap-2">
              <span className="px-3 py-1 rounded-full bg-emerald-100 text-emerald-800 font-bold text-xs">
                Periode: 01 Juli - 31 Des 2024
              </span>
            </div>
          </div>

          {/* Quick Action: Log Attendance & Submit Journal */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Log Presensi PKL */}
            <div className="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-3 text-xs">
              <h4 className="font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <CalendarCheck className="w-4 h-4 text-amber-600" />
                <span>Input Presensi Kehadiran Magang Hari Ini</span>
              </h4>
              <div className="space-y-2">
                <div>
                  <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">Status Kehadiran</label>
                  <div className="grid grid-cols-3 gap-2">
                    {(['HADIR', 'IZIN', 'SAKIT'] as const).map((st) => (
                      <button
                        key={st}
                        type="button"
                        onClick={() => setAttStatus(st)}
                        className={`py-2 rounded-xl font-bold transition-all cursor-pointer ${
                          attStatus === st
                            ? 'bg-amber-600 text-white'
                            : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
                        }`}
                      >
                        {st}
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">Catatan / Lokasi Penugasan</label>
                  <input
                    type="text"
                    value={attNotes}
                    onChange={(e) => setAttNotes(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
                  />
                </div>

                <button
                  type="button"
                  onClick={handleAddPklAttendance}
                  className="w-full py-2.5 bg-amber-600 hover:bg-amber-700 text-white rounded-xl font-bold flex items-center justify-center gap-1.5 cursor-pointer shadow-xs"
                >
                  <Check className="w-4 h-4" />
                  <span>Kirim Presensi PKL</span>
                </button>
              </div>
            </div>

            {/* Input Jurnal Kegiatan */}
            <form
              onSubmit={handleAddJournal}
              className="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-3 text-xs"
            >
              <h4 className="font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <FileSpreadsheet className="w-4 h-4 text-amber-600" />
                <span>Input Jurnal Kegiatan Harian</span>
              </h4>

              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">Uraian Pekerjaan / Aktivitas</label>
                <textarea
                  rows={2}
                  required
                  placeholder="contoh: Konfigurasi switch fiber optic dan pengkabelan rack server..."
                  value={journalActivity}
                  onChange={(e) => setJournalActivity(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">Kompetensi yang Dipelajari</label>
                <input
                  type="text"
                  required
                  placeholder="contoh: Routing VLAN & Fiber Splicing"
                  value={journalCompetency}
                  onChange={(e) => setJournalCompetency(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
                />
              </div>

              <button
                type="submit"
                className="w-full py-2.5 bg-amber-600 hover:bg-amber-700 text-white rounded-xl font-bold flex items-center justify-center gap-1.5 cursor-pointer shadow-xs"
              >
                <Send className="w-4 h-4" />
                <span>Kirim Jurnal untuk Diverifikasi</span>
              </button>
            </form>
          </div>

          {/* List of Previous Journals */}
          <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-5 shadow-xs space-y-3">
            <h4 className="text-sm font-bold text-slate-900 dark:text-white">
              Riwayat Jurnal Harian PKL
            </h4>
            <div className="space-y-2 text-xs">
              {pklJournals.map((j) => (
                <div
                  key={j.id}
                  className="p-3.5 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-850 flex flex-col sm:flex-row sm:items-center justify-between gap-2"
                >
                  <div className="space-y-0.5">
                    <span className="font-mono text-[11px] text-slate-400">{j.date}</span>
                    <p className="font-bold text-slate-900 dark:text-white">{j.activity_summary}</p>
                    <p className="text-[11px] text-slate-500">Kompetensi: {j.competencies_learned}</p>
                  </div>
                  <div>
                    <span
                      className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold ${
                        j.supervisor_verified
                          ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                          : 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300'
                      }`}
                    >
                      {j.supervisor_verified ? 'Telah Diverifikasi Pembimbing' : 'Menunggu Verifikasi'}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
