import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useTenant } from '../../context/TenantContext';
import {
  SchoolClass,
  Subject,
  ClassSchedule,
  StudentProfile,
  StudentReportCard,
  StudentDisciplineRecord,
} from '../../types';
import { academicRepository } from '../../repositories/academicRepository';
import {
  BookOpen,
  GraduationCap,
  CalendarCheck,
  Award,
  Users,
  FileSpreadsheet,
  CheckCircle2,
  Clock,
  Sparkles,
  ShieldCheck,
  Compass,
  ChevronRight,
  TrendingUp,
} from 'lucide-react';

export const SmaManagementModule: React.FC = () => {
  const { currentUser } = useAuth();
  const { currentTenant } = useTenant();

  const [activeTab, setActiveTab] = useState<'classes_subjects' | 'schedules' | 'academics_rapor' | 'ptn_career'>('classes_subjects');
  const [classes, setClasses] = useState<SchoolClass[]>([]);
  const [subjects, setSubjects] = useState<Subject[]>([]);
  const [schedules, setSchedules] = useState<ClassSchedule[]>([]);
  const [students, setStudents] = useState<StudentProfile[]>([]);
  const [reportCards, setReportCards] = useState<StudentReportCard[]>([]);
  const [disciplineRecords, setDisciplineRecords] = useState<StudentDisciplineRecord[]>([]);
  const [selectedClassId, setSelectedClassId] = useState<string>('cls-sma-10-1');
  const [isLoading, setIsLoading] = useState(true);

  const loadData = async () => {
    if (!currentTenant) return;
    setIsLoading(true);
    try {
      const [clsData, subData, schData, stdData, rptData, dscData] = await Promise.all([
        academicRepository.getClassesByTenant(currentTenant.id, currentUser),
        academicRepository.getSubjects(currentTenant.id),
        academicRepository.getClassSchedules(currentTenant.id, selectedClassId),
        academicRepository.getStudentsByTenant(currentTenant.id, currentUser),
        academicRepository.getReportCards(currentTenant.id, currentUser),
        academicRepository.getDisciplineRecords(currentTenant.id),
      ]);

      setClasses(clsData);
      setSubjects(subData);
      setSchedules(schData);
      setStudents(stdData);
      setReportCards(rptData);
      setDisciplineRecords(dscData);
    } catch (err) {
      console.error('Error loading SMA data:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, [currentTenant?.id, selectedClassId]);

  const generalSubjects = subjects.filter((s) => s.category === 'UMUM');
  const electiveSubjects = subjects.filter((s) => s.category === 'PEMINATAN');
  const p5Subjects = subjects.filter((s) => s.category === 'P5' || s.category === 'MULOK');

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="p-6 rounded-3xl bg-gradient-to-r from-blue-700 via-indigo-700 to-blue-800 text-white shadow-xl relative overflow-hidden">
        <div className="absolute right-0 top-0 translate-x-8 -translate-y-8 w-64 h-64 bg-white/10 rounded-full blur-2xl pointer-events-none" />
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/20 backdrop-blur-md text-[11px] font-bold tracking-wide uppercase">
              <GraduationCap className="w-3.5 h-3.5" />
              <span>Modul Akademik SMA (Sekolah Menengah Atas)</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-black tracking-tight">
              Kurikulum Merdeka, Peminatan & Sukses PTN
            </h2>
            <p className="text-xs text-blue-100 max-w-2xl leading-relaxed">
              Pengelolaan fase perkembangan Fase E & Fase F, mata pelajaran peminatan sains/sosial/humaniora, projek P5, e-Rapor komprehensif, dan pembinaan minat perguruan tinggi negeri.
            </p>
          </div>

          <div className="flex gap-2">
            <div className="px-4 py-3 rounded-2xl bg-white/10 backdrop-blur-md text-center">
              <div className="text-2xl font-black">{classes.length}</div>
              <div className="text-[10px] text-blue-200 uppercase font-bold">Rombel Kelas</div>
            </div>
            <div className="px-4 py-3 rounded-2xl bg-white/10 backdrop-blur-md text-center">
              <div className="text-2xl font-black">{students.length}</div>
              <div className="text-[10px] text-blue-200 uppercase font-bold">Siswa Aktif</div>
            </div>
          </div>
        </div>
      </div>

      {/* Main Tabs */}
      <div className="flex border-b border-slate-200 dark:border-slate-800 gap-2 overflow-x-auto pb-1">
        <button
          type="button"
          onClick={() => setActiveTab('classes_subjects')}
          className={`px-4 py-2.5 rounded-xl text-xs font-bold transition-all whitespace-nowrap cursor-pointer flex items-center gap-2 ${
            activeTab === 'classes_subjects'
              ? 'bg-blue-600 text-white shadow-md'
              : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
          }`}
        >
          <BookOpen className="w-4 h-4" />
          <span>Struktur Kelas & Mata Pelajaran</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('schedules')}
          className={`px-4 py-2.5 rounded-xl text-xs font-bold transition-all whitespace-nowrap cursor-pointer flex items-center gap-2 ${
            activeTab === 'schedules'
              ? 'bg-blue-600 text-white shadow-md'
              : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
          }`}
        >
          <CalendarCheck className="w-4 h-4" />
          <span>Jadwal Pelajaran KBM</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('academics_rapor')}
          className={`px-4 py-2.5 rounded-xl text-xs font-bold transition-all whitespace-nowrap cursor-pointer flex items-center gap-2 ${
            activeTab === 'academics_rapor'
              ? 'bg-blue-600 text-white shadow-md'
              : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
          }`}
        >
          <FileSpreadsheet className="w-4 h-4" />
          <span>e-Rapor & Capaian KKTP</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('ptn_career')}
          className={`px-4 py-2.5 rounded-xl text-xs font-bold transition-all whitespace-nowrap cursor-pointer flex items-center gap-2 ${
            activeTab === 'ptn_career'
              ? 'bg-blue-600 text-white shadow-md'
              : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
          }`}
        >
          <Compass className="w-4 h-4" />
          <span>Kesiapan Studi Lanjut (SNBP / PTN)</span>
        </button>
      </div>

      {/* Tab 1: Struktur Kelas & Mata Pelajaran */}
      {activeTab === 'classes_subjects' && (
        <div className="space-y-6">
          {/* Kelas Grid */}
          <div className="space-y-3">
            <h3 className="text-sm font-bold text-slate-900 dark:text-white uppercase tracking-wider text-slate-500">
              Rombongan Belajar (Rombel) SMA
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {classes.map((cls) => (
                <div
                  key={cls.id}
                  className="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-3"
                >
                  <div className="flex items-start justify-between">
                    <div>
                      <span className="text-[10px] font-bold text-blue-600 uppercase">Tingkat {cls.grade_level}</span>
                      <h4 className="text-base font-black text-slate-900 dark:text-white">{cls.name}</h4>
                    </div>
                    <span className="px-2.5 py-0.5 rounded-full bg-blue-50 dark:bg-blue-950 text-blue-700 dark:text-blue-300 text-xs font-bold">
                      {cls.capacity} Siswa
                    </span>
                  </div>

                  <div className="space-y-1 text-xs text-slate-600 dark:text-slate-400">
                    <div>Peminatan: <strong className="text-slate-800 dark:text-slate-200">{cls.major || 'Fase E (Umum/MIPA)'}</strong></div>
                    <div>Wali Kelas: <strong className="text-slate-800 dark:text-slate-200">{cls.homeroom_teacher_name}</strong></div>
                    <div>Ruang: <strong className="text-slate-800 dark:text-slate-200">{cls.room_number}</strong></div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Mapel Categories */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-3">
              <div className="flex items-center gap-2 text-blue-600 font-bold text-xs uppercase tracking-wider">
                <BookOpen className="w-4 h-4" />
                <span>Mapel Umum (Wajib)</span>
              </div>
              <div className="space-y-2">
                {generalSubjects.map((sub) => (
                  <div key={sub.id} className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/50 flex justify-between items-center text-xs">
                    <div>
                      <div className="font-bold text-slate-900 dark:text-white">{sub.name}</div>
                      <div className="text-[10px] text-slate-400">Kode: {sub.code} • {sub.hours_per_week} Jam/Minggu</div>
                    </div>
                    <span className="text-[11px] font-bold text-slate-600 dark:text-slate-300 font-mono">KKTP: {sub.kkm}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-3">
              <div className="flex items-center gap-2 text-indigo-600 font-bold text-xs uppercase tracking-wider">
                <Sparkles className="w-4 h-4" />
                <span>Peminatan MIPA & Soshum</span>
              </div>
              <div className="space-y-2">
                {electiveSubjects.map((sub) => (
                  <div key={sub.id} className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/50 flex justify-between items-center text-xs">
                    <div>
                      <div className="font-bold text-slate-900 dark:text-white">{sub.name}</div>
                      <div className="text-[10px] text-slate-400">Kode: {sub.code} • {sub.hours_per_week} Jam/Minggu</div>
                    </div>
                    <span className="text-[11px] font-bold text-indigo-600 dark:text-indigo-400 font-mono">KKTP: {sub.kkm}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-3">
              <div className="flex items-center gap-2 text-emerald-600 font-bold text-xs uppercase tracking-wider">
                <ShieldCheck className="w-4 h-4" />
                <span>P5 & Muatan Lokal</span>
              </div>
              <div className="space-y-2">
                {p5Subjects.map((sub) => (
                  <div key={sub.id} className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/50 flex justify-between items-center text-xs">
                    <div>
                      <div className="font-bold text-slate-900 dark:text-white">{sub.name}</div>
                      <div className="text-[10px] text-slate-400">Tema: Gaya Hidup Berkelanjutan</div>
                    </div>
                    <span className="text-[11px] font-bold text-emerald-600 font-mono">Berkembang</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Tab 2: Jadwal Pelajaran */}
      {activeTab === 'schedules' && (
        <div className="space-y-4">
          <div className="flex items-center gap-3">
            <span className="text-xs font-bold text-slate-500">Pilih Kelas:</span>
            <div className="flex gap-2">
              {classes.map((cls) => (
                <button
                  key={cls.id}
                  type="button"
                  onClick={() => setSelectedClassId(cls.id)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold cursor-pointer transition-all ${
                    selectedClassId === cls.id
                      ? 'bg-blue-600 text-white shadow-xs'
                      : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-400 border border-slate-200 dark:border-slate-800'
                  }`}
                >
                  {cls.name}
                </button>
              ))}
            </div>
          </div>

          <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 overflow-hidden shadow-xs">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 dark:bg-slate-800/60 text-slate-400 font-bold uppercase text-[10px] tracking-wider border-b border-slate-200 dark:border-slate-800">
                  <tr>
                    <th className="py-3 px-4">Hari</th>
                    <th className="py-3 px-4">Waktu</th>
                    <th className="py-3 px-4">Mata Pelajaran</th>
                    <th className="py-3 px-4">Guru Pengampu</th>
                    <th className="py-3 px-4">Ruang Kelas</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {schedules.map((sch) => (
                    <tr key={sch.id}>
                      <td className="py-3.5 px-4 font-bold text-blue-600">{sch.day_of_week}</td>
                      <td className="py-3.5 px-4 font-mono text-[11px] text-slate-500">
                        {sch.start_time} - {sch.end_time}
                      </td>
                      <td className="py-3.5 px-4 font-bold text-slate-900 dark:text-white">
                        {sch.subject_name}
                      </td>
                      <td className="py-3.5 px-4 text-slate-600 dark:text-slate-300">
                        {sch.teacher_name}
                      </td>
                      <td className="py-3.5 px-4 text-slate-500">
                        {sch.room}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* Tab 3: e-Rapor & Capaian KKTP */}
      {activeTab === 'academics_rapor' && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {reportCards.map((rc) => (
              <div
                key={rc.id}
                className="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-4"
              >
                <div className="flex items-start justify-between">
                  <div>
                    <span className="text-[10px] font-bold text-blue-600 uppercase">NISN: {rc.nisn}</span>
                    <h4 className="text-base font-black text-slate-900 dark:text-white">{rc.student_name}</h4>
                    <div className="text-xs text-slate-400">{rc.class_name} • Semester {rc.semester}</div>
                  </div>
                  <div className="text-right">
                    <div className="text-2xl font-black text-blue-600 dark:text-blue-400">
                      {rc.average_score.toFixed(1)}
                    </div>
                    <div className="text-[10px] text-slate-400 font-bold">Rata-Rata Kelas</div>
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="text-[11px] font-bold text-slate-500 uppercase">Nilai Per Mata Pelajaran:</div>
                  <div className="space-y-1.5">
                    {rc.subjects.map((s, idx) => (
                      <div key={idx} className="flex justify-between items-center text-xs p-2 bg-slate-50 dark:bg-slate-800/40 rounded-xl">
                        <span className="font-semibold text-slate-800 dark:text-slate-200">{s.subject_name}</span>
                        <div className="flex items-center gap-3">
                          <span className="text-[10px] text-slate-400">KKTP {s.kkm}</span>
                          <span className="font-bold text-slate-900 dark:text-white font-mono">{s.final_score}</span>
                          <span className="px-1.5 py-0.5 rounded-md bg-blue-100 text-blue-800 dark:bg-blue-950 dark:text-blue-300 text-[10px] font-bold">
                            {s.letter_grade}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="pt-2 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs">
                  <span className="text-[11px] text-emerald-600 font-bold">Status: Rapor Terbit Resmi</span>
                  <span className="text-[11px] text-slate-400">Presensi: {rc.attendance_summary.hadir} Hadir • {rc.attendance_summary.alpa} Alpa</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tab 4: Kesiapan Sukses PTN (SNBP / SNBT) */}
      {activeTab === 'ptn_career' && (
        <div className="space-y-4">
          <div className="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-base font-black text-slate-900 dark:text-white flex items-center gap-2">
                  <Compass className="w-5 h-5 text-blue-600" />
                  <span>Pemetaan Minat & Peminatan Studi Lanjut PTN (Kelas XII)</span>
                </h3>
                <p className="text-xs text-slate-500">
                  Data pemetaan eligible SNBP (Seleksi Nasional Berdasarkan Prestasi) berdasarkan pemeringkatan nilai rapor semester 1-5.
                </p>
              </div>
              <span className="px-3 py-1 rounded-full bg-blue-50 dark:bg-blue-950 text-blue-700 dark:text-blue-300 text-xs font-bold">
                Kuota 40% (Akreditasi A)
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 space-y-1">
                <div className="text-xs font-semibold text-slate-500">Target PTN Terbanyak</div>
                <div className="text-lg font-black text-slate-900 dark:text-white">UI, ITB, UGM, Unpad</div>
                <div className="text-[10px] text-slate-400">Fakultas Kedokteran & STEI</div>
              </div>
              <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 space-y-1">
                <div className="text-xs font-semibold text-slate-500">Siswa Eligible SNBP</div>
                <div className="text-lg font-black text-blue-600">32 Siswa</div>
                <div className="text-[10px] text-slate-400">Rata-rata Rapor &gt; 86.5</div>
              </div>
              <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 space-y-1">
                <div className="text-xs font-semibold text-slate-500">Konsultasi BK Aktif</div>
                <div className="text-lg font-black text-emerald-600">100% Terlayani</div>
                <div className="text-[10px] text-slate-400">Tes Bakat & Minat Karier</div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
