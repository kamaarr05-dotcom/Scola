-- ==========================================================
-- SCOLA - SISTEM MANAJEMEN AKADEMIK MULTI-TENANT (SMA & SMK)
-- SUPABASE POSTGRESQL DDL SCHEMA & SEED SCRIPT
-- ==========================================================

-- 1. TENANTS TABLE (Sekolah SMA & SMK)
CREATE TABLE IF NOT EXISTS public.tenants (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    npsn TEXT UNIQUE NOT NULL,
    type TEXT NOT NULL CHECK (type IN ('SMA', 'SMK')),
    accreditation TEXT DEFAULT 'A',
    address TEXT,
    city TEXT,
    province TEXT,
    phone TEXT,
    email TEXT,
    logo_url TEXT,
    brand_color TEXT DEFAULT '#1e40af',
    teacher_quota INTEGER DEFAULT 25,
    active_teacher_count INTEGER DEFAULT 0,
    is_active BOOLEAN DEFAULT true,
    status TEXT DEFAULT 'ACTIVE' CHECK (status IN ('ACTIVE', 'INACTIVE')),
    subscription_tier TEXT DEFAULT 'STANDARD',
    valid_until DATE,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 2. USER PROFILES TABLE
CREATE TABLE IF NOT EXISTS public.user_profiles (
    id TEXT PRIMARY KEY,
    tenant_id TEXT REFERENCES public.tenants(id) ON DELETE SET NULL,
    email TEXT UNIQUE NOT NULL,
    full_name TEXT NOT NULL,
    phone TEXT,
    role TEXT NOT NULL CHECK (role IN ('MASTER', 'KEPALA_SEKOLAH', 'GURU', 'SISWA', 'ORANG_TUA', 'TENAGA_KEPENDIDIKAN')),
    status TEXT DEFAULT 'ACTIVE' CHECK (status IN ('ACTIVE', 'SUSPENDED', 'INACTIVE')),
    assignments JSONB DEFAULT '[]'::jsonb,
    linked_students JSONB DEFAULT '[]'::jsonb,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 3. CLASSES TABLE (Rombel / Kelas)
CREATE TABLE IF NOT EXISTS public.classes (
    id TEXT PRIMARY KEY,
    tenant_id TEXT NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    grade_level INTEGER NOT NULL CHECK (grade_level IN (10, 11, 12)),
    school_type TEXT NOT NULL CHECK (school_type IN ('SMA', 'SMK')),
    major_or_stream TEXT NOT NULL,
    academic_year_id TEXT,
    wali_kelas_teacher_id TEXT,
    wali_kelas_name TEXT,
    capacity INTEGER DEFAULT 36,
    total_students INTEGER DEFAULT 0,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 4. STUDENTS TABLE (Data Peserta Didik)
CREATE TABLE IF NOT EXISTS public.students (
    id TEXT PRIMARY KEY,
    tenant_id TEXT NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
    nisn TEXT UNIQUE NOT NULL,
    nis TEXT NOT NULL,
    full_name TEXT NOT NULL,
    class_id TEXT REFERENCES public.classes(id) ON DELETE SET NULL,
    grade_level INTEGER NOT NULL,
    school_type TEXT NOT NULL,
    major_or_stream TEXT NOT NULL,
    gender TEXT CHECK (gender IN ('L', 'P')),
    birth_place TEXT,
    birth_date DATE,
    religion TEXT,
    address TEXT,
    guardian_name TEXT,
    guardian_phone TEXT,
    status TEXT DEFAULT 'ACTIVE' CHECK (status IN ('ACTIVE', 'MUTASI', 'LULUS', 'DROPOUT')),
    avatar_url TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 5. SUBJECTS TABLE (Mata Pelajaran)
CREATE TABLE IF NOT EXISTS public.subjects (
    id TEXT PRIMARY KEY,
    tenant_id TEXT NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
    code TEXT NOT NULL,
    name TEXT NOT NULL,
    school_type TEXT NOT NULL CHECK (school_type IN ('SMA', 'SMK', 'BOTH')),
    kkm NUMERIC DEFAULT 75,
    teacher_id TEXT,
    teacher_name TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 6. ATTENDANCE TABLE (Presensi Harian)
CREATE TABLE IF NOT EXISTS public.daily_attendance (
    id TEXT PRIMARY KEY,
    tenant_id TEXT NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
    class_id TEXT NOT NULL REFERENCES public.classes(id) ON DELETE CASCADE,
    student_id TEXT NOT NULL REFERENCES public.students(id) ON DELETE CASCADE,
    date DATE NOT NULL,
    status TEXT NOT NULL CHECK (status IN ('HADIR', 'SAKIT', 'IZIN', 'ALPA')),
    notes TEXT,
    recorded_by TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 7. GRADES TABLE (Penilaian Akademik)
CREATE TABLE IF NOT EXISTS public.grades (
    id TEXT PRIMARY KEY,
    tenant_id TEXT NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
    student_id TEXT NOT NULL REFERENCES public.students(id) ON DELETE CASCADE,
    subject_id TEXT NOT NULL REFERENCES public.subjects(id) ON DELETE CASCADE,
    type TEXT NOT NULL CHECK (type IN ('TUGAS', 'UH', 'PTS', 'PAS', 'PRAKTIK')),
    score NUMERIC NOT NULL,
    weight NUMERIC DEFAULT 1,
    semester TEXT DEFAULT 'GANJIL',
    academic_year TEXT DEFAULT '2024/2025',
    graded_by TEXT,
    graded_at TIMESTAMPTZ DEFAULT NOW()
);

-- 8. ACADEMIC TASKS TABLE (Tugas & PR)
CREATE TABLE IF NOT EXISTS public.academic_tasks (
    id TEXT PRIMARY KEY,
    tenant_id TEXT NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
    class_id TEXT NOT NULL REFERENCES public.classes(id) ON DELETE CASCADE,
    subject_id TEXT NOT NULL REFERENCES public.subjects(id) ON DELETE CASCADE,
    title TEXT NOT NULL,
    description TEXT,
    due_date TIMESTAMPTZ NOT NULL,
    created_by TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 9. AUDIT LOGS TABLE
CREATE TABLE IF NOT EXISTS public.audit_logs (
    id TEXT PRIMARY KEY,
    timestamp TIMESTAMPTZ DEFAULT NOW(),
    event TEXT NOT NULL,
    user_id TEXT,
    email TEXT,
    role TEXT,
    tenant_id TEXT,
    tenant_name TEXT,
    status TEXT DEFAULT 'SUCCESS',
    ip_address TEXT,
    details TEXT
);

-- 10. ROW LEVEL SECURITY (RLS) POLICIES
-- Enable RLS
ALTER TABLE public.tenants ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.classes ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.students ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.subjects ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.daily_attendance ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.grades ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.academic_tasks ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.audit_logs ENABLE ROW LEVEL SECURITY;

-- Allow read & write access for anon/authenticated (controlled by SCOLA app client role engine)
CREATE POLICY "Allow public read-write for tenants" ON public.tenants FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Allow public read-write for user_profiles" ON public.user_profiles FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Allow public read-write for classes" ON public.classes FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Allow public read-write for students" ON public.students FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Allow public read-write for subjects" ON public.subjects FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Allow public read-write for daily_attendance" ON public.daily_attendance FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Allow public read-write for grades" ON public.grades FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Allow public read-write for academic_tasks" ON public.academic_tasks FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Allow public read-write for audit_logs" ON public.audit_logs FOR ALL USING (true) WITH CHECK (true);

-- 11. INITIAL MASTER ACCOUNT SEED
INSERT INTO public.user_profiles (id, tenant_id, email, full_name, phone, role, status)
VALUES ('usr-master', NULL, 'mdqputra@gmail.com', 'Platform Master (MDQ Putra)', '081234567890', 'MASTER', 'ACTIVE')
ON CONFLICT (id) DO UPDATE SET 
  email = 'mdqputra@gmail.com',
  full_name = 'Platform Master (MDQ Putra)',
  role = 'MASTER',
  status = 'ACTIVE';
