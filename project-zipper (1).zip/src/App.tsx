import React, { useState, useEffect } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { TenantProvider, useTenant } from './context/TenantContext';
import { DeviceFrame } from './components/common/DeviceFrame';
import { TenantPersonaBar } from './components/common/TenantPersonaBar';
import { ArchitectureModal } from './components/common/ArchitectureModal';
import { SupabaseSyncModal } from './components/common/SupabaseSyncModal';
import { supabaseSyncService } from './services/supabaseSyncService';
import { DashboardLayout } from './components/layout/DashboardLayout';
import { useResponsive } from './hooks/useResponsive';

// Views
import { LoginView } from './views/LoginView';
import { MasterDashboardView } from './views/MasterDashboardView';
import { KepalaSekolahView } from './views/KepalaSekolahView';
import { GuruDashboardView } from './views/GuruDashboardView';
import { SiswaDashboardView } from './views/SiswaDashboardView';
import { OrangTuaDashboardView } from './views/OrangTuaDashboardView';
import { TenagaKependidikanView } from './views/TenagaKependidikanView';
import { AuditLogView } from './views/AuditLogView';
import { SmkManagementModule } from './components/smk/SmkManagementModule';
import { SmaManagementModule } from './components/sma/SmaManagementModule';
import { WakaDashboardView } from './components/dashboard/WakaDashboardView';
import { BkDashboardView } from './components/dashboard/BkDashboardView';

const AppContent: React.FC = () => {
  const { currentRoute, isAuthenticated, currentUser } = useAuth();
  const [architectureModalOpen, setArchitectureModalOpen] = useState(false);
  const [supabaseModalOpen, setSupabaseModalOpen] = useState(false);
  const { viewportMode, setViewportMode } = useResponsive();

  useEffect(() => {
    // Attempt automatic sync with cloud database on load
    supabaseSyncService.initializeDatabase();
  }, []);

  // Route Dispatcher
  const renderCurrentView = () => {
    if (!isAuthenticated || currentRoute === '/login') {
      return <LoginView />;
    }

    // Role Master Views
    if (
      currentRoute === '/master' ||
      currentRoute === '/master/tenants' ||
      currentRoute === '/master/quotas'
    ) {
      return (
        <DashboardLayout>
          <MasterDashboardView />
        </DashboardLayout>
      );
    }

    // Kepala Sekolah Views
    if (
      currentRoute === '/kepsek' ||
      currentRoute === '/kepsek/teachers' ||
      currentRoute === '/classes' ||
      currentRoute === '/reports'
    ) {
      return (
        <DashboardLayout>
          <KepalaSekolahView />
        </DashboardLayout>
      );
    }

    // Guru & Assignments Views
    if (
      currentRoute === '/guru' ||
      currentRoute === '/guru/teaching' ||
      currentRoute === '/guru/attendance' ||
      currentRoute === '/guru/grading' ||
      currentRoute === '/guru/wali-kelas' ||
      currentRoute === '/guru/kurikulum' ||
      currentRoute === '/guru/kaprog'
    ) {
      return (
        <DashboardLayout>
          <GuruDashboardView />
        </DashboardLayout>
      );
    }

    // Specialized School & Assignment Views
    if (currentRoute === '/smk') {
      return (
        <DashboardLayout>
          <SmkManagementModule />
        </DashboardLayout>
      );
    }

    if (currentRoute === '/sma') {
      return (
        <DashboardLayout>
          <SmaManagementModule />
        </DashboardLayout>
      );
    }

    if (currentRoute === '/waka') {
      return (
        <DashboardLayout>
          <WakaDashboardView />
        </DashboardLayout>
      );
    }

    if (currentRoute === '/bk') {
      return (
        <DashboardLayout>
          <BkDashboardView />
        </DashboardLayout>
      );
    }

    // Siswa Views
    if (
      currentRoute === '/siswa' ||
      currentRoute === '/siswa/schedule' ||
      currentRoute === '/siswa/grades' ||
      currentRoute === '/siswa/attendance' ||
      currentRoute === '/siswa/pkl'
    ) {
      return (
        <DashboardLayout>
          <SiswaDashboardView />
        </DashboardLayout>
      );
    }

    // Orang Tua Views
    if (
      currentRoute === '/parent' ||
      currentRoute === '/parent/attendance' ||
      currentRoute === '/parent/grades' ||
      currentRoute === '/parent/contact'
    ) {
      return (
        <DashboardLayout>
          <OrangTuaDashboardView />
        </DashboardLayout>
      );
    }

    // Tenaga Kependidikan / TU Views
    if (
      currentRoute === '/tu' ||
      currentRoute === '/tu/sarpras' ||
      currentRoute === '/tu/letters'
    ) {
      return (
        <DashboardLayout>
          <TenagaKependidikanView />
        </DashboardLayout>
      );
    }

    // Global Audit Logs View
    if (currentRoute === '/audit') {
      return (
        <DashboardLayout>
          <AuditLogView />
        </DashboardLayout>
      );
    }

    // Fallback based on user role
    return (
      <DashboardLayout>
        {currentUser?.role === 'MASTER' && <MasterDashboardView />}
        {currentUser?.role === 'KEPALA_SEKOLAH' && <KepalaSekolahView />}
        {currentUser?.role === 'GURU' && <GuruDashboardView />}
        {currentUser?.role === 'SISWA' && <SiswaDashboardView />}
        {currentUser?.role === 'ORANG_TUA' && <OrangTuaDashboardView />}
        {currentUser?.role === 'TENAGA_KEPENDIDIKAN' && <TenagaKependidikanView />}
      </DashboardLayout>
    );
  };

  return (
    <DeviceFrame mode={viewportMode} onModeChange={setViewportMode}>
      <TenantPersonaBar
        onOpenArchitecture={() => setArchitectureModalOpen(true)}
        onOpenSupabaseSync={() => setSupabaseModalOpen(true)}
      />
      {renderCurrentView()}
      <ArchitectureModal
        isOpen={architectureModalOpen}
        onClose={() => setArchitectureModalOpen(false)}
      />
      <SupabaseSyncModal
        isOpen={supabaseModalOpen}
        onClose={() => setSupabaseModalOpen(false)}
      />
    </DeviceFrame>
  );
};

export function App() {
  return (
    <AuthProvider>
      <TenantConsumerWrapper />
    </AuthProvider>
  );
}

// Inner wrapper to supply current user to TenantProvider
const TenantConsumerWrapper: React.FC = () => {
  const { currentUser } = useAuth();
  return (
    <TenantProvider currentUser={currentUser}>
      <AppContent />
    </TenantProvider>
  );
};

export default App;
