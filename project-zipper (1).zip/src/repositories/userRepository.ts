import { UserProfile } from '../types';
import { INITIAL_USERS } from '../data/mockDatabase';
import { getSupabase } from '../config/supabase';
import { canActivateParentAccount } from '../lib/permissions';

class UserRepository {
  private users: UserProfile[] = [...INITIAL_USERS];

  async getAll(): Promise<UserProfile[]> {
    const supabase = getSupabase();
    if (supabase) {
      try {
        const { data, error } = await supabase.from('user_profiles').select('*');
        if (!error && data && data.length > 0) {
          this.users = data as UserProfile[];
        }
      } catch (err) {
        console.warn('Supabase fetch users fallback:', err);
      }
    }
    return [...this.users];
  }

  async getById(userId: string): Promise<UserProfile | null> {
    const supabase = getSupabase();
    if (supabase) {
      try {
        const { data, error } = await supabase
          .from('user_profiles')
          .select('*')
          .eq('id', userId)
          .single();
        if (!error && data) return data as UserProfile;
      } catch (err) {
        console.warn('Supabase fetch user by id fallback:', err);
      }
    }
    return this.users.find((u) => u.id === userId) || null;
  }

  async getByEmail(email: string): Promise<UserProfile | null> {
    const cleanEmail = email.toLowerCase().trim();
    const supabase = getSupabase();
    if (supabase) {
      try {
        const { data, error } = await supabase
          .from('user_profiles')
          .select('*')
          .eq('email', cleanEmail)
          .single();
        if (!error && data) return data as UserProfile;
      } catch (err) {
        console.warn('Supabase fetch user by email fallback:', err);
      }
    }
    return this.users.find((u) => u.email.toLowerCase() === cleanEmail) || null;
  }

  async addUser(user: UserProfile): Promise<UserProfile> {
    const existingIdx = this.users.findIndex((u) => u.id === user.id || u.email.toLowerCase() === user.email.toLowerCase());
    if (existingIdx >= 0) {
      this.users[existingIdx] = user;
    } else {
      this.users.push(user);
    }
    const supabase = getSupabase();
    if (supabase) {
      try {
        await supabase.from('user_profiles').upsert(user, { onConflict: 'id' });
      } catch (err) {
        console.warn('Supabase upsert user fallback:', err);
      }
    }
    return user;
  }

  async create(user: UserProfile): Promise<UserProfile> {
    return this.addUser(user);
  }

  async update(userId: string, data: Partial<UserProfile>): Promise<UserProfile | null> {
    const user = this.users.find((u) => u.id === userId);
    if (user) {
      Object.assign(user, data, { updated_at: new Date().toISOString() });
      const supabase = getSupabase();
      if (supabase) {
        try {
          await supabase.from('user_profiles').update(data).eq('id', userId);
        } catch (err) {
          console.warn('Supabase update user fallback:', err);
        }
      }
      return user;
    }
    return null;
  }

  async updateUserStatus(userId: string, status: UserProfile['status']): Promise<UserProfile | null> {
    const user = this.users.find((u) => u.id === userId);
    if (user) {
      user.status = status;
      user.updated_at = new Date().toISOString();
      const supabase = getSupabase();
      if (supabase) {
        try {
          await supabase.from('user_profiles').update({ status, updated_at: user.updated_at }).eq('id', userId);
        } catch (err) {
          console.warn('Supabase update user status fallback:', err);
        }
      }
    }
    return user || null;
  }

  /**
   * Business Rule: Student self-registration allowed.
   */
  async registerStudent(params: {
    tenant_id: string;
    full_name: string;
    email: string;
    nisn: string;
    nis: string;
    generation_year: number;
    school_type: 'SMA' | 'SMK';
    peminatan_or_program: string;
  }): Promise<UserProfile> {
    const newUserId = `usr-std-${Date.now()}`;
    const newUserProfile: UserProfile = {
      id: newUserId,
      tenant_id: params.tenant_id,
      email: params.email,
      full_name: params.full_name,
      role: 'SISWA',
      status: 'ACTIVE',
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    };

    const supabase = getSupabase();
    if (supabase) {
      try {
        await supabase.from('user_profiles').upsert(newUserProfile, { onConflict: 'id' });
        await supabase.from('students').upsert([
          {
            id: `std-${newUserId}`,
            tenant_id: params.tenant_id,
            nisn: params.nisn,
            nis: params.nis,
            full_name: params.full_name,
            grade_level: 10,
            school_type: params.school_type,
            major_or_stream: params.peminatan_or_program,
            status: 'ACTIVE',
          },
        ], { onConflict: 'id' });
      } catch (err) {
        console.warn('Supabase student registration fallback:', err);
      }
    }

    this.users.push(newUserProfile);
    return newUserProfile;
  }

  /**
   * Business Rule: Parent accounts CANNOT self-register.
   * Created / Activated by Wali Kelas or Kepala Sekolah.
   * 1 parent can be linked to multiple students.
   */
  async createParentAccount(
    params: {
      tenant_id: string;
      full_name: string;
      email: string;
      phone: string;
      relation_type: 'AYAH' | 'IBU' | 'WALI';
      student_ids: string[];
    },
    actorUser: UserProfile
  ): Promise<UserProfile> {
    if (!canActivateParentAccount(actorUser)) {
      throw new Error('Akses Ditolak: Hanya Wali Kelas atau Kepala Sekolah yang dapat membuat/mengaktifkan akun Orang Tua.');
    }

    const newUserId = `usr-parent-${Date.now()}`;
    const newParent: UserProfile = {
      id: newUserId,
      tenant_id: params.tenant_id,
      email: params.email,
      full_name: params.full_name,
      phone: params.phone,
      role: 'ORANG_TUA',
      status: 'ACTIVE',
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
      linked_students: params.student_ids.map((sid, idx) => ({
        id: sid,
        nisn: `007${idx}${Date.now().toString().slice(-4)}`,
        full_name: `Anak ke-${idx + 1} (${params.full_name})`,
        class_name: 'X MIPA 1',
        tenant_name: 'Sekolah Terdaftar',
        school_type: 'SMA',
      })),
    };

    const supabase = getSupabase();
    if (supabase) {
      try {
        await supabase.from('user_profiles').upsert(newParent, { onConflict: 'id' });
      } catch (err) {
        console.warn('Supabase parent creation fallback:', err);
      }
    }

    this.users.push(newParent);
    return newParent;
  }

  /**
   * Prompt 5: MASTER dapat membuat akun Kepala Sekolah & menghubungkannya dengan tenant.
   * Hanya MASTER yang berwenang membuat akun Kepala Sekolah.
   * Kepala Sekolah tidak boleh self-register.
   */
  async createPrincipalAccount(
    params: {
      tenant_id: string;
      full_name: string;
      email: string;
      phone?: string;
      nip?: string;
    },
    actor: UserProfile
  ): Promise<UserProfile> {
    if (actor.role !== 'MASTER') {
      throw new Error('Akses Ditolak: Hanya MASTER yang dapat membuat akun Kepala Sekolah.');
    }

    // Check duplicate email
    const existingEmail = this.users.find((u) => u.email.toLowerCase() === params.email.toLowerCase());
    if (existingEmail) {
      throw new Error(`Email ${params.email} sudah terdaftar di platform.`);
    }

    const newUserId = `usr-kepsek-${Date.now()}`;
    const newPrincipal: UserProfile = {
      id: newUserId,
      tenant_id: params.tenant_id,
      email: params.email,
      full_name: params.full_name,
      phone: params.phone,
      role: 'KEPALA_SEKOLAH',
      status: 'ACTIVE',
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    };

    const supabase = getSupabase();
    if (supabase) {
      try {
        await supabase.from('user_profiles').upsert(newPrincipal, { onConflict: 'id' });
      } catch (err) {
        console.warn('Supabase principal insert fallback:', err);
      }
    }

    this.users.push(newPrincipal);

    // Audit log event
    const { auditService } = await import('../services/auditService');
    await auditService.recordEvent({
      event: 'KEPALA_SEKOLAH_CREATED',
      email: actor.email,
      user_id: actor.id,
      role: actor.role,
      tenant_id: params.tenant_id,
      principal_name: newPrincipal.full_name,
      status: 'SUCCESS',
      details: `Akun Kepala Sekolah "${newPrincipal.full_name}" (${newPrincipal.email}) berhasil dibuat dan dihubungkan ke tenant "${params.tenant_id}".`,
    });

    return newPrincipal;
  }

  async getPrincipals(): Promise<UserProfile[]> {
    return this.users.filter((u) => u.role === 'KEPALA_SEKOLAH');
  }

  async getPrincipalByTenant(tenantId: string): Promise<UserProfile | null> {
    return this.users.find((u) => u.role === 'KEPALA_SEKOLAH' && u.tenant_id === tenantId) || null;
  }

  async getUsersByTenant(tenantId: string, actor: UserProfile): Promise<UserProfile[]> {
    if (actor.role !== 'MASTER' && actor.tenant_id !== tenantId) {
      throw new Error('Akses Ditolak: Pelanggaran isolasi data tenant.');
    }
    return this.users.filter((u) => u.tenant_id === tenantId);
  }
}

export const userRepository = new UserRepository();
