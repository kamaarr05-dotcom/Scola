import { Tenant, UserProfile } from '../types';
import { INITIAL_TENANTS } from '../data/mockDatabase';
import { getSupabase } from '../config/supabase';
import { auditService } from '../services/auditService';

class TenantRepository {
  private tenants: Tenant[] = [...INITIAL_TENANTS];

  async getAll(): Promise<Tenant[]> {
    const supabase = getSupabase();
    if (supabase) {
      const { data, error } = await supabase.from('tenants').select('*');
      if (!error && data) return data as Tenant[];
    }
    return [...this.tenants];
  }

  async getById(id: string): Promise<Tenant | null> {
    const supabase = getSupabase();
    if (supabase) {
      const { data, error } = await supabase
        .from('tenants')
        .select('*')
        .eq('id', id)
        .single();
      if (!error && data) return data as Tenant;
    }
    return this.tenants.find((t) => t.id === id) || null;
  }

  /**
   * Prompt 5: MASTER dapat membuat tenant baru & data sekolah.
   * Hanya MASTER yang berwenang membuat tenant.
   */
  async createTenant(
    data: {
      name: string;
      npsn: string;
      type: 'SMA' | 'SMK';
      accreditation?: 'A' | 'B' | 'C' | 'BELUM_TERAKREDITASI';
      address: string;
      city: string;
      province: string;
      phone: string;
      email: string;
      logo_url?: string;
      brand_color?: string;
      teacher_quota?: number;
      is_active?: boolean;
      subscription_tier?: 'TRIAL' | 'STANDARD' | 'ENTERPRISE';
    },
    actor: UserProfile
  ): Promise<Tenant> {
    if (actor.role !== 'MASTER') {
      await auditService.recordEvent({
        event: 'PERMISSION_DENIED',
        email: actor.email,
        user_id: actor.id,
        role: actor.role,
        tenant_id: actor.tenant_id,
        status: 'FAILED',
        details: 'Percobaan membuat tenant ditolak: Hanya MASTER yang berwenang.',
      });
      throw new Error('Akses Ditolak: Hanya MASTER yang dapat membuat tenant sekolah baru.');
    }

    // Check duplicate NPSN
    const existingNpsn = this.tenants.find((t) => t.npsn === data.npsn);
    if (existingNpsn) {
      throw new Error(`NPSN ${data.npsn} sudah terdaftar untuk sekolah "${existingNpsn.name}".`);
    }

    const tenantId = `tenant-${data.type.toLowerCase()}-${Date.now().toString().slice(-6)}`;
    const isActive = data.is_active ?? true;
    const quota = data.teacher_quota !== undefined ? data.teacher_quota : 20;

    const newTenant: Tenant = {
      id: tenantId,
      npsn: data.npsn,
      name: data.name,
      slug: data.name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, ''),
      type: data.type,
      accreditation: data.accreditation || 'A',
      province: data.province,
      city: data.city,
      address: data.address,
      phone: data.phone,
      email: data.email,
      logo_url: data.logo_url || 'https://images.unsplash.com/photo-1546410531-bb4caa6b424d?w=128&auto=format&fit=crop&q=80',
      brand_color: data.brand_color || (data.type === 'SMA' ? '#1e40af' : '#047857'),
      teacher_quota: quota,
      active_teacher_count: 0,
      is_active: isActive,
      status: isActive ? 'ACTIVE' : 'INACTIVE',
      subscription_tier: data.subscription_tier || 'STANDARD',
      valid_until: new Date(Date.now() + 365 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    };

    const supabase = getSupabase();
    if (supabase) {
      try {
        await supabase.from('tenants').insert([newTenant]);
      } catch (err) {
        console.warn('Supabase tenant insert fallback to local:', err);
      }
    }

    this.tenants.push(newTenant);

    await auditService.recordEvent({
      event: 'TENANT_CREATED',
      email: actor.email,
      user_id: actor.id,
      role: actor.role,
      tenant_id: newTenant.id,
      tenant_name: newTenant.name,
      status: 'SUCCESS',
      quota_after: newTenant.teacher_quota,
      details: `Tenant baru ${newTenant.name} (${newTenant.type}, NPSN: ${newTenant.npsn}) berhasil dibuat oleh Master dengan kuota awal ${newTenant.teacher_quota} guru.`,
    });

    return newTenant;
  }

  /**
   * Prompt 5: Mengubah profil sekolah & school branding.
   * Dilakukan oleh MASTER atau KEPALA SEKOLAH pada tenant miliknya sendiri.
   * Kepala Sekolah TIDAK BISA mengubah kuota atau status aktif tenant.
   */
  async updateSchoolProfile(
    tenantId: string,
    data: {
      name?: string;
      address?: string;
      city?: string;
      province?: string;
      phone?: string;
      email?: string;
      logo_url?: string;
      brand_color?: string;
      accreditation?: 'A' | 'B' | 'C' | 'BELUM_TERAKREDITASI';
      teacher_quota?: number;
      is_active?: boolean;
    },
    actor: UserProfile
  ): Promise<Tenant> {
    const isMaster = actor.role === 'MASTER';
    const isOwnPrincipal = actor.role === 'KEPALA_SEKOLAH' && actor.tenant_id === tenantId;

    if (!isMaster && !isOwnPrincipal) {
      await auditService.recordEvent({
        event: 'PERMISSION_DENIED',
        email: actor.email,
        user_id: actor.id,
        role: actor.role,
        tenant_id: tenantId,
        status: 'FAILED',
        details: 'Percobaan modifikasi profil sekolah ditolak: Bukan Kepala Sekolah dari tenant ini atau Master.',
      });
      throw new Error('Akses Ditolak: Anda hanya berwenang mengelola profil sekolah Anda sendiri.');
    }

    // Strict Rule: Non-master cannot change teacher quota or activation status
    if (!isMaster) {
      if (data.teacher_quota !== undefined) {
        throw new Error('Akses Ditolak: Hanya MASTER yang dapat mengubah quota Guru.');
      }
      if (data.is_active !== undefined) {
        throw new Error('Akses Ditolak: Hanya MASTER yang dapat mengaktifkan/menonaktifkan tenant sekolah.');
      }
    }

    const index = this.tenants.findIndex((t) => t.id === tenantId);
    if (index === -1) throw new Error('Tenant sekolah tidak ditemukan.');

    const oldTenant = this.tenants[index];
    const updatedTenant: Tenant = {
      ...oldTenant,
      name: data.name ?? oldTenant.name,
      address: data.address ?? oldTenant.address,
      city: data.city ?? oldTenant.city,
      province: data.province ?? oldTenant.province,
      phone: data.phone ?? oldTenant.phone,
      email: data.email ?? oldTenant.email,
      logo_url: data.logo_url ?? oldTenant.logo_url,
      brand_color: data.brand_color ?? oldTenant.brand_color,
      accreditation: data.accreditation ?? oldTenant.accreditation,
      teacher_quota: isMaster && data.teacher_quota !== undefined ? data.teacher_quota : oldTenant.teacher_quota,
      is_active: isMaster && data.is_active !== undefined ? data.is_active : oldTenant.is_active,
      status: (isMaster && data.is_active !== undefined)
        ? (data.is_active ? 'ACTIVE' : 'INACTIVE')
        : oldTenant.status,
      updated_at: new Date().toISOString(),
    };

    this.tenants[index] = updatedTenant;

    const supabase = getSupabase();
    if (supabase) {
      try {
        await supabase.from('tenants').update(updatedTenant).eq('id', tenantId);
      } catch (err) {
        console.warn('Supabase update tenant fallback:', err);
      }
    }

    await auditService.recordEvent({
      event: 'SCHOOL_PROFILE_UPDATED',
      email: actor.email,
      user_id: actor.id,
      role: actor.role,
      tenant_id: tenantId,
      tenant_name: updatedTenant.name,
      status: 'SUCCESS',
      details: `Profil & branding sekolah "${updatedTenant.name}" diperbarui oleh ${actor.full_name} (${actor.role}).`,
    });

    return updatedTenant;
  }

  /**
   * Prompt 5: MASTER dapat mengaktifkan/menonaktifkan tenant.
   * Tenant INACTIVE memblokir login pengguna sekolah tetapi mempertahankan historical data.
   */
  async toggleTenantStatus(
    tenantId: string,
    isActive: boolean,
    actor: UserProfile,
    reason?: string
  ): Promise<Tenant> {
    if (actor.role !== 'MASTER') {
      await auditService.recordEvent({
        event: 'PERMISSION_DENIED',
        email: actor.email,
        user_id: actor.id,
        role: actor.role,
        tenant_id: tenantId,
        status: 'FAILED',
        details: 'Percobaan aktivasi/penonaktifan tenant ditolak: Hanya MASTER yang berwenang.',
      });
      throw new Error('Akses Ditolak: Hanya MASTER yang dapat mengaktifkan atau menonaktifkan tenant sekolah.');
    }

    const index = this.tenants.findIndex((t) => t.id === tenantId);
    if (index === -1) throw new Error('Tenant sekolah tidak ditemukan.');

    const targetTenant = this.tenants[index];
    targetTenant.is_active = isActive;
    targetTenant.status = isActive ? 'ACTIVE' : 'INACTIVE';
    targetTenant.updated_at = new Date().toISOString();

    const supabase = getSupabase();
    if (supabase) {
      try {
        await supabase
          .from('tenants')
          .update({ is_active: isActive, updated_at: targetTenant.updated_at })
          .eq('id', tenantId);
      } catch (err) {
        console.warn('Supabase toggle tenant status fallback:', err);
      }
    }

    const event = isActive ? 'TENANT_ACTIVATED' : 'TENANT_DEACTIVATED';
    await auditService.recordEvent({
      event,
      email: actor.email,
      user_id: actor.id,
      role: actor.role,
      tenant_id: tenantId,
      tenant_name: targetTenant.name,
      status: 'SUCCESS',
      reason: reason || (isActive ? 'Reaktivasi layanan' : 'Penangguhan operasional'),
      details: `Tenant "${targetTenant.name}" ${
        isActive ? 'diaktifkan kembali' : 'dinonaktifkan'
      } oleh Master. Alasan: ${reason || '-'}. Integritas historical data tetap dipertahankan.`,
    });

    return { ...targetTenant };
  }

  async updateQuota(
    tenantId: string,
    newQuota: number,
    actor?: UserProfile,
    reason?: string
  ): Promise<Tenant> {
    if (actor && actor.role !== 'MASTER') {
      throw new Error('Akses Ditolak: Hanya MASTER yang dapat mengubah quota Guru.');
    }
    const supabase = getSupabase();
    if (supabase) {
      const { data, error } = await supabase
        .from('tenants')
        .update({ teacher_quota: newQuota, updated_at: new Date().toISOString() })
        .eq('id', tenantId)
        .select()
        .single();
      if (!error && data) return data as Tenant;
    }

    const index = this.tenants.findIndex((t) => t.id === tenantId);
    if (index === -1) throw new Error('Tenant tidak ditemukan');
    
    const quotaBefore = this.tenants[index].teacher_quota;
    this.tenants[index] = {
      ...this.tenants[index],
      teacher_quota: newQuota,
      updated_at: new Date().toISOString(),
    };

    if (actor) {
      await auditService.recordEvent({
        event: 'QUOTA_CHANGED',
        email: actor.email,
        user_id: actor.id,
        role: actor.role,
        tenant_id: tenantId,
        tenant_name: this.tenants[index].name,
        status: 'SUCCESS',
        quota_before: quotaBefore,
        quota_after: newQuota,
        reason: reason || 'Penyesuaian kuota lisensi guru',
        details: `Kuota guru tenant ${this.tenants[index].name} diubah dari ${quotaBefore} menjadi ${newQuota}`,
      });
    }

    return this.tenants[index];
  }

  async updateActiveTeacherCount(tenantId: string, delta: number): Promise<void> {
    const index = this.tenants.findIndex((t) => t.id === tenantId);
    if (index !== -1) {
      this.tenants[index].active_teacher_count = Math.max(
        0,
        this.tenants[index].active_teacher_count + delta
      );
    }
  }
}

export const tenantRepository = new TenantRepository();
