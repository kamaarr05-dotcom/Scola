import {
  SchoolClass,
  DailyAttendance,
  AttendanceStatus,
  GradeItem,
  Subject,
  ReportCard,
  StudentReportCard,
  ClassSchedule,
  AcademicTask,
  TaskSubmission,
  StudentGuardian,
  SMKProgramKeahlian,
  SMKPklRecord,
  SMKUKKRecord,
  UserProfile,
  StudentProfile,
  StudentStatus,
  AcademicYear,
  TeacherAssignmentType,
  TeacherAssignment,
  SMKIndustryPartner,
  SMKPklJournal,
  SMKPklAttendance,
  SMKPklAssessment,
  SMKBkkJob,
  SMKTracerStudy,
  BKCounselingRecord,
  StudentDisciplineRecord,
  SchoolFacility,
  SchoolLetter,
} from '../types';
import {
  INITIAL_CLASSES,
  INITIAL_ATTENDANCE,
  INITIAL_GRADES,
  INITIAL_SMK_PROGRAMS,
  INITIAL_SMK_PKL,
  INITIAL_SMK_UKK,
  INITIAL_STUDENTS,
  INITIAL_SUBJECTS,
  INITIAL_STUDENT_GUARDIANS,
  INITIAL_CLASS_SCHEDULES,
  INITIAL_ACADEMIC_TASKS,
  INITIAL_TASK_SUBMISSIONS,
  INITIAL_REPORT_CARDS,
  INITIAL_SMK_PARTNERS,
  INITIAL_SMK_PKL_JOURNALS,
  INITIAL_SMK_PKL_ATTENDANCE,
  INITIAL_SMK_PKL_ASSESSMENTS,
  INITIAL_SMK_BKK_JOBS,
  INITIAL_SMK_TRACER,
  INITIAL_BK_RECORDS,
  INITIAL_DISCIPLINE_RECORDS,
  INITIAL_FACILITIES,
  INITIAL_LETTERS,
} from '../data/mockDatabase';
import { auditService } from '../services/auditService';
import { checkPermission } from '../lib/permissions';
import { getSupabase } from '../config/supabase';
import { tenantRepository } from './tenantRepository';
import { userRepository } from './userRepository';

class AcademicRepository {
  private classes: SchoolClass[] = [...INITIAL_CLASSES];
  private students: StudentProfile[] = [...INITIAL_STUDENTS];
  private attendance: DailyAttendance[] = [...INITIAL_ATTENDANCE];
  private grades: GradeItem[] = [...INITIAL_GRADES];
  private smkPrograms: SMKProgramKeahlian[] = [...INITIAL_SMK_PROGRAMS];
  private smkPkl: SMKPklRecord[] = [...INITIAL_SMK_PKL];
  private smkUkk: SMKUKKRecord[] = [...INITIAL_SMK_UKK];
  private subjects: Subject[] = [...INITIAL_SUBJECTS];
  private studentGuardians: StudentGuardian[] = [...INITIAL_STUDENT_GUARDIANS];
  private schedules: ClassSchedule[] = [...INITIAL_CLASS_SCHEDULES];
  private tasks: AcademicTask[] = [...INITIAL_ACADEMIC_TASKS];
  private submissions: TaskSubmission[] = [...INITIAL_TASK_SUBMISSIONS];
  private reportCards: ReportCard[] = [...INITIAL_REPORT_CARDS];
  private smkPartners: SMKIndustryPartner[] = [...INITIAL_SMK_PARTNERS];
  private smkPklJournals: SMKPklJournal[] = [...INITIAL_SMK_PKL_JOURNALS];
  private smkPklAttendance: SMKPklAttendance[] = [...INITIAL_SMK_PKL_ATTENDANCE];
  private smkPklAssessments: SMKPklAssessment[] = [...INITIAL_SMK_PKL_ASSESSMENTS];
  private smkBkkJobs: SMKBkkJob[] = [...INITIAL_SMK_BKK_JOBS];
  private smkTracer: SMKTracerStudy[] = [...INITIAL_SMK_TRACER];
  private bkRecords: BKCounselingRecord[] = [...INITIAL_BK_RECORDS];
  private disciplineRecords: StudentDisciplineRecord[] = [...INITIAL_DISCIPLINE_RECORDS];
  private facilities: SchoolFacility[] = [...INITIAL_FACILITIES];
  private letters: SchoolLetter[] = [...INITIAL_LETTERS];
  private teacherAssignments: TeacherAssignment[] = [
    {
      id: 'asg-001',
      tenant_id: 'tenant-sma-01',
      teacher_id: 'usr-guru-budi',
      teacher_user_id: 'usr-guru-budi',
      type: 'WALI_KELAS',
      class_id: 'cls-sma-10-1',
      academic_year_id: 'ay-2024-ganjil',
      active: true,
      notes: 'SK Pembagian Tugas Guru No. 421/01/2024',
      assigned_at: '2024-07-15T08:00:00Z',
    },
    {
      id: 'asg-002',
      tenant_id: 'tenant-sma-01',
      teacher_id: 'usr-guru-budi',
      teacher_user_id: 'usr-guru-budi',
      type: 'WAKA_KURIKULUM',
      academic_year_id: 'ay-2024-ganjil',
      active: true,
      notes: 'SK Tim Pengembang Kurikulum Operasional Satuan Pendidikan',
      assigned_at: '2024-07-15T08:00:00Z',
    },
    {
      id: 'asg-003',
      tenant_id: 'tenant-smk-02',
      teacher_id: 'usr-guru-hendra',
      teacher_user_id: 'usr-guru-hendra',
      type: 'KAPROG',
      program_id: 'prog-rpl',
      academic_year_id: 'ay-2024-ganjil',
      active: true,
      notes: 'Kepala Program Keahlian PPLG',
      assigned_at: '2024-07-15T08:00:00Z',
    },
  ];
  private academicYears: AcademicYear[] = [
    {
      id: 'ay-2024-ganjil',
      tenant_id: 'tenant-sma-01',
      name: '2024/2025',
      semester: 'GANJIL',
      is_active: true,
      start_date: '2024-07-15',
      end_date: '2024-12-20',
    },
    {
      id: 'ay-2024-genap',
      tenant_id: 'tenant-sma-01',
      name: '2024/2025',
      semester: 'GENAP',
      is_active: false,
      start_date: '2025-01-06',
      end_date: '2025-06-20',
    },
    {
      id: 'ay-smk-2024-ganjil',
      tenant_id: 'tenant-smk-02',
      name: '2024/2025',
      semester: 'GANJIL',
      is_active: true,
      start_date: '2024-07-15',
      end_date: '2024-12-20',
    },
  ];

  // =================== CLASSES ===================
  async getClassesByTenant(tenantId: string, currentUser: UserProfile | null): Promise<SchoolClass[]> {
    if (!currentUser) return [];
    if (currentUser.role !== 'MASTER' && currentUser.tenant_id !== tenantId) return [];
    const supabase = getSupabase();
    if (supabase) {
      try {
        const { data, error } = await supabase.from('classes').select('*').eq('tenant_id', tenantId);
        if (!error && data && data.length > 0) {
          return data as SchoolClass[];
        }
      } catch (err) {
        console.warn('Supabase fetch classes fallback:', err);
      }
    }
    return this.classes.filter((c) => c.tenant_id === tenantId);
  }

  async getClasses(tenantId: string, currentUser: UserProfile | null): Promise<SchoolClass[]> {
    return this.getClassesByTenant(tenantId, currentUser);
  }

  async createClass(
    data: {
      tenant_id: string;
      name: string;
      grade_level: 10 | 11 | 12;
      school_type: 'SMA' | 'SMK';
      major_or_stream: string;
      academic_year_id: string;
      wali_kelas_teacher_id?: string;
      wali_kelas_name?: string;
      capacity?: number;
    },
    actor: UserProfile
  ): Promise<SchoolClass> {
    if (actor.role !== 'MASTER' && (actor.role !== 'KEPALA_SEKOLAH' || actor.tenant_id !== data.tenant_id)) {
      throw new Error('Akses Ditolak: Anda tidak memiliki izin membuat kelas di sekolah ini.');
    }
    const newClass: SchoolClass = {
      id: `cls-${Date.now().toString().slice(-6)}`,
      tenant_id: data.tenant_id,
      name: data.name,
      grade_level: data.grade_level,
      school_type: data.school_type,
      major_or_stream: data.major_or_stream,
      academic_year_id: data.academic_year_id || 'ay-2024-ganjil',
      wali_kelas_teacher_id: data.wali_kelas_teacher_id,
      wali_kelas_name: data.wali_kelas_name,
      capacity: data.capacity || 36,
      total_students: 0,
    };
    this.classes.push(newClass);

    const supabase = getSupabase();
    if (supabase) {
      try {
        await supabase.from('classes').upsert(newClass, { onConflict: 'id' });
      } catch (err) {
        console.warn('Supabase upsert class fallback:', err);
      }
    }

    await auditService.recordEvent({
      event: 'CLASS_CREATED',
      email: actor.email,
      user_id: actor.id,
      role: actor.role,
      tenant_id: data.tenant_id,
      status: 'SUCCESS',
      details: `Kelas baru "${newClass.name}" (Tingkat ${newClass.grade_level}) berhasil dibuat oleh ${actor.full_name}.`,
    });
    return newClass;
  }

  async updateClass(
    classId: string,
    data: Partial<SchoolClass>,
    actor: UserProfile
  ): Promise<SchoolClass> {
    const cls = this.classes.find((c) => c.id === classId);
    if (!cls) throw new Error('Kelas tidak ditemukan');
    if (actor.role !== 'MASTER' && (actor.role !== 'KEPALA_SEKOLAH' || actor.tenant_id !== cls.tenant_id)) {
      throw new Error('Akses Ditolak: Anda tidak memiliki izin mengubah kelas ini.');
    }
    Object.assign(cls, data);
    return cls;
  }

  // =================== STUDENTS ===================
  async getStudentsByTenant(
    tenantId: string,
    currentUser: UserProfile | null,
    filters?: { class_id?: string }
  ): Promise<StudentProfile[]> {
    if (!currentUser) return [];
    if (currentUser.role !== 'MASTER' && currentUser.tenant_id !== tenantId) return [];

    const supabase = getSupabase();
    if (supabase) {
      try {
        const { data, error } = await supabase.from('students').select('*').eq('tenant_id', tenantId);
        if (!error && data && data.length > 0) {
          // Merge or update local state
          data.forEach((st: any) => {
            const idx = this.students.findIndex((s) => s.id === st.id);
            if (idx >= 0) this.students[idx] = { ...this.students[idx], ...st };
            else this.students.push(st);
          });
        }
      } catch (err) {
        console.warn('Supabase fetch students fallback:', err);
      }
    }

    let result = this.students.filter((s) => s.tenant_id === tenantId);

    // Siswa RLS: Strictly restrict to own profile
    if (currentUser.role === 'SISWA') {
      result = result.filter(
        (s) =>
          s.user_id === currentUser.id ||
          s.id === currentUser.id ||
          (s.email && s.email.toLowerCase() === currentUser.email.toLowerCase())
      );
    } else if (currentUser.role === 'ORANG_TUA') {
      // Orang Tua RLS: Only linked children
      const linkedIds = currentUser.linked_students?.map((ls) => ls.id) || [];
      result = result.filter((s) => linkedIds.includes(s.id));
    }

    if (filters?.class_id) {
      result = result.filter((s) => s.class_id === filters.class_id);
    }

    return result;
  }

  async getStudentById(studentId: string, currentUser: UserProfile | null): Promise<StudentProfile | null> {
    if (!currentUser) return null;
    const student = this.students.find((s) => s.id === studentId || s.user_id === studentId);
    if (!student) return null;
    if (currentUser.role !== 'MASTER' && currentUser.tenant_id !== student.tenant_id) {
      return null;
    }
    if (currentUser.role === 'SISWA') {
      if (student.user_id !== currentUser.id && student.id !== currentUser.id && (!student.email || student.email.toLowerCase() !== currentUser.email.toLowerCase())) {
        throw new Error('Akses Ditolak: Anda tidak memiliki izin melihat data siswa lain.');
      }
    }
    return student;
  }

  async validateStudentRegistration(data: {
    tenant_id: string;
    nisn: string;
    nis: string;
    email?: string;
  }): Promise<{ valid: boolean; errors: string[] }> {
    const errors: string[] = [];
    const tenant = await tenantRepository.getById(data.tenant_id);
    if (!tenant) {
      errors.push('Sekolah tujuan tidak valid atau tidak terdaftar di platform SCOLA.');
    } else if (!tenant.is_active) {
      errors.push(`Sekolah "${tenant.name}" saat ini berstatus NONAKTIF dan tidak menerima pendaftaran.`);
    }

    const cleanNisn = (data.nisn || '').trim();
    if (!/^[0-9]{10}$/.test(cleanNisn)) {
      errors.push('NISN wajib berupa tepat 10 digit angka standar Dapodik.');
    } else {
      const existingNisn = this.students.find((s) => s.nisn.trim() === cleanNisn);
      if (existingNisn) {
        errors.push(`NISN "${cleanNisn}" sudah terdaftar di sistem SCOLA. Satu siswa tidak diperkenankan memiliki akun ganda.`);
      }
    }

    const cleanNis = (data.nis || '').trim();
    if (!cleanNis) {
      errors.push('NIS lokal sekolah wajib diisi.');
    } else {
      const existingNis = this.students.find(
        (s) => s.tenant_id === data.tenant_id && s.nis.trim() === cleanNis
      );
      if (existingNis) {
        errors.push(`NIS "${cleanNis}" sudah digunakan oleh siswa lain di sekolah ini.`);
      }
    }

    if (data.email) {
      const cleanEmail = data.email.toLowerCase().trim();
      const existingUser = await userRepository.getByEmail(cleanEmail);
      const existingStudentEmail = this.students.find(
        (s) => s.email && s.email.toLowerCase().trim() === cleanEmail
      );
      if (existingUser || existingStudentEmail) {
        errors.push(`Email "${cleanEmail}" sudah terdaftar sebagai akun pengguna lain.`);
      }
    }

    return {
      valid: errors.length === 0,
      errors,
    };
  }

  async selfRegisterStudent(payload: {
    tenant_id: string;
    full_name: string;
    nisn: string;
    nis: string;
    gender: 'L' | 'P';
    class_id: string;
    class_name?: string;
    address?: string;
    phone?: string;
    email: string;
    password?: string;
    parent_name: string;
    parent_relation: 'AYAH' | 'IBU' | 'WALI';
    parent_whatsapp: string;
    generation_year?: number;
    sma_peminatan?: string;
    smk_program_id?: string;
    smk_program_name?: string;
    kompetensi_keahlian?: string;
  }): Promise<{ student: StudentProfile; user: UserProfile; status: 'PENDING' }> {
    const val = await this.validateStudentRegistration({
      tenant_id: payload.tenant_id,
      nisn: payload.nisn,
      nis: payload.nis,
      email: payload.email,
    });
    if (!val.valid) {
      throw new Error(val.errors.join(' | '));
    }

    const tenant = await tenantRepository.getById(payload.tenant_id);
    if (!tenant) throw new Error('Tenant sekolah tidak ditemukan.');

    const targetClass = this.classes.find(
      (c) => c.id === payload.class_id && c.tenant_id === payload.tenant_id
    );
    if (!targetClass) {
      throw new Error('Kelas/Rombel yang dipilih tidak sesuai dengan sekolah tujuan.');
    }

    if (!payload.parent_name || payload.parent_name.trim().length < 2) {
      throw new Error('Nama Orang Tua / Wali wajib diisi.');
    }
    if (!['AYAH', 'IBU', 'WALI'].includes(payload.parent_relation)) {
      throw new Error('Hubungan dengan siswa wajib dipilih (AYAH, IBU, atau WALI).');
    }

    const cleanWA = (payload.parent_whatsapp || '').replace(/[^0-9+]/g, '');
    if (cleanWA.length < 9) {
      throw new Error('Nomor WhatsApp Orang Tua / Wali tidak valid.');
    }

    const userId = `usr-std-${Date.now()}`;
    const newUser: UserProfile = {
      id: userId,
      tenant_id: payload.tenant_id,
      email: payload.email.toLowerCase().trim(),
      full_name: payload.full_name.trim(),
      phone: payload.phone?.trim(),
      role: 'SISWA',
      status: 'PENDING_VERIFICATION',
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    };
    await userRepository.addUser(newUser);

    const studentId = `std-${Date.now()}`;
    const newStudent: StudentProfile = {
      id: studentId,
      tenant_id: payload.tenant_id,
      tenant_name: tenant.name,
      user_id: userId,
      nisn: payload.nisn.trim(),
      nis: payload.nis.trim(),
      full_name: payload.full_name.trim(),
      gender: payload.gender,
      class_id: payload.class_id,
      class_name: targetClass.name,
      generation_year: payload.generation_year || 2024,
      status: 'PENDING',
      self_registered: true,
      registration_date: new Date().toISOString().split('T')[0],
      sma_peminatan: payload.sma_peminatan,
      smk_program_id: payload.smk_program_id,
      smk_program_name: payload.smk_program_name,
      kompetensi_keahlian: payload.kompetensi_keahlian,
      address: payload.address?.trim(),
      phone: payload.phone?.trim(),
      email: payload.email.toLowerCase().trim(),
      parent_name: payload.parent_name.trim(),
      parent_relation: payload.parent_relation,
      parent_whatsapp: cleanWA,
    };
    this.students.push(newStudent);
    targetClass.total_students = (targetClass.total_students || 0) + 1;

    await auditService.recordEvent({
      event: 'STUDENT_SELF_REGISTER',
      email: payload.email,
      user_id: userId,
      role: 'SISWA',
      tenant_id: payload.tenant_id,
      tenant_name: tenant.name,
      status: 'SUCCESS',
      student_id: studentId,
      student_name: newStudent.full_name,
      nisn: newStudent.nisn,
      details: `Self-registration siswa baru "${newStudent.full_name}" (NISN: ${newStudent.nisn}, NIS: ${newStudent.nis}) di ${tenant.name}. Menunggu verifikasi sekolah. Data orang tua: ${newStudent.parent_name} (${newStudent.parent_relation}), WA: ${newStudent.parent_whatsapp}.`,
    });

    return {
      student: newStudent,
      user: newUser,
      status: 'PENDING',
    };
  }

  async updateStudentStatus(
    studentId: string,
    newStatus: StudentStatus,
    actor: UserProfile,
    reason?: string
  ): Promise<StudentProfile> {
    const student = this.students.find((s) => s.id === studentId);
    if (!student) throw new Error('Data siswa tidak ditemukan.');

    const hasPerm = checkPermission(actor, 'STUDENT_STATUS_MANAGE', {
      tenant_id: student.tenant_id,
      class_id: student.class_id,
    });
    if (!hasPerm) {
      throw new Error('Akses Ditolak: Anda tidak memiliki wewenang mengubah status siswa ini.');
    }

    const oldStatus = student.status;
    student.status = newStatus;

    if (newStatus === 'ACTIVE') {
      await userRepository.updateUserStatus(student.user_id, 'ACTIVE');
      await auditService.recordEvent({
        event: 'STUDENT_ACTIVATED',
        email: actor.email,
        user_id: actor.id,
        role: actor.role,
        tenant_id: student.tenant_id,
        student_id: student.id,
        student_name: student.full_name,
        nisn: student.nisn,
        old_value: oldStatus,
        new_value: newStatus,
        status: 'SUCCESS',
        details: `Akun siswa "${student.full_name}" (NISN: ${student.nisn}) berhasil diverifikasi dan diaktifkan oleh ${actor.full_name}.`,
      });
    } else if (newStatus === 'INACTIVE') {
      await userRepository.updateUserStatus(student.user_id, 'INACTIVE');
      await auditService.recordEvent({
        event: 'STUDENT_DEACTIVATED',
        email: actor.email,
        user_id: actor.id,
        role: actor.role,
        tenant_id: student.tenant_id,
        student_id: student.id,
        student_name: student.full_name,
        nisn: student.nisn,
        old_value: oldStatus,
        new_value: newStatus,
        status: 'SUCCESS',
        reason,
        details: `Siswa "${student.full_name}" dinonaktifkan oleh ${actor.full_name}. Alasan: ${reason || 'Penonaktifan administratif'}.`,
      });
    } else {
      if (newStatus === 'GRADUATED') {
        await userRepository.updateUserStatus(student.user_id, 'ACTIVE');
      }
      await auditService.recordEvent({
        event: 'STUDENT_STATUS_CHANGED',
        email: actor.email,
        user_id: actor.id,
        role: actor.role,
        tenant_id: student.tenant_id,
        student_id: student.id,
        student_name: student.full_name,
        nisn: student.nisn,
        old_value: oldStatus,
        new_value: newStatus,
        status: 'SUCCESS',
        reason,
        details: `Status siswa "${student.full_name}" diubah dari ${oldStatus} ke ${newStatus} oleh ${actor.full_name}.`,
      });
    }
    return student;
  }

  async updateStudentClass(
    studentId: string,
    newClassId: string,
    actor: UserProfile
  ): Promise<StudentProfile> {
    const student = this.students.find((s) => s.id === studentId);
    if (!student) throw new Error('Data siswa tidak ditemukan.');
    const hasPerm = checkPermission(actor, 'STUDENT_CLASS_ASSIGN', {
      tenant_id: student.tenant_id,
    });
    if (!hasPerm) {
      throw new Error('Akses Ditolak: Hanya Kepala Sekolah yang berwenang memindahkan kelas siswa.');
    }
    const targetClass = this.classes.find(
      (c) => c.id === newClassId && c.tenant_id === student.tenant_id
    );
    if (!targetClass) {
      throw new Error('Kelas tujuan tidak valid.');
    }
    const oldClass = student.class_name;
    const oldCls = this.classes.find((c) => c.id === student.class_id);
    if (oldCls && (oldCls.total_students || 0) > 0) {
      oldCls.total_students = (oldCls.total_students || 1) - 1;
    }
    student.class_id = newClassId;
    student.class_name = targetClass.name;
    targetClass.total_students = (targetClass.total_students || 0) + 1;

    await auditService.recordEvent({
      event: 'STUDENT_CLASS_CHANGED',
      email: actor.email,
      user_id: actor.id,
      role: actor.role,
      tenant_id: student.tenant_id,
      student_id: student.id,
      student_name: student.full_name,
      nisn: student.nisn,
      old_value: oldClass,
      new_value: targetClass.name,
      status: 'SUCCESS',
      details: `Siswa "${student.full_name}" dipindahkan dari rombel "${oldClass}" ke rombel "${targetClass.name}" oleh ${actor.full_name}.`,
    });
    return student;
  }

  async updateStudentProfile(
    studentId: string,
    data: Partial<StudentProfile>,
    actor: UserProfile
  ): Promise<StudentProfile> {
    const student = this.students.find((s) => s.id === studentId || s.user_id === studentId);
    if (!student) throw new Error('Data siswa tidak ditemukan.');

    if (actor.role === 'SISWA') {
      if (student.user_id !== actor.id && student.id !== actor.id) {
        throw new Error('Akses Ditolak: Anda tidak dapat mengubah data siswa lain.');
      }
      if (data.phone !== undefined) student.phone = data.phone;
      if (data.address !== undefined) student.address = data.address;
    } else {
      if (actor.role !== 'MASTER' && (actor.role !== 'KEPALA_SEKOLAH' || actor.tenant_id !== student.tenant_id)) {
        throw new Error('Akses Ditolak: Anda tidak memiliki wewenang mengubah data siswa ini.');
      }
      Object.assign(student, data);
    }

    await auditService.recordEvent({
      event: 'STUDENT_PROFILE_UPDATED',
      email: actor.email,
      user_id: actor.id,
      role: actor.role,
      tenant_id: student.tenant_id,
      student_id: student.id,
      student_name: student.full_name,
      nisn: student.nisn,
      status: 'SUCCESS',
      details: `Profil siswa "${student.full_name}" diperbarui oleh ${actor.full_name}.`,
    });
    return student;
  }

  async createStudent(
    data: {
      tenant_id: string;
      full_name: string;
      nisn: string;
      nis: string;
      gender: 'L' | 'P';
      class_id: string;
      class_name: string;
      generation_year?: number;
      sma_peminatan?: string;
      smk_program_id?: string;
      smk_program_name?: string;
      kompetensi_keahlian?: string;
      address?: string;
      phone?: string;
      email?: string;
      parent_name?: string;
      parent_relation?: 'AYAH' | 'IBU' | 'WALI';
      parent_whatsapp?: string;
      status?: StudentStatus;
    },
    actor: UserProfile
  ): Promise<StudentProfile> {
    if (actor.role !== 'MASTER' && (actor.role !== 'KEPALA_SEKOLAH' || actor.tenant_id !== data.tenant_id)) {
      throw new Error('Akses Ditolak: Anda tidak memiliki izin mendaftarkan siswa di sekolah ini.');
    }
    const tenant = await tenantRepository.getById(data.tenant_id);
    const newStudent: StudentProfile = {
      id: `std-${Date.now()}`,
      tenant_id: data.tenant_id,
      tenant_name: tenant?.name,
      user_id: `usr-std-${Date.now()}`,
      full_name: data.full_name,
      nisn: data.nisn,
      nis: data.nis,
      gender: data.gender,
      class_id: data.class_id,
      class_name: data.class_name,
      generation_year: data.generation_year || 2024,
      status: data.status || 'ACTIVE',
      self_registered: false,
      registration_date: new Date().toISOString().split('T')[0],
      sma_peminatan: data.sma_peminatan,
      smk_program_id: data.smk_program_id,
      smk_program_name: data.smk_program_name,
      kompetensi_keahlian: data.kompetensi_keahlian,
      address: data.address,
      phone: data.phone,
      email: data.email,
      parent_name: data.parent_name,
      parent_relation: data.parent_relation,
      parent_whatsapp: data.parent_whatsapp,
    };
    this.students.push(newStudent);

    const targetClass = this.classes.find((c) => c.id === data.class_id);
    if (targetClass) {
      targetClass.total_students = (targetClass.total_students || 0) + 1;
    }
    return newStudent;
  }

  // =================== ACADEMIC YEARS ===================
  async getAcademicYears(tenantId: string, currentUser: UserProfile | null): Promise<AcademicYear[]> {
    if (!currentUser) return [];
    if (currentUser.role !== 'MASTER' && currentUser.tenant_id !== tenantId) return [];
    const years = this.academicYears.filter((y) => y.tenant_id === tenantId);
    if (years.length === 0) {
      return [
        {
          id: `ay-${tenantId}-ganjil`,
          tenant_id: tenantId,
          name: '2024/2025',
          semester: 'GANJIL',
          is_active: true,
          start_date: '2024-07-15',
          end_date: '2024-12-20',
        },
      ];
    }
    return years;
  }

  async setActiveAcademicYear(
    tenantId: string,
    yearId: string,
    actor: UserProfile
  ): Promise<AcademicYear> {
    if (actor.role !== 'MASTER' && (actor.role !== 'KEPALA_SEKOLAH' || actor.tenant_id !== tenantId)) {
      throw new Error('Akses Ditolak: Anda tidak memiliki izin mengubah tahun ajaran sekolah ini.');
    }
    this.academicYears.forEach((y) => {
      if (y.tenant_id === tenantId) {
        y.is_active = y.id === yearId;
      }
    });
    const activeYear = this.academicYears.find((y) => y.id === yearId);
    if (!activeYear) throw new Error('Tahun ajaran tidak ditemukan');
    await auditService.recordEvent({
      event: 'ACADEMIC_CONFIG_UPDATED',
      email: actor.email,
      user_id: actor.id,
      role: actor.role,
      tenant_id: tenantId,
      status: 'SUCCESS',
      details: `Tahun ajaran aktif diubah menjadi ${activeYear.name} (${activeYear.semester}) oleh ${actor.full_name}.`,
    });
    return activeYear;
  }

  // =================== TEACHER ASSIGNMENTS ===================
  async assignTeacher(
    params: {
      tenant_id: string;
      teacher_user_id: string;
      assignment_type: TeacherAssignmentType;
      class_id?: string;
      program_id?: string;
      notes?: string;
    },
    actor: UserProfile
  ): Promise<TeacherAssignment> {
    if (actor.role !== 'MASTER' && (actor.role !== 'KEPALA_SEKOLAH' || actor.tenant_id !== params.tenant_id)) {
      throw new Error('Akses Ditolak: Hanya Kepala Sekolah yang berwenang memberikan tugas tambahan kepada guru.');
    }
    const user = await userRepository.getById(params.teacher_user_id);
    if (!user) throw new Error('Guru tidak ditemukan.');
    if (!user.assignments) {
      user.assignments = [];
    }
    const newAssignment: TeacherAssignment = {
      id: `asg-${Date.now()}`,
      tenant_id: params.tenant_id,
      teacher_id: params.teacher_user_id,
      teacher_user_id: params.teacher_user_id,
      type: params.assignment_type,
      assignment_type: params.assignment_type,
      class_id: params.class_id,
      program_id: params.program_id,
      academic_year_id: 'ay-2024-ganjil',
      active: true,
      notes: params.notes,
      assigned_at: new Date().toISOString(),
    };
    user.assignments.push(newAssignment);
    this.teacherAssignments.push(newAssignment);

    if (params.assignment_type === 'WALI_KELAS' && params.class_id) {
      const cls = this.classes.find((c) => c.id === params.class_id);
      if (cls) {
        cls.wali_kelas_teacher_id = params.teacher_user_id;
        cls.wali_kelas_name = user.full_name;
      }
    }
    await auditService.recordEvent({
      event: 'ASSIGNMENT_UPDATED',
      email: actor.email,
      user_id: actor.id,
      role: actor.role,
      tenant_id: params.tenant_id,
      teacher_id: params.teacher_user_id,
      teacher_name: user.full_name,
      status: 'SUCCESS',
      details: `Penugasan "${params.assignment_type}" diberikan kepada guru ${user.full_name} oleh ${actor.full_name}.`,
    });
    return newAssignment;
  }

  async getAssignmentsByTenant(
    tenantId: string,
    currentUser: UserProfile | null
  ): Promise<TeacherAssignment[]> {
    if (!currentUser) return [];
    if (currentUser.role !== 'MASTER' && currentUser.tenant_id !== tenantId) return [];
    return this.teacherAssignments.filter((a) => a.tenant_id === tenantId);
  }

  // =================== ATTENDANCE & GRADES ===================
  async getAttendanceByTenant(tenantId: string, currentUser: UserProfile | null): Promise<DailyAttendance[]> {
    if (!currentUser) return [];
    if (currentUser.role !== 'MASTER' && currentUser.tenant_id !== tenantId) return [];
    return this.attendance.filter((a) => a.tenant_id === tenantId);
  }

  async getGradesByTenant(tenantId: string, currentUser: UserProfile | null): Promise<GradeItem[]> {
    if (!currentUser) return [];
    if (currentUser.role !== 'MASTER' && currentUser.tenant_id !== tenantId) return [];
    return this.grades.filter((g) => g.tenant_id === tenantId);
  }

  async getSmkProgramsByTenant(tenantId: string, currentUser: UserProfile | null): Promise<SMKProgramKeahlian[]> {
    if (!currentUser) return [];
    if (currentUser.role !== 'MASTER' && currentUser.tenant_id !== tenantId) return [];
    return this.smkPrograms.filter((p) => p.tenant_id === tenantId);
  }

  async getSmkPklRecords(tenantId: string, currentUser: UserProfile | null): Promise<SMKPklRecord[]> {
    if (!currentUser) return [];
    if (currentUser.role !== 'MASTER' && currentUser.tenant_id !== tenantId) return [];
    return this.smkPkl.filter((p) => p.tenant_id === tenantId);
  }

  async getSmkUkkRecords(tenantId: string, currentUser: UserProfile | null): Promise<SMKUKKRecord[]> {
    if (!currentUser) return [];
    if (currentUser.role !== 'MASTER' && currentUser.tenant_id !== tenantId) return [];
    return this.smkUkk.filter((u) => u.tenant_id === tenantId);
  }

  // =================== ORANG TUA / WALI (student_guardians) ===================
  async getStudentGuardians(
    tenantId: string,
    currentUser: UserProfile | null,
    filters?: { class_id?: string; student_id?: string }
  ): Promise<StudentGuardian[]> {
    if (!currentUser) return [];
    if (currentUser.role !== 'MASTER' && currentUser.tenant_id !== tenantId) return [];
    let result = this.studentGuardians.filter((g) => g.tenant_id === tenantId);

    if (currentUser.role === 'ORANG_TUA') {
      result = result.filter((g) => g.guardian_user_id === currentUser.id);
    } else if (currentUser.role === 'SISWA') {
      const student = this.students.find((s) => s.user_id === currentUser.id || s.id === currentUser.id);
      if (student) {
        result = result.filter((g) => g.student_id === student.id);
      } else {
        result = [];
      }
    } else if (currentUser.role === 'GURU') {
      const waliKelasAssignment = currentUser.assignments?.find(
        (a) => a.type === 'WALI_KELAS' && a.active
      );
      if (waliKelasAssignment?.class_id && filters?.class_id) {
        result = result.filter((g) => g.class_id === filters.class_id);
      }
    }

    if (filters?.class_id) {
      result = result.filter((g) => g.class_id === filters.class_id);
    }
    if (filters?.student_id) {
      result = result.filter((g) => g.student_id === filters.student_id);
    }
    return result;
  }

  async activateParentAccount(
    params: {
      tenant_id: string;
      full_name: string;
      whatsapp: string;
      email: string;
      relation_type: 'AYAH' | 'IBU' | 'WALI';
      student_ids: string[];
      class_id?: string;
    },
    actor: UserProfile
  ): Promise<{ parent: UserProfile; guardians: StudentGuardian[] }> {
    const isWaliKelas = actor.role === 'GURU' && actor.assignments?.some(
      (a) => a.type === 'WALI_KELAS' && a.active && (!params.class_id || a.class_id === params.class_id)
    );
    const isAuthorized = actor.role === 'MASTER' || actor.role === 'KEPALA_SEKOLAH' || isWaliKelas;
    if (!isAuthorized) {
      await auditService.recordEvent({
        event: 'PERMISSION_DENIED',
        email: actor.email,
        user_id: actor.id,
        role: actor.role,
        tenant_id: params.tenant_id,
        status: 'FAILED',
        details: `Unauthorized parent activation attempt by ${actor.full_name} (${actor.role})`,
      });
      throw new Error('Hanya Wali Kelas (atau Kepala Sekolah/Master) yang berwenang mengaktifkan akun orang tua.');
    }
    if (actor.role !== 'MASTER' && actor.tenant_id !== params.tenant_id) {
      throw new Error('Akses lintas sekolah ditolak.');
    }

    const targetStudents = this.students.filter(
      (s) => params.student_ids.includes(s.id) && s.tenant_id === params.tenant_id
    );
    if (targetStudents.length === 0) {
      throw new Error('Tidak ada siswa valid yang dipilih dalam rombel ini.');
    }

    const cleanEmail = params.email.toLowerCase().trim();
    const existingUsers = await userRepository.getAll();
    let parentUser = existingUsers.find(
      (u) => u.email.toLowerCase() === cleanEmail || (u.role === 'ORANG_TUA' && u.phone === params.whatsapp)
    );

    const linkedStudentSummaries = targetStudents.map((s) => ({
      id: s.id,
      nisn: s.nisn,
      full_name: s.full_name,
      class_name: s.class_name || 'Kelas Aktif',
      tenant_name: 'Sekolah Terdaftar',
      school_type: s.school_type || 'SMA',
    }));

    if (!parentUser) {
      const parentUserId = `usr-parent-${Date.now()}`;
      parentUser = {
        id: parentUserId,
        tenant_id: params.tenant_id,
        email: cleanEmail,
        full_name: params.full_name,
        phone: params.whatsapp,
        role: 'ORANG_TUA',
        status: 'ACTIVE',
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
        linked_students: linkedStudentSummaries,
      };
      await userRepository.create(parentUser);
    } else {
      const currentLinked = parentUser.linked_students || [];
      for (const summary of linkedStudentSummaries) {
        if (!currentLinked.some((s) => s.id === summary.id)) {
          currentLinked.push(summary);
        }
      }
      parentUser.linked_students = currentLinked;
      parentUser.status = 'ACTIVE';
      parentUser.phone = params.whatsapp;
      await userRepository.update(parentUser.id, parentUser);
    }

    const createdGuardians: StudentGuardian[] = [];
    for (const student of targetStudents) {
      let guardianRecord = this.studentGuardians.find(
        (g) => g.tenant_id === params.tenant_id && g.guardian_user_id === parentUser!.id && g.student_id === student.id
      );
      if (!guardianRecord) {
        guardianRecord = {
          id: `sg-${Date.now()}-${student.id.slice(-4)}`,
          tenant_id: params.tenant_id,
          guardian_user_id: parentUser.id,
          guardian_name: params.full_name,
          guardian_whatsapp: params.whatsapp,
          guardian_email: cleanEmail,
          student_id: student.id,
          student_name: student.full_name,
          student_nisn: student.nisn,
          class_id: student.class_id,
          class_name: student.class_name || 'Rombel',
          relation_type: params.relation_type,
          status: 'ACTIVE',
          is_primary: true,
          activated_by_wali_kelas_id: actor.id,
          activated_by_name: actor.full_name,
          activation_mode: 'SUPABASE_AUTH_INTERNAL_PROVISION',
          created_at: new Date().toISOString(),
        };
        this.studentGuardians.push(guardianRecord);
      } else {
        guardianRecord.status = 'ACTIVE';
        guardianRecord.guardian_whatsapp = params.whatsapp;
        guardianRecord.relation_type = params.relation_type;
      }
      createdGuardians.push(guardianRecord);

      student.parent_name = params.full_name;
      student.parent_whatsapp = params.whatsapp;
      student.parent_relation = params.relation_type;

      await auditService.recordEvent({
        event: 'STUDENT_GUARDIAN_LINKED',
        email: actor.email,
        user_id: actor.id,
        role: actor.role,
        tenant_id: params.tenant_id,
        status: 'SUCCESS',
        details: `Siswa ${student.full_name} (${student.nisn}) berhasil dihubungkan ke wali ${params.full_name} (${params.relation_type})`,
      });
    }

    await auditService.recordEvent({
      event: 'PARENT_ACTIVATED',
      email: actor.email,
      user_id: actor.id,
      role: actor.role,
      tenant_id: params.tenant_id,
      status: 'SUCCESS',
      details: `Akun Orang Tua/Wali '${params.full_name}' diaktifkan oleh ${actor.full_name} (${actor.role}) via Supabase Auth. Terhubung ke ${targetStudents.length} siswa.`,
    });

    return { parent: parentUser, guardians: createdGuardians };
  }

  async linkGuardianToAdditionalStudent(
    params: {
      tenant_id: string;
      guardian_user_id: string;
      student_id: string;
      relation_type: 'AYAH' | 'IBU' | 'WALI';
    },
    actor: UserProfile
  ): Promise<StudentGuardian> {
    const isWaliKelas = actor.role === 'GURU' && actor.assignments?.some((a) => a.type === 'WALI_KELAS' && a.active);
    const isAuthorized = actor.role === 'MASTER' || actor.role === 'KEPALA_SEKOLAH' || isWaliKelas;
    if (!isAuthorized) {
      throw new Error('Hanya Wali Kelas atau Kepala Sekolah yang dapat menghubungkan siswa ke wali.');
    }
    const student = this.students.find((s) => s.id === params.student_id && s.tenant_id === params.tenant_id);
    if (!student) throw new Error('Siswa tidak ditemukan.');

    const parentUser = await userRepository.getById(params.guardian_user_id);
    if (!parentUser) throw new Error('Akun Orang Tua tidak ditemukan.');

    let guardianRecord = this.studentGuardians.find(
      (g) => g.tenant_id === params.tenant_id && g.guardian_user_id === params.guardian_user_id && g.student_id === params.student_id
    );
    if (!guardianRecord) {
      guardianRecord = {
        id: `sg-${Date.now()}-${student.id.slice(-4)}`,
        tenant_id: params.tenant_id,
        guardian_user_id: parentUser.id,
        guardian_name: parentUser.full_name,
        guardian_whatsapp: parentUser.phone || '',
        guardian_email: parentUser.email,
        student_id: student.id,
        student_name: student.full_name,
        student_nisn: student.nisn,
        class_id: student.class_id,
        class_name: student.class_name || 'Rombel',
        relation_type: params.relation_type,
        status: 'ACTIVE',
        is_primary: false,
        activated_by_wali_kelas_id: actor.id,
        activated_by_name: actor.full_name,
        activation_mode: 'SUPABASE_AUTH_INTERNAL_PROVISION',
        created_at: new Date().toISOString(),
      };
      this.studentGuardians.push(guardianRecord);
    }

    if (!parentUser.linked_students) parentUser.linked_students = [];
    if (!parentUser.linked_students.some((s) => s.id === student.id)) {
      parentUser.linked_students.push({
        id: student.id,
        nisn: student.nisn,
        full_name: student.full_name,
        class_name: student.class_name || 'Rombel',
        tenant_name: 'Sekolah Terdaftar',
        school_type: student.school_type || 'SMA',
      });
      await userRepository.update(parentUser.id, parentUser);
    }

    await auditService.recordEvent({
      event: 'STUDENT_GUARDIAN_LINKED',
      email: actor.email,
      user_id: actor.id,
      role: actor.role,
      tenant_id: params.tenant_id,
      status: 'SUCCESS',
      details: `Penambahan relasi: ${parentUser.full_name} terhubung ke anak ${student.full_name} (${student.nisn})`,
    });

    return guardianRecord;
  }

  // =================== MATA PELAJARAN (SUBJECTS) ===================
  async getSubjects(tenantId: string, currentUser?: UserProfile | null): Promise<Subject[]> {
    if (currentUser && currentUser.role !== 'MASTER' && currentUser.tenant_id !== tenantId) return [];
    return this.subjects.filter((s) => s.tenant_id === tenantId);
  }

  async createSubject(data: Omit<Subject, 'id'>, actor: UserProfile): Promise<Subject> {
    const isWakaKurikulum = actor.role === 'GURU' && actor.assignments?.some((a) => a.type === 'WAKA_KURIKULUM' && a.active);
    const isAuthorized = actor.role === 'MASTER' || actor.role === 'KEPALA_SEKOLAH' || isWakaKurikulum;
    if (!isAuthorized) {
      throw new Error('Hanya Kepala Sekolah atau Waka Kurikulum yang dapat menambahkan mata pelajaran.');
    }
    const newSubject: Subject = {
      ...data,
      id: `sbj-${Date.now()}`,
    };
    this.subjects.push(newSubject);
    await auditService.recordEvent({
      event: 'SUBJECT_CREATED',
      email: actor.email,
      user_id: actor.id,
      role: actor.role,
      tenant_id: data.tenant_id,
      status: 'SUCCESS',
      details: `Mata pelajaran baru ditambahkan: ${newSubject.name} (${newSubject.code})`,
    });
    return newSubject;
  }

  // =================== JADWAL PELAJARAN (SCHEDULES) ===================
  async getSchedules(
    tenantId: string,
    currentUser: UserProfile | null,
    filters?: { class_id?: string; teacher_id?: string; student_id?: string; day?: string }
  ): Promise<ClassSchedule[]> {
    if (!currentUser) return [];
    if (currentUser.role !== 'MASTER' && currentUser.role !== 'ORANG_TUA' && currentUser.tenant_id !== tenantId) return [];
    let result = this.schedules.filter((s) => s.tenant_id === tenantId);

    if (currentUser.role === 'SISWA') {
      const student = this.students.find((s) => s.user_id === currentUser.id || s.id === currentUser.id);
      if (student) {
        result = result.filter((s) => s.class_id === student.class_id);
      }
    }
    if (currentUser.role === 'ORANG_TUA' && filters?.student_id) {
      const student = this.students.find((s) => s.id === filters.student_id);
      if (student) {
        result = result.filter((s) => s.class_id === student.class_id);
      }
    }
    if (filters?.class_id) {
      result = result.filter((s) => s.class_id === filters.class_id);
    }
    if (filters?.teacher_id) {
      result = result.filter((s) => s.teacher_id === filters.teacher_id);
    }
    if (filters?.day) {
      result = result.filter((s) => s.day === filters.day);
    }
    return result;
  }

  async getClassSchedules(tenantId: string, classId?: string): Promise<ClassSchedule[]> {
    let result = this.schedules.filter((s) => s.tenant_id === tenantId);
    if (classId) {
      result = result.filter((s) => s.class_id === classId);
    }
    return result;
  }

  async createSchedule(data: Omit<ClassSchedule, 'id'>, actor: UserProfile): Promise<ClassSchedule> {
    const isWakaKurikulum = actor.role === 'GURU' && actor.assignments?.some((a) => a.type === 'WAKA_KURIKULUM' && a.active);
    const isAuthorized = actor.role === 'MASTER' || actor.role === 'KEPALA_SEKOLAH' || isWakaKurikulum;
    if (!isAuthorized) {
      throw new Error('Hanya Kepala Sekolah atau Waka Kurikulum yang dapat menyusun jadwal pelajaran.');
    }
    const newSchedule: ClassSchedule = {
      ...data,
      id: `sch-${Date.now()}`,
    };
    this.schedules.push(newSchedule);
    await auditService.recordEvent({
      event: 'SCHEDULE_CREATED',
      email: actor.email,
      user_id: actor.id,
      role: actor.role,
      tenant_id: data.tenant_id,
      status: 'SUCCESS',
      details: `Jadwal baru ditambahkan: ${newSchedule.subject_name} (${newSchedule.class_name}) hari ${newSchedule.day} pukul ${newSchedule.start_time}-${newSchedule.end_time}`,
    });
    return newSchedule;
  }

  async deleteSchedule(scheduleId: string, actor: UserProfile): Promise<boolean> {
    const isWakaKurikulum = actor.role === 'GURU' && actor.assignments?.some((a) => a.type === 'WAKA_KURIKULUM' && a.active);
    const isAuthorized = actor.role === 'MASTER' || actor.role === 'KEPALA_SEKOLAH' || isWakaKurikulum;
    if (!isAuthorized) {
      throw new Error('Hanya Kepala Sekolah atau Waka Kurikulum yang dapat menghapus jadwal.');
    }
    const idx = this.schedules.findIndex((s) => s.id === scheduleId);
    if (idx >= 0) {
      const removed = this.schedules.splice(idx, 1)[0];
      await auditService.recordEvent({
        event: 'SCHEDULE_DELETED',
        email: actor.email,
        user_id: actor.id,
        role: actor.role,
        tenant_id: removed.tenant_id,
        status: 'SUCCESS',
        details: `Jadwal ${removed.subject_name} kelas ${removed.class_name} telah dihapus.`,
      });
      return true;
    }
    return false;
  }

  // =================== TUGAS AKADEMIK & PENGUMPULAN ===================
  async getTasks(
    tenantId: string,
    currentUser: UserProfile | null,
    filters?: { class_id?: string; subject_id?: string; teacher_id?: string; student_id?: string }
  ): Promise<AcademicTask[]> {
    if (!currentUser) return [];
    if (currentUser.role !== 'MASTER' && currentUser.role !== 'ORANG_TUA' && currentUser.tenant_id !== tenantId) return [];
    let result = this.tasks.filter((t) => t.tenant_id === tenantId);

    if (currentUser.role === 'SISWA') {
      const student = this.students.find((s) => s.user_id === currentUser.id || s.id === currentUser.id);
      if (student) {
        result = result.filter((t) => t.class_id === student.class_id);
      }
    }
    if (currentUser.role === 'ORANG_TUA' && filters?.student_id) {
      const student = this.students.find((s) => s.id === filters.student_id);
      if (student) {
        result = result.filter((t) => t.class_id === student.class_id);
      }
    }
    if (filters?.class_id) {
      result = result.filter((t) => t.class_id === filters.class_id);
    }
    if (filters?.subject_id) {
      result = result.filter((t) => t.subject_id === filters.subject_id);
    }
    if (filters?.teacher_id) {
      result = result.filter((t) => t.teacher_id === filters.teacher_id);
    }
    return result;
  }

  async createTask(
    data: Omit<AcademicTask, 'id' | 'created_at' | 'submissions_count'>,
    actor: UserProfile
  ): Promise<AcademicTask> {
    if (actor.role !== 'GURU' && actor.role !== 'KEPALA_SEKOLAH' && actor.role !== 'MASTER') {
      throw new Error('Hanya Guru atau Kepala Sekolah yang dapat memberikan tugas.');
    }
    const newTask: AcademicTask = {
      ...data,
      id: `tsk-${Date.now()}`,
      created_at: new Date().toISOString(),
      submissions_count: 0,
      submission_count: 0,
    };
    this.tasks.push(newTask);
    await auditService.recordEvent({
      event: 'TASK_CREATED',
      email: actor.email,
      user_id: actor.id,
      role: actor.role,
      tenant_id: data.tenant_id,
      status: 'SUCCESS',
      details: `Tugas baru '${newTask.title}' untuk kelas ${newTask.class_name} dibuat oleh ${actor.full_name}`,
    });
    return newTask;
  }

  async getSubmissions(tenantIdOrTaskId: string, taskIdOrUser: string | UserProfile | null, currentUserMaybe?: UserProfile | null): Promise<TaskSubmission[]> {
    const taskId = typeof taskIdOrUser === 'string' ? taskIdOrUser : tenantIdOrTaskId;
    const currentUser = typeof taskIdOrUser === 'string' ? currentUserMaybe : taskIdOrUser;

    if (!currentUser) return [];
    let result = this.submissions.filter((s) => s.task_id === taskId);

    if (currentUser.role === 'SISWA') {
      const student = this.students.find((s) => s.user_id === currentUser.id || s.id === currentUser.id);
      if (student) {
        result = result.filter((s) => s.student_id === student.id);
      }
    }
    if (currentUser.role === 'ORANG_TUA') {
      const linkedIds = currentUser.linked_students?.map((s) => s.id) || [];
      result = result.filter((s) => linkedIds.includes(s.student_id));
    }
    return result;
  }

  async submitTask(
    params: {
      tenant_id?: string;
      task_id: string;
      student_id: string;
      student_name?: string;
      student_nisn?: string;
      submission_content: string;
      attachment_url?: string;
    },
    actor: UserProfile
  ): Promise<TaskSubmission> {
    if (actor.role !== 'SISWA') {
      throw new Error('Hanya Siswa yang dapat mengumpulkan tugas.');
    }
    const student = this.students.find((s) => s.user_id === actor.id || s.id === actor.id);
    if (!student || student.id !== params.student_id) {
      throw new Error('Siswa hanya berwenang mengumpulkan tugas atas nama diri sendiri.');
    }
    const task = this.tasks.find((t) => t.id === params.task_id);
    if (!task) throw new Error('Tugas tidak ditemukan.');

    let submission = this.submissions.find(
      (s) => s.task_id === params.task_id && s.student_id === student.id
    );
    if (submission) {
      submission.submission_content = params.submission_content;
      submission.attachment_url = params.attachment_url;
      submission.submitted_at = new Date().toISOString();
      submission.status = 'SUBMITTED';
    } else {
      submission = {
        id: `sub-${Date.now()}`,
        tenant_id: task.tenant_id,
        task_id: params.task_id,
        student_id: student.id,
        student_name: student.full_name,
        student_nisn: student.nisn,
        submission_content: params.submission_content,
        attachment_url: params.attachment_url,
        status: 'SUBMITTED',
        submitted_at: new Date().toISOString(),
      };
      this.submissions.push(submission);
      task.submissions_count = (task.submissions_count || 0) + 1;
      task.submission_count = (task.submission_count || 0) + 1;
    }
    await auditService.recordEvent({
      event: 'TASK_SUBMITTED',
      email: actor.email,
      user_id: actor.id,
      role: actor.role,
      tenant_id: task.tenant_id,
      status: 'SUCCESS',
      details: `Siswa ${student.full_name} berhasil mengumpulkan tugas '${task.title}'`,
    });
    return submission;
  }

  async gradeSubmission(
    submissionId: string,
    data: {
      score: number;
      feedback?: string;
    },
    actor: UserProfile
  ): Promise<TaskSubmission> {
    if (actor.role !== 'GURU' && actor.role !== 'KEPALA_SEKOLAH' && actor.role !== 'MASTER') {
      throw new Error('Hanya Guru yang dapat menilai tugas.');
    }
    const submission = this.submissions.find((s) => s.id === submissionId);
    if (!submission) throw new Error('Pengumpulan tugas tidak ditemukan.');

    submission.score = data.score;
    submission.feedback = data.feedback;
    submission.status = 'GRADED';
    submission.graded_at = new Date().toISOString();
    submission.graded_by = actor.full_name;

    await auditService.recordEvent({
      event: 'TASK_GRADED',
      email: actor.email,
      user_id: actor.id,
      role: actor.role,
      tenant_id: submission.tenant_id,
      status: 'SUCCESS',
      details: `Tugas siswa ${submission.student_name} dinilai: ${data.score}/100 oleh ${actor.full_name}`,
    });
    return submission;
  }

  // =================== ABSENSI (ATTENDANCE) ===================
  async recordBulkAttendance(
    recordsOrPayload:
      | Array<{ student_id: string; class_id: string; date: string; status: AttendanceStatus; notes?: string }>
      | {
          tenant_id: string;
          class_id: string;
          date: string;
          attendance: Array<{ student_id: string; status: AttendanceStatus; notes?: string }>;
        },
    actor: UserProfile
  ): Promise<DailyAttendance[]> {
    if (actor.role !== 'GURU' && actor.role !== 'KEPALA_SEKOLAH' && actor.role !== 'MASTER') {
      throw new Error('Hanya Guru atau Wali Kelas yang dapat mencatat absensi.');
    }

    const entries: Array<{ student_id: string; class_id: string; date: string; status: AttendanceStatus; notes?: string }> = Array.isArray(recordsOrPayload)
      ? recordsOrPayload
      : recordsOrPayload.attendance.map((a) => ({
          student_id: a.student_id,
          class_id: recordsOrPayload.class_id,
          date: recordsOrPayload.date,
          status: a.status,
          notes: a.notes,
        }));

    const savedRecords: DailyAttendance[] = [];
    for (const rec of entries) {
      const student = this.students.find((s) => s.id === rec.student_id);
      const studentName = student?.full_name || 'Siswa';
      const tenantId = student?.tenant_id || actor.tenant_id || 'tenant-sma-01';

      let existing = this.attendance.find(
        (a) => a.student_id === rec.student_id && a.date === rec.date
      );
      if (existing) {
        existing.status = rec.status;
        existing.notes = rec.notes;
        existing.recorded_by_user_id = actor.id;
        existing.recorded_by_name = actor.full_name;
        savedRecords.push(existing);
      } else {
        const newAtt: DailyAttendance = {
          id: `att-${Date.now()}-${rec.student_id.slice(-4)}`,
          tenant_id: tenantId,
          student_id: rec.student_id,
          student_name: studentName,
          class_id: rec.class_id,
          date: rec.date,
          status: rec.status,
          recorded_by_user_id: actor.id,
          recorded_by_name: actor.full_name,
          notes: rec.notes,
        };
        this.attendance.push(newAtt);
        savedRecords.push(newAtt);
      }
    }
    await auditService.recordEvent({
      event: 'ATTENDANCE_RECORDED',
      email: actor.email,
      user_id: actor.id,
      role: actor.role,
      tenant_id: actor.tenant_id,
      status: 'SUCCESS',
      details: `Presensi ${entries.length} siswa berhasil dicatat oleh ${actor.full_name}`,
    });
    return savedRecords;
  }

  async getAttendance(
    tenantId: string,
    currentUser: UserProfile | null,
    filters?: { class_id?: string; student_id?: string; date?: string }
  ): Promise<DailyAttendance[]> {
    if (!currentUser) return [];
    if (currentUser.role !== 'MASTER' && currentUser.role !== 'ORANG_TUA' && currentUser.tenant_id !== tenantId) return [];
    let result = this.attendance.filter((a) => a.tenant_id === tenantId);

    if (currentUser.role === 'SISWA') {
      const student = this.students.find((s) => s.user_id === currentUser.id || s.id === currentUser.id);
      if (student) {
        result = result.filter((a) => a.student_id === student.id);
      }
    }
    if (currentUser.role === 'ORANG_TUA') {
      const linkedIds = currentUser.linked_students?.map((s) => s.id) || [];
      if (filters?.student_id && linkedIds.includes(filters.student_id)) {
        result = result.filter((a) => a.student_id === filters.student_id);
      } else {
        result = result.filter((a) => linkedIds.includes(a.student_id));
      }
    }
    if (filters?.class_id) {
      result = result.filter((a) => a.class_id === filters.class_id);
    }
    if (filters?.student_id && currentUser.role !== 'ORANG_TUA') {
      result = result.filter((a) => a.student_id === filters.student_id);
    }
    if (filters?.date) {
      result = result.filter((a) => a.date === filters.date);
    }
    return result;
  }

  // =================== NILAI (GRADES) ===================
  async recordGrade(
    data: Omit<GradeItem, 'id' | 'created_at'> & {
      assessment_title?: string;
      weight?: number;
      competency_achievement?: string;
    },
    actor: UserProfile
  ): Promise<GradeItem> {
    if (actor.role !== 'GURU' && actor.role !== 'KEPALA_SEKOLAH' && actor.role !== 'MASTER') {
      throw new Error('Hanya Guru atau Wali Kelas yang dapat menginput nilai.');
    }
    const newGrade: GradeItem = {
      ...data,
      id: `grd-${Date.now()}`,
      created_at: new Date().toISOString().split('T')[0],
      competency_achievement: data.competency_achievement || data.competency_desc,
    };
    this.grades.push(newGrade);
    await auditService.recordEvent({
      event: 'GRADE_RECORDED',
      email: actor.email,
      user_id: actor.id,
      role: actor.role,
      tenant_id: data.tenant_id,
      status: 'SUCCESS',
      details: `Nilai ${data.assessment_type} (${data.score}/${data.max_score || 100}) diinput untuk siswa ${data.student_name} pada mapel ${data.subject_name}`,
    });
    return newGrade;
  }

  async getGrades(
    tenantId: string,
    currentUser: UserProfile | null,
    filters?: { class_id?: string; subject_id?: string; student_id?: string }
  ): Promise<GradeItem[]> {
    if (!currentUser) return [];
    if (currentUser.role !== 'MASTER' && currentUser.role !== 'ORANG_TUA' && currentUser.tenant_id !== tenantId) return [];
    let result = this.grades.filter((g) => g.tenant_id === tenantId);

    if (currentUser.role === 'SISWA') {
      const student = this.students.find((s) => s.user_id === currentUser.id || s.id === currentUser.id);
      if (student) {
        result = result.filter((g) => g.student_id === student.id || g.student_id === student.user_id);
      }
    } else if (currentUser.role === 'ORANG_TUA') {
      const linkedIds = currentUser.linked_students?.map((s) => s.id) || [];
      if (filters?.student_id) {
        const target = this.students.find((s) => s.id === filters.student_id || s.user_id === filters.student_id);
        const validId = target ? target.id : filters.student_id;
        result = result.filter((g) => g.student_id === validId);
      } else {
        result = result.filter((g) => linkedIds.includes(g.student_id));
      }
    } else {
      if (filters?.student_id) {
        const target = this.students.find((s) => s.id === filters.student_id || s.user_id === filters.student_id);
        const validId = target ? target.id : filters.student_id;
        result = result.filter((g) => g.student_id === validId);
      }
    }

    if (filters?.class_id) {
      result = result.filter((g) => g.class_id === filters.class_id);
    }
    if (filters?.subject_id) {
      result = result.filter((g) => g.subject_id === filters.subject_id);
    }

    return result.map((g: any) => {
      const score = Number(g.score ?? g.final_score ?? 85);
      const predicate = g.predicate ?? (score >= 90 ? 'A' : score >= 80 ? 'B' : score >= 70 ? 'C' : 'D');
      return {
        ...g,
        score,
        final_score: score,
        predicate,
        letter_grade: g.letter_grade ?? predicate,
        tugas_score: g.tugas_score ?? Math.round(score * 0.96),
        uts_score: g.uts_score ?? Math.round(score * 0.98),
        uas_score: g.uas_score ?? score,
      };
    });
  }

  // =================== RAPOR SISWA (REPORT CARDS) ===================
  async getReportCards(
    tenantId: string,
    currentUser: UserProfile | null,
    filters?: { class_id?: string; student_id?: string; academic_year_id?: string; semester?: 'GANJIL' | 'GENAP' }
  ): Promise<StudentReportCard[]> {
    if (!currentUser) return [];
    if (currentUser.role !== 'MASTER' && currentUser.role !== 'ORANG_TUA' && currentUser.tenant_id !== tenantId) return [];
    let result = this.reportCards.filter((r) => r.tenant_id === tenantId);

    if (currentUser.role === 'SISWA') {
      const student = this.students.find((s) => s.user_id === currentUser.id || s.id === currentUser.id);
      if (student) {
        result = result.filter((r) => (r.student_id === student.id || r.student_id === student.user_id || r.nisn === student.nisn || r.student_nisn === student.nisn));
      } else {
        result = result.filter((r) => r.student_id === currentUser.id);
      }
    } else if (currentUser.role === 'ORANG_TUA') {
      const linkedIds = currentUser.linked_students?.map((s) => s.id) || [];
      if (filters?.student_id) {
        const target = this.students.find((s) => s.id === filters.student_id || s.user_id === filters.student_id);
        const validId = target ? target.id : filters.student_id;
        result = result.filter((r) => r.student_id === validId);
      } else {
        result = result.filter((r) => linkedIds.includes(r.student_id));
      }
    }

    if (filters?.class_id) {
      result = result.filter((r) => r.class_id === filters.class_id);
    }
    if (filters?.student_id && currentUser.role !== 'SISWA' && currentUser.role !== 'ORANG_TUA') {
      const target = this.students.find((s) => s.id === filters.student_id || s.user_id === filters.student_id);
      const validId = target ? target.id : filters.student_id;
      result = result.filter((r) => r.student_id === validId);
    }
    if (filters?.academic_year_id) {
      result = result.filter((r) => r.academic_year_id === filters.academic_year_id);
    }
    if (filters?.semester) {
      result = result.filter((r) => r.semester === filters.semester);
    }

    // If no report card found for a student, synthesize a valid default one from available data
    if (result.length === 0 && (currentUser.role === 'SISWA' || filters?.student_id)) {
      const targetStudent = this.students.find((s) =>
        s.user_id === currentUser.id ||
        s.id === currentUser.id ||
        s.id === filters?.student_id ||
        s.user_id === filters?.student_id
      );

      if (targetStudent) {
        const defaultRapor: ReportCard = {
          id: `rep-auto-${targetStudent.id}`,
          tenant_id: tenantId,
          student_id: targetStudent.id,
          student_name: targetStudent.full_name,
          student_nisn: targetStudent.nisn || '0078912345',
          nisn: targetStudent.nisn || '0078912345',
          class_id: targetStudent.class_id || 'cls-1',
          class_name: targetStudent.class_name || 'X MIPA 1',
          academic_year_id: 'ay-2024-ganjil',
          academic_year: '2024/2025',
          semester: 'GANJIL',
          status: 'PUBLISHED',
          published: true,
          published_at: new Date().toISOString(),
          homeroom_teacher_name: 'Budi Santoso, S.Pd., M.Si.',
          wali_kelas_notes: 'Menunjukkan motivasi belajar tinggi, kedisiplinan yang sangat baik, dan aktif dalam pembelajaran.',
          general_average: 89.5,
          grades: [
            {
              subject_id: 'sbj-1',
              subject_name: 'Pendidikan Agama & Budi Pekerti',
              final_score: 92,
              letter_grade: 'A',
              predicate: 'A (Sangat Baik)',
              competency_achievement: 'Memahami nilai-nilai toleransi dan akhlak terpuji secara konsisten.',
            },
            {
              subject_id: 'sbj-2',
              subject_name: 'Bahasa Indonesia',
              final_score: 88,
              letter_grade: 'B',
              predicate: 'B (Baik)',
              competency_achievement: 'Mampu menyusun teks laporan hasil observasi dengan sistematika tepat.',
            },
            {
              subject_id: 'sbj-3',
              subject_name: 'Matematika',
              final_score: 90,
              letter_grade: 'A',
              predicate: 'A (Sangat Baik)',
              competency_achievement: 'Terampil menyelesaikan sistem persamaan linear dan eksponensial.',
            },
            {
              subject_id: 'sbj-4',
              subject_name: 'Bahasa Inggris',
              final_score: 88,
              letter_grade: 'B',
              predicate: 'B (Baik)',
              competency_achievement: 'Aktif berkomunikasi lisan dan memahami teks deskriptif kompleks.',
            },
          ],
          attendance_summary: {
            hadir: 50,
            sakit: 1,
            izin: 1,
            alpa: 0,
          },
          extracurriculars: [
            { name: 'Pramuka Wajib', score: 'A', description: 'Disiplin dan bertanggung jawab' },
          ],
        };
        this.reportCards.push(defaultRapor);
        result = [defaultRapor];
      }
    }

    return result.map((r) => {
      const avg = r.general_average ?? 89.5;
      const gradesList = r.grades || [
        {
          subject_id: 'sbj-1',
          subject_name: 'Mata Pelajaran Umum',
          final_score: 90,
          letter_grade: 'A',
          predicate: 'A (Sangat Baik)',
          competency_achievement: 'Tuntas tujuan pembelajaran.',
        },
      ];

      return {
        ...r,
        student_nisn: r.student_nisn || r.nisn,
        academic_year: r.academic_year || '2024/2025',
        general_average: avg,
        average_score: avg,
        grades: gradesList,
        subject_grades: r.subject_grades || gradesList.map((g) => ({
          subject_id: g.subject_id,
          subject_name: g.subject_name,
          final_score: g.final_score,
          predicate: g.predicate || `${g.letter_grade} (Baik)`,
          competency_achievement: g.competency_achievement,
        })),
        extracurriculars: r.extracurriculars || [
          { name: 'Pramuka Wajib', score: 'A', description: 'Disiplin dan aktif' },
        ],
        attendance_summary: {
          hadir: r.attendance_summary?.hadir ?? 48,
          sakit: r.attendance_summary?.sakit ?? r.attendance_summary?.sick ?? 1,
          sick: r.attendance_summary?.sick ?? r.attendance_summary?.sakit ?? 1,
          izin: r.attendance_summary?.izin ?? r.attendance_summary?.permission ?? 0,
          permission: r.attendance_summary?.permission ?? r.attendance_summary?.izin ?? 0,
          alpa: r.attendance_summary?.alpa ?? r.attendance_summary?.unexcused ?? 0,
          unexcused: r.attendance_summary?.unexcused ?? r.attendance_summary?.alpa ?? 0,
        },
      };
    });
  }

  async updateReportCard(
    reportCardId: string,
    data: {
      wali_kelas_notes?: string;
      attendance_summary?: { hadir: number; izin: number; sakit: number; alpa: number };
    },
    actor: UserProfile
  ): Promise<StudentReportCard> {
    const reportCard = this.reportCards.find((r) => r.id === reportCardId);
    if (!reportCard) throw new Error('Rapor tidak ditemukan.');

    if (data.wali_kelas_notes !== undefined) {
      reportCard.wali_kelas_notes = data.wali_kelas_notes;
      reportCard.teacher_notes = data.wali_kelas_notes;
    }
    if (data.attendance_summary !== undefined) {
      reportCard.attendance_summary = data.attendance_summary;
    }
    const [ret] = await this.getReportCards(reportCard.tenant_id, actor, { student_id: reportCard.student_id });
    return ret;
  }

  async publishReportCard(reportCardId: string, actor: UserProfile): Promise<StudentReportCard> {
    const reportCard = this.reportCards.find((r) => r.id === reportCardId);
    if (!reportCard) throw new Error('Rapor tidak ditemukan.');
    reportCard.published = true;
    reportCard.status = 'PUBLISHED';
    reportCard.published_at = new Date().toISOString();

    await auditService.recordEvent({
      event: 'REPORT_CARD_PUBLISHED',
      email: actor.email,
      user_id: actor.id,
      role: actor.role,
      tenant_id: reportCard.tenant_id,
      status: 'SUCCESS',
      details: `Rapor semester ${reportCard.semester} siswa ${reportCard.student_name} resmi dipublikasikan oleh ${actor.full_name}. Siswa dan Orang Tua sekarang dapat mengaksesnya.`,
    });

    const [ret] = await this.getReportCards(reportCard.tenant_id, actor, { student_id: reportCard.student_id });
    return ret;
  }

  // =================== SMK INDUSTRY PARTNERS ===================
  async getSmkPartners(tenantId: string, currentUser?: UserProfile | null): Promise<SMKIndustryPartner[]> {
    return this.smkPartners.filter((p) => p.tenant_id === tenantId);
  }

  async createSmkPartner(data: Omit<SMKIndustryPartner, 'id'>, actor: UserProfile): Promise<SMKIndustryPartner> {
    const newPartner: SMKIndustryPartner = {
      ...data,
      id: `dudi-${Date.now()}`,
    };
    this.smkPartners.push(newPartner);
    await auditService.recordEvent({
      event: 'TENANT_UPDATED',
      email: actor.email,
      user_id: actor.id,
      role: actor.role,
      tenant_id: data.tenant_id,
      status: 'SUCCESS',
      details: `Mitra industri baru didaftarkan: ${newPartner.name} (MoU: ${newPartner.mou_number})`,
    });
    return newPartner;
  }

  // =================== SMK PKL JOURNALS ===================
  async getSmkPklJournals(
    tenantId: string,
    currentUser?: UserProfile | null,
    filters?: { pkl_id?: string; student_id?: string }
  ): Promise<SMKPklJournal[]> {
    let result = this.smkPklJournals.filter((j) => j.tenant_id === tenantId);
    if (filters?.pkl_id) result = result.filter((j) => j.pkl_id === filters.pkl_id);
    if (filters?.student_id) result = result.filter((j) => j.student_id === filters.student_id);
    return result;
  }

  async addPklJournal(
    data: Omit<SMKPklJournal, 'id' | 'created_at' | 'mentor_verified' | 'school_supervisor_reviewed'>,
    actor: UserProfile
  ): Promise<SMKPklJournal> {
    const newJournal: SMKPklJournal = {
      ...data,
      id: `jrn-${Date.now()}`,
      mentor_verified: false,
      school_supervisor_reviewed: false,
      created_at: new Date().toISOString(),
    };
    this.smkPklJournals.unshift(newJournal);
    await auditService.recordEvent({
      event: 'TASK_SUBMITTED',
      email: actor.email,
      user_id: actor.id,
      role: actor.role,
      tenant_id: data.tenant_id,
      status: 'SUCCESS',
      details: `Jurnal PKL harian dicatat oleh ${data.student_name}: "${data.activity_title}"`,
    });
    return newJournal;
  }

  async verifyPklJournal(
    journalId: string,
    data: { mentor_notes?: string; mentor_verified?: boolean; school_supervisor_reviewed?: boolean },
    actor: UserProfile
  ): Promise<SMKPklJournal> {
    const journal = this.smkPklJournals.find((j) => j.id === journalId);
    if (!journal) throw new Error('Jurnal PKL tidak ditemukan');
    if (data.mentor_notes !== undefined) journal.mentor_notes = data.mentor_notes;
    if (data.mentor_verified !== undefined) journal.mentor_verified = data.mentor_verified;
    if (data.school_supervisor_reviewed !== undefined) journal.school_supervisor_reviewed = data.school_supervisor_reviewed;
    return journal;
  }

  // =================== SMK PKL ATTENDANCE ===================
  async getSmkPklAttendance(
    tenantId: string,
    currentUser?: UserProfile | null,
    filters?: { pkl_id?: string; student_id?: string }
  ): Promise<SMKPklAttendance[]> {
    let result = this.smkPklAttendance.filter((a) => a.tenant_id === tenantId);
    if (filters?.pkl_id) result = result.filter((a) => a.pkl_id === filters.pkl_id);
    if (filters?.student_id) result = result.filter((a) => a.student_id === filters.student_id);
    return result;
  }

  async recordPklAttendance(
    data: Omit<SMKPklAttendance, 'id'>,
    actor: UserProfile
  ): Promise<SMKPklAttendance> {
    const newAtt: SMKPklAttendance = {
      ...data,
      id: `att-pkl-${Date.now()}`,
    };
    this.smkPklAttendance.unshift(newAtt);
    return newAtt;
  }

  // =================== SMK PKL ASSESSMENTS ===================
  async getSmkPklAssessments(tenantId: string): Promise<SMKPklAssessment[]> {
    return this.smkPklAssessments.filter((a) => a.tenant_id === tenantId);
  }

  async savePklAssessment(
    data: Omit<SMKPklAssessment, 'id' | 'completed_at'>,
    actor: UserProfile
  ): Promise<SMKPklAssessment> {
    const existingIdx = this.smkPklAssessments.findIndex((a) => a.pkl_id === data.pkl_id);
    const newAssessment: SMKPklAssessment = {
      ...data,
      id: existingIdx >= 0 ? this.smkPklAssessments[existingIdx].id : `ass-pkl-${Date.now()}`,
      completed_at: new Date().toISOString(),
    };
    if (existingIdx >= 0) {
      this.smkPklAssessments[existingIdx] = newAssessment;
    } else {
      this.smkPklAssessments.push(newAssessment);
    }
    // Also update SMKPklRecord grade and status
    const pklRecord = this.smkPkl.find((p) => p.id === data.pkl_id);
    if (pklRecord) {
      pklRecord.grade = data.final_score;
      pklRecord.status = 'SELESAI';
    }
    return newAssessment;
  }

  // =================== SMK BKK & CAREER ===================
  async getBkkJobs(tenantId: string): Promise<SMKBkkJob[]> {
    return this.smkBkkJobs.filter((j) => j.tenant_id === tenantId);
  }

  async createBkkJob(data: Omit<SMKBkkJob, 'id'>, actor: UserProfile): Promise<SMKBkkJob> {
    const newJob: SMKBkkJob = {
      ...data,
      id: `bkk-${Date.now()}`,
    };
    this.smkBkkJobs.unshift(newJob);
    return newJob;
  }

  async getTracerStudies(tenantId: string): Promise<SMKTracerStudy[]> {
    return this.smkTracer.filter((t) => t.tenant_id === tenantId);
  }

  // =================== BK (BIMBINGAN KONSELING) ===================
  async getBkRecords(tenantId: string): Promise<BKCounselingRecord[]> {
    return this.bkRecords.filter((b) => b.tenant_id === tenantId);
  }

  async addBkRecord(data: Omit<BKCounselingRecord, 'id'>, actor: UserProfile): Promise<BKCounselingRecord> {
    const newRecord: BKCounselingRecord = {
      ...data,
      id: `bk-${Date.now()}`,
    };
    this.bkRecords.unshift(newRecord);
    await auditService.recordEvent({
      event: 'ASSIGNMENT_UPDATED',
      email: actor.email,
      user_id: actor.id,
      role: actor.role,
      tenant_id: data.tenant_id,
      status: 'SUCCESS',
      details: `Catatan konseling BK (${data.category}) dibuat untuk siswa ${data.student_name}`,
    });
    return newRecord;
  }

  async updateBkRecordStatus(recordId: string, status: 'OPEN' | 'IN_PROGRESS' | 'RESOLVED'): Promise<BKCounselingRecord> {
    const record = this.bkRecords.find((b) => b.id === recordId);
    if (!record) throw new Error('Catatan BK tidak ditemukan');
    record.status = status;
    return record;
  }

  // =================== KEDISIPLINAN & TATA TERTIB ===================
  async getDisciplineRecords(tenantId: string, filters?: { student_id?: string }): Promise<StudentDisciplineRecord[]> {
    let result = this.disciplineRecords.filter((d) => d.tenant_id === tenantId);
    if (filters?.student_id) result = result.filter((d) => d.student_id === filters.student_id);
    return result;
  }

  async addDisciplineRecord(data: Omit<StudentDisciplineRecord, 'id'>, actor: UserProfile): Promise<StudentDisciplineRecord> {
    const newRecord: StudentDisciplineRecord = {
      ...data,
      id: `disc-${Date.now()}`,
    };
    this.disciplineRecords.unshift(newRecord);
    return newRecord;
  }

  // =================== SARANA & PRASARANA (SARPRAS) ===================
  async getFacilities(tenantId: string): Promise<SchoolFacility[]> {
    return this.facilities.filter((f) => f.tenant_id === tenantId);
  }

  async addFacility(data: Omit<SchoolFacility, 'id'>, actor: UserProfile): Promise<SchoolFacility> {
    const newFacility: SchoolFacility = {
      ...data,
      id: `fac-${Date.now()}`,
    };
    this.facilities.unshift(newFacility);
    return newFacility;
  }

  // =================== PERSURATAN & TU ===================
  async getLetters(tenantId: string): Promise<SchoolLetter[]> {
    return this.letters.filter((l) => l.tenant_id === tenantId);
  }

  async createLetter(data: Omit<SchoolLetter, 'id'>, actor: UserProfile): Promise<SchoolLetter> {
    const newLetter: SchoolLetter = {
      ...data,
      id: `ltr-${Date.now()}`,
    };
    this.letters.unshift(newLetter);
    return newLetter;
  }

  async addLetter(data: any, actor: UserProfile): Promise<SchoolLetter> {
    return this.createLetter(data, actor);
  }

  async addSmkPklJournal(data: any, actor: UserProfile): Promise<SMKPklJournal> {
    return this.addPklJournal(data, actor);
  }

  async addSmkPklAttendance(data: any, actor: UserProfile): Promise<SMKPklAttendance> {
    return this.recordPklAttendance(data, actor);
  }
}

export const academicRepository = new AcademicRepository();
