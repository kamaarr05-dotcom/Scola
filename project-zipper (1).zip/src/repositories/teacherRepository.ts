import { TeacherProfile, UserProfile } from '../types';
import { INITIAL_TEACHERS } from '../data/mockDatabase';
import { getSupabase } from '../config/supabase';
import { validateTeacherQuota } from '../lib/quotaValidator';
import { tenantRepository } from './tenantRepository';

class TeacherRepository {
  private teachers: TeacherProfile[] = [...INITIAL_TEACHERS];

  async getByTenant(tenantId: string, currentUser: UserProfile | null): Promise<TeacherProfile[]> {
    // Multi-tenant isolation rule
    if (!currentUser) return [];
    if (currentUser.role !== 'MASTER' && currentUser.tenant_id !== tenantId) {
      return [];
    }
    const supabase = getSupabase();
    if (supabase) {
      const { data, error } = await supabase
        .from('teachers')
        .select('*')
        .eq('tenant_id', tenantId);
      if (!error && data) return data as TeacherProfile[];
    }
    return this.teachers.filter((t) => t.tenant_id === tenantId);
  }

  async createTeacher(
    data: Omit<TeacherProfile, 'id'>,
    creatorUser: UserProfile
  ): Promise<TeacherProfile> {
    // Business Rule Check: Guru cannot self-register, must be created by MASTER or KEPALA_SEKOLAH
    if (creatorUser.role !== 'MASTER' && creatorUser.role !== 'KEPALA_SEKOLAH') {
      throw new Error('Akses Ditolak: Hanya MASTER atau KEPALA SEKOLAH yang berwenang menambah akun guru.');
    }
    // Teacher Quota check
    const tenant = await tenantRepository.getById(data.tenant_id);
    if (!tenant) throw new Error('Tenant sekolah tidak ditemukan.');
    const currentTeachers = await this.getByTenant(data.tenant_id, creatorUser);
    const quotaCheck = validateTeacherQuota(tenant, currentTeachers, undefined, data.status);
    if (!quotaCheck.allowed) {
      throw new Error(quotaCheck.reason || 'Kuota guru terlampaui');
    }

    const newTeacher: TeacherProfile = {
      ...data,
      id: `t-${Date.now()}`,
      created_by: creatorUser.id,
    };

    const supabase = getSupabase();
    if (supabase) {
      const { data: inserted, error } = await supabase
        .from('teachers')
        .insert([newTeacher])
        .select()
        .single();
      if (!error && inserted) {
        if (data.status === 'ACTIVE') {
          await tenantRepository.updateActiveTeacherCount(data.tenant_id, 1);
        }
        return inserted as TeacherProfile;
      }
    }

    this.teachers.push(newTeacher);
    if (data.status === 'ACTIVE') {
      await tenantRepository.updateActiveTeacherCount(data.tenant_id, 1);
    }
    return newTeacher;
  }

  async updateTeacherStatus(
    teacherId: string,
    newStatus: 'ACTIVE' | 'INACTIVE',
    actorUser: UserProfile
  ): Promise<TeacherProfile> {
    const teacher = this.teachers.find((t) => t.id === teacherId);
    if (!teacher) throw new Error('Data guru tidak ditemukan');
    if (actorUser.role !== 'MASTER' && actorUser.tenant_id !== teacher.tenant_id) {
      throw new Error('Akses ditolak: Tenant mismatch');
    }
    if (newStatus === 'ACTIVE' && teacher.status !== 'ACTIVE') {
      const tenant = await tenantRepository.getById(teacher.tenant_id);
      if (tenant) {
        const currentTeachers = await this.getByTenant(teacher.tenant_id, actorUser);
        const quotaCheck = validateTeacherQuota(tenant, currentTeachers, teacherId, 'ACTIVE');
        if (!quotaCheck.allowed) {
          throw new Error(quotaCheck.reason);
        }
      }
    }
    const oldStatus = teacher.status;
    teacher.status = newStatus;
    if (newStatus === 'INACTIVE' && !teacher.exit_date) {
      teacher.exit_date = new Date().toISOString().split('T')[0];
    } else if (newStatus === 'ACTIVE') {
      teacher.exit_date = undefined;
    }
    // Update count
    if (oldStatus !== 'ACTIVE' && newStatus === 'ACTIVE') {
      await tenantRepository.updateActiveTeacherCount(teacher.tenant_id, 1);
    } else if (oldStatus === 'ACTIVE' && newStatus === 'INACTIVE') {
      await tenantRepository.updateActiveTeacherCount(teacher.tenant_id, -1);
    }
    return teacher;
  }
}

export const teacherRepository = new TeacherRepository();
