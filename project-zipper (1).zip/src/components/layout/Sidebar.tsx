import React from 'react';
import { useAuth } from '../../context/AuthContext';
import { useTenant } from '../../context/TenantContext';
import { ScolaBrand } from '../common/ScolaBrand';
import {
  LayoutDashboard,
  Building2,
  Users,
  ShieldCheck,
  GraduationCap,
  FileSpreadsheet,
  CalendarCheck,
  BookOpen,
  Award,
  HeartHandshake,
  Baby,
  Briefcase,
  Layers,
  ChevronRight,
  ClipboardList,
} from 'lucide-react';

interface SidebarProps {
  onCloseMobile?: () => void;
}

interface NavItem {
  label: string;
  route: string;
  icon: React.ReactNode;
  badge?: string;
  badgeColor?: string;
}

export const Sidebar: React.FC<SidebarProps> = ({ onCloseMobile }) => {
  const { currentUser, currentRoute, navigate } = useAuth();
  const { currentTenant } = useTenant();

  const getNavItems = (): NavItem[] => {
    if (!currentUser) return [];

    switch (currentUser.role) {
      case 'MASTER':
        return [
          {
            label: 'Master Overview',
            route: '/master',
            icon: <LayoutDashboard className="w-4 h-4" />,
          },
          {
            label: 'Manajemen Sekolah (Tenant)',
            route: '/master/tenants',
            icon: <Building2 className="w-4 h-4" />,
          },
          {
            label: 'Alokasi Kuota Guru',
            route: '/master/quotas',
            icon: <Users className="w-4 h-4" />,
            badge: 'Rp15k/guru',
            badgeColor: 'bg-purple-100 text-purple-700 dark:bg-purple-950 dark:text-purple-300',
          },
          {
            label: 'Audit Log Sistem',
            route: '/audit',
            icon: <ShieldCheck className="w-4 h-4" />,
          },
        ];

      case 'KEPALA_SEKOLAH':
        return [
          {
            label: 'Dashboard Kepsek',
            route: '/kepsek',
            icon: <LayoutDashboard className="w-4 h-4" />,
          },
          {
            label: currentTenant?.type === 'SMK' ? 'Modul Kejuruan & PKL SMK' : 'Modul Akademik SMA',
            route: currentTenant?.type === 'SMK' ? '/smk' : '/sma',
            icon: currentTenant?.type === 'SMK' ? <Briefcase className="w-4 h-4 text-amber-600" /> : <BookOpen className="w-4 h-4 text-blue-600" />,
            badge: currentTenant?.type || 'SCH',
            badgeColor: 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300',
          },
          {
            label: 'Guru & Penugasan',
            route: '/kepsek/teachers',
            icon: <Users className="w-4 h-4" />,
            badge: `${currentTenant?.teacher_quota || 25} Kuota`,
            badgeColor: 'bg-blue-100 text-blue-700 dark:bg-blue-950 dark:text-blue-300',
          },
          {
            label: 'Daftar Siswa & Kelas',
            route: '/classes',
            icon: <GraduationCap className="w-4 h-4" />,
          },
          {
            label: 'Laporan & Raport',
            route: '/reports',
            icon: <FileSpreadsheet className="w-4 h-4" />,
          },
          {
            label: 'Log Audit Sekolah',
            route: '/audit',
            icon: <ShieldCheck className="w-4 h-4" />,
          },
        ];

      case 'GURU': {
        const items: NavItem[] = [
          {
            label: 'Dashboard Guru',
            route: '/guru',
            icon: <LayoutDashboard className="w-4 h-4" />,
          },
          {
            label: 'Agenda Mengajar',
            route: '/guru/teaching',
            icon: <BookOpen className="w-4 h-4" />,
          },
          {
            label: 'Presensi Siswa',
            route: '/guru/attendance',
            icon: <CalendarCheck className="w-4 h-4" />,
          },
          {
            label: 'Penilaian & Rapor',
            route: '/guru/grading',
            icon: <FileSpreadsheet className="w-4 h-4" />,
          },
        ];

        // Conditional assignment items
        const asgTypes = currentUser.assignments?.map((a) => a.type) || [];

        if (asgTypes.includes('WALI_KELAS')) {
          items.push({
            label: 'Tugas: Wali Kelas',
            route: '/guru/wali-kelas',
            icon: <Users className="w-4 h-4 text-emerald-600" />,
            badge: 'Wali',
            badgeColor: 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300',
          });
        }

        if (asgTypes.some((t) => t.startsWith('WAKA_'))) {
          items.push({
            label: 'Tugas: WAKA 4-Bidang',
            route: '/waka',
            icon: <Award className="w-4 h-4 text-indigo-600" />,
            badge: 'Waka',
            badgeColor: 'bg-indigo-100 text-indigo-700 dark:bg-indigo-950 dark:text-indigo-300',
          });
        }

        if (asgTypes.includes('GURU_BK')) {
          items.push({
            label: 'Tugas: Guru BK (Konseling)',
            route: '/bk',
            icon: <HeartHandshake className="w-4 h-4 text-rose-600" />,
            badge: 'BK',
            badgeColor: 'bg-rose-100 text-rose-700 dark:bg-rose-950 dark:text-rose-300',
          });
        }

        if (asgTypes.includes('KAPROG')) {
          items.push({
            label: 'Tugas: Kaprog Kejuruan SMK',
            route: '/smk',
            icon: <Briefcase className="w-4 h-4 text-amber-600" />,
            badge: 'Kaprog',
            badgeColor: 'bg-amber-100 text-amber-700 dark:bg-amber-950 dark:text-amber-300',
          });
        }

        return items;
      }

      case 'SISWA': {
        const studentItems: NavItem[] = [
          {
            label: 'Dashboard Siswa',
            route: '/siswa',
            icon: <LayoutDashboard className="w-4 h-4" />,
          },
          {
            label: 'Jadwal Pelajaran',
            route: '/siswa/schedule',
            icon: <CalendarCheck className="w-4 h-4" />,
          },
          {
            label: 'Nilai Akademik & Rapor',
            route: '/siswa/grades',
            icon: <FileSpreadsheet className="w-4 h-4" />,
          },
          {
            label: 'Riwayat Presensi',
            route: '/siswa/attendance',
            icon: <ClipboardList className="w-4 h-4" />,
          },
        ];

        if (currentTenant?.type === 'SMK') {
          studentItems.push({
            label: 'Jurnal & Absensi PKL',
            route: '/siswa/pkl',
            icon: <Briefcase className="w-4 h-4 text-amber-600" />,
            badge: 'DUDI',
            badgeColor: 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300',
          });
        }

        return studentItems;
      }

      case 'ORANG_TUA':
        return [
          {
            label: 'Pantau Anak',
            route: '/parent',
            icon: <Baby className="w-4 h-4" />,
          },
          {
            label: 'Presensi & Kehadiran',
            route: '/parent/attendance',
            icon: <CalendarCheck className="w-4 h-4" />,
          },
          {
            label: 'Hasil Belajar & Nilai',
            route: '/parent/grades',
            icon: <FileSpreadsheet className="w-4 h-4" />,
          },
          {
            label: 'Konsultasi Wali Kelas',
            route: '/parent/contact',
            icon: <HeartHandshake className="w-4 h-4" />,
          },
        ];

      case 'TENAGA_KEPENDIDIKAN':
        return [
          {
            label: 'Administrasi TU',
            route: '/tu',
            icon: <LayoutDashboard className="w-4 h-4" />,
          },
          {
            label: 'Inventaris & Sarpras',
            route: '/tu/sarpras',
            icon: <Layers className="w-4 h-4" />,
          },
          {
            label: 'Surat & Berkas',
            route: '/tu/letters',
            icon: <FileSpreadsheet className="w-4 h-4" />,
          },
        ];

      default:
        return [];
    }
  };

  const navItems = getNavItems();

  const handleNavClick = (route: string) => {
    navigate(route);
    if (onCloseMobile) onCloseMobile();
  };

  return (
    <aside className="w-64 bg-white dark:bg-slate-900 border-r border-slate-200 dark:border-slate-800 flex flex-col h-full shrink-0 select-none">
      {/* Brand Header */}
      <div className="p-4 border-b border-slate-200 dark:border-slate-800">
        <ScolaBrand size="md" showTagline={true} />
      </div>

      {/* Nav List */}
      <div className="flex-1 overflow-y-auto py-3 px-3 space-y-1">
        <div className="px-3 py-1.5 text-[10px] font-bold text-slate-400 uppercase tracking-wider">
          Navigasi Utama
        </div>

        {navItems.map((item) => {
          const isActive = currentRoute === item.route;
          return (
            <button
              key={item.route}
              type="button"
              onClick={() => handleNavClick(item.route)}
              className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                isActive
                  ? 'bg-blue-600 text-white shadow-sm shadow-blue-500/20'
                  : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              <div className="flex items-center gap-2.5">
                <span className={isActive ? 'text-white' : 'text-slate-500 dark:text-slate-400'}>
                  {item.icon}
                </span>
                <span className="truncate">{item.label}</span>
              </div>
              <div className="flex items-center gap-1">
                {item.badge && (
                  <span
                    className={`text-[10px] px-1.5 py-0.5 rounded font-bold ${
                      isActive ? 'bg-white/20 text-white' : item.badgeColor || 'bg-slate-100 text-slate-700'
                    }`}
                  >
                    {item.badge}
                  </span>
                )}
                <ChevronRight
                  className={`w-3.5 h-3.5 opacity-60 ${isActive ? 'text-white' : 'text-slate-400'}`}
                />
              </div>
            </button>
          );
        })}
      </div>

      {/* Tenant Status Footer */}
      {currentTenant && (
        <div className="p-3 border-t border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-850 m-2 rounded-2xl">
          <div className="flex items-center justify-between text-[11px] font-medium text-slate-500 dark:text-slate-400">
            <span>Status Sekolah:</span>
            <span className="font-bold text-emerald-600 dark:text-emerald-400 flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
              {currentTenant.is_active ? 'TERHUBUNG' : 'NONAKTIF'}
            </span>
          </div>
          <div className="text-[10px] text-slate-400 truncate mt-0.5">
            {currentTenant.city}, {currentTenant.province}
          </div>
        </div>
      )}
    </aside>
  );
};
