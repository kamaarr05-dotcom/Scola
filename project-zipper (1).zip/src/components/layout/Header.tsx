import React from 'react';
import { useAuth } from '../../context/AuthContext';
import { useTenant } from '../../context/TenantContext';
import { RoleBadge } from '../common/RoleBadge';
import { AssignmentPill } from '../common/AssignmentPill';
import { ScolaBrand } from '../common/ScolaBrand';
import {
  Menu,
  LogOut,
  User,
  GraduationCap,
  Baby,
} from 'lucide-react';

interface HeaderProps {
  onMenuToggle?: () => void;
}

export const Header: React.FC<HeaderProps> = ({ onMenuToggle }) => {
  const {
    currentUser,
    logout,
    activeTeacherAssignment,
    setActiveTeacherAssignment,
    selectedChildId,
    setSelectedChildId,
  } = useAuth();
  const { currentTenant } = useTenant();

  return (
    <header className="bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 px-4 py-2.5 flex items-center justify-between gap-3 sticky top-0 z-30">
      {/* Left: Mobile Toggle & Brand/Tenant info */}
      <div className="flex items-center gap-3">
        {onMenuToggle && (
          <button
            type="button"
            onClick={onMenuToggle}
            className="md:hidden p-2 rounded-xl text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
            aria-label="Toggle navigation menu"
          >
            <Menu className="w-5 h-5" />
          </button>
        )}

        {/* School / Tenant Banner */}
        {currentTenant ? (
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-blue-50 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-800 flex items-center justify-center font-bold text-blue-700 dark:text-blue-300 text-sm shrink-0 overflow-hidden">
              {currentTenant.logo_url ? (
                <img
                  src={currentTenant.logo_url}
                  alt={currentTenant.name}
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
              ) : (
                <GraduationCap className="w-5 h-5" />
              )}
            </div>
            <div className="flex flex-col">
              <span className="font-bold text-sm text-slate-900 dark:text-white leading-tight truncate max-w-[200px] sm:max-w-none">
                {currentTenant.name}
              </span>
              <div className="flex items-center gap-1.5 text-[11px] text-slate-500 dark:text-slate-400">
                <span className="font-mono">NPSN: {currentTenant.npsn}</span>
                <span>•</span>
                <span className="font-semibold text-blue-600 dark:text-blue-400">
                  {currentTenant.type} (Akreditasi {currentTenant.accreditation || 'A'})
                </span>
              </div>
            </div>
          </div>
        ) : (
          <ScolaBrand size="sm" />
        )}
      </div>

      {/* Middle: Dynamic Teacher Assignment Switcher OR Parent Child Selector */}
      <div className="hidden lg:flex items-center gap-2">
        {/* Guru dynamic assignment switcher */}
        {currentUser?.role === 'GURU' && currentUser.assignments && (
          <div className="flex items-center gap-1.5 bg-slate-100 dark:bg-slate-800/60 p-1 rounded-xl border border-slate-200 dark:border-slate-700 text-xs">
            <span className="text-[11px] font-semibold text-slate-500 px-1">
              Mode Tugas Guru:
            </span>
            {currentUser.assignments.map((asg) => (
              <AssignmentPill
                key={asg.id}
                type={asg.type}
                active={asg.active}
                selected={activeTeacherAssignment === asg.type}
                onClick={() => setActiveTeacherAssignment(asg.type)}
              />
            ))}
          </div>
        )}

        {/* Orang Tua child selector */}
        {currentUser?.role === 'ORANG_TUA' && currentUser.linked_students && (
          <div className="flex items-center gap-1.5 bg-amber-50 dark:bg-amber-950/40 p-1.5 rounded-xl border border-amber-200 dark:border-amber-800 text-xs">
            <Baby className="w-4 h-4 text-amber-600" />
            <span className="font-semibold text-amber-900 dark:text-amber-200">
              Pilih Anak:
            </span>
            <select
              value={selectedChildId || ''}
              onChange={(e) => setSelectedChildId(e.target.value)}
              className="bg-white dark:bg-slate-900 border border-amber-300 dark:border-amber-700 rounded-lg px-2 py-0.5 font-semibold text-xs text-slate-800 dark:text-white"
            >
              {currentUser.linked_students.map((child) => (
                <option key={child.id} value={child.id}>
                  {child.full_name} ({child.class_name || 'Kelas'})
                </option>
              ))}
            </select>
          </div>
        )}
      </div>

      {/* Right: User Profile & Logout */}
      <div className="flex items-center gap-3">
        {currentUser && (
          <div className="flex items-center gap-2.5">
            <div className="flex flex-col text-right hidden sm:flex">
              <span className="text-xs font-bold text-slate-900 dark:text-white leading-tight">
                {currentUser.full_name}
              </span>
              <div className="flex items-center justify-end gap-1 mt-0.5">
                <RoleBadge role={currentUser.role} size="sm" />
              </div>
            </div>
            <div className="w-9 h-9 rounded-full bg-slate-200 dark:bg-slate-700 flex items-center justify-center font-bold text-slate-700 dark:text-slate-200 border border-slate-300 dark:border-slate-600 text-xs">
              <User className="w-4 h-4" />
            </div>
            <button
              type="button"
              onClick={logout}
              className="p-2 rounded-xl text-slate-500 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40 transition-colors cursor-pointer"
              title="Keluar dari sesi (Sign Out)"
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        )}
      </div>
    </header>
  );
};
