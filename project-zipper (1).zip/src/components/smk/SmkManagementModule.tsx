import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useTenant } from '../../context/TenantContext';
import {
  SMKProgramKeahlian,
  SMKPklRecord,
  SMKUKKRecord,
  SMKIndustryPartner,
  SMKPklJournal,
  SMKPklAttendance,
  SMKPklAssessment,
  SMKBkkJob,
  SMKTracerStudy,
  StudentProfile,
  UserProfile,
} from '../../types';
import { academicRepository } from '../../repositories/academicRepository';
import {
  Briefcase,
  Building2,
  Users,
  GraduationCap,
  Award,
  CheckCircle2,
  Clock,
  FileSpreadsheet,
  Plus,
  Search,
  ExternalLink,
  ChevronRight,
  TrendingUp,
  MapPin,
  FileCheck,
  Calendar,
  AlertCircle,
  X,
} from 'lucide-react';

interface SmkManagementModuleProps {
  initialTab?: 'programs' | 'pkl' | 'career_alumni' | 'ukk';
}

export const SmkManagementModule: React.FC<SmkManagementModuleProps> = ({
  initialTab = 'programs',
}) => {
  const { currentUser } = useAuth();
  const { currentTenant } = useTenant();

  const [activeTab, setActiveTab] = useState<'programs' | 'pkl' | 'career_alumni' | 'ukk'>(initialTab);
  const [pklSubTab, setPklSubTab] = useState<'placements' | 'partners' | 'journals' | 'attendance' | 'assessments'>('placements');

  const [programs, setPrograms] = useState<SMKProgramKeahlian[]>([]);
  const [pklRecords, setPklRecords] = useState<SMKPklRecord[]>([]);
  const [partners, setPartners] = useState<SMKIndustryPartner[]>([]);
  const [journals, setJournals] = useState<SMKPklJournal[]>([]);
  const [attendance, setAttendance] = useState<SMKPklAttendance[]>([]);
  const [assessments, setAssessments] = useState<SMKPklAssessment[]>([]);
  const [bkkJobs, setBkkJobs] = useState<SMKBkkJob[]>([]);
  const [tracerList, setTracerList] = useState<SMKTracerStudy[]>([]);
  const [ukkRecords, setUkkRecords] = useState<SMKUKKRecord[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  // Modal State for Adding Industry Partner
  const [showAddPartnerModal, setShowAddPartnerModal] = useState(false);
  const [newPartnerName, setNewPartnerName] = useState('');
  const [newPartnerSector, setNewPartnerSector] = useState('Software House & Digital Services');
  const [newPartnerCity, setNewPartnerCity] = useState('');
  const [newPartnerPic, setNewPartnerPic] = useState('');
  const [newPartnerPhone, setNewPartnerPhone] = useState('');
  const [newPartnerQuota, setNewPartnerQuota] = useState(10);
  const [newPartnerMou, setNewPartnerMou] = useState('');
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  // Modal State for Verifying Journal
  const [selectedJournal, setSelectedJournal] = useState<SMKPklJournal | null>(null);
  const [journalMentorNotes, setJournalMentorNotes] = useState('');

  const loadData = async () => {
    if (!currentTenant) return;
    setIsLoading(true);
    try {
      const [
        progData,
        pklData,
        partnerData,
        jrnData,
        attData,
        assData,
        jobsData,
        tracerData,
        ukkData,
      ] = await Promise.all([
        academicRepository.getSmkProgramsByTenant(currentTenant.id, currentUser),
        academicRepository.getSmkPklRecords(currentTenant.id, currentUser),
        academicRepository.getSmkPartners(currentTenant.id, currentUser),
        academicRepository.getSmkPklJournals(currentTenant.id, currentUser),
        academicRepository.getSmkPklAttendance(currentTenant.id, currentUser),
        academicRepository.getSmkPklAssessments(currentTenant.id),
        academicRepository.getBkkJobs(currentTenant.id),
        academicRepository.getTracerStudies(currentTenant.id),
        academicRepository.getSmkUkkRecords(currentTenant.id, currentUser),
      ]);

      setPrograms(progData);
      setPklRecords(pklData);
      setPartners(partnerData);
      setJournals(jrnData);
      setAttendance(attData);
      setAssessments(assData);
      setBkkJobs(jobsData);
      setTracerList(tracerData);
      setUkkRecords(ukkData);
    } catch (err) {
      console.error('Error loading SMK data:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, [currentTenant?.id]);

  const handleCreatePartner = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentTenant || !currentUser) return;
    try {
      await academicRepository.createSmkPartner(
        {
          tenant_id: currentTenant.id,
          name: newPartnerName,
          industry_sector: newPartnerSector,
          address: `Kawasan Industri ${newPartnerCity}`,
          city: newPartnerCity,
          pic_name: newPartnerPic,
          pic_role: 'HR & Internship Coordinator',
          pic_phone: newPartnerPhone,
          pic_email: `contact@${newPartnerName.toLowerCase().replace(/[^a-z0-9]/g, '')}.com`,
          quota: newPartnerQuota,
          active_interns_count: 0,
          mou_number: newPartnerMou || `MoU/DUDI/${Date.now().toString().slice(-4)}`,
          mou_valid_until: '2027-12-31',
          is_active: true,
        },
        currentUser
      );
      setSuccessMsg(`Mitra DUDI ${newPartnerName} berhasil didaftarkan.`);
      setShowAddPartnerModal(false);
      setNewPartnerName('');
      setNewPartnerCity('');
      setNewPartnerPic('');
      setNewPartnerPhone('');
      await loadData();
    } catch (err: any) {
      alert(err.message || 'Gagal menambahkan mitra industri');
    }
  };

  const handleVerifyJournal = async (journalId: string, approve: boolean) => {
    if (!currentUser) return;
    try {
      await academicRepository.verifyPklJournal(
        journalId,
        {
          mentor_verified: approve,
          school_supervisor_reviewed: true,
          mentor_notes: journalMentorNotes || (approve ? 'Disetujui pembimbing.' : 'Perlu revisi penulisan.'),
        },
        currentUser
      );
      setSelectedJournal(null);
      setJournalMentorNotes('');
      setSuccessMsg('Status verifikasi jurnal berhasil diperbarui.');
      await loadData();
    } catch (err: any) {
      alert(err.message || 'Gagal memverifikasi jurnal');
    }
  };

  // Metrics calculation
  const totalInterns = pklRecords.length;
  const activeInterns = pklRecords.filter((p) => p.status === 'BERLANGSUNG').length;
  const completedInterns = pklRecords.filter((p) => p.status === 'SELESAI').length;
  const totalPartners = partners.length;
  const totalBkkOpenings = bkkJobs.filter((j) => j.status === 'OPEN').length;

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="p-6 rounded-3xl bg-gradient-to-r from-amber-600 via-orange-600 to-amber-700 text-white shadow-xl relative overflow-hidden">
        <div className="absolute right-0 top-0 translate-x-8 -translate-y-8 w-64 h-64 bg-white/10 rounded-full blur-2xl pointer-events-none" />
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/20 backdrop-blur-md text-[11px] font-bold tracking-wide uppercase">
              <Briefcase className="w-3.5 h-3.5" />
              <span>Modul Khusus SMK Kejuruan</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-black tracking-tight">
              Program Keahlian, PKL & Penelusuran Karir
            </h2>
            <p className="text-xs text-amber-100 max-w-2xl leading-relaxed">
              Manajemen komprehensif kemitraan Dunia Usaha & Dunia Industri (DUDI), penempatan magang PKL, verifikasi logbook harian, serta penelusuran lulusan BMW (Bekerja, Melanjutkan, Wirausaha).
            </p>
          </div>

          <div className="flex flex-wrap gap-2">
            <button
              type="button"
              onClick={() => setShowAddPartnerModal(true)}
              className="px-4 py-2.5 bg-white text-amber-900 hover:bg-amber-50 text-xs font-bold rounded-xl transition-all shadow-md flex items-center gap-2 cursor-pointer"
            >
              <Plus className="w-4 h-4 text-amber-600" />
              <span>Tambah Mitra DUDI</span>
            </button>
          </div>
        </div>
      </div>

      {/* Success Notification */}
      {successMsg && (
        <div className="p-4 rounded-2xl bg-emerald-50 text-emerald-800 border border-emerald-200 text-xs font-bold flex items-center justify-between">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>{successMsg}</span>
          </div>
          <button type="button" onClick={() => setSuccessMsg(null)} className="cursor-pointer">
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Key Metrics */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-1">
          <div className="flex items-center justify-between text-slate-500 text-xs font-semibold">
            <span>Program Keahlian</span>
            <GraduationCap className="w-4 h-4 text-amber-500" />
          </div>
          <div className="text-2xl font-black text-slate-900 dark:text-white">
            {programs.length} Jurusan
          </div>
          <p className="text-[11px] text-slate-400">Terdaftar di tenant</p>
        </div>

        <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-1">
          <div className="flex items-center justify-between text-slate-500 text-xs font-semibold">
            <span>Mitra Industri (DUDI)</span>
            <Building2 className="w-4 h-4 text-blue-500" />
          </div>
          <div className="text-2xl font-black text-slate-900 dark:text-white">
            {totalPartners} Perusahaan
          </div>
          <p className="text-[11px] text-emerald-600 font-medium">MoU Aktif & Terverifikasi</p>
        </div>

        <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-1">
          <div className="flex items-center justify-between text-slate-500 text-xs font-semibold">
            <span>Siswa Sedang PKL</span>
            <Clock className="w-4 h-4 text-indigo-500" />
          </div>
          <div className="text-2xl font-black text-indigo-600 dark:text-indigo-400">
            {activeInterns} Siswa
          </div>
          <p className="text-[11px] text-slate-400">{completedInterns} telah lulus magang</p>
        </div>

        <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-1">
          <div className="flex items-center justify-between text-slate-500 text-xs font-semibold">
            <span>Lowongan BKK Aktif</span>
            <TrendingUp className="w-4 h-4 text-emerald-500" />
          </div>
          <div className="text-2xl font-black text-emerald-600 dark:text-emerald-400">
            {totalBkkOpenings} Posisi
          </div>
          <p className="text-[11px] text-slate-400">Magang & Rekrutmen Baru</p>
        </div>
      </div>

      {/* Main Module Tabs */}
      <div className="flex border-b border-slate-200 dark:border-slate-800 gap-2 overflow-x-auto pb-1">
        <button
          type="button"
          onClick={() => setActiveTab('programs')}
          className={`px-4 py-2.5 rounded-xl text-xs font-bold transition-all whitespace-nowrap cursor-pointer flex items-center gap-2 ${
            activeTab === 'programs'
              ? 'bg-amber-500 text-white shadow-md'
              : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
          }`}
        >
          <GraduationCap className="w-4 h-4" />
          <span>Program & Kompetensi Keahlian</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('pkl')}
          className={`px-4 py-2.5 rounded-xl text-xs font-bold transition-all whitespace-nowrap cursor-pointer flex items-center gap-2 ${
            activeTab === 'pkl'
              ? 'bg-amber-500 text-white shadow-md'
              : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
          }`}
        >
          <Briefcase className="w-4 h-4" />
          <span>Struktur PKL (Praktik Kerja Lapangan)</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('career_alumni')}
          className={`px-4 py-2.5 rounded-xl text-xs font-bold transition-all whitespace-nowrap cursor-pointer flex items-center gap-2 ${
            activeTab === 'career_alumni'
              ? 'bg-amber-500 text-white shadow-md'
              : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
          }`}
        >
          <TrendingUp className="w-4 h-4" />
          <span>BKK & Tracer Study Alumni</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('ukk')}
          className={`px-4 py-2.5 rounded-xl text-xs font-bold transition-all whitespace-nowrap cursor-pointer flex items-center gap-2 ${
            activeTab === 'ukk'
              ? 'bg-amber-500 text-white shadow-md'
              : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
          }`}
        >
          <Award className="w-4 h-4" />
          <span>Sertifikasi UKK & LSP-P1</span>
        </button>
      </div>

      {/* Tab 1: Program Keahlian */}
      {activeTab === 'programs' && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {programs.map((prog) => (
              <div
                key={prog.id}
                className="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm hover:border-amber-400 transition-all space-y-4"
              >
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <span className="text-[10px] font-bold text-amber-600 dark:text-amber-400 uppercase tracking-wider">
                      {prog.bidang_keahlian}
                    </span>
                    <h3 className="text-lg font-black text-slate-900 dark:text-white">
                      {prog.program_keahlian}
                    </h3>
                  </div>
                  <span className="px-3 py-1 rounded-full bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300 text-[11px] font-bold">
                    {prog.industrial_partners} Mitra DUDI
                  </span>
                </div>

                {/* Konsentrasi Keahlian */}
                <div className="space-y-1.5">
                  <div className="text-[11px] font-bold text-slate-500 uppercase">Konsentrasi Keahlian:</div>
                  <div className="flex flex-wrap gap-1.5">
                    {prog.konsentrasi_keahlian.map((item, idx) => (
                      <span
                        key={idx}
                        className="px-2.5 py-1 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 text-xs font-medium"
                      >
                        {item}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Kaprog assignment */}
                <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs">
                  <div className="flex items-center gap-2">
                    <div className="w-7 h-7 rounded-full bg-amber-500 text-white flex items-center justify-center font-black text-xs">
                      KP
                    </div>
                    <div>
                      <div className="text-[10px] text-slate-400">Kepala Program Keahlian:</div>
                      <div className="font-bold text-slate-800 dark:text-slate-200">
                        {prog.kaprog_name || 'Ir. Hendra Kurniawan, M.Kom.'}
                      </div>
                    </div>
                  </div>
                  <span className="text-[11px] font-bold text-emerald-600 bg-emerald-50 dark:bg-emerald-950 px-2 py-0.5 rounded-md">
                    SK Aktif
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tab 2: Struktur PKL */}
      {activeTab === 'pkl' && (
        <div className="space-y-4">
          {/* Sub-Tabs for PKL */}
          <div className="flex gap-2 p-1.5 bg-slate-100 dark:bg-slate-800 rounded-2xl w-fit">
            <button
              type="button"
              onClick={() => setPklSubTab('placements')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                pklSubTab === 'placements'
                  ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs'
                  : 'text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
              }`}
            >
              Penempatan Siswa ({pklRecords.length})
            </button>
            <button
              type="button"
              onClick={() => setPklSubTab('partners')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                pklSubTab === 'partners'
                  ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs'
                  : 'text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
              }`}
            >
              Mitra Industri DUDI ({partners.length})
            </button>
            <button
              type="button"
              onClick={() => setPklSubTab('journals')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                pklSubTab === 'journals'
                  ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs'
                  : 'text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
              }`}
            >
              Jurnal Harian ({journals.length})
            </button>
            <button
              type="button"
              onClick={() => setPklSubTab('attendance')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                pklSubTab === 'attendance'
                  ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs'
                  : 'text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
              }`}
            >
              Presensi PKL ({attendance.length})
            </button>
            <button
              type="button"
              onClick={() => setPklSubTab('assessments')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                pklSubTab === 'assessments'
                  ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs'
                  : 'text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
              }`}
            >
              Penilaian & Sertifikat ({assessments.length})
            </button>
          </div>

          {/* SubTab: Placements */}
          {pklSubTab === 'placements' && (
            <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 overflow-hidden shadow-xs">
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-50 dark:bg-slate-800/60 text-slate-400 font-bold uppercase text-[10px] tracking-wider border-b border-slate-200 dark:border-slate-800">
                    <tr>
                      <th className="py-3.5 px-4">Siswa Magang</th>
                      <th className="py-3.5 px-4">Industri Mitra</th>
                      <th className="py-3.5 px-4">Pembimbing Sekolah</th>
                      <th className="py-3.5 px-4">Pembimbing Industri</th>
                      <th className="py-3.5 px-4">Periode</th>
                      <th className="py-3.5 px-4">Status</th>
                      <th className="py-3.5 px-4 text-right">Nilai Akhir</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                    {pklRecords.map((pkl) => (
                      <tr key={pkl.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/40 transition-colors">
                        <td className="py-3.5 px-4">
                          <div className="font-bold text-slate-900 dark:text-white">
                            {pkl.student_name}
                          </div>
                          <div className="text-[10px] text-slate-400">ID: {pkl.student_id}</div>
                        </td>
                        <td className="py-3.5 px-4">
                          <div className="font-semibold text-slate-800 dark:text-slate-200 flex items-center gap-1.5">
                            <Building2 className="w-3.5 h-3.5 text-blue-500" />
                            <span>{pkl.company_name}</span>
                          </div>
                        </td>
                        <td className="py-3.5 px-4 text-slate-600 dark:text-slate-300">
                          {pkl.school_supervisor_name}
                        </td>
                        <td className="py-3.5 px-4 text-slate-600 dark:text-slate-300">
                          {pkl.industry_mentor}
                        </td>
                        <td className="py-3.5 px-4 text-slate-500 font-mono text-[11px]">
                          {pkl.start_date} s/d {pkl.end_date}
                        </td>
                        <td className="py-3.5 px-4">
                          <span
                            className={`px-2.5 py-1 rounded-full text-[10px] font-bold ${
                              pkl.status === 'BERLANGSUNG'
                                ? 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300'
                                : pkl.status === 'SELESAI'
                                ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                                : 'bg-slate-100 text-slate-800 dark:bg-slate-800 dark:text-slate-300'
                            }`}
                          >
                            {pkl.status}
                          </span>
                        </td>
                        <td className="py-3.5 px-4 text-right font-black text-slate-900 dark:text-white">
                          {pkl.grade ? `${pkl.grade}/100` : '-'}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* SubTab: Partners */}
          {pklSubTab === 'partners' && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {partners.map((partner) => (
                <div
                  key={partner.id}
                  className="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-3"
                >
                  <div className="flex items-start justify-between">
                    <div>
                      <h4 className="text-base font-black text-slate-900 dark:text-white">
                        {partner.name}
                      </h4>
                      <div className="text-xs text-amber-600 dark:text-amber-400 font-medium">
                        {partner.industry_sector}
                      </div>
                    </div>
                    <span className="px-2.5 py-1 rounded-full bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300 text-[10px] font-bold">
                      MoU Aktif
                    </span>
                  </div>

                  <div className="space-y-1.5 text-xs text-slate-600 dark:text-slate-300">
                    <div className="flex items-center gap-2">
                      <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                      <span>{partner.address}, {partner.city}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Users className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                      <span>PIC: {partner.pic_name} ({partner.pic_role})</span>
                    </div>
                    <div className="flex items-center gap-2 font-mono text-[11px]">
                      <FileCheck className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                      <span>No. MoU: {partner.mou_number}</span>
                    </div>
                  </div>

                  <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs">
                    <span className="text-slate-400">
                      Kuota Siswa: <strong className="text-slate-800 dark:text-slate-200">{partner.active_interns_count} / {partner.quota}</strong>
                    </span>
                    <span className="text-[11px] text-slate-400">
                      Berlaku s/d: {partner.mou_valid_until}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* SubTab: Journals */}
          {pklSubTab === 'journals' && (
            <div className="space-y-3">
              {journals.map((j) => (
                <div
                  key={j.id}
                  className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-3"
                >
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-xl bg-amber-100 dark:bg-amber-950 text-amber-700 dark:text-amber-300 flex items-center justify-center font-bold text-xs shrink-0">
                        {j.date.slice(-2)}
                      </div>
                      <div>
                        <div className="text-xs font-bold text-slate-900 dark:text-white">
                          {j.activity_title}
                        </div>
                        <div className="text-[11px] text-slate-400">
                          Oleh: <strong className="text-slate-600 dark:text-slate-300">{j.student_name}</strong> • Tanggal: {j.date}
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      {j.mentor_verified ? (
                        <span className="px-2.5 py-1 rounded-full bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300 text-[10px] font-bold flex items-center gap-1">
                          <CheckCircle2 className="w-3 h-3" /> Diverifikasi Mentor
                        </span>
                      ) : (
                        <span className="px-2.5 py-1 rounded-full bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300 text-[10px] font-bold flex items-center gap-1">
                          <Clock className="w-3 h-3" /> Menunggu Verifikasi
                        </span>
                      )}

                      {!j.mentor_verified && (
                        <button
                          type="button"
                          onClick={() => {
                            setSelectedJournal(j);
                            setJournalMentorNotes(j.mentor_notes || '');
                          }}
                          className="px-3 py-1 rounded-xl bg-amber-500 hover:bg-amber-600 text-white text-[11px] font-bold cursor-pointer"
                        >
                          Review / Verifikasi
                        </button>
                      )}
                    </div>
                  </div>

                  <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed bg-slate-50 dark:bg-slate-800/50 p-3 rounded-xl">
                    {j.activity_description}
                  </p>

                  <div className="text-[11px] text-slate-500 flex flex-wrap gap-2">
                    <span>Kompetensi Terapan: <strong className="text-slate-700 dark:text-slate-200">{j.competencies_learned}</strong></span>
                    {j.mentor_notes && (
                      <span className="text-amber-700 dark:text-amber-400 italic">• Catatan Mentor: "{j.mentor_notes}"</span>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* SubTab: Attendance */}
          {pklSubTab === 'attendance' && (
            <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 overflow-hidden shadow-xs">
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-50 dark:bg-slate-800/60 text-slate-400 font-bold uppercase text-[10px] tracking-wider border-b border-slate-200 dark:border-slate-800">
                    <tr>
                      <th className="py-3 px-4">Tanggal</th>
                      <th className="py-3 px-4">Nama Siswa</th>
                      <th className="py-3 px-4">Jam Masuk</th>
                      <th className="py-3 px-4">Jam Pulang</th>
                      <th className="py-3 px-4">Status</th>
                      <th className="py-3 px-4">Validasi Mentor</th>
                      <th className="py-3 px-4">Keterangan</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                    {attendance.map((att) => (
                      <tr key={att.id}>
                        <td className="py-3 px-4 font-mono font-medium">{att.date}</td>
                        <td className="py-3 px-4 font-bold text-slate-900 dark:text-white">{att.student_name}</td>
                        <td className="py-3 px-4 font-mono text-emerald-600">{att.check_in_time}</td>
                        <td className="py-3 px-4 font-mono text-blue-600">{att.check_out_time}</td>
                        <td className="py-3 px-4">
                          <span className="px-2 py-0.5 rounded-md bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300 text-[10px] font-bold">
                            {att.status}
                          </span>
                        </td>
                        <td className="py-3 px-4">
                          {att.verified_by_mentor ? (
                            <span className="text-emerald-600 font-bold text-[11px] flex items-center gap-1">
                              <CheckCircle2 className="w-3.5 h-3.5" /> Terverifikasi
                            </span>
                          ) : (
                            <span className="text-slate-400 text-[11px]">Pending</span>
                          )}
                        </td>
                        <td className="py-3 px-4 text-slate-500 text-[11px]">{att.notes || '-'}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* SubTab: Assessments */}
          {pklSubTab === 'assessments' && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {assessments.map((ass) => (
                <div
                  key={ass.id}
                  className="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-3"
                >
                  <div className="flex items-start justify-between">
                    <div>
                      <h4 className="text-base font-black text-slate-900 dark:text-white">
                        {ass.student_name}
                      </h4>
                      <div className="text-xs text-slate-400 font-mono">
                        {ass.certificate_number}
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-2xl font-black text-emerald-600 dark:text-emerald-400">
                        {ass.final_score}
                      </div>
                      <div className="text-[10px] font-bold text-slate-400">Predikat: {ass.letter_grade} (Sangat Baik)</div>
                    </div>
                  </div>

                  {/* Score breakdown */}
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-center text-xs">
                    <div className="p-2 bg-slate-50 dark:bg-slate-800 rounded-xl">
                      <div className="text-[10px] text-slate-400">Teknis</div>
                      <div className="font-black text-slate-800 dark:text-slate-200">{ass.technical_competence_score}</div>
                    </div>
                    <div className="p-2 bg-slate-50 dark:bg-slate-800 rounded-xl">
                      <div className="text-[10px] text-slate-400">Soft Skills</div>
                      <div className="font-black text-slate-800 dark:text-slate-200">{ass.work_ethic_score}</div>
                    </div>
                    <div className="p-2 bg-slate-50 dark:bg-slate-800 rounded-xl">
                      <div className="text-[10px] text-slate-400">Disiplin</div>
                      <div className="font-black text-slate-800 dark:text-slate-200">{ass.discipline_attendance_score}</div>
                    </div>
                    <div className="p-2 bg-slate-50 dark:bg-slate-800 rounded-xl">
                      <div className="text-[10px] text-slate-400">Kerjasama</div>
                      <div className="font-black text-slate-800 dark:text-slate-200">{ass.communication_teamwork_score}</div>
                    </div>
                  </div>

                  <p className="text-xs text-slate-600 dark:text-slate-300 italic bg-amber-50 dark:bg-amber-950/40 p-3 rounded-xl border border-amber-200/40">
                    "{ass.mentor_comment}"
                  </p>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Tab 3: Career & Alumni (BKK & Tracer Study) */}
      {activeTab === 'career_alumni' && (
        <div className="space-y-6">
          {/* BKK Jobs */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <Briefcase className="w-4 h-4 text-amber-500" />
                <span>Bursa Kerja Khusus (BKK) & Peluang Industri</span>
              </h3>
              <span className="text-xs text-slate-500">Kerjasama Resmi DUDI</span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {bkkJobs.map((job) => (
                <div
                  key={job.id}
                  className="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs flex flex-col justify-between space-y-3"
                >
                  <div className="space-y-2">
                    <div className="flex items-start justify-between gap-2">
                      <span className="px-2.5 py-0.5 rounded-md bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300 text-[10px] font-bold">
                        {job.job_type}
                      </span>
                      <span className="text-[10px] text-slate-400 font-mono">Batas: {job.deadline}</span>
                    </div>

                    <h4 className="text-sm font-black text-slate-900 dark:text-white">
                      {job.job_title}
                    </h4>
                    <div className="text-xs font-semibold text-blue-600 flex items-center gap-1">
                      <Building2 className="w-3.5 h-3.5" />
                      <span>{job.company_name}</span>
                    </div>
                    <p className="text-xs text-slate-500 leading-relaxed">
                      {job.description}
                    </p>

                    <div className="space-y-1">
                      <div className="text-[10px] font-bold text-slate-400 uppercase">Persyaratan:</div>
                      <ul className="text-[11px] text-slate-600 dark:text-slate-300 list-disc list-inside space-y-0.5">
                        {job.requirements.map((req, i) => (
                          <li key={i}>{req}</li>
                        ))}
                      </ul>
                    </div>
                  </div>

                  <div className="pt-2 border-t border-slate-100 dark:border-slate-800">
                    <a
                      href={`mailto:${job.contact_or_apply_url}`}
                      className="w-full py-2 bg-amber-500 hover:bg-amber-600 text-white rounded-xl text-xs font-bold transition-all text-center block"
                    >
                      Lamar via BKK Sekolah
                    </a>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Tracer Study BMW */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
                  <TrendingUp className="w-4 h-4 text-emerald-500" />
                  <span>Tracer Study Alumni (BMW: Bekerja, Melanjutkan, Wirausaha)</span>
                </h3>
                <p className="text-xs text-slate-500">Penelusuran serapan lulusan SMK di industri dan perguruan tinggi</p>
              </div>
            </div>

            <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 overflow-hidden shadow-xs">
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-50 dark:bg-slate-800/60 text-slate-400 font-bold uppercase text-[10px] tracking-wider border-b border-slate-200 dark:border-slate-800">
                    <tr>
                      <th className="py-3 px-4">Nama Alumni</th>
                      <th className="py-3 px-4">Jurusan & Tahun Lulus</th>
                      <th className="py-3 px-4">Status BMW</th>
                      <th className="py-3 px-4">Perusahaan / Kampus</th>
                      <th className="py-3 px-4">Posisi / Program Studi</th>
                      <th className="py-3 px-4">Rentang Penghasilan</th>
                      <th className="py-3 px-4 text-right">Relevansi Kurikulum</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                    {tracerList.map((trc) => (
                      <tr key={trc.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/40 transition-colors">
                        <td className="py-3.5 px-4 font-bold text-slate-900 dark:text-white">
                          {trc.student_name}
                        </td>
                        <td className="py-3.5 px-4 text-slate-600 dark:text-slate-300">
                          {trc.program_name} ({trc.graduation_year})
                        </td>
                        <td className="py-3.5 px-4">
                          <span
                            className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold ${
                              trc.status === 'BEKERJA'
                                ? 'bg-blue-100 text-blue-800 dark:bg-blue-950 dark:text-blue-300'
                                : trc.status === 'MELANJUTKAN'
                                ? 'bg-purple-100 text-purple-800 dark:bg-purple-950 dark:text-purple-300'
                                : 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                            }`}
                          >
                            {trc.status}
                          </span>
                        </td>
                        <td className="py-3.5 px-4 font-semibold text-slate-800 dark:text-slate-200">
                          {trc.institution_or_company}
                        </td>
                        <td className="py-3.5 px-4 text-slate-600 dark:text-slate-300">
                          {trc.position_or_major}
                        </td>
                        <td className="py-3.5 px-4 font-mono text-[11px] text-slate-500">
                          {trc.monthly_income_range || '-'}
                        </td>
                        <td className="py-3.5 px-4 text-right font-black text-amber-500">
                          {'★'.repeat(trc.curriculum_relevance_rating)}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Tab 4: Sertifikasi UKK & LSP */}
      {activeTab === 'ukk' && (
        <div className="space-y-4">
          <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 overflow-hidden shadow-xs">
            <div className="p-4 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between">
              <div>
                <h4 className="text-sm font-bold text-slate-900 dark:text-white">
                  Daftar Uji Kompetensi Keahlian (UKK) & Sertifikasi BNSP
                </h4>
                <p className="text-xs text-slate-500">Pengujian kompetensi standar industri LSP Pihak Pertama (LSP-P1)</p>
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 dark:bg-slate-800/60 text-slate-400 font-bold uppercase text-[10px] tracking-wider border-b border-slate-200 dark:border-slate-800">
                  <tr>
                    <th className="py-3 px-4">Nama Siswa</th>
                    <th className="py-3 px-4">Skema Sertifikasi</th>
                    <th className="py-3 px-4">Penguji Internal</th>
                    <th className="py-3 px-4">Asesor Eksternal (Industri)</th>
                    <th className="py-3 px-4">Tanggal Ujian</th>
                    <th className="py-3 px-4">Status</th>
                    <th className="py-3 px-4 text-right">Skor Akhir</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {ukkRecords.map((ukk) => (
                    <tr key={ukk.id}>
                      <td className="py-3.5 px-4 font-bold text-slate-900 dark:text-white">
                        {ukk.student_name}
                      </td>
                      <td className="py-3.5 px-4 font-medium text-slate-800 dark:text-slate-200">
                        {ukk.scheme_name}
                      </td>
                      <td className="py-3.5 px-4 text-slate-600 dark:text-slate-300">
                        {ukk.examiner_internal}
                      </td>
                      <td className="py-3.5 px-4 text-slate-600 dark:text-slate-300">
                        {ukk.examiner_external} ({ukk.institution_partner})
                      </td>
                      <td className="py-3.5 px-4 font-mono text-[11px] text-slate-500">
                        {ukk.test_date}
                      </td>
                      <td className="py-3.5 px-4">
                        <span
                          className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold ${
                            ukk.status === 'KOMPETEN'
                              ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                              : 'bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-300'
                          }`}
                        >
                          {ukk.status}
                        </span>
                      </td>
                      <td className="py-3.5 px-4 text-right font-black text-slate-900 dark:text-white">
                        {ukk.score}/100
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* Modal: Tambah Mitra DUDI */}
      {showAddPartnerModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="bg-white dark:bg-slate-900 rounded-3xl max-w-lg w-full p-6 shadow-2xl border border-slate-200 dark:border-slate-800 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
              <h3 className="text-base font-black text-slate-900 dark:text-white flex items-center gap-2">
                <Building2 className="w-5 h-5 text-amber-500" />
                <span>Pendaftaran Mitra DUDI Baru</span>
              </h3>
              <button
                type="button"
                onClick={() => setShowAddPartnerModal(false)}
                className="p-1 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-400 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreatePartner} className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-700 dark:text-slate-300 font-bold mb-1">Nama Perusahaan / Industri</label>
                <input
                  type="text"
                  required
                  placeholder="contoh: PT Solusi Teknologi Nusantara"
                  value={newPartnerName}
                  onChange={(e) => setNewPartnerName(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-700 dark:text-slate-300 font-bold mb-1">Bidang / Sektor Usaha</label>
                  <input
                    type="text"
                    required
                    value={newPartnerSector}
                    onChange={(e) => setNewPartnerSector(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
                  />
                </div>
                <div>
                  <label className="block text-slate-700 dark:text-slate-300 font-bold mb-1">Kota / Lokasi</label>
                  <input
                    type="text"
                    required
                    placeholder="contoh: Jakarta Selatan"
                    value={newPartnerCity}
                    onChange={(e) => setNewPartnerCity(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-700 dark:text-slate-300 font-bold mb-1">Nama PIC Industri</label>
                  <input
                    type="text"
                    required
                    placeholder="contoh: Ir. Bambang, M.T."
                    value={newPartnerPic}
                    onChange={(e) => setNewPartnerPic(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
                  />
                </div>
                <div>
                  <label className="block text-slate-700 dark:text-slate-300 font-bold mb-1">Kontak WhatsApp / Telp</label>
                  <input
                    type="text"
                    required
                    placeholder="08123456789"
                    value={newPartnerPhone}
                    onChange={(e) => setNewPartnerPhone(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-700 dark:text-slate-300 font-bold mb-1">Kuota Siswa Magang</label>
                  <input
                    type="number"
                    min={1}
                    max={50}
                    value={newPartnerQuota}
                    onChange={(e) => setNewPartnerQuota(Number(e.target.value))}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
                  />
                </div>
                <div>
                  <label className="block text-slate-700 dark:text-slate-300 font-bold mb-1">Nomor Dokumen MoU</label>
                  <input
                    type="text"
                    placeholder="MoU/DUDI/2024/09"
                    value={newPartnerMou}
                    onChange={(e) => setNewPartnerMou(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
                  />
                </div>
              </div>

              <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowAddPartnerModal(false)}
                  className="px-4 py-2 rounded-xl border border-slate-200 dark:border-slate-700 font-bold text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-600 text-white font-bold cursor-pointer"
                >
                  Simpan & Daftarkan MoU
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal: Verifikasi Jurnal PKL */}
      {selectedJournal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="bg-white dark:bg-slate-900 rounded-3xl max-w-lg w-full p-6 shadow-2xl border border-slate-200 dark:border-slate-800 space-y-4 text-xs">
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
              <h3 className="text-sm font-black text-slate-900 dark:text-white">
                Verifikasi Jurnal Kegiatan PKL Siswa
              </h3>
              <button
                type="button"
                onClick={() => setSelectedJournal(null)}
                className="p-1 rounded-lg hover:bg-slate-100 text-slate-400 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-2 bg-slate-50 dark:bg-slate-800/50 p-3 rounded-2xl">
              <div><strong>Siswa:</strong> {selectedJournal.student_name}</div>
              <div><strong>Tanggal:</strong> {selectedJournal.date}</div>
              <div><strong>Judul Kegiatan:</strong> {selectedJournal.activity_title}</div>
              <div><strong>Deskripsi:</strong> {selectedJournal.activity_description}</div>
              <div><strong>Kompetensi:</strong> {selectedJournal.competencies_learned}</div>
            </div>

            <div>
              <label className="block text-slate-700 dark:text-slate-300 font-bold mb-1">
                Catatan Evaluasi Pembimbing / Mentor:
              </label>
              <textarea
                rows={3}
                placeholder="Tuliskan catatan teknis atau masukan pembimbing..."
                value={journalMentorNotes}
                onChange={(e) => setJournalMentorNotes(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
              />
            </div>

            <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex justify-end gap-2">
              <button
                type="button"
                onClick={() => handleVerifyJournal(selectedJournal.id, false)}
                className="px-3.5 py-2 rounded-xl bg-rose-100 hover:bg-rose-200 text-rose-800 dark:bg-rose-950 dark:text-rose-300 font-bold cursor-pointer"
              >
                Perlu Perbaikan
              </button>
              <button
                type="button"
                onClick={() => handleVerifyJournal(selectedJournal.id, true)}
                className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold cursor-pointer"
              >
                Setujui & Paraf Jurnal
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
