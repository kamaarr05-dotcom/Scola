import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useTenant } from '../../context/TenantContext';
import { BKCounselingRecord, StudentProfile, StudentReportCard } from '../../types';
import { academicRepository } from '../../repositories/academicRepository';
import {
  HeartHandshake,
  AlertCircle,
  TrendingDown,
  CheckCircle2,
  Clock,
  Plus,
  Compass,
  FileText,
  User,
  X,
} from 'lucide-react';

export const BkDashboardView: React.FC = () => {
  const { currentUser } = useAuth();
  const { currentTenant } = useTenant();

  const [records, setRecords] = useState<BKCounselingRecord[]>([]);
  const [students, setStudents] = useState<StudentProfile[]>([]);
  const [reportCards, setReportCards] = useState<StudentReportCard[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  // New Counseling Record Modal
  const [showAddModal, setShowAddModal] = useState(false);
  const [studentName, setStudentName] = useState('');
  const [category, setCategory] = useState<'PRIBADI' | 'SOSIAL' | 'BELAJAR' | 'KARIR_STUDI_LANJUT'>('BELAJAR');
  const [issueSummary, setIssueSummary] = useState('');
  const [actionPlan, setActionPlan] = useState('');

  const loadData = async () => {
    if (!currentTenant) return;
    setIsLoading(true);
    try {
      const [bkData, stdData, rptData] = await Promise.all([
        academicRepository.getBkRecords(currentTenant.id),
        academicRepository.getStudentsByTenant(currentTenant.id, currentUser),
        academicRepository.getReportCards(currentTenant.id, currentUser),
      ]);

      setRecords(bkData);
      setStudents(stdData);
      setReportCards(rptData);
    } catch (err) {
      console.error('Error loading BK data:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, [currentTenant?.id]);

  const handleCreateRecord = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentTenant || !currentUser) return;
    try {
      await academicRepository.addBkRecord(
        {
          tenant_id: currentTenant.id,
          student_id: `std-${Date.now().toString().slice(-4)}`,
          student_name: studentName,
          class_name: 'X MIPA 1',
          counselor_name: currentUser.full_name,
          date: new Date().toISOString().split('T')[0],
          category,
          issue_summary: issueSummary,
          action_plan: actionPlan,
          status: 'IN_PROGRESS',
          confidentiality_level: 'STANDARD',
        },
        currentUser
      );
      setShowAddModal(false);
      setStudentName('');
      setIssueSummary('');
      setActionPlan('');
      await loadData();
    } catch (err: any) {
      alert(err.message || 'Gagal menyimpan catatan BK');
    }
  };

  const handleUpdateStatus = async (recordId: string, status: 'OPEN' | 'IN_PROGRESS' | 'RESOLVED') => {
    try {
      await academicRepository.updateBkRecordStatus(recordId, status);
      await loadData();
    } catch (err: any) {
      alert(err.message || 'Gagal memperbarui status');
    }
  };

  return (
    <div className="space-y-6">
      {/* Banner */}
      <div className="p-6 rounded-3xl bg-gradient-to-r from-teal-700 via-emerald-800 to-teal-900 text-white shadow-xl relative overflow-hidden">
        <div className="space-y-1">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/20 backdrop-blur-md text-[11px] font-bold uppercase">
            <HeartHandshake className="w-3.5 h-3.5" />
            <span>Modul Bimbingan & Konseling (BK)</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-black tracking-tight">
            Pemantauan Kesejahteraan, Akademik & Karir Siswa
          </h2>
          <p className="text-xs text-teal-100 max-w-2xl leading-relaxed">
            Deteksi dini siswa dengan ketidakhadiran beruntun (alpa), penurunan nilai drastis, pembimbingan pribadi/sosial, dispensasi izin resmi, dan konsultasi studi lanjut ke PTN / DUDI.
          </p>
        </div>
      </div>

      {/* Warning Detection Box */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Early Warning: Alpa Beruntun */}
        <div className="p-5 rounded-3xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900/50 space-y-3">
          <div className="flex items-center gap-2 text-rose-800 dark:text-rose-300 font-bold text-xs">
            <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
            <span>Deteksi Otomatis: Ketidakhadiran Beruntun (&gt; 2 Hari Alpa)</span>
          </div>
          <div className="space-y-2 text-xs">
            <div className="p-3 bg-white dark:bg-slate-900 rounded-2xl border border-rose-100 dark:border-rose-900/30 flex justify-between items-center">
              <div>
                <div className="font-bold text-slate-900 dark:text-white">Ahmad Rizky (X MIPA 1)</div>
                <div className="text-[11px] text-slate-400">3 Hari Alpa berurutan pekan ini</div>
              </div>
              <button
                type="button"
                onClick={() => {
                  setStudentName('Ahmad Rizky');
                  setCategory('BELAJAR');
                  setIssueSummary('Alpa 3 hari berturut-turut tanpa kabar');
                  setActionPlan('Panggilan orang tua dan bimbingan wali kelas');
                  setShowAddModal(true);
                }}
                className="px-3 py-1 bg-rose-600 hover:bg-rose-700 text-white font-bold rounded-xl text-[11px] cursor-pointer"
              >
                Tindak Lanjut BK
              </button>
            </div>
          </div>
        </div>

        {/* Warning: Nilai Drop */}
        <div className="p-5 rounded-3xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-900/50 space-y-3">
          <div className="flex items-center gap-2 text-amber-800 dark:text-amber-300 font-bold text-xs">
            <TrendingDown className="w-4 h-4 text-amber-600 shrink-0" />
            <span>Deteksi Otomatis: Penurunan Capaian Belajar / Remedial</span>
          </div>
          <div className="space-y-2 text-xs">
            <div className="p-3 bg-white dark:bg-slate-900 rounded-2xl border border-amber-100 dark:border-amber-900/30 flex justify-between items-center">
              <div>
                <div className="font-bold text-slate-900 dark:text-white">Dewi Anggraini (X MIPA 1)</div>
                <div className="text-[11px] text-slate-400">Nilai Matematika di bawah batas KKTP (68/75)</div>
              </div>
              <button
                type="button"
                onClick={() => {
                  setStudentName('Dewi Anggraini');
                  setCategory('BELAJAR');
                  setIssueSummary('Kesulitan memahami materi trigonometri dan remedial belum tuntas');
                  setActionPlan('Bimbingan belajar khusus dan koordinasi dengan guru matematika');
                  setShowAddModal(true);
                }}
                className="px-3 py-1 bg-amber-600 hover:bg-amber-700 text-white font-bold rounded-xl text-[11px] cursor-pointer"
              >
                Konseling Belajar
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Counseling Records List */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 overflow-hidden shadow-xs space-y-4">
        <div className="p-5 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between">
          <div>
            <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <FileText className="w-4 h-4 text-teal-600" />
              <span>Buku Catatan Log Bimbingan Konseling Siswa</span>
            </h3>
            <p className="text-xs text-slate-500">Tercatat secara rahasia dan aman sesuai kode etik bimbingan</p>
          </div>

          <button
            type="button"
            onClick={() => {
              setStudentName('');
              setIssueSummary('');
              setActionPlan('');
              setShowAddModal(true);
            }}
            className="px-4 py-2 bg-teal-600 hover:bg-teal-700 text-white rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer shadow-xs"
          >
            <Plus className="w-4 h-4" />
            <span>Tambah Catatan Konseling</span>
          </button>
        </div>

        <div className="p-5 space-y-3">
          {records.map((r) => (
            <div
              key={r.id}
              className="p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/40 space-y-3 text-xs"
            >
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-xl bg-teal-100 text-teal-800 dark:bg-teal-950 dark:text-teal-300 flex items-center justify-center font-bold text-xs">
                    BK
                  </div>
                  <div>
                    <div className="font-bold text-slate-900 dark:text-white">
                      {r.student_name} ({r.class_name})
                    </div>
                    <div className="text-[11px] text-slate-400">
                      Konselor: {r.counselor_name} • Tanggal: {r.date}
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <span className="px-2.5 py-0.5 rounded-full bg-teal-100 text-teal-800 dark:bg-teal-950 dark:text-teal-300 text-[10px] font-bold">
                    Kategori: {r.category}
                  </span>

                  <select
                    value={r.status}
                    onChange={(e) => handleUpdateStatus(r.id, e.target.value as any)}
                    className="p-1 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-[11px] font-bold"
                  >
                    <option value="OPEN">Terbuka / Baru</option>
                    <option value="IN_PROGRESS">Dalam Pembinaan</option>
                    <option value="RESOLVED">Selesai (Tuntas)</option>
                  </select>
                </div>
              </div>

              <div className="p-3 bg-white dark:bg-slate-900 rounded-xl space-y-1">
                <div className="font-semibold text-slate-800 dark:text-slate-200">
                  Pokok Permasalahan / Diskusi:
                </div>
                <p className="text-slate-600 dark:text-slate-400">{r.issue_summary}</p>
              </div>

              <div className="flex items-center justify-between text-[11px] text-slate-500">
                <span>Rencana Aksi / Solusi: <strong className="text-slate-700 dark:text-slate-300">{r.action_plan}</strong></span>
                {r.parent_notified && (
                  <span className="text-emerald-600 font-bold flex items-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5" /> Orang Tua Diberitahu
                  </span>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Modal Add Counseling */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="bg-white dark:bg-slate-900 rounded-3xl max-w-md w-full p-6 shadow-2xl border border-slate-200 dark:border-slate-800 space-y-4 text-xs">
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
              <h3 className="text-base font-black text-slate-900 dark:text-white flex items-center gap-2">
                <HeartHandshake className="w-5 h-5 text-teal-600" />
                <span>Formulir Konseling Siswa</span>
              </h3>
              <button
                type="button"
                onClick={() => setShowAddModal(false)}
                className="p-1 rounded-lg hover:bg-slate-100 text-slate-400 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateRecord} className="space-y-3">
              <div>
                <label className="block text-slate-700 dark:text-slate-300 font-bold mb-1">Nama Siswa</label>
                <input
                  type="text"
                  required
                  placeholder="Ahmad Rizky"
                  value={studentName}
                  onChange={(e) => setStudentName(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
                />
              </div>

              <div>
                <label className="block text-slate-700 dark:text-slate-300 font-bold mb-1">Bidang Bimbingan</label>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value as any)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 font-bold"
                >
                  <option value="BELAJAR">Bimbingan Belajar / Akademik</option>
                  <option value="PRIBADI">Bimbingan Pribadi & Karakter</option>
                  <option value="SOSIAL">Bimbingan Sosial & Relasi Teman</option>
                  <option value="KARIR_STUDI_LANJUT">Bimbingan Karir / Studi Lanjut PTN</option>
                </select>
              </div>

              <div>
                <label className="block text-slate-700 dark:text-slate-300 font-bold mb-1">Ringkasan Masalah / Topik Bimbingan</label>
                <textarea
                  rows={2}
                  required
                  value={issueSummary}
                  onChange={(e) => setIssueSummary(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
                />
              </div>

              <div>
                <label className="block text-slate-700 dark:text-slate-300 font-bold mb-1">Rencana Tindak Lanjut</label>
                <textarea
                  rows={2}
                  required
                  value={actionPlan}
                  onChange={(e) => setActionPlan(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
                />
              </div>

              <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 rounded-xl border border-slate-200 dark:border-slate-700 font-bold text-slate-600 dark:text-slate-400 cursor-pointer"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-teal-600 hover:bg-teal-700 text-white font-bold cursor-pointer"
                >
                  Simpan Catatan BK
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
