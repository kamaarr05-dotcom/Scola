import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useTenant } from '../../context/TenantContext';
import {
  SchoolClass,
  Subject,
  ClassSchedule,
  StudentDisciplineRecord,
  SchoolFacility,
  SMKIndustryPartner,
  UserProfile,
} from '../../types';
import { academicRepository } from '../../repositories/academicRepository';
import { teacherRepository } from '../../repositories/teacherRepository';
import {
  Award,
  BookOpen,
  Calendar,
  Users,
  ShieldAlert,
  Layers,
  Building2,
  CheckCircle2,
  AlertTriangle,
  Clock,
  FileSpreadsheet,
  Plus,
  Send,
  X,
} from 'lucide-react';

interface WakaDashboardViewProps {
  defaultField?: 'KURIKULUM' | 'KESISWAAN' | 'SARPRAS' | 'HUMAS';
}

export const WakaDashboardView: React.FC<WakaDashboardViewProps> = ({
  defaultField = 'KURIKULUM',
}) => {
  const { currentUser } = useAuth();
  const { currentTenant } = useTenant();

  const [activeField, setActiveField] = useState<'KURIKULUM' | 'KESISWAAN' | 'SARPRAS' | 'HUMAS'>(defaultField);
  const [classes, setClasses] = useState<SchoolClass[]>([]);
  const [subjects, setSubjects] = useState<Subject[]>([]);
  const [teachers, setTeachers] = useState<UserProfile[]>([]);
  const [disciplineRecords, setDisciplineRecords] = useState<StudentDisciplineRecord[]>([]);
  const [facilities, setFacilities] = useState<SchoolFacility[]>([]);
  const [partners, setPartners] = useState<SMKIndustryPartner[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  // New discipline record modal state
  const [showAddDisciplineModal, setShowAddDisciplineModal] = useState(false);
  const [discStudentName, setDiscStudentName] = useState('');
  const [discType, setDiscType] = useState<'PELANGGARAN' | 'PRESTASI'>('PELANGGARAN');
  const [discCategory, setDiscCategory] = useState('Keterlambatan Masuk Sekolah');
  const [discPoints, setDiscPoints] = useState(5);
  const [discAction, setDiscAction] = useState('Peringatan Lisan & Pembinaan');

  const loadData = async () => {
    if (!currentTenant) return;
    setIsLoading(true);
    try {
      const [clsData, subData, tchData, discData, facData, partData] = await Promise.all([
        academicRepository.getClassesByTenant(currentTenant.id, currentUser),
        academicRepository.getSubjects(currentTenant.id, currentUser),
        teacherRepository.getByTenant(currentTenant.id, currentUser),
        academicRepository.getDisciplineRecords(currentTenant.id),
        academicRepository.getFacilities(currentTenant.id),
        academicRepository.getSmkPartners(currentTenant.id, currentUser),
      ]);

      setClasses(clsData);
      setSubjects(subData);
      setTeachers(tchData);
      setDisciplineRecords(discData);
      setFacilities(facData);
      setPartners(partData);
    } catch (err) {
      console.error('Error loading Waka data:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, [currentTenant?.id]);

  const handleAddDiscipline = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentTenant || !currentUser) return;
    try {
      await academicRepository.addDisciplineRecord(
        {
          tenant_id: currentTenant.id,
          student_id: `std-${Date.now().toString().slice(-4)}`,
          student_name: discStudentName,
          class_name: 'X MIPA 1',
          record_type: discType,
          category: discCategory,
          points: discPoints,
          description: `Dicatat oleh ${currentUser.full_name}: ${discCategory}`,
          follow_up_action: discAction,
          date: new Date().toISOString().split('T')[0],
          recorded_by_name: currentUser.full_name,
        },
        currentUser
      );
      setShowAddDisciplineModal(false);
      setDiscStudentName('');
      await loadData();
    } catch (err: any) {
      alert(err.message || 'Gagal menyimpan catatan kesiswaan');
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="p-6 rounded-3xl bg-gradient-to-r from-indigo-700 via-purple-700 to-indigo-900 text-white shadow-xl relative overflow-hidden">
        <div className="space-y-1">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/20 backdrop-blur-md text-[11px] font-bold uppercase">
            <Award className="w-3.5 h-3.5" />
            <span>Dashboard Penugasan Wakil Kepala Sekolah (WAKA)</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-black tracking-tight">
            Koordinasi Bidang & Manajemen Operasional Sekolah
          </h2>
          <p className="text-xs text-indigo-100 max-w-2xl leading-relaxed">
            Pengelolaan terarah sesuai bidang tugas: Kurikulum & Pembelajaran, Kesiswaan & Tata Tertib, Sarana Prasarana (Sarpras), serta Hubungan Industri & Masyarakat (Humas/DUDI).
          </p>
        </div>
      </div>

      {/* Field Switcher */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
        <button
          type="button"
          onClick={() => setActiveField('KURIKULUM')}
          className={`p-3.5 rounded-2xl font-bold text-xs flex items-center justify-center gap-2 transition-all cursor-pointer ${
            activeField === 'KURIKULUM'
              ? 'bg-indigo-600 text-white shadow-md'
              : 'bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-800'
          }`}
        >
          <BookOpen className="w-4 h-4" />
          <span>Waka Kurikulum</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveField('KESISWAAN')}
          className={`p-3.5 rounded-2xl font-bold text-xs flex items-center justify-center gap-2 transition-all cursor-pointer ${
            activeField === 'KESISWAAN'
              ? 'bg-indigo-600 text-white shadow-md'
              : 'bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-800'
          }`}
        >
          <ShieldAlert className="w-4 h-4" />
          <span>Waka Kesiswaan</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveField('SARPRAS')}
          className={`p-3.5 rounded-2xl font-bold text-xs flex items-center justify-center gap-2 transition-all cursor-pointer ${
            activeField === 'SARPRAS'
              ? 'bg-indigo-600 text-white shadow-md'
              : 'bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-800'
          }`}
        >
          <Layers className="w-4 h-4" />
          <span>Waka Sarpras</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveField('HUMAS')}
          className={`p-3.5 rounded-2xl font-bold text-xs flex items-center justify-center gap-2 transition-all cursor-pointer ${
            activeField === 'HUMAS'
              ? 'bg-indigo-600 text-white shadow-md'
              : 'bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-800'
          }`}
        >
          <Building2 className="w-4 h-4" />
          <span>Waka Humas / Hubin</span>
        </button>
      </div>

      {/* Field 1: WAKA KURIKULUM */}
      {activeField === 'KURIKULUM' && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-1">
              <span className="text-xs font-semibold text-slate-500">Mata Pelajaran Aktif</span>
              <div className="text-2xl font-black text-slate-900 dark:text-white">{subjects.length} Mapel</div>
              <p className="text-[11px] text-slate-400">Umum, Peminatan, Kejuruan</p>
            </div>
            <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-1">
              <span className="text-xs font-semibold text-slate-500">Beban Jam Mengajar Guru</span>
              <div className="text-2xl font-black text-indigo-600">24-32 JJM/Minggu</div>
              <p className="text-[11px] text-slate-400">100% Memenuhi standar sertifikasi</p>
            </div>
            <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-1">
              <span className="text-xs font-semibold text-slate-500">Kalender Akademik</span>
              <div className="text-2xl font-black text-emerald-600">Fase Berjalan</div>
              <p className="text-[11px] text-slate-400">Semester Ganjil 2024/2025</p>
            </div>
          </div>

          <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 overflow-hidden shadow-xs">
            <div className="p-4 border-b border-slate-100 dark:border-slate-800 font-bold text-xs text-slate-900 dark:text-white">
              Daftar Beban Mengajar & Capaian Guru Pengampu
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 dark:bg-slate-800/60 text-slate-400 font-bold uppercase text-[10px] tracking-wider border-b border-slate-200 dark:border-slate-800">
                  <tr>
                    <th className="py-3 px-4">Nama Guru</th>
                    <th className="py-3 px-4">Tugas Tambahan</th>
                    <th className="py-3 px-4">Total Jam (JJM)</th>
                    <th className="py-3 px-4">Status Sertifikasi</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {teachers.map((t) => (
                    <tr key={t.id}>
                      <td className="py-3 px-4 font-bold text-slate-900 dark:text-white">{t.full_name}</td>
                      <td className="py-3 px-4 text-slate-600 dark:text-slate-300">
                        {t.assignments?.map((a) => a.type).join(', ') || 'Guru Pengampu'}
                      </td>
                      <td className="py-3 px-4 font-mono text-indigo-600 font-bold">28 Jam / Minggu</td>
                      <td className="py-3 px-4">
                        <span className="px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300 text-[10px] font-bold">
                          Terverifikasi
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* Field 2: WAKA KESISWAAN */}
      {activeField === 'KESISWAAN' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                Buku Catatan Tata Tertib, Kedisiplinan & Penghargaan Siswa
              </h3>
              <p className="text-xs text-slate-500">Sistem poin pelanggaran dan poin prestasi kesiswaan terpadu</p>
            </div>
            <button
              type="button"
              onClick={() => setShowAddDisciplineModal(true)}
              className="px-3.5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer shadow-xs"
            >
              <Plus className="w-4 h-4" />
              <span>Catat Kasus / Prestasi</span>
            </button>
          </div>

          <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 overflow-hidden shadow-xs">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 dark:bg-slate-800/60 text-slate-400 font-bold uppercase text-[10px] tracking-wider border-b border-slate-200 dark:border-slate-800">
                  <tr>
                    <th className="py-3 px-4">Tanggal</th>
                    <th className="py-3 px-4">Nama Siswa</th>
                    <th className="py-3 px-4">Kelas</th>
                    <th className="py-3 px-4">Kategori</th>
                    <th className="py-3 px-4">Jenis</th>
                    <th className="py-3 px-4">Poin</th>
                    <th className="py-3 px-4">Tindak Lanjut</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {disciplineRecords.map((d) => (
                    <tr key={d.id}>
                      <td className="py-3 px-4 font-mono text-slate-400">{d.date}</td>
                      <td className="py-3 px-4 font-bold text-slate-900 dark:text-white">{d.student_name}</td>
                      <td className="py-3 px-4 text-slate-600 dark:text-slate-300">{d.class_name}</td>
                      <td className="py-3 px-4 text-slate-700 dark:text-slate-200">{d.category}</td>
                      <td className="py-3 px-4">
                        <span
                          className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                            d.record_type === 'PRESTASI'
                              ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                              : 'bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-300'
                          }`}
                        >
                          {d.record_type}
                        </span>
                      </td>
                      <td className="py-3 px-4 font-mono font-bold">
                        {d.record_type === 'PRESTASI' ? `+${d.points}` : `-${d.points}`}
                      </td>
                      <td className="py-3 px-4 text-slate-600 dark:text-slate-300">{d.follow_up_action}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* Field 3: WAKA SARPRAS */}
      {activeField === 'SARPRAS' && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {facilities.map((fac) => (
              <div
                key={fac.id}
                className="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-3"
              >
                <div className="flex items-start justify-between">
                  <div>
                    <span className="text-[10px] font-bold text-indigo-600 uppercase">{fac.category}</span>
                    <h4 className="text-base font-black text-slate-900 dark:text-white">{fac.name}</h4>
                    <div className="text-xs text-slate-400">Lokasi: {fac.location}</div>
                  </div>
                  <span
                    className={`px-2.5 py-1 rounded-full text-[10px] font-bold ${
                      fac.condition === 'BAIK'
                        ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                        : 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300'
                    }`}
                  >
                    Kondisi: {fac.condition}
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-2 text-xs">
                  <div className="p-2.5 bg-slate-50 dark:bg-slate-800 rounded-xl">
                    <span className="text-[10px] text-slate-400">Kapasitas:</span>
                    <div className="font-bold text-slate-800 dark:text-slate-200">{fac.capacity} Orang / Unit</div>
                  </div>
                  <div className="p-2.5 bg-slate-50 dark:bg-slate-800 rounded-xl">
                    <span className="text-[10px] text-slate-400">Pemeriksaan Terakhir:</span>
                    <div className="font-mono font-bold text-slate-800 dark:text-slate-200">{fac.last_inspected}</div>
                  </div>
                </div>

                <div className="text-[11px] text-slate-500">
                  PIC Penanggung Jawab: <strong className="text-slate-700 dark:text-slate-300">{fac.pic_user_name}</strong>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Field 4: WAKA HUMAS */}
      {activeField === 'HUMAS' && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-1">
              <span className="text-xs font-semibold text-slate-500">MoU Industri Aktif</span>
              <div className="text-2xl font-black text-indigo-600">{partners.length} Mitra</div>
              <p className="text-[11px] text-slate-400">Kerjasama DUDI terikat hukum</p>
            </div>
            <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-1">
              <span className="text-xs font-semibold text-slate-500">Kunjungan Industri</span>
              <div className="text-2xl font-black text-emerald-600">4 Agenda</div>
              <p className="text-[11px] text-slate-400">Terjadwal semester ini</p>
            </div>
            <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-1">
              <span className="text-xs font-semibold text-slate-500">Guru Tamu Industri</span>
              <div className="text-2xl font-black text-slate-900 dark:text-white">6 Praktisi</div>
              <p className="text-[11px] text-slate-400">Sharing session kejuruan</p>
            </div>
          </div>
        </div>
      )}

      {/* Modal Catat Kasus / Prestasi */}
      {showAddDisciplineModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="bg-white dark:bg-slate-900 rounded-3xl max-w-md w-full p-6 shadow-2xl border border-slate-200 dark:border-slate-800 space-y-4 text-xs">
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
              <h3 className="text-base font-black text-slate-900 dark:text-white">
                Pencatatan Poin Kesiswaan
              </h3>
              <button
                type="button"
                onClick={() => setShowAddDisciplineModal(false)}
                className="p-1 rounded-lg hover:bg-slate-100 text-slate-400 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleAddDiscipline} className="space-y-3">
              <div>
                <label className="block text-slate-700 dark:text-slate-300 font-bold mb-1">Nama Siswa</label>
                <input
                  type="text"
                  required
                  placeholder="contoh: Ahmad Rizky"
                  value={discStudentName}
                  onChange={(e) => setDiscStudentName(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-700 dark:text-slate-300 font-bold mb-1">Jenis Catatan</label>
                  <select
                    value={discType}
                    onChange={(e) => setDiscType(e.target.value as any)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 font-bold"
                  >
                    <option value="PELANGGARAN">Pelanggaran (Minus)</option>
                    <option value="PRESTASI">Prestasi (Plus)</option>
                  </select>
                </div>
                <div>
                  <label className="block text-slate-700 dark:text-slate-300 font-bold mb-1">Bobot Poin</label>
                  <input
                    type="number"
                    min={1}
                    max={100}
                    value={discPoints}
                    onChange={(e) => setDiscPoints(Number(e.target.value))}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-700 dark:text-slate-300 font-bold mb-1">Kategori / Kasus</label>
                <input
                  type="text"
                  required
                  value={discCategory}
                  onChange={(e) => setDiscCategory(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
                />
              </div>

              <div>
                <label className="block text-slate-700 dark:text-slate-300 font-bold mb-1">Tindak Lanjut / Reward</label>
                <input
                  type="text"
                  required
                  value={discAction}
                  onChange={(e) => setDiscAction(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
                />
              </div>

              <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowAddDisciplineModal(false)}
                  className="px-4 py-2 rounded-xl border border-slate-200 dark:border-slate-700 font-bold text-slate-600 dark:text-slate-400 cursor-pointer"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold cursor-pointer"
                >
                  Simpan Catatan
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
