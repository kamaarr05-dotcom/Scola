import React from 'react';

interface ScolaBrandProps {
  size?: 'sm' | 'md' | 'lg';
  showTagline?: boolean;
  className?: string;
  lightMode?: boolean;
}

export const ScolaBrand: React.FC<ScolaBrandProps> = ({
  size = 'md',
  showTagline = false,
  className = '',
  lightMode = false,
}) => {
  const iconDimensions = {
    sm: { w: 28, h: 28, text: 'text-lg', sub: 'text-[10px]' },
    md: { w: 38, h: 38, text: 'text-2xl', sub: 'text-xs' },
    lg: { w: 56, h: 56, text: 'text-4xl', sub: 'text-sm' },
  }[size];

  return (
    <div className={`flex items-center gap-2.5 select-none ${className}`}>
      {/* SCOLA Isometric Geometric Brand Mark (S-Cap + Neural Circuit) */}
      <div
        className="relative flex items-center justify-center shrink-0 rounded-xl overflow-hidden shadow-sm"
        style={{ width: iconDimensions.w, height: iconDimensions.h }}
      >
        <svg
          viewBox="0 0 100 100"
          className="w-full h-full"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          <defs>
            <linearGradient id="scolaGrad1" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#1E3A8A" />
              <stop offset="45%" stopColor="#2563EB" />
              <stop offset="100%" stopColor="#0D9488" />
            </linearGradient>
            <linearGradient id="scolaGrad2" x1="0%" y1="100%" x2="100%" y2="0%">
              <stop offset="0%" stopColor="#06B6D4" />
              <stop offset="60%" stopColor="#10B981" />
              <stop offset="100%" stopColor="#3B82F6" />
            </linearGradient>
          </defs>
          {/* Background Rounded Shield */}
          <rect width="100" height="100" rx="22" fill="#0F172A" />
          {/* Top Isometric Cube / Graduation Cap Peak */}
          <path
            d="M50 16L78 30L50 44L22 30L50 16Z"
            fill="url(#scolaGrad1)"
            stroke="#93C5FD"
            strokeWidth="1.5"
          />
          {/* Left Isometric Drop */}
          <path
            d="M22 30L50 44V72L22 58V30Z"
            fill="url(#scolaGrad1)"
            opacity="0.9"
          />
          {/* Right Isometric Sweeping Curve forming 'S' */}
          <path
            d="M50 44L78 30V58C78 68 66 78 50 82V68C58 66 64 61 64 55V44H50Z"
            fill="url(#scolaGrad2)"
          />
          {/* Bottom Circuit Connector Loop */}
          <path
            d="M32 66C32 74 40 82 50 82C40 82 28 78 28 66H32Z"
            fill="#06B6D4"
          />
          {/* Neural / Circuit Nodes */}
          <circle cx="36" cy="62" r="4.5" fill="#38BDF8" stroke="#0F172A" strokeWidth="2" />
          <circle cx="64" cy="62" r="4.5" fill="#34D399" stroke="#0F172A" strokeWidth="2" />
          <path
            d="M39 64L50 71L61 64"
            stroke="#67E8F9"
            strokeWidth="2.5"
            strokeLinecap="round"
          />
        </svg>
      </div>
      <div className="flex flex-col">
        <div className="flex items-baseline gap-1.5">
          <span
            className={`font-extrabold tracking-wider ${iconDimensions.text} ${
              lightMode ? 'text-slate-900' : 'text-slate-900 dark:text-white'
            }`}
            style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}
          >
            SCOLA
          </span>
          <span className="text-[10px] uppercase font-bold tracking-widest px-1.5 py-0.5 rounded bg-blue-100 dark:bg-blue-900/60 text-blue-700 dark:text-blue-300">
            School OS
          </span>
        </div>
        {showTagline && (
          <span
            className={`text-slate-500 dark:text-slate-400 font-medium ${iconDimensions.sub}`}
          >
            Operating System SMA & SMK
          </span>
        )}
      </div>
    </div>
  );
};
