import React from 'react';
import {
  Layers,
  ShieldCheck,
  CheckCircle,
  X,
  Lock,
  Smartphone,
} from 'lucide-react';

interface ArchitectureModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ArchitectureModal: React.FC<ArchitectureModalProps> = ({
  isOpen,
  onClose,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl max-w-3xl w-full max-h-[90vh] flex flex-col shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="bg-slate-900 text-white p-5 flex items-center justify-between border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-blue-600 text-white">
              <Layers className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold">
                SCOLA Master Architecture & Blueprint Inspector
              </h3>
              <p className="text-xs text-slate-400">
                School Operating System for SMA & SMK • Multi-Tenant Multi-Device Auth & RLS
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-lg cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto space-y-6 text-xs text-slate-700 dark:text-slate-300">
          {/* Security Principle Highlight */}
          <div className="p-3.5 rounded-xl bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-800 text-[11px] text-amber-900 dark:text-amber-200 space-y-1">
            <div className="font-bold flex items-center gap-1.5 text-amber-800 dark:text-amber-300">
              <ShieldCheck className="w-4 h-4" />
              <span>Prinsip Keamanan Kunci SCOLA (Security Mandate):</span>
            </div>
            <p className="leading-relaxed">
              1. <strong>Tanpa Service Role Key pada Client:</strong> Web, Android, dan iOS hanya menggunakan <code>VITE_SUPABASE_URL</code> dan <code>VITE_SUPABASE_ANON_KEY</code>.<br />
              2. <strong>Tenant Isolation via RLS:</strong> Sistem tidak pernah mempercayai <code>tenant_id</code> dari frontend; tenant diputuskan oleh keanggotaan user terverifikasi di PostgreSQL.<br />
              3. <strong>Pemisahan Role & Assignment:</strong> Semua guru memiliki <code>ROLE = GURU</code>; tugas tambahan (Wali Kelas, Waka Kurikulum, dll.) bersifat dinamis.<br />
              4. <strong>Log Audit Bersih:</strong> Password dan rahasia tidak pernah dicatat dalam log audit.
            </p>
          </div>

          {/* Section 1: Multi-Device Unified Backend */}
          <div className="space-y-2">
            <h4 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <Smartphone className="w-4 h-4 text-blue-600" />
              <span>1. Multi-Device Platform (Web, Android, iOS)</span>
            </h4>
            <p className="text-[11px] leading-relaxed text-slate-600 dark:text-slate-400">
              Semua platform (Web browser desktop/mobile, aplikasi native Android & iOS via Capacitor) terhubung ke <strong>satu backend Supabase yang sama</strong>, satu skema database PostgreSQL yang sama, storage yang sama, serta otentikasi Supabase Auth yang sama.
            </p>
            <div className="grid grid-cols-3 gap-2 text-center pt-1 font-mono text-[11px]">
              <div className="p-2 rounded-lg bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700">
                Web App (Vite React)
              </div>
              <div className="p-2 rounded-lg bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700">
                Android (Capacitor)
              </div>
              <div className="p-2 rounded-lg bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700">
                iOS (Capacitor)
              </div>
            </div>
          </div>

          {/* Section 2: Supabase RLS & Multi-Tenancy */}
          <div className="space-y-2">
            <h4 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-emerald-600" />
              <span>2. Multi-Tenant Isolation & Supabase RLS Policies</span>
            </h4>
            <p className="text-[11px] leading-relaxed text-slate-600 dark:text-slate-400">
              Setiap sekolah adalah sebuah tenant mandiri. Semua tabel memiliki kolom <code>tenant_id</code> dan dilindungi oleh <strong>Row-Level Security (RLS)</strong> di level PostgreSQL. User dari SMAN 1 tidak dapat membaca atau memodifikasi data SMKN 2, kecuali role MASTER.
            </p>
            <div className="p-3 rounded-lg bg-slate-900 text-slate-300 font-mono text-[10px] overflow-x-auto space-y-1">
              <div className="text-emerald-400">-- PostgreSQL Row-Level Security Sample:</div>
              <div>CREATE POLICY &quot;Users view own tenant&quot; ON user_profiles</div>
              <div>  FOR SELECT USING (tenant_id = auth.current_tenant_id() OR auth.is_master());</div>
              <div>CREATE POLICY &quot;Principal manages teachers&quot; ON teacher_assignments</div>
              <div>  FOR ALL USING (auth.current_role() = &apos;KEPALA_SEKOLAH&apos; AND tenant_id = auth.current_tenant_id());</div>
            </div>
            <div className="p-2.5 rounded-lg bg-emerald-50 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-800 text-[11px] text-slate-700 dark:text-slate-300">
              <strong>Prinsip Keamanan Client:</strong> Aplikasi client (Web, Android, iOS) <em>hanya</em> menggunakan <code>Supabase URL</code> dan <code>Supabase Anon Key</code>. <code>Service Role Key</code> dilarang keras diminta atau digunakan di sisi client, dan hanya boleh berada pada server-side/Edge Function terisolasi.
            </div>
          </div>

          {/* Section 3: Teacher Quota & Concurrency */}
          <div className="space-y-2">
            <h4 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <Lock className="w-4 h-4 text-amber-600" />
              <span>3. Teacher License Quota Enforced</span>
            </h4>
            <ul className="list-disc pl-4 space-y-1 text-[11px] text-slate-600 dark:text-slate-400">
              <li>Hanya <strong>MASTER</strong> yang dapat mengubah kuota lisensi guru.</li>
              <li>Jumlah guru berstatus <code>ACTIVE</code> tidak boleh melebihi kuota tenant.</li>
              <li>Guru pensiun/pindah statusnya diubah menjadi <code>INACTIVE</code> agar slot lisensi dilepas namun riwayat nilai/absensi siswa tetap terjaga.</li>
              <li>Dilindungi pada frontend, repository, dan PostgreSQL Database Trigger (<code>trg_check_teacher_quota</code>) dengan row-level lock.</li>
            </ul>
          </div>

          {/* Section 4: Role vs Assignment Decoupling */}
          <div className="space-y-2">
            <h4 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <Layers className="w-4 h-4 text-purple-600" />
              <span>4. Pemisahan Role dan Assignment</span>
            </h4>
            <div className="p-3 rounded-xl bg-purple-50 dark:bg-purple-950/30 border border-purple-200 dark:border-purple-800 text-[11px] space-y-1">
              <p>
                <strong>Role Inti (6):</strong> MASTER, KEPALA_SEKOLAH, GURU, SISWA, ORANG_TUA, TENAGA_KEPENDIDIKAN.
              </p>
              <p>
                <strong>Assignment (Penugasan Guru):</strong> Waka Kurikulum/Kesiswaan, Wali Kelas, Kepala Program Keahlian (Kaprog SMK), dan Guru BK. Semua pemegang tugas tambahan tetap bertindak dengan <code>ROLE = GURU</code>.
              </p>
            </div>
          </div>

          {/* Section 5: Registration Rules */}
          <div className="space-y-2">
            <h4 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <CheckCircle className="w-4 h-4 text-blue-600" />
              <span>5. Aturan Registrasi Akun</span>
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-[11px]">
              <div className="p-2.5 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50">
                <span className="font-bold text-slate-900 dark:text-white block">Siswa:</span>
                <span className="text-emerald-600 dark:text-emerald-400 font-semibold">Self-Register Boleh</span>
              </div>
              <div className="p-2.5 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50">
                <span className="font-bold text-slate-900 dark:text-white block">Guru:</span>
                <span className="text-rose-600 dark:text-rose-400 font-semibold">Dibuat Kepsek/Master</span>
              </div>
              <div className="p-2.5 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50">
                <span className="font-bold text-slate-900 dark:text-white block">Orang Tua:</span>
                <span className="text-amber-600 dark:text-amber-400 font-semibold">Diaktivasi Wali Kelas</span>
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="bg-slate-50 dark:bg-slate-850 p-4 border-t border-slate-200 dark:border-slate-800 flex justify-end">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white dark:bg-white dark:text-slate-900 text-xs font-bold rounded-xl cursor-pointer"
          >
            Tutup Inspeksi
          </button>
        </div>
      </div>
    </div>
  );
};
