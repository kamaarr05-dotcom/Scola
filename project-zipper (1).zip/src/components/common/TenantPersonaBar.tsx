import React from 'react';
import { useAuth } from '../../context/AuthContext';
import { useTenant } from '../../context/TenantContext';
import { ScolaRole } from '../../types';
import { RoleBadge } from './RoleBadge';
import { UserCheck, RefreshCw, KeyRound, Building2, Database, Cloud } from 'lucide-react';
import { isSupabaseConfigured } from '../../config/supabase';

interface TenantPersonaBarProps {
  onOpenArchitecture: () => void;
  onOpenSupabaseSync: () => void;
}

export const TenantPersonaBar: React.FC<TenantPersonaBarProps> = ({
  onOpenArchitecture,
  onOpenSupabaseSync,
}) => {
  const { currentUser, availableUsers, switchPersona, expireSession } = useAuth();
  const { currentTenant, allTenants, setCurrentTenant } = useTenant();
  const isCloudSynced = isSupabaseConfigured();

  // Pick one representative user for each role from availableUsers
  const roleSampleUsers: { role: ScolaRole; label: string; user?: typeof availableUsers[0] }[] = [
    {
      role: 'MASTER',
      label: 'Super Admin / Master',
      user: availableUsers.find((u) => u.role === 'MASTER'),
    },
    {
      role: 'KEPALA_SEKOLAH',
      label: 'Kepala Sekolah (SMAN 1)',
      user: availableUsers.find((u) => u.role === 'KEPALA_SEKOLAH'),
    },
    {
      role: 'GURU',
      label: 'Guru & Wali Kelas',
      user: availableUsers.find((u) => u.role === 'GURU'),
    },
    {
      role: 'SISWA',
      label: 'Siswa (SMAN 1)',
      user: availableUsers.find((u) => u.role === 'SISWA'),
    },
    {
      role: 'ORANG_TUA',
      label: 'Orang Tua / Wali',
      user: availableUsers.find((u) => u.role === 'ORANG_TUA'),
    },
    {
      role: 'TENAGA_KEPENDIDIKAN',
      label: 'TU / Sarpras / Karyawan',
      user: availableUsers.find((u) => u.role === 'TENAGA_KEPENDIDIKAN'),
    },
  ];

  return (
    <div className="bg-slate-900 text-slate-200 border-b border-slate-800 text-xs px-4 py-2.5 flex flex-wrap items-center justify-between gap-3 sticky top-0 z-40">
      {/* Left: Persona Switcher */}
      <div className="flex flex-wrap items-center gap-2">
        <div className="flex items-center gap-1.5 font-bold text-slate-300">
          <UserCheck className="w-4 h-4 text-blue-400" />
          <span className="hidden sm:inline">Simulasi Persona:</span>
        </div>

        <div className="flex flex-wrap items-center gap-1">
          {roleSampleUsers
            .filter((item) => item.role !== 'MASTER' || currentUser?.role === 'MASTER')
            .map((item) => {
            const isCurrent = currentUser?.id === item.user?.id;
            return (
              <button
                key={item.role}
                type="button"
                onClick={() => item.user && switchPersona(item.user.id)}
                disabled={!item.user}
                className={`px-2.5 py-1 rounded-lg font-medium transition-all flex items-center gap-1.5 cursor-pointer ${
                  isCurrent
                    ? 'bg-blue-600 text-white shadow-sm ring-2 ring-blue-400/30'
                    : 'bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700'
                }`}
                title={`Beralih ke persona: ${item.label}`}
              >
                <RoleBadge role={item.role} size="sm" />
                <span className="hidden md:inline truncate max-w-[90px]">
                  {item.user?.full_name?.split(' ')[0] || item.role}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Right: Tenant Switcher (for MASTER) & Quick Actions */}
      <div className="flex items-center gap-2">
        {currentUser?.role === 'MASTER' && (
          <div className="flex items-center gap-1.5 bg-slate-800 px-2.5 py-1 rounded-lg border border-slate-700">
            <Building2 className="w-3.5 h-3.5 text-purple-400" />
            <select
              value={currentTenant?.id || ''}
              onChange={(e) => {
                const found = allTenants.find((t) => t.id === e.target.value);
                if (found) setCurrentTenant(found);
              }}
              className="bg-transparent text-slate-200 text-xs font-semibold focus:outline-none cursor-pointer"
            >
              {allTenants.map((t) => (
                <option key={t.id} value={t.id} className="bg-slate-900 text-white">
                  {t.name} ({t.type})
                </option>
              ))}
            </select>
          </div>
        )}

        <button
          type="button"
          onClick={onOpenSupabaseSync}
          className={`px-2.5 py-1 rounded-lg border flex items-center gap-1.5 cursor-pointer font-medium transition-all ${
            isCloudSynced
              ? 'bg-emerald-950/50 hover:bg-emerald-900/60 text-emerald-300 border-emerald-700/60'
              : 'bg-slate-800 hover:bg-slate-700 text-slate-300 border-slate-700'
          }`}
          title="Sinkronisasi Cloud Database (Supabase) - Multi-Device Sync"
        >
          <Database className={`w-3.5 h-3.5 ${isCloudSynced ? 'text-emerald-400' : 'text-slate-400'}`} />
          <span>{isCloudSynced ? 'Supabase Sync' : 'Setup Supabase'}</span>
        </button>

        <button
          type="button"
          onClick={onOpenArchitecture}
          className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 flex items-center gap-1 cursor-pointer font-medium"
          title="Buka blueprint arsitektur SCOLA"
        >
          <RefreshCw className="w-3.5 h-3.5 text-blue-400" />
          <span className="hidden sm:inline">Blueprint Arsitektur</span>
        </button>

        <button
          type="button"
          onClick={() => expireSession()}
          className="px-2.5 py-1 rounded-lg bg-amber-950/40 hover:bg-amber-900/60 text-amber-300 border border-amber-800/60 flex items-center gap-1 cursor-pointer font-medium"
          title="Uji coba session kedaluwarsa (Expired Token Test)"
        >
          <KeyRound className="w-3.5 h-3.5 text-amber-400" />
          <span className="hidden lg:inline">Tes Token Expire</span>
        </button>
      </div>
    </div>
  );
};
