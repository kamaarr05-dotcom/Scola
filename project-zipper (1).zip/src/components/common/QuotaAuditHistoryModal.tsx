import React from 'react';
import { AuthAuditLog } from '../../types';
import { History, X, ShieldAlert, CheckCircle } from 'lucide-react';

interface QuotaAuditHistoryModalProps {
  isOpen: boolean;
  onClose: () => void;
  logs: AuthAuditLog[];
  tenantName?: string;
}

export const QuotaAuditHistoryModal: React.FC<QuotaAuditHistoryModalProps> = ({
  isOpen,
  onClose,
  logs,
  tenantName,
}) => {
  if (!isOpen) return null;

  const quotaLogs = logs.filter(
    (l) => l.event === 'QUOTA_UPDATED' || l.event === 'QUOTA_EXCEEDED' || l.event === 'TEACHER_ACTIVATED' || l.event === 'TEACHER_DEACTIVATED'
  );

  return (
    <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl max-w-2xl w-full max-h-[85vh] flex flex-col shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="bg-slate-900 text-white p-4 flex items-center justify-between border-b border-slate-800">
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-xl bg-purple-600 text-white">
              <History className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-bold">
                Riwayat Audit Perubahan Kuota & Lisensi Guru
              </h3>
              <p className="text-[11px] text-slate-400">
                {tenantName ? `Audit log untuk ${tenantName}` : 'Audit perubahan lisensi sistem'}
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-lg cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-4 overflow-y-auto space-y-3">
          {quotaLogs.length === 0 ? (
            <div className="text-center py-8 text-xs text-slate-500">
              Belum ada riwayat perubahan kuota yang tercatat.
            </div>
          ) : (
            quotaLogs.map((log) => (
              <div
                key={log.id}
                className="p-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-850 flex flex-col gap-1 text-xs"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5 font-bold">
                    {log.status === 'SUCCESS' ? (
                      <CheckCircle className="w-4 h-4 text-emerald-600" />
                    ) : (
                      <ShieldAlert className="w-4 h-4 text-rose-600" />
                    )}
                    <span
                      className={
                        log.event === 'QUOTA_UPDATED'
                          ? 'text-purple-600 dark:text-purple-400'
                          : log.event === 'QUOTA_EXCEEDED'
                          ? 'text-rose-600 dark:text-rose-400'
                          : 'text-blue-600 dark:text-blue-400'
                      }
                    >
                      {log.event}
                    </span>
                  </div>
                  <span className="text-[10px] text-slate-400 font-mono">
                    {new Date(log.timestamp).toLocaleString('id-ID')}
                  </span>
                </div>

                <p className="text-slate-700 dark:text-slate-300 font-medium">
                  {log.details}
                </p>

                <div className="flex flex-wrap items-center gap-3 text-[10px] text-slate-500 dark:text-slate-400 pt-1 border-t border-slate-200 dark:border-slate-800">
                  <span>Aktor: {log.email || 'System'}</span>
                  <span>Role: {log.role || '-'}</span>
                  {log.tenant_name && <span>Tenant: {log.tenant_name}</span>}
                </div>
              </div>
            ))
          )}
        </div>

        {/* Footer */}
        <div className="bg-slate-50 dark:bg-slate-850 p-3 border-t border-slate-200 dark:border-slate-800 flex justify-end">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-1.5 bg-slate-900 hover:bg-slate-800 text-white dark:bg-white dark:text-slate-900 text-xs font-bold rounded-xl cursor-pointer"
          >
            Tutup
          </button>
        </div>
      </div>
    </div>
  );
};
