import React from 'react';
import { TeacherAssignmentType } from '../../types';
import { ASSIGNMENT_LABELS } from '../../lib/permissions';
import { Award, BookOpen, Users, Compass, Building, Briefcase } from 'lucide-react';

interface AssignmentPillProps {
  type: TeacherAssignmentType;
  active?: boolean;
  notes?: string;
  onClick?: () => void;
  selected?: boolean;
}

export const AssignmentPill: React.FC<AssignmentPillProps> = ({
  type,
  active = true,
  notes,
  onClick,
  selected = false,
}) => {
  const getIcon = () => {
    switch (type) {
      case 'WALI_KELAS':
        return <Users className="w-3.5 h-3.5" />;
      case 'WAKA_KURIKULUM':
        return <BookOpen className="w-3.5 h-3.5" />;
      case 'WAKA_KESISWAAN':
        return <Award className="w-3.5 h-3.5" />;
      case 'WAKA_SARPRAS':
        return <Building className="w-3.5 h-3.5" />;
      case 'WAKA_HUMAS':
        return <Briefcase className="w-3.5 h-3.5" />;
      case 'KAPROG':
        return <Compass className="w-3.5 h-3.5" />;
      case 'BK':
      case 'GURU_BK':
        return <Users className="w-3.5 h-3.5" />;
      default:
        return <Award className="w-3.5 h-3.5" />;
    }
  };

  return (
    <button
      type="button"
      onClick={onClick}
      disabled={!onClick}
      title={notes || ASSIGNMENT_LABELS[type]}
      className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold transition-all whitespace-nowrap ${
        selected
          ? 'bg-blue-600 text-white shadow-sm ring-2 ring-blue-500/20'
          : active
          ? 'bg-blue-50 text-blue-800 border border-blue-200 hover:bg-blue-100 dark:bg-blue-950/50 dark:text-blue-200 dark:border-blue-800'
          : 'bg-slate-100 text-slate-400 border border-slate-200 dark:bg-slate-800 dark:text-slate-500 line-through'
      } ${onClick ? 'cursor-pointer' : 'cursor-default'}`}
    >
      {getIcon()}
      <span>{ASSIGNMENT_LABELS[type]}</span>
      <span className="text-[10px] uppercase tracking-wider px-1 py-0.2 rounded bg-white/20 font-bold">
        Tugas
      </span>
    </button>
  );
};
