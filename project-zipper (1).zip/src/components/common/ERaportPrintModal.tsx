import React from 'react';
import { StudentReportCard } from '../../types';
import { useTenant } from '../../context/TenantContext';
import {
  Printer,
  X,
  Award,
  CheckCircle2,
  BookOpen,
  Calendar,
  UserCheck,
} from 'lucide-react';

interface ERaportPrintModalProps {
  isOpen: boolean;
  onClose: () => void;
  reportCard: StudentReportCard | null;
}

export const ERaportPrintModal: React.FC<ERaportPrintModalProps> = ({
  isOpen,
  onClose,
  reportCard,
}) => {
  const { currentTenant } = useTenant();

  if (!isOpen || !reportCard) return null;

  const subjects = reportCard.subject_grades || reportCard.grades || [];
  const extracurriculars = reportCard.extracurriculars || [];
  const attendance = reportCard.attendance_summary || { hadir: 50, sakit: 1, izin: 0, alpa: 0 };
  const avg = reportCard.general_average ?? (reportCard as any).average_score ?? 89.5;

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/80 backdrop-blur-sm overflow-y-auto flex items-start justify-center p-3 sm:p-6 print:p-0 print:bg-white print:static">
      <div className="bg-white dark:bg-slate-900 w-full max-w-4xl rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden my-4 print:my-0 print:border-none print:shadow-none print:w-full print:max-w-none text-slate-800 dark:text-slate-100">
        {/* Top Control Bar (Hidden on Print) */}
        <div className="p-4 sm:px-6 bg-slate-100 dark:bg-slate-850 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between print:hidden">
          <div className="flex items-center gap-2.5">
            <span className="p-2 rounded-xl bg-blue-100 text-blue-700 dark:bg-blue-950 dark:text-blue-300">
              <Award className="w-5 h-5" />
            </span>
            <div>
              <h3 className="font-bold text-sm text-slate-900 dark:text-white">
                Dokumen Resmi Buku Rapor Peserta Didik Digital (e-Rapor)
              </h3>
              <p className="text-[11px] text-slate-500">
                Format Standar Kurikulum Nasional &amp; Kemendikbudristek
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handlePrint}
              className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold flex items-center gap-2 shadow-sm cursor-pointer transition-colors"
            >
              <Printer className="w-4 h-4" />
              <span>Cetak / Simpan PDF</span>
            </button>
            <button
              type="button"
              onClick={onClose}
              className="p-2 rounded-xl bg-slate-200 dark:bg-slate-800 hover:bg-slate-300 text-slate-600 dark:text-slate-300 cursor-pointer transition-colors"
              title="Tutup"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable Paper Area */}
        <div className="p-6 sm:p-10 space-y-6 bg-white text-slate-900 print:p-8 font-sans">
          {/* Header Kop Surat Sekolah */}
          <div className="border-b-2 border-slate-900 pb-4 flex items-center justify-between gap-4 text-center">
            <div className="w-16 h-16 rounded-2xl bg-blue-50 border border-blue-200 flex items-center justify-center shrink-0">
              <BookOpen className="w-8 h-8 text-blue-700" />
            </div>
            <div className="flex-1 space-y-0.5">
              <h4 className="text-xs font-bold uppercase tracking-widest text-slate-500">
                Pemerintah Daerah Provinsi • Dinas Pendidikan
              </h4>
              <h2 className="text-xl sm:text-2xl font-black uppercase text-slate-950 tracking-tight">
                {currentTenant?.name || 'SMA / SMK NEGERI 1'}
              </h2>
              <p className="text-xs text-slate-600">
                {currentTenant?.address || 'Jl. Pendidikan No. 1, Kawasan Edukasi Terpadu'} • NPSN: {currentTenant?.npsn || '20108922'} • Telp: {currentTenant?.phone || '(021) 7891234'}
              </p>
              <p className="text-[11px] text-slate-500 italic">
                Website: {currentTenant?.subdomain || 'sekolah'}.scola.id • Email: info@{currentTenant?.subdomain || 'sekolah'}.sch.id
              </p>
            </div>
            <div className="w-16 h-16 rounded-2xl bg-emerald-50 border border-emerald-200 flex items-center justify-center shrink-0">
              <Award className="w-8 h-8 text-emerald-700" />
            </div>
          </div>

          {/* Judul Rapor */}
          <div className="text-center space-y-1">
            <h3 className="text-base font-extrabold uppercase tracking-wide text-slate-900 underline underline-offset-4">
              LAPORAN HASIL BELAJAR PESERTA DIDIK (e-RAPOR)
            </h3>
            <p className="text-xs text-slate-500 font-medium">
              Tahun Ajaran {reportCard.academic_year || '2024/2025'} • Semester {reportCard.semester}
            </p>
          </div>

          {/* Identitas Siswa */}
          <div className="grid grid-cols-2 gap-4 text-xs bg-slate-50 p-4 rounded-xl border border-slate-200">
            <div className="space-y-1.5">
              <div className="flex">
                <span className="w-32 font-semibold text-slate-600">Nama Peserta Didik</span>
                <span className="font-bold text-slate-950">: {reportCard.student_name}</span>
              </div>
              <div className="flex">
                <span className="w-32 font-semibold text-slate-600">NISN / NIS</span>
                <span className="font-mono font-bold text-slate-900">: {reportCard.nisn || reportCard.student_nisn || '-'}</span>
              </div>
              <div className="flex">
                <span className="w-32 font-semibold text-slate-600">Nama Sekolah</span>
                <span className="font-semibold text-slate-900">: {currentTenant?.name}</span>
              </div>
            </div>
            <div className="space-y-1.5">
              <div className="flex">
                <span className="w-28 font-semibold text-slate-600">Kelas / Fase</span>
                <span className="font-bold text-blue-700">: {reportCard.class_name || 'X MIPA 1'} (Fase E/F)</span>
              </div>
              <div className="flex">
                <span className="w-28 font-semibold text-slate-600">Semester</span>
                <span className="font-semibold text-slate-900">: {reportCard.semester}</span>
              </div>
              <div className="flex">
                <span className="w-28 font-semibold text-slate-600">Tahun Ajaran</span>
                <span className="font-semibold text-slate-900">: {reportCard.academic_year || '2024/2025'}</span>
              </div>
            </div>
          </div>

          {/* Tabel Nilai Capaian Kompetensi */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-800 flex items-center gap-1.5">
                <span>A. Capaian Hasil Belajar Mata Pelajaran</span>
              </h4>
              <span className="text-[11px] font-bold text-slate-600">
                Kriteria Ketercapaian Tujuan Pembelajaran (KKTP): 75
              </span>
            </div>

            <table className="w-full border-collapse border border-slate-300 text-xs">
              <thead>
                <tr className="bg-slate-100 text-slate-800">
                  <th className="border border-slate-300 px-2.5 py-2 w-10 text-center font-bold">No</th>
                  <th className="border border-slate-300 px-3 py-2 text-left font-bold w-1/4">Mata Pelajaran</th>
                  <th className="border border-slate-300 px-2.5 py-2 text-center font-bold w-16">Nilai Akhir</th>
                  <th className="border border-slate-300 px-2.5 py-2 text-center font-bold w-16">Predikat</th>
                  <th className="border border-slate-300 px-3 py-2 text-left font-bold">Capaian Kompetensi &amp; Deskripsi Kemajuan</th>
                </tr>
              </thead>
              <tbody>
                {subjects.map((s: any, idx: number) => (
                  <tr key={idx} className="hover:bg-slate-50/70">
                    <td className="border border-slate-300 px-2.5 py-2 text-center font-medium text-slate-500">
                      {idx + 1}
                    </td>
                    <td className="border border-slate-300 px-3 py-2 font-bold text-slate-900">
                      {s.subject_name}
                    </td>
                    <td className="border border-slate-300 px-2.5 py-2 text-center font-mono font-extrabold text-sm text-blue-900">
                      {s.final_score}
                    </td>
                    <td className="border border-slate-300 px-2.5 py-2 text-center font-bold">
                      <span className="px-2 py-0.5 rounded bg-blue-50 text-blue-800 border border-blue-200 text-xs">
                        {s.predicate?.charAt(0) || s.letter_grade || 'A'}
                      </span>
                    </td>
                    <td className="border border-slate-300 px-3 py-2 text-[11px] text-slate-700 leading-relaxed">
                      {s.competency_achievement || 'Menunjukkan penguasaan yang sangat baik dalam seluruh tujuan pembelajaran yang diujikan.'}
                    </td>
                  </tr>
                ))}
              </tbody>
              <tfoot>
                <tr className="bg-slate-100 font-bold">
                  <td colSpan={2} className="border border-slate-300 px-3 py-2 text-right uppercase">
                    Rata-Rata Nilai Keseluruhan:
                  </td>
                  <td className="border border-slate-300 px-2.5 py-2 text-center font-mono text-sm text-blue-900 font-black">
                    {Number(avg).toFixed(1)}
                  </td>
                  <td colSpan={2} className="border border-slate-300 px-3 py-2 text-slate-600 text-xs font-normal">
                    {avg >= 85 ? 'Kategori Sangat Memuaskan (A)' : 'Kategori Baik (B)'}
                  </td>
                </tr>
              </tfoot>
            </table>
          </div>

          {/* Ekstrakurikuler & Kehadiran (2 Kolom) */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Ekstrakurikuler */}
            <div className="space-y-1.5">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-800">
                B. Kegiatan Ekstrakurikuler
              </h4>
              <table className="w-full border-collapse border border-slate-300 text-xs">
                <thead>
                  <tr className="bg-slate-100">
                    <th className="border border-slate-300 px-2 py-1.5 text-center w-8">No</th>
                    <th className="border border-slate-300 px-2.5 py-1.5 text-left">Nama Kegiatan</th>
                    <th className="border border-slate-300 px-2 py-1.5 text-center w-14">Predikat</th>
                    <th className="border border-slate-300 px-2.5 py-1.5 text-left">Keterangan</th>
                  </tr>
                </thead>
                <tbody>
                  {extracurriculars.length === 0 ? (
                    <tr>
                      <td colSpan={4} className="border border-slate-300 p-2 text-center text-slate-400 italic">
                        Tidak ada catatan kegiatan ekstrakurikuler.
                      </td>
                    </tr>
                  ) : (
                    extracurriculars.map((ex: any, idx: number) => (
                      <tr key={idx}>
                        <td className="border border-slate-300 px-2 py-1 text-center">{idx + 1}</td>
                        <td className="border border-slate-300 px-2.5 py-1 font-semibold text-slate-900">{ex.name}</td>
                        <td className="border border-slate-300 px-2 py-1 text-center font-bold text-emerald-700">{ex.score}</td>
                        <td className="border border-slate-300 px-2.5 py-1 text-[11px] text-slate-600">{ex.description || ex.notes || 'Sangat aktif dan disiplin.'}</td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>

            {/* Presensi Kehadiran */}
            <div className="space-y-1.5">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-800">
                C. Rekapitulasi Presensi Ketidakhadiran
              </h4>
              <table className="w-full border-collapse border border-slate-300 text-xs">
                <tbody>
                  <tr>
                    <td className="border border-slate-300 px-3 py-1.5 text-slate-700 w-2/3">Kehadiran Efektif</td>
                    <td className="border border-slate-300 px-3 py-1.5 font-bold font-mono text-center">{attendance.hadir ?? 48} Hari</td>
                  </tr>
                  <tr>
                    <td className="border border-slate-300 px-3 py-1.5 text-slate-700">Sakit (S)</td>
                    <td className="border border-slate-300 px-3 py-1.5 font-bold font-mono text-center">{attendance.sakit ?? 0} Hari</td>
                  </tr>
                  <tr>
                    <td className="border border-slate-300 px-3 py-1.5 text-slate-700">Izin (I)</td>
                    <td className="border border-slate-300 px-3 py-1.5 font-bold font-mono text-center">{attendance.izin ?? 0} Hari</td>
                  </tr>
                  <tr>
                    <td className="border border-slate-300 px-3 py-1.5 text-slate-700">Tanpa Keterangan / Alpa (A)</td>
                    <td className="border border-slate-300 px-3 py-1.5 font-bold font-mono text-center">{attendance.alpa ?? 0} Hari</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>

          {/* Catatan Wali Kelas */}
          <div className="space-y-1.5">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-800">
              D. Catatan Perkembangan &amp; Karakter Profil Pelajar Pancasila
            </h4>
            <div className="p-3.5 rounded-xl border border-slate-300 bg-slate-50 text-xs text-slate-800 leading-relaxed font-serif italic">
              &quot;{reportCard.wali_kelas_notes || reportCard.teacher_notes || 'Ananda menunjukkan antusiasme yang sangat baik, berkarakter mandiri, bernalar kritis, dan menjalin kolaborasi harmonis dengan teman sebaya.'}&quot;
            </div>
          </div>

          {/* Status Kenaikan / Keputusan */}
          <div className="p-3 rounded-xl border-2 border-dashed border-emerald-300 bg-emerald-50 text-center text-xs">
            <span className="font-bold text-emerald-900">
              Keputusan: Berdasarkan pencapaian seluruh tujuan pembelajaran pada semester ini, peserta didik dinyatakan MEMENUHI SYARAT KELULUSAN / KELANJUTAN FASE.
            </span>
          </div>

          {/* Area Tanda Tangan Resmi Sekolah */}
          <div className="pt-6 grid grid-cols-3 gap-4 text-center text-xs">
            <div className="space-y-16">
              <p className="text-slate-600">Mengetahui,<br />Orang Tua / Wali Siswa</p>
              <div className="border-b border-slate-400 mx-6 font-bold text-slate-900">
                ( .................................... )
              </div>
            </div>

            <div className="space-y-16">
              <p className="text-slate-600">
                Diberikan di: {currentTenant?.city || 'Kota Administratif'}<br />
                Pada tanggal: {reportCard.published_at ? new Date(reportCard.published_at).toLocaleDateString('id-ID', { day: 'numeric', month: 'long', year: 'numeric' }) : '15 Desember 2024'}
              </p>
              <div className="space-y-0.5">
                <p className="font-bold text-slate-950 underline underline-offset-2">
                  {reportCard.homeroom_teacher_name || 'Budi Santoso, S.Pd., M.Si.'}
                </p>
                <p className="text-[10px] text-slate-500 font-mono">
                  NIP. 19820512 200801 1 009
                </p>
                <p className="text-[10px] text-emerald-700 font-semibold flex items-center justify-center gap-1">
                  <CheckCircle2 className="w-3 h-3" />
                  <span>Wali Kelas (Tanda Tangan Digital Terverifikasi)</span>
                </p>
              </div>
            </div>

            <div className="space-y-16">
              <p className="text-slate-600">
                Mengetahui,<br />
                Kepala {currentTenant?.name || 'Sekolah'}
              </p>
              <div className="space-y-0.5">
                <p className="font-bold text-slate-950 underline underline-offset-2">
                  Drs. H. Ahmad Sudrajat, M.M.
                </p>
                <p className="text-[10px] text-slate-500 font-mono">
                  NIP. 19710315 199602 1 003
                </p>
                <p className="text-[10px] text-blue-700 font-semibold flex items-center justify-center gap-1">
                  <UserCheck className="w-3 h-3" />
                  <span>Kepala Sekolah (Terkonfirmasi Resmi)</span>
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
