import React from 'react';
import { Tenant } from '../../types';
import { Users, AlertTriangle } from 'lucide-react';

interface QuotaIndicatorProps {
  tenant: Tenant;
  activeTeacherCount: number;
  onModifyClick?: () => void;
  canModify?: boolean;
}

export const QuotaIndicator: React.FC<QuotaIndicatorProps> = ({
  tenant,
  activeTeacherCount,
  onModifyClick,
  canModify = false,
}) => {
  const quota = tenant.teacher_quota || 25;
  const percentage = Math.min(100, Math.round((activeTeacherCount / quota) * 100));
  const isNearLimit = percentage >= 85 && percentage < 100;
  const isFull = percentage >= 100;

  const barColor = isFull
    ? 'bg-rose-600'
    : isNearLimit
    ? 'bg-amber-500'
    : 'bg-emerald-500';

  return (
    <div className="p-3.5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs flex flex-col gap-2">
      <div className="flex items-center justify-between text-xs">
        <div className="flex items-center gap-1.5 font-semibold text-slate-700 dark:text-slate-300">
          <Users className="w-4 h-4 text-blue-600" />
          <span>Kuota Lisensi Guru Aktif</span>
        </div>
        <div className="flex items-center gap-2">
          <span className="font-mono font-bold text-slate-900 dark:text-white">
            {activeTeacherCount} / {quota} Guru
          </span>
          {canModify && onModifyClick && (
            <button
              type="button"
              onClick={onModifyClick}
              className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-purple-100 text-purple-700 hover:bg-purple-200 dark:bg-purple-950 dark:text-purple-300 cursor-pointer"
            >
              Ubah Kuota
            </button>
          )}
        </div>
      </div>

      {/* Progress Bar */}
      <div className="w-full h-2 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
        <div
          className={`h-full transition-all duration-300 ${barColor}`}
          style={{ width: `${percentage}%` }}
        />
      </div>

      {/* Warning if full or near limit */}
      {isFull && (
        <div className="flex items-center gap-1 text-[11px] text-rose-600 dark:text-rose-400 font-medium pt-0.5">
          <AlertTriangle className="w-3.5 h-3.5 shrink-0" />
          <span>Kuota lisensi guru telah penuh ({quota}/{quota}). Aktivasi guru baru dibatasi.</span>
        </div>
      )}
      {isNearLimit && !isFull && (
        <div className="flex items-center gap-1 text-[11px] text-amber-600 dark:text-amber-400 font-medium pt-0.5">
          <AlertTriangle className="w-3.5 h-3.5 shrink-0" />
          <span>Tersisa {quota - activeTeacherCount} slot lisensi guru.</span>
        </div>
      )}
    </div>
  );
};
