import React from 'react';
import { ViewportMode } from '../../types';
import { Monitor, Tablet, Smartphone } from 'lucide-react';

interface DeviceFrameProps {
  mode: ViewportMode;
  onModeChange: (mode: ViewportMode) => void;
  children: React.ReactNode;
}

export const DeviceFrame: React.FC<DeviceFrameProps> = ({
  mode,
  onModeChange,
  children,
}) => {
  return (
    <div className="min-h-screen bg-slate-900 text-slate-100 flex flex-col">
      {/* Top Architecture & Multi-Device Control Banner */}
      <header className="bg-slate-950 border-b border-slate-800 px-4 py-2 flex flex-wrap items-center justify-between gap-3 text-xs z-30 sticky top-0">
        <div className="flex items-center gap-2">
          <span className="flex h-2 w-2 rounded-full bg-emerald-400 animate-pulse" />
          <span className="font-semibold text-slate-200">
            SCOLA Multi-Platform Simulator
          </span>
          <span className="hidden sm:inline-block text-[11px] text-slate-400">
            Single Backend • Supabase Auth • PostgreSQL RLS • Web/Android/iOS
          </span>
        </div>
        {/* Viewport Switcher */}
        <div className="flex items-center gap-1 bg-slate-900 border border-slate-700/80 rounded-lg p-0.5">
          <button
            type="button"
            onClick={() => onModeChange('desktop')}
            className={`flex items-center gap-1 px-2.5 py-1 rounded-md transition-all font-medium cursor-pointer ${
              mode === 'desktop'
                ? 'bg-blue-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
            title="Desktop Mode (Full width)"
          >
            <Monitor className="w-3.5 h-3.5" />
            <span>Desktop</span>
          </button>
          <button
            type="button"
            onClick={() => onModeChange('tablet')}
            className={`flex items-center gap-1 px-2.5 py-1 rounded-md transition-all font-medium cursor-pointer ${
              mode === 'tablet'
                ? 'bg-blue-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
            title="Tablet Mode (iPad 768px)"
          >
            <Tablet className="w-3.5 h-3.5" />
            <span>Tablet (768px)</span>
          </button>
          <button
            type="button"
            onClick={() => onModeChange('mobile')}
            className={`flex items-center gap-1 px-2.5 py-1 rounded-md transition-all font-medium cursor-pointer ${
              mode === 'mobile'
                ? 'bg-blue-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
            title="Mobile Mode (Smartphone 390px)"
          >
            <Smartphone className="w-3.5 h-3.5" />
            <span>Mobile (390px)</span>
          </button>
        </div>
      </header>

      {/* Viewport Container */}
      <div className="flex-1 flex justify-center items-start bg-slate-950/60 p-0 sm:p-3 overflow-y-auto">
        {mode === 'desktop' && (
          <div className="w-full min-h-screen bg-slate-50 text-slate-900 dark:bg-slate-950 dark:text-slate-100 transition-all">
            {children}
          </div>
        )}
        {mode === 'tablet' && (
          <div className="w-[768px] max-w-full my-4 bg-slate-50 text-slate-900 dark:bg-slate-950 dark:text-slate-100 rounded-3xl shadow-2xl border-4 border-slate-700 overflow-hidden min-h-[960px] flex flex-col">
            {/* Tablet Camera Bezel */}
            <div className="bg-slate-800 h-6 flex items-center justify-center">
              <div className="w-3 h-3 rounded-full bg-slate-900 border border-slate-700" />
            </div>
            <div className="flex-1 overflow-y-auto">{children}</div>
          </div>
        )}
        {mode === 'mobile' && (
          <div className="w-[390px] max-w-full my-4 bg-slate-50 text-slate-900 dark:bg-slate-950 dark:text-slate-100 rounded-[40px] shadow-2xl border-[6px] border-slate-800 overflow-hidden min-h-[800px] flex flex-col">
            {/* Dynamic Island / Mobile Notch */}
            <div className="bg-slate-900 h-8 flex items-center justify-between px-6 pt-1">
              <span className="text-[10px] font-semibold text-slate-400">09:41</span>
              <div className="w-20 h-4 bg-slate-950 rounded-full flex items-center justify-center">
                <div className="w-2.5 h-2.5 rounded-full bg-slate-800" />
              </div>
              <div className="flex items-center gap-1 text-[10px] text-slate-400">
                <span>5G</span>
                <span>100%</span>
              </div>
            </div>
            <div className="flex-1 overflow-y-auto">{children}</div>
            {/* Mobile Home Bar */}
            <div className="bg-slate-900 h-5 flex items-center justify-center">
              <div className="w-28 h-1 bg-slate-600 rounded-full" />
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
