import React, { useState, useEffect } from 'react';
import {
  Database,
  CheckCircle2,
  AlertTriangle,
  RefreshCw,
  Copy,
  Check,
  ExternalLink,
  X,
  Cloud,
  CloudOff,
  Server,
  ShieldCheck,
} from 'lucide-react';
import { isSupabaseConfigured, setSupabaseCredentials, getSupabase } from '../../config/supabase';
import { ENV } from '../../config/env';
import { supabaseSyncService } from '../../services/supabaseSyncService';

interface SupabaseSyncModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const SupabaseSyncModal: React.FC<SupabaseSyncModalProps> = ({ isOpen, onClose }) => {
  const [supabaseUrl, setSupabaseUrl] = useState(ENV.SUPABASE_URL || '');
  const [anonKey, setAnonKey] = useState(ENV.SUPABASE_ANON_KEY || '');
  const [isConfigured, setIsConfigured] = useState(isSupabaseConfigured());
  const [activeTab, setActiveTab] = useState<'config' | 'sql'>('config');
  const [syncStatus, setSyncStatus] = useState<string | null>(null);
  const [syncError, setSyncError] = useState<string | null>(null);
  const [isSyncing, setIsSyncing] = useState(false);
  const [copiedSql, setCopiedSql] = useState(false);

  useEffect(() => {
    if (isOpen) {
      setSupabaseUrl(ENV.SUPABASE_URL || '');
      setAnonKey(ENV.SUPABASE_ANON_KEY || '');
      setIsConfigured(isSupabaseConfigured());
      setSyncStatus(null);
      setSyncError(null);
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleSaveCredentials = async () => {
    setSyncError(null);
    setSyncStatus(null);

    if (!supabaseUrl.trim() || !anonKey.trim()) {
      setSyncError('Harap masukkan Supabase URL dan Anon Key.');
      return;
    }

    const success = setSupabaseCredentials(supabaseUrl.trim(), anonKey.trim());
    setIsConfigured(success);

    if (success) {
      setIsSyncing(true);
      setSyncStatus('Menguji koneksi ke cloud Supabase...');
      const initResult = await supabaseSyncService.initializeDatabase();
      setIsSyncing(false);
      if (initResult.success) {
        setSyncStatus('✅ Berhasil terhubung dan tersinkronisasi ke Supabase!');
      } else {
        setSyncStatus('Kredensial tersimpan. Pastikan tabel di Supabase sudah dibuat menggunakan Skrip SQL.');
      }
    } else {
      setSyncError('Koneksi gagal. Periksa format URL dan Key Anda.');
    }
  };

  const handleManualSyncNow = async () => {
    setIsSyncing(true);
    setSyncError(null);
    setSyncStatus('Memulai sinkronisasi data awal ke Supabase...');
    try {
      const res = await supabaseSyncService.initializeDatabase();
      setIsSyncing(false);
      if (res.success) {
        setSyncStatus('✅ Database Supabase berhasil disinkronkan & diisi data awal!');
      } else {
        setSyncError(`Gagal sinkron: ${res.message}. Silakan jalankan Skrip SQL di Supabase terlebih dahulu.`);
      }
    } catch (err: any) {
      setIsSyncing(false);
      setSyncError(err?.message || 'Terjadi kesalahan sinkronisasi');
    }
  };

  const copySqlSchema = () => {
    const sqlCode = `-- SCOLA SCHEMA DDL UNTUK SUPABASE
CREATE TABLE IF NOT EXISTS public.tenants (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    npsn TEXT UNIQUE NOT NULL,
    type TEXT NOT NULL CHECK (type IN ('SMA', 'SMK')),
    accreditation TEXT DEFAULT 'A',
    address TEXT,
    city TEXT,
    province TEXT,
    phone TEXT,
    email TEXT,
    logo_url TEXT,
    brand_color TEXT DEFAULT '#1e40af',
    teacher_quota INTEGER DEFAULT 25,
    active_teacher_count INTEGER DEFAULT 0,
    is_active BOOLEAN DEFAULT true,
    status TEXT DEFAULT 'ACTIVE',
    subscription_tier TEXT DEFAULT 'STANDARD',
    valid_until DATE,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS public.user_profiles (
    id TEXT PRIMARY KEY,
    tenant_id TEXT REFERENCES public.tenants(id) ON DELETE SET NULL,
    email TEXT UNIQUE NOT NULL,
    full_name TEXT NOT NULL,
    phone TEXT,
    role TEXT NOT NULL,
    status TEXT DEFAULT 'ACTIVE',
    assignments JSONB DEFAULT '[]'::jsonb,
    linked_students JSONB DEFAULT '[]'::jsonb,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS public.classes (
    id TEXT PRIMARY KEY,
    tenant_id TEXT NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    grade_level INTEGER NOT NULL,
    school_type TEXT NOT NULL,
    major_or_stream TEXT NOT NULL,
    academic_year_id TEXT,
    wali_kelas_teacher_id TEXT,
    wali_kelas_name TEXT,
    capacity INTEGER DEFAULT 36,
    total_students INTEGER DEFAULT 0,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS public.students (
    id TEXT PRIMARY KEY,
    tenant_id TEXT NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
    nisn TEXT UNIQUE NOT NULL,
    nis TEXT NOT NULL,
    full_name TEXT NOT NULL,
    class_id TEXT REFERENCES public.classes(id) ON DELETE SET NULL,
    grade_level INTEGER NOT NULL,
    school_type TEXT NOT NULL,
    major_or_stream TEXT NOT NULL,
    gender TEXT,
    status TEXT DEFAULT 'ACTIVE',
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS public.subjects (
    id TEXT PRIMARY KEY,
    tenant_id TEXT NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
    code TEXT NOT NULL,
    name TEXT NOT NULL,
    school_type TEXT NOT NULL,
    kkm NUMERIC DEFAULT 75,
    teacher_id TEXT,
    teacher_name TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS public.daily_attendance (
    id TEXT PRIMARY KEY,
    tenant_id TEXT NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
    class_id TEXT NOT NULL REFERENCES public.classes(id) ON DELETE CASCADE,
    student_id TEXT NOT NULL REFERENCES public.students(id) ON DELETE CASCADE,
    date DATE NOT NULL,
    status TEXT NOT NULL,
    notes TEXT,
    recorded_by TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS public.grades (
    id TEXT PRIMARY KEY,
    tenant_id TEXT NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
    student_id TEXT NOT NULL REFERENCES public.students(id) ON DELETE CASCADE,
    subject_id TEXT NOT NULL REFERENCES public.subjects(id) ON DELETE CASCADE,
    type TEXT NOT NULL,
    score NUMERIC NOT NULL,
    semester TEXT DEFAULT 'GANJIL',
    academic_year TEXT DEFAULT '2024/2025',
    graded_by TEXT,
    graded_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS public.academic_tasks (
    id TEXT PRIMARY KEY,
    tenant_id TEXT NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
    class_id TEXT NOT NULL REFERENCES public.classes(id) ON DELETE CASCADE,
    subject_id TEXT NOT NULL REFERENCES public.subjects(id) ON DELETE CASCADE,
    title TEXT NOT NULL,
    description TEXT,
    due_date TIMESTAMPTZ NOT NULL,
    created_by TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE public.tenants ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.classes ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.students ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.subjects ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.daily_attendance ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.grades ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.academic_tasks ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Allow public all tenants" ON public.tenants FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Allow public all user_profiles" ON public.user_profiles FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Allow public all classes" ON public.classes FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Allow public all students" ON public.students FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Allow public all subjects" ON public.subjects FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Allow public all daily_attendance" ON public.daily_attendance FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Allow public all grades" ON public.grades FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Allow public all academic_tasks" ON public.academic_tasks FOR ALL USING (true) WITH CHECK (true);

INSERT INTO public.user_profiles (id, tenant_id, email, full_name, phone, role, status)
VALUES ('usr-master', NULL, 'mdqputra@gmail.com', 'Platform Master (MDQ Putra)', '081234567890', 'MASTER', 'ACTIVE')
ON CONFLICT (id) DO UPDATE SET email = 'mdqputra@gmail.com', role = 'MASTER';`;

    navigator.clipboard.writeText(sqlCode);
    setCopiedSql(true);
    setTimeout(() => setCopiedSql(false), 3000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl w-full max-w-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between bg-slate-50 dark:bg-slate-800/60">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/10 dark:bg-emerald-500/20 text-emerald-600 dark:text-emerald-400 flex items-center justify-center">
              <Database className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
                Sinkronisasi Cloud Database (Supabase)
                {isConfigured ? (
                  <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-semibold bg-emerald-100 text-emerald-800 dark:bg-emerald-950/60 dark:text-emerald-300">
                    <Cloud className="w-3 h-3" /> Terhubung
                  </span>
                ) : (
                  <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-semibold bg-amber-100 text-amber-800 dark:bg-amber-950/60 dark:text-amber-300">
                    <CloudOff className="w-3 h-3" /> Standalone / Local Mode
                  </span>
                )}
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Memastikan data tetap sinkron di mana pun aplikasi web ini dibuka.
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex border-b border-slate-200 dark:border-slate-800 bg-slate-100/50 dark:bg-slate-900 px-6 pt-2">
          <button
            type="button"
            onClick={() => setActiveTab('config')}
            className={`pb-2.5 px-4 font-semibold text-xs border-b-2 transition-colors cursor-pointer ${
              activeTab === 'config'
                ? 'border-emerald-600 text-emerald-600 dark:border-emerald-400 dark:text-emerald-400'
                : 'border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-slate-300'
            }`}
          >
            Konfigurasi & Koneksi
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('sql')}
            className={`pb-2.5 px-4 font-semibold text-xs border-b-2 transition-colors cursor-pointer ${
              activeTab === 'sql'
                ? 'border-emerald-600 text-emerald-600 dark:border-emerald-400 dark:text-emerald-400'
                : 'border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-slate-300'
            }`}
          >
            Skrip SQL Schema Supabase
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 overflow-y-auto space-y-4">
          {activeTab === 'config' ? (
            <>
              <div className="p-3.5 rounded-xl bg-blue-50 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-900 text-xs text-blue-800 dark:text-blue-300 flex items-start gap-2.5">
                <Server className="w-4 h-4 mt-0.5 shrink-0" />
                <div>
                  <p className="font-semibold">Sinkronisasi Multi-Device & Deployment:</p>
                  <p className="mt-0.5">
                    Masukkan URL dan Anon Public Key dari project Supabase Anda. Kredensial akan disimpan secara aman dan otomatis mengaktifkan integrasi realtime lintas perangkat.
                  </p>
                </div>
              </div>

              <div className="space-y-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Supabase Project URL
                  </label>
                  <input
                    type="text"
                    value={supabaseUrl}
                    onChange={(e) => setSupabaseUrl(e.target.value)}
                    placeholder="https://xyzcompany.supabase.co"
                    className="w-full px-3 py-2 rounded-xl text-xs bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-slate-100 focus:ring-2 focus:ring-emerald-500 focus:outline-none font-mono"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Supabase Anon Public API Key
                  </label>
                  <input
                    type="password"
                    value={anonKey}
                    onChange={(e) => setAnonKey(e.target.value)}
                    placeholder="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
                    className="w-full px-3 py-2 rounded-xl text-xs bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-slate-100 focus:ring-2 focus:ring-emerald-500 focus:outline-none font-mono"
                  />
                  <p className="text-[11px] text-slate-400 mt-1">
                    *Hanya gunakan Anon Public Key. Jangan gunakan Service Role Secret di client.
                  </p>
                </div>
              </div>

              {syncStatus && (
                <div className="p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 text-xs text-emerald-800 dark:text-emerald-300 flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 shrink-0" />
                  <span>{syncStatus}</span>
                </div>
              )}

              {syncError && (
                <div className="p-3 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800 text-xs text-rose-800 dark:text-rose-300 flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 shrink-0" />
                  <span>{syncError}</span>
                </div>
              )}

              <div className="flex flex-wrap items-center gap-3 pt-2">
                <button
                  type="button"
                  onClick={handleSaveCredentials}
                  disabled={isSyncing}
                  className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold shadow-sm flex items-center gap-2 transition-all cursor-pointer disabled:opacity-50"
                >
                  <ShieldCheck className="w-4 h-4" />
                  Simpan & Hubungkan Supabase
                </button>

                {isConfigured && (
                  <button
                    type="button"
                    onClick={handleManualSyncNow}
                    disabled={isSyncing}
                    className="px-4 py-2 rounded-xl bg-slate-200 hover:bg-slate-300 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 text-xs font-bold flex items-center gap-2 transition-all cursor-pointer disabled:opacity-50"
                  >
                    <RefreshCw className={`w-3.5 h-3.5 ${isSyncing ? 'animate-spin' : ''}`} />
                    Sinkronkan Data Cloud Sekarang
                  </button>
                )}
              </div>
            </>
          ) : (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <p className="text-xs text-slate-600 dark:text-slate-400">
                  Jalankan skrip ini sekali di menu <strong>SQL Editor</strong> pada dashboard Supabase Anda:
                </p>
                <button
                  type="button"
                  onClick={copySqlSchema}
                  className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold flex items-center gap-1.5 cursor-pointer transition-colors"
                >
                  {copiedSql ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                  {copiedSql ? 'Tersalin!' : 'Salin Skrip SQL'}
                </button>
              </div>

              <div className="p-3 bg-slate-900 text-emerald-400 font-mono text-[11px] rounded-xl border border-slate-800 max-h-60 overflow-y-auto leading-relaxed">
                <p className="text-slate-500">-- 1. Tenants (SMA & SMK)</p>
                <p>CREATE TABLE IF NOT EXISTS public.tenants (...);</p>
                <p className="text-slate-500 mt-2">-- 2. User Profiles (Termasuk Akun Master mdqputra@gmail.com)</p>
                <p>CREATE TABLE IF NOT EXISTS public.user_profiles (...);</p>
                <p className="text-slate-500 mt-2">-- 3. Classes, Students, Subjects, Attendance, Grades, Tasks</p>
                <p>CREATE TABLE IF NOT EXISTS public.classes (...);</p>
                <p>CREATE TABLE IF NOT EXISTS public.students (...);</p>
                <p>CREATE TABLE IF NOT EXISTS public.daily_attendance (...);</p>
                <p>CREATE TABLE IF NOT EXISTS public.grades (...);</p>
                <p className="text-slate-500 mt-2">-- File lengkap tersedia di supabase_schema.sql di dalam ZIP</p>
              </div>

              <div className="flex items-center gap-2 text-xs text-slate-500">
                <ExternalLink className="w-3.5 h-3.5" />
                <a
                  href="https://supabase.com/dashboard"
                  target="_blank"
                  rel="noreferrer"
                  className="text-blue-600 dark:text-blue-400 hover:underline"
                >
                  Buka Supabase Console Dashboard
                </a>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-3 border-t border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/40 flex justify-end">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-1.5 rounded-xl bg-slate-200 hover:bg-slate-300 dark:bg-slate-700 dark:hover:bg-slate-600 text-slate-800 dark:text-slate-200 text-xs font-semibold cursor-pointer"
          >
            Tutup
          </button>
        </div>
      </div>
    </div>
  );
};
