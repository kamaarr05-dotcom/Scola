import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { UserProfile, TeacherAssignmentType, AuthAuditLog } from '../types';
import { authService, AuthSession } from '../services/authService';
import { auditService } from '../services/auditService';
import { getDefaultRouteForRole, canAccessRoute } from '../lib/permissions';

interface AuthContextValue {
  currentUser: UserProfile | null;
  session: AuthSession | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  sessionError: string | null;
  currentRoute: string;
  navigate: (route: string) => void;
  login: (email: string, password: string) => Promise<{ success: boolean; error?: string }>;
  logout: () => Promise<void>;
  expireSession: () => Promise<void>;
  clearSessionError: () => void;
  availableUsers: UserProfile[];
  switchPersona: (userId: string) => void;
  registerStudent: (params: {
    tenant_id: string;
    full_name: string;
    email: string;
    password?: string;
    nisn: string;
    nis: string;
    gender?: 'L' | 'P';
    class_id?: string;
    class_name?: string;
    generation_year?: number;
    school_type?: 'SMA' | 'SMK';
    peminatan_or_program?: string;
    sma_peminatan?: string;
    smk_program_id?: string;
    smk_program_name?: string;
    kompetensi_keahlian?: string;
    address?: string;
    phone?: string;
    parent_name?: string;
    parent_relation?: 'AYAH' | 'IBU' | 'WALI';
    parent_whatsapp?: string;
  }) => Promise<UserProfile>;
  createTeacher: (params: {
    tenant_id: string;
    full_name: string;
    email: string;
    phone: string;
    assignments?: TeacherAssignmentType[];
  }) => Promise<UserProfile>;
  createParentAccount: (params: {
    tenant_id: string;
    full_name: string;
    email: string;
    phone: string;
    relation_type: 'AYAH' | 'IBU' | 'WALI';
    student_ids: string[];
    class_id?: string;
  }) => Promise<UserProfile>;
  activeTeacherAssignment: TeacherAssignmentType | null;
  setActiveTeacherAssignment: (asg: TeacherAssignmentType | null) => void;
  selectedChildId: string | null;
  setSelectedChildId: (childId: string | null) => void;
  auditLogs: AuthAuditLog[];
  refreshAuditLogs: () => void;
}

const AuthContext = createContext<AuthContextValue | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<UserProfile | null>(() => authService.getCurrentUser());
  const [session, setSession] = useState<AuthSession | null>(() => authService.getCurrentSession());
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [sessionError, setSessionError] = useState<string | null>(null);

  const [currentRoute, setCurrentRoute] = useState<string>(() => {
    const user = authService.getCurrentUser();
    return user ? getDefaultRouteForRole(user.role) : '/login';
  });

  const [activeTeacherAssignment, setActiveTeacherAssignment] = useState<TeacherAssignmentType | null>(null);
  const [selectedChildId, setSelectedChildId] = useState<string | null>(null);
  const [availableUsers, setAvailableUsers] = useState<UserProfile[]>(() => authService.getAvailableUsers());
  const [auditLogs, setAuditLogs] = useState<AuthAuditLog[]>(() =>
    auditService.getLogs(currentUser?.tenant_id, currentUser?.role === 'MASTER')
  );

  const refreshAuditLogs = useCallback(() => {
    setAuditLogs(auditService.getLogs(currentUser?.tenant_id, currentUser?.role === 'MASTER'));
  }, [currentUser?.tenant_id, currentUser?.role]);

  // Set default active assignment when user changes
  useEffect(() => {
    if (currentUser?.role === 'GURU' && currentUser.assignments && currentUser.assignments.length > 0) {
      setActiveTeacherAssignment(currentUser.assignments[0].type);
    } else {
      setActiveTeacherAssignment(null);
    }

    if (currentUser?.role === 'ORANG_TUA' && currentUser.linked_students && currentUser.linked_students.length > 0) {
      setSelectedChildId(currentUser.linked_students[0].id);
    } else {
      setSelectedChildId(null);
    }

    refreshAuditLogs();
  }, [currentUser?.id, refreshAuditLogs]);

  const navigate = (route: string) => {
    const check = canAccessRoute(currentUser, route);
    if (!check.allowed) {
      if (!currentUser) {
        setSessionError(check.reason || 'Session telah berakhir. Silakan login kembali.');
        setCurrentRoute('/login');
        return;
      }
      setSessionError(check.reason || 'Anda tidak memiliki akses ke halaman ini.');
      return;
    }
    setSessionError(null);
    setCurrentRoute(route);
  };

  const login = async (email: string, password: string): Promise<{ success: boolean; error?: string }> => {
    setIsLoading(true);
    setSessionError(null);
    try {
      const result = await authService.signInWithPassword(email, password);
      if (result.error || !result.user) {
        setSessionError(result.error || 'Email atau password tidak sesuai.');
        return { success: false, error: result.error || 'Email atau password tidak sesuai.' };
      }
      setCurrentUser(result.user);
      setSession(result.session);
      setAvailableUsers(authService.getAvailableUsers());
      refreshAuditLogs();
      const targetRoute = getDefaultRouteForRole(result.user.role);
      setCurrentRoute(targetRoute);
      return { success: true };
    } catch {
      const safeError = 'Email atau password tidak sesuai.';
      setSessionError(safeError);
      return { success: false, error: safeError };
    } finally {
      setIsLoading(false);
    }
  };

  const logout = async (): Promise<void> => {
    setIsLoading(true);
    try {
      await authService.signOut();
      setCurrentUser(null);
      setSession(null);
      setActiveTeacherAssignment(null);
      setSelectedChildId(null);
      setSessionError(null);
      setCurrentRoute('/login');
      refreshAuditLogs();
    } finally {
      setIsLoading(false);
    }
  };

  const expireSession = async (): Promise<void> => {
    await authService.expireSession();
    setCurrentUser(null);
    setSession(null);
    setSessionError('Session telah berakhir. Silakan login kembali.');
    setCurrentRoute('/login');
    refreshAuditLogs();
  };

  const clearSessionError = () => {
    setSessionError(null);
  };

  const switchPersona = (userId: string) => {
    const found = availableUsers.find((u) => u.id === userId);
    if (found) {
      authService.setCurrentUser(found);
      setCurrentUser(found);
      setSession({
        access_token: `scola_jwt_${found.id}`,
        token_type: 'bearer',
        expires_in: 3600,
        expires_at: Math.floor(Date.now() / 1000) + 3600,
        user_id: found.id,
      });
      setSessionError(null);
      const targetRoute = getDefaultRouteForRole(found.role);
      setCurrentRoute(targetRoute);
      refreshAuditLogs();
    }
  };

  const registerStudent = async (params: {
    tenant_id: string;
    full_name: string;
    email: string;
    password?: string;
    nisn: string;
    nis: string;
    gender?: 'L' | 'P';
    class_id?: string;
    class_name?: string;
    generation_year?: number;
    school_type?: 'SMA' | 'SMK';
    peminatan_or_program?: string;
    sma_peminatan?: string;
    smk_program_id?: string;
    smk_program_name?: string;
    kompetensi_keahlian?: string;
    address?: string;
    phone?: string;
    parent_name?: string;
    parent_relation?: 'AYAH' | 'IBU' | 'WALI';
    parent_whatsapp?: string;
  }): Promise<UserProfile> => {
    setIsLoading(true);
    try {
      const newStudent = await authService.registerStudent(params);
      setAvailableUsers(authService.getAvailableUsers());
      refreshAuditLogs();
      return newStudent;
    } finally {
      setIsLoading(false);
    }
  };

  const createTeacher = async (params: {
    tenant_id: string;
    full_name: string;
    email: string;
    phone: string;
    assignments?: TeacherAssignmentType[];
  }): Promise<UserProfile> => {
    if (!currentUser) throw new Error('Unauthenticated');
    setIsLoading(true);
    try {
      const newTeacher = await authService.createTeacher(params, currentUser);
      setAvailableUsers(authService.getAvailableUsers());
      refreshAuditLogs();
      return newTeacher;
    } finally {
      setIsLoading(false);
    }
  };

  const createParentAccount = async (params: {
    tenant_id: string;
    full_name: string;
    email: string;
    phone: string;
    relation_type: 'AYAH' | 'IBU' | 'WALI';
    student_ids: string[];
    class_id?: string;
  }): Promise<UserProfile> => {
    if (!currentUser) throw new Error('Unauthenticated');
    setIsLoading(true);
    try {
      const newParent = await authService.activateParent(params, currentUser);
      setAvailableUsers(authService.getAvailableUsers());
      refreshAuditLogs();
      return newParent;
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <AuthContext.Provider
      value={{
        currentUser,
        session,
        isAuthenticated: Boolean(currentUser && session),
        isLoading,
        sessionError,
        currentRoute,
        navigate,
        login,
        logout,
        expireSession,
        clearSessionError,
        availableUsers,
        switchPersona,
        registerStudent,
        createTeacher,
        createParentAccount,
        activeTeacherAssignment,
        setActiveTeacherAssignment,
        selectedChildId,
        setSelectedChildId,
        auditLogs,
        refreshAuditLogs,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
