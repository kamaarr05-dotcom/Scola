import React, { createContext, useContext, useState, useEffect } from 'react';
import { Tenant, UserProfile } from '../types';
import { tenantRepository } from '../repositories/tenantRepository';
import { teacherLicenseService } from '../services/teacherLicenseService';

interface TenantContextValue {
  currentTenant: Tenant | null;
  allTenants: Tenant[];
  isLoading: boolean;
  setCurrentTenant: (tenant: Tenant) => void;
  updateQuota: (
    tenantId: string,
    newQuota: number,
    actor: UserProfile,
    reason?: string
  ) => Promise<void>;
  createTenant: (
    data: {
      name: string;
      npsn: string;
      type: 'SMA' | 'SMK';
      accreditation?: 'A' | 'B' | 'C' | 'BELUM_TERAKREDITASI';
      address: string;
      city: string;
      province: string;
      phone: string;
      email: string;
      logo_url?: string;
      brand_color?: string;
      teacher_quota?: number;
      is_active?: boolean;
      subscription_tier?: 'TRIAL' | 'STANDARD' | 'ENTERPRISE';
    },
    actor: UserProfile
  ) => Promise<Tenant>;
  updateSchoolProfile: (
    tenantId: string,
    data: {
      name?: string;
      address?: string;
      city?: string;
      province?: string;
      phone?: string;
      email?: string;
      logo_url?: string;
      brand_color?: string;
      accreditation?: 'A' | 'B' | 'C' | 'BELUM_TERAKREDITASI';
    },
    actor: UserProfile
  ) => Promise<Tenant>;
  toggleTenantStatus: (
    tenantId: string,
    isActive: boolean,
    actor: UserProfile,
    reason?: string
  ) => Promise<Tenant>;
  refreshTenants: () => Promise<void>;
}

const TenantContext = createContext<TenantContextValue | undefined>(undefined);

export const TenantProvider: React.FC<{
  children: React.ReactNode;
  currentUser: UserProfile | null;
}> = ({ children, currentUser }) => {
  const [tenants, setTenants] = useState<Tenant[]>([]);
  const [currentTenant, setCurrentTenantState] = useState<Tenant | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);

  const refreshTenants = async () => {
    setIsLoading(true);
    try {
      const data = await tenantRepository.getAll();
      setTenants(data);
      if (currentUser?.tenant_id) {
        const found = data.find((t) => t.id === currentUser.tenant_id);
        setCurrentTenantState(found || data[0] || null);
      } else if (!currentTenant && data.length > 0) {
        setCurrentTenantState(data[0]);
      }
    } catch (err) {
      console.error('Failed to load tenants:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    refreshTenants();
  }, [currentUser?.tenant_id]);

  const setCurrentTenant = (tenant: Tenant) => {
    // Only MASTER can switch arbitrarily between tenants.
    // Regular users are locked to their assigned tenant.
    if (currentUser?.role === 'MASTER' || currentUser?.tenant_id === tenant.id) {
      setCurrentTenantState(tenant);
    } else {
      console.warn('Unauthorized tenant switch attempted');
    }
  };

  const updateQuota = async (
    tenantId: string,
    newQuota: number,
    actor: UserProfile,
    reason?: string
  ) => {
    const result = await teacherLicenseService.updateTenantQuota({
      tenantId,
      newQuota,
      actor,
      reason,
    });
    setTenants((prev) => prev.map((t) => (t.id === tenantId ? result.tenant : t)));
    if (currentTenant?.id === tenantId) {
      setCurrentTenantState(result.tenant);
    }
  };

  const createTenant = async (
    data: {
      name: string;
      npsn: string;
      type: 'SMA' | 'SMK';
      accreditation?: 'A' | 'B' | 'C' | 'BELUM_TERAKREDITASI';
      address: string;
      city: string;
      province: string;
      phone: string;
      email: string;
      logo_url?: string;
      brand_color?: string;
      teacher_quota?: number;
      is_active?: boolean;
      subscription_tier?: 'TRIAL' | 'STANDARD' | 'ENTERPRISE';
    },
    actor: UserProfile
  ): Promise<Tenant> => {
    const newTenant = await tenantRepository.createTenant(data, actor);
    setTenants((prev) => [...prev, newTenant]);
    return newTenant;
  };

  const updateSchoolProfile = async (
    tenantId: string,
    data: {
      name?: string;
      address?: string;
      city?: string;
      province?: string;
      phone?: string;
      email?: string;
      logo_url?: string;
      brand_color?: string;
      accreditation?: 'A' | 'B' | 'C' | 'BELUM_TERAKREDITASI';
    },
    actor: UserProfile
  ): Promise<Tenant> => {
    const updated = await tenantRepository.updateSchoolProfile(tenantId, data, actor);
    setTenants((prev) => prev.map((t) => (t.id === tenantId ? updated : t)));
    if (currentTenant?.id === tenantId) {
      setCurrentTenantState(updated);
    }
    return updated;
  };

  const toggleTenantStatus = async (
    tenantId: string,
    isActive: boolean,
    actor: UserProfile,
    reason?: string
  ): Promise<Tenant> => {
    const toggled = await tenantRepository.toggleTenantStatus(tenantId, isActive, actor, reason);
    setTenants((prev) => prev.map((t) => (t.id === tenantId ? toggled : t)));
    if (currentTenant?.id === tenantId) {
      setCurrentTenantState(toggled);
    }
    return toggled;
  };

  return (
    <TenantContext.Provider
      value={{
        currentTenant,
        allTenants: tenants,
        isLoading,
        setCurrentTenant,
        updateQuota,
        createTenant,
        updateSchoolProfile,
        toggleTenantStatus,
        refreshTenants,
      }}
    >
      {children}
    </TenantContext.Provider>
  );
};

export function useTenant() {
  const context = useContext(TenantContext);
  if (!context) {
    throw new Error('useTenant must be used within a TenantProvider');
  }
  return context;
}
