import { ScolaRole, TeacherProfile, Tenant, UserStatus } from '../types';

export interface QuotaCheckResult {
  allowed: boolean;
  currentCount: number;
  quotaLimit: number;
  availableSlots: number;
  reason?: string;
}

/**
 * Validates if an active teacher can be added or reactivated under the tenant's license quota.
 */
export function validateTeacherQuota(
  tenant: Tenant,
  currentTeachers: Array<{ id?: string; status: UserStatus }>,
  targetTeacherId?: string,
  newStatus: UserStatus = 'ACTIVE'
): QuotaCheckResult {
  // Count only teachers with status = 'ACTIVE' excluding target if updating
  const activeCount = currentTeachers.filter(
    (t) => t.status === 'ACTIVE' && t.id !== targetTeacherId
  ).length;
  const quota = tenant.teacher_quota;
  const neededSlots = newStatus === 'ACTIVE' ? 1 : 0;
  const projectedCount = activeCount + neededSlots;
  const availableSlots = Math.max(0, quota - activeCount);

  if (newStatus === 'ACTIVE' && projectedCount > quota) {
    return {
      allowed: false,
      currentCount: activeCount,
      quotaLimit: quota,
      availableSlots: 0,
      reason: `Kuota guru telah habis. Silakan hubungi administrator SCOLA untuk menambah lisensi. (Kuota lisensi guru tidak mencukupi: ${activeCount}/${quota})`,
    };
  }

  return {
    allowed: true,
    currentCount: activeCount,
    quotaLimit: quota,
    availableSlots: quota - projectedCount,
  };
}

export const TEACHER_LICENSE_PRICE_PER_MONTH = 15000;

/**
 * Calculates estimated monthly teacher license cost.
 * SCOLA locked business rule: Rp15.000 / active teacher / month.
 */
export function calculateTeacherLicenseFee(activeTeacherCount: number): number {
  return Math.max(0, activeTeacherCount) * TEACHER_LICENSE_PRICE_PER_MONTH;
}

/**
 * Validates whether the actor has the authority to update teacher quota.
 */
export function validateQuotaModificationAuthority(
  actorRole: ScolaRole,
  newQuota: number,
  currentActiveCount?: number
): { allowed: boolean; reason?: string } {
  if (actorRole !== 'MASTER') {
    return {
      allowed: false,
      reason: 'AKSES DITOLAK: Hanya role MASTER yang berwenang mengubah kuota lisensi guru pada tenant.',
    };
  }
  if (newQuota < 1) {
    return {
      allowed: false,
      reason: 'Kuota guru harus bernilai minimal 1.',
    };
  }
  if (currentActiveCount !== undefined && newQuota < currentActiveCount) {
    return {
      allowed: false,
      reason: `Kuota baru (${newQuota}) tidak boleh lebih kecil dari jumlah Guru yang saat ini aktif (${currentActiveCount}). Nonaktifkan guru terlebih dahulu jika ingin menurunkan kuota.`,
    };
  }
  return { allowed: true };
}

/**
 * Checks if a tenant has available quota to add an active teacher.
 */
export function checkTenantQuotaBeforeAddingTeacher(
  tenant: Tenant,
  currentTeachers: TeacherProfile[]
): QuotaCheckResult {
  return validateTeacherQuota(tenant, currentTeachers, undefined, 'ACTIVE');
}
