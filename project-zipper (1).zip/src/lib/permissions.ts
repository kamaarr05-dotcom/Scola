import { ScolaRole, TeacherAssignment, TeacherAssignmentType, UserProfile } from '../types';

/**
 * Access Control & Permission Validator
 * Enforces business rules across all platforms (Web, Android, iOS).
 */
export const ROLE_HIERARCHY: Record<ScolaRole, number> = {
  MASTER: 100,
  KEPALA_SEKOLAH: 80,
  TENAGA_KEPENDIDIKAN: 60,
  GURU: 50,
  SISWA: 20,
  ORANG_TUA: 20,
};

export const ROLE_LABELS: Record<ScolaRole, string> = {
  MASTER: 'Super Master Platform',
  KEPALA_SEKOLAH: 'Kepala Sekolah',
  GURU: 'Guru Pengajar',
  SISWA: 'Siswa / Siswi',
  ORANG_TUA: 'Orang Tua / Wali Murid',
  TENAGA_KEPENDIDIKAN: 'Tenaga Kependidikan / TU',
};

export const ASSIGNMENT_LABELS: Record<TeacherAssignmentType, string> = {
  GURU: 'Guru Pengajar',
  WAKA_KURIKULUM: 'Waka Kurikulum',
  WAKA_KESISWAAN: 'Waka Kesiswaan',
  WAKA_SARPRAS: 'Waka Sarpras',
  WAKA_HUMAS: 'Waka Humas / Hubin',
  WALI_KELAS: 'Wali Kelas',
  KAPROG: 'Kepala Program (SMK)',
  BK: 'Guru Bimbingan Konseling (BK)',
  GURU_BK: 'Guru Bimbingan Konseling (BK)',
};

export function hasRole(user: UserProfile | null, allowedRoles: ScolaRole[]): boolean {
  if (!user) return false;
  if (user.role === 'MASTER') return true; // MASTER has universal platform access
  return allowedRoles.includes(user.role);
}

export function hasAssignment(
  user: UserProfile | null,
  assignmentType: TeacherAssignmentType
): boolean {
  if (!user) return false;
  if (user.role === 'MASTER') return true;
  if (user.role !== 'GURU' || !user.assignments) return false;
  // Normalize BK & GURU_BK
  const targetTypes = (assignmentType === 'BK' || assignmentType === 'GURU_BK')
    ? ['BK', 'GURU_BK']
    : [assignmentType];
  return user.assignments.some(
    (a) => targetTypes.includes(a.type) && a.active
  );
}

export function getActiveAssignments(user: UserProfile | null): TeacherAssignment[] {
  if (!user || !user.assignments) return [];
  return user.assignments.filter((a) => a.active);
}

/**
 * Tenant Security:
 * Validates whether the authenticated user has authorization to access the specified tenant.
 * Crucial: Never trust tenant_id passed by frontend without validating user membership.
 */
export function validateTenantAccess(
  user: UserProfile | null,
  targetTenantId: string | null | undefined
): boolean {
  if (!user) return false;
  if (user.role === 'MASTER') return true; // Master has multi-tenant oversight
  if (!targetTenantId || !user.tenant_id) return false;
  return user.tenant_id === targetTenantId;
}

/**
 * Permission types based on ROLE + ASSIGNMENT + TENANT + RESOURCE OWNERSHIP
 */
export type ScolaPermission =
  | 'TENANT_MANAGE'
  | 'TEACHER_QUOTA_MANAGE'
  | 'TEACHER_CREATE'
  | 'TEACHER_ASSIGN'
  | 'PARENT_ACTIVATE'
  | 'STUDENT_REGISTER'
  | 'STUDENT_STATUS_MANAGE'
  | 'STUDENT_EDIT'
  | 'STUDENT_CLASS_ASSIGN'
  | 'WALI_KELAS_ACCESS'
  | 'WAKA_KURIKULUM_ACCESS'
  | 'WAKA_KESISWAAN_ACCESS'
  | 'WAKA_SARPRAS_ACCESS'
  | 'WAKA_HUMAS_ACCESS'
  | 'KAPROG_ACCESS'
  | 'BK_ACCESS'
  | 'STUDENT_DATA_VIEW';

export interface PermissionContext {
  tenant_id?: string;
  class_id?: string;
  student_id?: string;
  resource_owner_id?: string;
}

/**
 * Comprehensive authorization validator enforcing:
 * ROLE + ASSIGNMENT + TENANT + RESOURCE OWNERSHIP
 */
export function checkPermission(
  user: UserProfile | null,
  permission: ScolaPermission,
  context?: PermissionContext
): boolean {
  if (!user) return false;
  if (user.status !== 'ACTIVE') return false;

  // Master bypass
  if (user.role === 'MASTER') return true;

  // Tenant Boundary Check: User cannot operate outside their assigned tenant
  if (context?.tenant_id && !validateTenantAccess(user, context.tenant_id)) {
    return false;
  }

  switch (permission) {
    case 'TENANT_MANAGE':
    case 'TEACHER_QUOTA_MANAGE':
      // Exclusively MASTER (already handled in Master bypass above)
      return false;

    case 'TEACHER_CREATE':
    case 'TEACHER_ASSIGN':
      // MASTER or KEPALA_SEKOLAH within their tenant
      return user.role === 'KEPALA_SEKOLAH';

    case 'PARENT_ACTIVATE':
      if (user.role === 'KEPALA_SEKOLAH') return true;
      if (user.role === 'GURU') {
        return user.assignments?.some(
          (a) =>
            a.type === 'WALI_KELAS' &&
            a.active &&
            (!context?.class_id || a.class_id === context.class_id)
        ) ?? false;
      }
      return false;

    case 'STUDENT_REGISTER':
      // Siswa can self-register
      return true;

    case 'STUDENT_STATUS_MANAGE':
      // KEPALA_SEKOLAH can activate/deactivate/graduate students in their tenant
      if (user.role === 'KEPALA_SEKOLAH') return true;
      // WALI_KELAS can manage status for students in their assigned class
      if (user.role === 'GURU' && hasAssignment(user, 'WALI_KELAS')) {
        if (!context?.class_id) return true;
        return user.assignments?.some(
          (a) => a.type === 'WALI_KELAS' && a.active && a.class_id === context.class_id
        ) ?? false;
      }
      return false;

    case 'STUDENT_EDIT':
      if (user.role === 'KEPALA_SEKOLAH') return true;
      if (user.role === 'GURU' && hasAssignment(user, 'WALI_KELAS')) {
        if (!context?.class_id) return true;
        return user.assignments?.some(
          (a) => a.type === 'WALI_KELAS' && a.active && a.class_id === context.class_id
        ) ?? false;
      }
      // Siswa can only edit their own contact details
      if (user.role === 'SISWA') {
        return context?.student_id === user.id || context?.resource_owner_id === user.id;
      }
      return false;

    case 'STUDENT_CLASS_ASSIGN':
      // Only KEPALA_SEKOLAH (and Master) can move students across classes
      return user.role === 'KEPALA_SEKOLAH';

    case 'WALI_KELAS_ACCESS':
      return hasAssignment(user, 'WALI_KELAS');
    case 'WAKA_KURIKULUM_ACCESS':
      return hasAssignment(user, 'WAKA_KURIKULUM');
    case 'WAKA_KESISWAAN_ACCESS':
      return hasAssignment(user, 'WAKA_KESISWAAN');
    case 'WAKA_SARPRAS_ACCESS':
      return hasAssignment(user, 'WAKA_SARPRAS');
    case 'WAKA_HUMAS_ACCESS':
      return hasAssignment(user, 'WAKA_HUMAS');
    case 'KAPROG_ACCESS':
      return hasAssignment(user, 'KAPROG');
    case 'BK_ACCESS':
      return hasAssignment(user, 'BK') || hasAssignment(user, 'GURU_BK');

    case 'STUDENT_DATA_VIEW':
      if (user.role === 'KEPALA_SEKOLAH') return true;
      if (user.role === 'GURU') return true; // Teachers can view students in their school
      if (user.role === 'SISWA') {
        // Ownership check: Student can ONLY view their own records
        return !context?.student_id || context.student_id === user.id;
      }
      if (user.role === 'ORANG_TUA') {
        // Ownership check: Parent can ONLY view their linked children
        if (!context?.student_id) return true;
        return user.linked_students?.some((s) => s.id === context.student_id) ?? false;
      }
      if (user.role === 'TENAGA_KEPENDIDIKAN') return true;
      return false;

    default:
      return false;
  }
}

/**
 * Route protection validator
 */
export function canAccessRoute(
  user: UserProfile | null,
  routePath: string
): { allowed: boolean; reason?: string; requiredRole?: ScolaRole } {
  if (routePath === '/login' || routePath === '/register-student') {
    return { allowed: true };
  }
  if (!user) {
    return {
      allowed: false,
      reason: 'Session telah berakhir. Silakan login kembali.',
    };
  }
  if (user.status !== 'ACTIVE') {
    return {
      allowed: false,
      reason: 'Akun Anda belum aktif.',
    };
  }
  if (user.role === 'MASTER') {
    return { allowed: true };
  }
  if (routePath.startsWith('/master')) {
    return {
      allowed: false,
      reason: 'Anda tidak memiliki akses ke halaman ini.',
      requiredRole: 'MASTER',
    };
  }
  if (routePath.startsWith('/school')) {
    return {
      allowed: user.role === 'KEPALA_SEKOLAH',
      reason: 'Anda tidak memiliki akses ke halaman ini.',
      requiredRole: 'KEPALA_SEKOLAH',
    };
  }
  if (routePath.startsWith('/teacher')) {
    return {
      allowed: user.role === 'GURU',
      reason: 'Anda tidak memiliki akses ke halaman ini.',
      requiredRole: 'GURU',
    };
  }
  if (routePath.startsWith('/student')) {
    return {
      allowed: user.role === 'SISWA',
      reason: 'Anda tidak memiliki akses ke halaman ini.',
      requiredRole: 'SISWA',
    };
  }
  if (routePath.startsWith('/parent')) {
    return {
      allowed: user.role === 'ORANG_TUA',
      reason: 'Anda tidak memiliki akses ke halaman ini.',
      requiredRole: 'ORANG_TUA',
    };
  }
  if (routePath.startsWith('/staff')) {
    return {
      allowed: user.role === 'TENAGA_KEPENDIDIKAN',
      reason: 'Anda tidak memiliki akses ke halaman ini.',
      requiredRole: 'TENAGA_KEPENDIDIKAN',
    };
  }
  return { allowed: true };
}

/**
 * Returns default dashboard route according to user role
 */
export function getDefaultRouteForRole(role: ScolaRole): string {
  switch (role) {
    case 'MASTER':
      return '/master';
    case 'KEPALA_SEKOLAH':
      return '/school';
    case 'GURU':
      return '/teacher';
    case 'SISWA':
      return '/student';
    case 'ORANG_TUA':
      return '/parent';
    case 'TENAGA_KEPENDIDIKAN':
      return '/staff';
    default:
      return '/login';
  }
}

/**
 * Business Rule: Can create teacher?
 * Guru cannot self-register. Only MASTER or KEPALA_SEKOLAH can create teacher accounts.
 */
export function canCreateTeacher(actorRole: ScolaRole): boolean {
  return actorRole === 'MASTER' || actorRole === 'KEPALA_SEKOLAH';
}

/**
 * Business Rule: Can create parent account?
 * Parents do NOT self-register. Must be created or activated by Wali Kelas (or Kepala Sekolah/Master).
 */
export function canActivateParentAccount(
  actor: UserProfile | null,
  studentClassId?: string
): boolean {
  if (!actor) return false;
  if (actor.role === 'MASTER' || actor.role === 'KEPALA_SEKOLAH') return true;
  if (actor.role === 'GURU') {
    // Check if teacher is Wali Kelas
    const isWaliKelas = actor.assignments?.some(
      (a) => a.type === 'WALI_KELAS' && a.active && (!studentClassId || a.class_id === studentClassId)
    );
    return Boolean(isWaliKelas);
  }
  return false;
}

/**
 * Business Rule: Can edit teacher quota?
 * Quota resides on tenant. ONLY MASTER can modify teacher quota!
 */
export function canModifyTeacherQuota(actorRole: ScolaRole): boolean {
  return actorRole === 'MASTER';
}
