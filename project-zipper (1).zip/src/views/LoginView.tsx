import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { useTenant } from '../context/TenantContext';
import { ScolaBrand } from '../components/common/ScolaBrand';
import { RoleBadge } from '../components/common/RoleBadge';
import {
  Lock,
  Mail,
  UserPlus,
  ShieldCheck,
  AlertCircle,
  GraduationCap,
  Sparkles,
  ArrowRight,
  Info,
  X,
  Phone,
  User,
  Users,
} from 'lucide-react';

export const LoginView: React.FC = () => {
  const { login, availableUsers, registerStudent, isLoading, sessionError, clearSessionError } = useAuth();
  const { allTenants } = useTenant();

  const [email, setEmail] = useState('kepsek.sman1@scola.id');
  const [password, setPassword] = useState('password123');
  const [localError, setLocalError] = useState<string | null>(null);

  // Registration Modal for Students (Siswa self-register is allowed!)
  const [showRegisterModal, setShowRegisterModal] = useState<boolean>(false);
  const [regTenantId, setRegTenantId] = useState<string>(allTenants[0]?.id || 'tenant-sman-1');
  const [regFullName, setRegFullName] = useState('');
  const [regEmail, setRegEmail] = useState('');
  const [regPassword, setRegPassword] = useState('');
  const [regNisn, setRegNisn] = useState('');
  const [regNis, setRegNis] = useState('');
  const [regGender, setRegGender] = useState<'L' | 'P'>('L');
  const [regPhone, setRegPhone] = useState('');
  const [regParentName, setRegParentName] = useState('');
  const [regParentRelation, setRegParentRelation] = useState<'AYAH' | 'IBU' | 'WALI'>('AYAH');
  const [regParentWa, setRegParentWa] = useState('');
  const [regProgram, setRegProgram] = useState('');
  const [regSuccessMsg, setRegSuccessMsg] = useState<string | null>(null);
  const [regErrorMsg, setRegErrorMsg] = useState<string | null>(null);

  const selectedRegTenant = allTenants.find((t) => t.id === regTenantId);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLocalError(null);
    clearSessionError();

    const result = await login(email, password);
    if (!result.success) {
      setLocalError(result.error || 'Email atau password tidak sesuai.');
    }
  };

  const handleRegisterStudent = async (e: React.FormEvent) => {
    e.preventDefault();
    setRegErrorMsg(null);
    setRegSuccessMsg(null);

    if (!regFullName || !regEmail || !regNisn || !regNis) {
      setRegErrorMsg('Harap lengkapi semua field yang wajib diisi (*).');
      return;
    }

    try {
      await registerStudent({
        tenant_id: regTenantId,
        full_name: regFullName,
        email: regEmail,
        password: regPassword || 'password123',
        nisn: regNisn,
        nis: regNis,
        gender: regGender,
        school_type: selectedRegTenant?.type || 'SMA',
        peminatan_or_program: regProgram,
        phone: regPhone,
        parent_name: regParentName,
        parent_relation: regParentRelation,
        parent_whatsapp: regParentWa,
      });

      setRegSuccessMsg('Registrasi Siswa Berhasil! Akun telah terdaftar dan dapat langsung digunakan untuk login.');
      // Auto fill login form
      setEmail(regEmail);
      setPassword(regPassword || 'password123');
      setTimeout(() => {
        setShowRegisterModal(false);
        setRegSuccessMsg(null);
      }, 2000);
    } catch (err: any) {
      setRegErrorMsg(err.message || 'Gagal mendaftar siswa.');
    }
  };

  return (
    <div className="min-h-screen bg-slate-900 text-slate-100 flex flex-col justify-between relative overflow-hidden">
      {/* Background Decorative Gradients */}
      <div className="absolute -top-40 -right-40 w-96 h-96 rounded-full bg-blue-600/20 blur-3xl pointer-events-none" />
      <div className="absolute -bottom-40 -left-40 w-96 h-96 rounded-full bg-emerald-600/15 blur-3xl pointer-events-none" />

      {/* Top Header */}
      <header className="p-6 flex items-center justify-between z-10">
        <ScolaBrand size="md" showTagline={true} />
        <div className="flex items-center gap-2">
          <span className="text-[11px] font-mono px-2.5 py-1 rounded-full bg-slate-800 text-blue-400 border border-slate-700">
            v2.4.0 • Enterprise Edition
          </span>
        </div>
      </header>

      {/* Main Login Card */}
      <div className="flex-1 flex items-center justify-center p-4 z-10">
        <div className="w-full max-w-md bg-white dark:bg-slate-900 text-slate-900 dark:text-white rounded-3xl p-6 sm:p-8 shadow-2xl border border-slate-200 dark:border-slate-800 space-y-6">
          <div className="text-center space-y-2">
            <h1 className="text-2xl font-black tracking-tight">
              Masuk ke Portal SCOLA
            </h1>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Satu pintu akses terintegrasi untuk Guru, Siswa, Orang Tua, dan Manajemen Sekolah
            </p>
          </div>

          {(localError || sessionError) && (
            <div className="p-3.5 rounded-2xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900 text-rose-700 dark:text-rose-300 text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{localError || sessionError}</span>
            </div>
          )}

          <form onSubmit={handleLogin} className="space-y-4">
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-700 dark:text-slate-300">
                Alamat Email Akun
              </label>
              <div className="relative">
                <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="nama@sekolah.sch.id"
                  className="w-full pl-9 pr-3 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs focus:ring-2 focus:ring-blue-500 focus:outline-none"
                />
              </div>
            </div>

            <div className="space-y-1.5">
              <div className="flex items-center justify-between">
                <label className="text-xs font-bold text-slate-700 dark:text-slate-300">
                  Kata Sandi
                </label>
                <span className="text-[11px] text-blue-600 dark:text-blue-400 hover:underline cursor-pointer">
                  Lupa sandi?
                </span>
              </div>
              <div className="relative">
                <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                <input
                  type="password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full pl-9 pr-3 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs focus:ring-2 focus:ring-blue-500 focus:outline-none"
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={isLoading}
              className="w-full py-3 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl text-xs transition-all shadow-md shadow-blue-500/20 flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
            >
              {isLoading ? (
                <span>Memproses Verifikasi...</span>
              ) : (
                <>
                  <span>Masuk Sekarang</span>
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>
          </form>

          {/* Registration Info & Rule Box */}
          <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-850 border border-slate-200 dark:border-slate-800 text-xs space-y-2">
            <div className="flex items-center justify-between">
              <span className="font-bold text-slate-800 dark:text-slate-200">
                Belum memiliki akun?
              </span>
              <button
                type="button"
                onClick={() => setShowRegisterModal(true)}
                className="text-blue-600 dark:text-blue-400 font-bold hover:underline flex items-center gap-1 cursor-pointer"
              >
                <UserPlus className="w-3.5 h-3.5" />
                <span>Registrasi Siswa</span>
              </button>
            </div>
            <p className="text-[11px] text-slate-500 dark:text-slate-400 leading-relaxed">
              <strong>Aturan Akses:</strong> Siswa baru diperbolehkan mendaftar mandiri. Akun Guru dibuat langsung oleh Kepala Sekolah/Master, dan akun Orang Tua diaktivasi oleh Wali Kelas.
            </p>
          </div>

          {/* Quick Demo Persona Switcher */}
          <div className="space-y-2 pt-2 border-t border-slate-100 dark:border-slate-800">
            <div className="flex items-center justify-between text-[11px] text-slate-400 font-semibold">
              <span className="flex items-center gap-1">
                <Sparkles className="w-3 h-3 text-amber-500" />
                Pintasan Akun Uji Coba:
              </span>
            </div>
            <div className="grid grid-cols-2 gap-1.5 text-[11px]">
              {availableUsers
                .filter((u) => u.role !== 'MASTER' && u.email !== 'mdqputra@gmail.com')
                .slice(0, 6)
                .map((u) => (
                <button
                  key={u.id}
                  type="button"
                  onClick={() => {
                    setEmail(u.email);
                    setPassword('password123');
                  }}
                  className="p-2 rounded-xl text-left bg-slate-100 dark:bg-slate-800/70 hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors border border-slate-200 dark:border-slate-700 flex flex-col cursor-pointer"
                >
                  <span className="font-bold text-slate-900 dark:text-white truncate">
                    {u.full_name.split(' ')[0]}
                  </span>
                  <div className="flex items-center gap-1 mt-0.5">
                    <RoleBadge role={u.role} size="sm" />
                  </div>
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer className="p-4 text-center text-xs text-slate-500 border-t border-slate-800 flex items-center justify-center gap-4">
        <span>© {new Date().getFullYear()} SCOLA Platform</span>
        <span>•</span>
        <span className="flex items-center gap-1">
          <ShieldCheck className="w-3.5 h-3.5 text-emerald-500" />
          Single Backend Supabase Auth & PostgreSQL RLS
        </span>
      </footer>

      {/* Siswa Self-Registration Modal */}
      {showRegisterModal && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl max-w-xl w-full max-h-[90vh] flex flex-col shadow-2xl overflow-hidden">
            {/* Header */}
            <div className="bg-slate-900 text-white p-4 flex items-center justify-between border-b border-slate-800">
              <div className="flex items-center gap-2">
                <div className="p-2 rounded-xl bg-emerald-600 text-white">
                  <GraduationCap className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm font-bold">
                    Pendaftaran Mandiri Siswa Baru
                  </h3>
                  <p className="text-[11px] text-slate-400">
                    Hanya Siswa yang dapat mendaftar mandiri sesuai aturan sistem
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setShowRegisterModal(false)}
                className="text-slate-400 hover:text-white p-1 rounded-lg cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Form */}
            <form onSubmit={handleRegisterStudent} className="p-5 overflow-y-auto space-y-4 text-xs">
              {regSuccessMsg && (
                <div className="p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 text-emerald-800 dark:text-emerald-200 font-semibold">
                  {regSuccessMsg}
                </div>
              )}
              {regErrorMsg && (
                <div className="p-3 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800 text-rose-800 dark:text-rose-200 font-semibold">
                  {regErrorMsg}
                </div>
              )}

              {/* Sekolah Target */}
              <div className="space-y-1">
                <label className="font-bold text-slate-700 dark:text-slate-300">
                  Pilih Sekolah (Tenant) *
                </label>
                <select
                  value={regTenantId}
                  onChange={(e) => setRegTenantId(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold focus:outline-none"
                >
                  {allTenants.map((t) => (
                    <option key={t.id} value={t.id}>
                      {t.name} ({t.type} - {t.city})
                    </option>
                  ))}
                </select>
              </div>

              {/* Data Siswa */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="font-bold text-slate-700 dark:text-slate-300">
                    Nama Lengkap Siswa *
                  </label>
                  <input
                    type="text"
                    required
                    value={regFullName}
                    onChange={(e) => setRegFullName(e.target.value)}
                    placeholder="Contoh: Muhammad Farhan"
                    className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs"
                  />
                </div>
                <div className="space-y-1">
                  <label className="font-bold text-slate-700 dark:text-slate-300">
                    Alamat Email Siswa *
                  </label>
                  <input
                    type="email"
                    required
                    value={regEmail}
                    onChange={(e) => setRegEmail(e.target.value)}
                    placeholder="farhan@siswa.scola.id"
                    className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="space-y-1">
                  <label className="font-bold text-slate-700 dark:text-slate-300">
                    NISN (10 Digit) *
                  </label>
                  <input
                    type="text"
                    required
                    value={regNisn}
                    onChange={(e) => setRegNisn(e.target.value)}
                    placeholder="0078901234"
                    className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs"
                  />
                </div>
                <div className="space-y-1">
                  <label className="font-bold text-slate-700 dark:text-slate-300">
                    NIS Sekolah *
                  </label>
                  <input
                    type="text"
                    required
                    value={regNis}
                    onChange={(e) => setRegNis(e.target.value)}
                    placeholder="2425001"
                    className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs"
                  />
                </div>
                <div className="space-y-1">
                  <label className="font-bold text-slate-700 dark:text-slate-300">
                    Jenis Kelamin
                  </label>
                  <select
                    value={regGender}
                    onChange={(e) => setRegGender(e.target.value as 'L' | 'P')}
                    className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs"
                  >
                    <option value="L">Laki-laki (L)</option>
                    <option value="P">Perempuan (P)</option>
                  </select>
                </div>
              </div>

              {/* Program / Peminatan Khusus SMA vs SMK */}
              <div className="p-3 bg-blue-50 dark:bg-blue-950/30 border border-blue-200 dark:border-blue-800 rounded-xl space-y-1">
                <label className="font-bold text-blue-900 dark:text-blue-200">
                  {selectedRegTenant?.type === 'SMK'
                    ? 'Program Keahlian SMK (Contoh: Rekayasa Perangkat Lunak)'
                    : 'Peminatan SMA (Contoh: MIPA / IPS / Kurikulum Merdeka)'}
                </label>
                <input
                  type="text"
                  value={regProgram}
                  onChange={(e) => setRegProgram(e.target.value)}
                  placeholder={
                    selectedRegTenant?.type === 'SMK'
                      ? 'RPL / TKJ / Otomotif / Multimedia'
                      : 'MIPA / IPS / Fase E Merdeka'
                  }
                  className="w-full p-2 bg-white dark:bg-slate-800 border border-blue-300 dark:border-blue-700 rounded-lg text-xs"
                />
              </div>

              {/* Data Orang Tua / Wali */}
              <div className="p-3 bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-800 rounded-xl space-y-2">
                <div className="font-bold text-amber-900 dark:text-amber-200 flex items-center gap-1.5">
                  <Users className="w-4 h-4" />
                  <span>Data Orang Tua / Wali Siswa (Untuk Verifikasi Wali Kelas)</span>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                  <input
                    type="text"
                    value={regParentName}
                    onChange={(e) => setRegParentName(e.target.value)}
                    placeholder="Nama Orang Tua / Wali"
                    className="p-2 bg-white dark:bg-slate-800 border border-amber-300 dark:border-amber-700 rounded-lg text-xs"
                  />
                  <select
                    value={regParentRelation}
                    onChange={(e) => setRegParentRelation(e.target.value as any)}
                    className="p-2 bg-white dark:bg-slate-800 border border-amber-300 dark:border-amber-700 rounded-lg text-xs"
                  >
                    <option value="AYAH">Ayah</option>
                    <option value="IBU">Ibu</option>
                    <option value="WALI">Wali</option>
                  </select>
                  <input
                    type="text"
                    value={regParentWa}
                    onChange={(e) => setRegParentWa(e.target.value)}
                    placeholder="WhatsApp Orang Tua (08...)"
                    className="p-2 bg-white dark:bg-slate-800 border border-amber-300 dark:border-amber-700 rounded-lg text-xs"
                  />
                </div>
              </div>

              {/* Password */}
              <div className="space-y-1">
                <label className="font-bold text-slate-700 dark:text-slate-300">
                  Kata Sandi Akun Siswa (Minimal 6 Karakter) *
                </label>
                <input
                  type="password"
                  required
                  value={regPassword}
                  onChange={(e) => setRegPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs"
                />
              </div>

              {/* Buttons */}
              <div className="pt-2 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowRegisterModal(false)}
                  className="px-4 py-2 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  disabled={isLoading}
                  className="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold cursor-pointer shadow-sm"
                >
                  Daftarkan Siswa
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
