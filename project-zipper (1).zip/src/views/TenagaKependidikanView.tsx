import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { useTenant } from '../context/TenantContext';
import { SchoolLetter, SchoolFacility } from '../types';
import { academicRepository } from '../repositories/academicRepository';
import {
  FileText,
  Boxes,
  Building,
  CheckCircle2,
  Plus,
  Send,
  Download,
  Clock,
  X,
  Printer,
} from 'lucide-react';

export const TenagaKependidikanView: React.FC = () => {
  const { currentUser } = useAuth();
  const { currentTenant } = useTenant();

  const [activeTab, setActiveTab] = useState<'surat' | 'sarpras'>('surat');
  const [letters, setLetters] = useState<SchoolLetter[]>([]);
  const [facilities, setFacilities] = useState<SchoolFacility[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  // Modal: New Letter
  const [showAddLetterModal, setShowAddLetterModal] = useState(false);
  const [letterSubject, setLetterSubject] = useState('');
  const [letterType, setLetterType] = useState<'SURAT_KETERANGAN' | 'SURAT_PENGANTAR_PKL' | 'SURAT_PERMOHONAN_DUDI' | 'SURAT_UNDANGAN_ORTU'>('SURAT_KETERANGAN');
  const [letterRecipient, setLetterRecipient] = useState('');

  // Modal: New Sarpras
  const [showAddSarprasModal, setShowAddSarprasModal] = useState(false);
  const [sarprasName, setSarprasName] = useState('');
  const [sarprasCategory, setSarprasCategory] = useState<'LABORATORIUM' | 'BENGKEL' | 'RUANG_KELAS' | 'PERPUSTAKAAN'>('LABORATORIUM');
  const [sarprasLocation, setSarprasLocation] = useState('');
  const [sarprasCapacity, setSarprasCapacity] = useState(30);

  const loadData = async () => {
    if (!currentTenant) return;
    setIsLoading(true);
    try {
      const [lData, fData] = await Promise.all([
        academicRepository.getLetters(currentTenant.id),
        academicRepository.getFacilities(currentTenant.id),
      ]);
      setLetters(lData);
      setFacilities(fData);
    } catch (err) {
      console.error('Error loading TU data:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, [currentTenant?.id]);

  const handleCreateLetter = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentTenant || !currentUser) return;
    try {
      const nextNum = `421.3/${(letters.length + 1).toString().padStart(3, '0')}/${currentTenant.type || 'SCH'}/IX/2024`;
      await academicRepository.addLetter(
        {
          tenant_id: currentTenant.id,
          letter_number: nextNum,
          letter_type: letterType,
          subject: letterSubject,
          recipient: letterRecipient,
          created_date: new Date().toISOString().split('T')[0],
          status: 'PROSES',
          created_by_name: currentUser.full_name,
        },
        currentUser
      );
      setShowAddLetterModal(false);
      setLetterSubject('');
      setLetterRecipient('');
      await loadData();
    } catch (err: any) {
      alert(err.message || 'Gagal membuat surat');
    }
  };

  const handleCreateFacility = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentTenant || !currentUser) return;
    try {
      await academicRepository.addFacility(
        {
          tenant_id: currentTenant.id,
          name: sarprasName,
          category: sarprasCategory,
          location: sarprasLocation,
          capacity: sarprasCapacity,
          condition: 'BAIK',
          last_inspected: new Date().toISOString().split('T')[0],
          pic_user_name: currentUser.full_name,
        },
        currentUser
      );
      setShowAddSarprasModal(false);
      setSarprasName('');
      setSarprasLocation('');
      await loadData();
    } catch (err: any) {
      alert(err.message || 'Gagal mendaftarkan sarpras');
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-slate-800 to-slate-900 text-white rounded-3xl p-6 shadow-xl relative overflow-hidden">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2 text-slate-300 text-xs font-semibold uppercase tracking-wider">
              <Building className="w-4 h-4" />
              <span>Portal Tata Usaha & Sarpras • {currentTenant?.name}</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-black tracking-tight">
              Administrasi & Tata Kelola Sekolah
            </h1>
            <p className="text-xs text-slate-300 max-w-2xl leading-relaxed">
              Manajemen korespondensi kedinasan, surat pengantar PKL, inventaris sarana prasarana sekolah, dan logistik kejuruan/akademik.
            </p>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-1 bg-white dark:bg-slate-900 p-1.5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs text-xs">
        <button
          type="button"
          onClick={() => setActiveTab('surat')}
          className={`flex-1 py-2.5 rounded-xl font-bold transition-all cursor-pointer flex items-center justify-center gap-2 ${
            activeTab === 'surat'
              ? 'bg-slate-900 text-white dark:bg-white dark:text-slate-900 shadow-xs'
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
          }`}
        >
          <FileText className="w-4 h-4" />
          <span>Surat & Dokumen Tata Usaha ({letters.length})</span>
        </button>
        <button
          type="button"
          onClick={() => setActiveTab('sarpras')}
          className={`flex-1 py-2.5 rounded-xl font-bold transition-all cursor-pointer flex items-center justify-center gap-2 ${
            activeTab === 'sarpras'
              ? 'bg-slate-900 text-white dark:bg-white dark:text-slate-900 shadow-xs'
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
          }`}
        >
          <Boxes className="w-4 h-4" />
          <span>Inventaris Sarana & Prasarana ({facilities.length})</span>
        </button>
      </div>

      {/* Content 1: Surat */}
      {activeTab === 'surat' && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-5 shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                Buku Agenda Surat Masuk & Keluar
              </h3>
              <p className="text-xs text-slate-500">Penomoran terstandarisasi dinas pendidikan</p>
            </div>
            <button
              type="button"
              onClick={() => setShowAddLetterModal(true)}
              className="px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold flex items-center gap-1 cursor-pointer shadow-xs"
            >
              <Plus className="w-4 h-4" />
              <span>Buat Surat Baru</span>
            </button>
          </div>

          <div className="space-y-2 text-xs">
            {letters.map((l) => (
              <div
                key={l.id}
                className="p-3.5 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-850 flex items-center justify-between gap-3"
              >
                <div>
                  <span className="font-bold text-slate-900 dark:text-white block">
                    {l.subject}
                  </span>
                  <span className="font-mono text-[11px] text-slate-400">
                    No: {l.letter_number} • Tanggal: {l.created_date} • Ditujukan: {l.recipient}
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <span
                    className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold ${
                      l.status === 'SELESAI'
                        ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                        : 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300'
                    }`}
                  >
                    {l.status}
                  </span>
                  <button
                    type="button"
                    onClick={() => alert(`Cetak surat: ${l.letter_number}`)}
                    className="p-1.5 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-lg text-slate-500 cursor-pointer"
                    title="Cetak Surat"
                  >
                    <Printer className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Content 2: Sarpras */}
      {activeTab === 'sarpras' && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-5 shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                Data Aset & Sarana Prasarana Sekolah
              </h3>
              <p className="text-xs text-slate-500">Pencatatan fasilitas pembelajaran dan bengkel kejuruan</p>
            </div>
            <button
              type="button"
              onClick={() => setShowAddSarprasModal(true)}
              className="px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold flex items-center gap-1 cursor-pointer shadow-xs"
            >
              <Plus className="w-4 h-4" />
              <span>Registrasi Sarpras</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
            {facilities.map((s) => (
              <div
                key={s.id}
                className="p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-850 space-y-2"
              >
                <div className="flex items-start justify-between">
                  <div>
                    <span className="text-[10px] font-bold text-blue-600 uppercase">{s.category}</span>
                    <span className="font-bold text-slate-900 dark:text-white block text-sm">
                      {s.name}
                    </span>
                    <span className="text-[11px] text-slate-400">
                      Lokasi: {s.location} • Kapasitas: {s.capacity}
                    </span>
                  </div>
                  <span
                    className={`px-2.5 py-0.5 rounded-full font-bold text-[10px] ${
                      s.condition === 'BAIK'
                        ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                        : 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300'
                    }`}
                  >
                    Kondisi: {s.condition}
                  </span>
                </div>

                <div className="text-[11px] text-slate-400 pt-1 border-t border-slate-200 dark:border-slate-800 flex justify-between">
                  <span>Inspeksi: {s.last_inspected}</span>
                  <span>PIC: {s.pic_user_name}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Modal Add Letter */}
      {showAddLetterModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="bg-white dark:bg-slate-900 rounded-3xl max-w-md w-full p-6 shadow-2xl border border-slate-200 dark:border-slate-800 space-y-4 text-xs">
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
              <h3 className="text-base font-black text-slate-900 dark:text-white">
                Buat Surat Resmi Sekolah
              </h3>
              <button
                type="button"
                onClick={() => setShowAddLetterModal(false)}
                className="p-1 rounded-lg hover:bg-slate-100 text-slate-400 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateLetter} className="space-y-3">
              <div>
                <label className="block text-slate-700 dark:text-slate-300 font-bold mb-1">Jenis Surat</label>
                <select
                  value={letterType}
                  onChange={(e) => setLetterType(e.target.value as any)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 font-bold"
                >
                  <option value="SURAT_KETERANGAN">Surat Keterangan Aktif Belajar Siswa</option>
                  <option value="SURAT_PENGANTAR_PKL">Surat Pengantar Prakerin / PKL SMK</option>
                  <option value="SURAT_PERMOHONAN_DUDI">Surat Permohonan Kerjasama DUDI / Industri</option>
                  <option value="SURAT_UNDANGAN_ORTU">Surat Undangan Orang Tua Siswa</option>
                </select>
              </div>

              <div>
                <label className="block text-slate-700 dark:text-slate-300 font-bold mb-1">Perihal / Judul Surat</label>
                <input
                  type="text"
                  required
                  placeholder="contoh: Permohonan Tempat Praktik Kerja Lapangan"
                  value={letterSubject}
                  onChange={(e) => setLetterSubject(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
                />
              </div>

              <div>
                <label className="block text-slate-700 dark:text-slate-300 font-bold mb-1">Ditujukan Kepada</label>
                <input
                  type="text"
                  required
                  placeholder="contoh: Pimpinan PT Telkom Akses"
                  value={letterRecipient}
                  onChange={(e) => setLetterRecipient(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
                />
              </div>

              <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowAddLetterModal(false)}
                  className="px-4 py-2 rounded-xl border border-slate-200 dark:border-slate-700 font-bold text-slate-600 dark:text-slate-400 cursor-pointer"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold cursor-pointer"
                >
                  Terbitkan Surat
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal Add Sarpras */}
      {showAddSarprasModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="bg-white dark:bg-slate-900 rounded-3xl max-w-md w-full p-6 shadow-2xl border border-slate-200 dark:border-slate-800 space-y-4 text-xs">
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
              <h3 className="text-base font-black text-slate-900 dark:text-white">
                Registrasi Fasilitas / Sarpras Baru
              </h3>
              <button
                type="button"
                onClick={() => setShowAddSarprasModal(false)}
                className="p-1 rounded-lg hover:bg-slate-100 text-slate-400 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateFacility} className="space-y-3">
              <div>
                <label className="block text-slate-700 dark:text-slate-300 font-bold mb-1">Nama Sarpras / Ruang</label>
                <input
                  type="text"
                  required
                  placeholder="contoh: Lab Software Engineering"
                  value={sarprasName}
                  onChange={(e) => setSarprasName(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
                />
              </div>

              <div>
                <label className="block text-slate-700 dark:text-slate-300 font-bold mb-1">Kategori</label>
                <select
                  value={sarprasCategory}
                  onChange={(e) => setSarprasCategory(e.target.value as any)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 font-bold"
                >
                  <option value="LABORATORIUM">Laboratorium Komputer / Sains</option>
                  <option value="BENGKEL">Bengkel Praktik Kejuruan (SMK)</option>
                  <option value="RUANG_KELAS">Ruang Kelas Teori</option>
                  <option value="PERPUSTAKAAN">Perpustakaan & Sumber Belajar</option>
                </select>
              </div>

              <div>
                <label className="block text-slate-700 dark:text-slate-300 font-bold mb-1">Lokasi Gedung / Lantai</label>
                <input
                  type="text"
                  required
                  placeholder="contoh: Gedung C Lantai 2"
                  value={sarprasLocation}
                  onChange={(e) => setSarprasLocation(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
                />
              </div>

              <div>
                <label className="block text-slate-700 dark:text-slate-300 font-bold mb-1">Kapasitas Maksimal</label>
                <input
                  type="number"
                  min={1}
                  max={200}
                  value={sarprasCapacity}
                  onChange={(e) => setSarprasCapacity(Number(e.target.value))}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-850"
                />
              </div>

              <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowAddSarprasModal(false)}
                  className="px-4 py-2 rounded-xl border border-slate-200 dark:border-slate-700 font-bold text-slate-600 dark:text-slate-400 cursor-pointer"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold cursor-pointer"
                >
                  Daftarkan Sarpras
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
