import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { useTenant } from '../context/TenantContext';
import { Tenant, UserProfile } from '../types';
import { QuotaAuditHistoryModal } from '../components/common/QuotaAuditHistoryModal';
import {
  Building2,
  Users,
  CreditCard,
  PlusCircle,
  History,
  CheckCircle2,
  AlertTriangle,
  ToggleLeft,
  ToggleRight,
  School,
  FileSpreadsheet,
  X,
  Lock,
} from 'lucide-react';

export const MasterDashboardView: React.FC = () => {
  const { currentUser, auditLogs, availableUsers } = useAuth();
  const {
    allTenants,
    updateQuota,
    createTenant,
    toggleTenantStatus,
  } = useTenant();

  // State for Quota Adjustment Modal
  const [selectedTenantForQuota, setSelectedTenantForQuota] = useState<Tenant | null>(null);
  const [newQuotaValue, setNewQuotaValue] = useState<number>(25);
  const [quotaReason, setQuotaReason] = useState<string>('');
  const [quotaError, setQuotaError] = useState<string | null>(null);
  const [quotaSuccess, setQuotaSuccess] = useState<string | null>(null);
  const [isUpdatingQuota, setIsUpdatingQuota] = useState(false);

  // State for New School Tenant Modal
  const [showCreateTenantModal, setShowCreateTenantModal] = useState(false);
  const [newSchoolName, setNewSchoolName] = useState('');
  const [newSchoolNpsn, setNewSchoolNpsn] = useState('');
  const [newSchoolType, setNewSchoolType] = useState<'SMA' | 'SMK'>('SMA');
  const [newSchoolAccreditation, setNewSchoolAccreditation] = useState<'A' | 'B' | 'C'>('A');
  const [newSchoolCity, setNewSchoolCity] = useState('');
  const [newSchoolProvince, setNewSchoolProvince] = useState('');
  const [newSchoolQuota, setNewSchoolQuota] = useState<number>(25);
  const [newSchoolPhone, setNewSchoolPhone] = useState('');
  const [newSchoolEmail, setNewSchoolEmail] = useState('');
  const [tenantCreateError, setTenantCreateError] = useState<string | null>(null);

  // State for Quota History Modal
  const [showHistoryModal, setShowHistoryModal] = useState(false);

  // Calculate Metrics
  const PRICE_PER_TEACHER = 15000; // Rp15.000 / guru aktif / bulan

  const getActiveTeachersForTenant = (tenantId: string) => {
    return availableUsers.filter(
      (u) => u.role === 'GURU' && u.tenant_id === tenantId && u.status === 'ACTIVE'
    ).length;
  };

  const totalTenants = allTenants.length;
  const activeTenants = allTenants.filter((t) => t.is_active).length;
  const totalAllocatedQuota = allTenants.reduce((acc, t) => acc + (t.teacher_quota || 25), 0);
  const totalActiveTeachers = allTenants.reduce(
    (acc, t) => acc + getActiveTeachersForTenant(t.id),
    0
  );
  const totalEstimatedMonthlyRevenue = totalActiveTeachers * PRICE_PER_TEACHER;

  const handleOpenQuotaModal = (tenant: Tenant) => {
    setSelectedTenantForQuota(tenant);
    setNewQuotaValue(tenant.teacher_quota || 25);
    setQuotaReason('Penyesuaian kuota lisensi semester baru');
    setQuotaError(null);
    setQuotaSuccess(null);
  };

  const handleSaveQuota = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedTenantForQuota || !currentUser) return;
    setIsUpdatingQuota(true);
    setQuotaError(null);
    setQuotaSuccess(null);

    try {
      await updateQuota(
        selectedTenantForQuota.id,
        newQuotaValue,
        currentUser,
        quotaReason
      );
      setQuotaSuccess(`Kuota ${selectedTenantForQuota.name} berhasil diperbarui menjadi ${newQuotaValue} guru.`);
      setTimeout(() => {
        setSelectedTenantForQuota(null);
        setQuotaSuccess(null);
      }, 1500);
    } catch (err: any) {
      setQuotaError(err.message || 'Gagal memperbarui kuota.');
    } finally {
      setIsUpdatingQuota(false);
    }
  };

  const handleCreateTenantSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) return;
    setTenantCreateError(null);

    try {
      await createTenant(
        {
          name: newSchoolName,
          npsn: newSchoolNpsn,
          type: newSchoolType,
          accreditation: newSchoolAccreditation,
          city: newSchoolCity,
          province: newSchoolProvince,
          address: `${newSchoolCity}, ${newSchoolProvince}`,
          phone: newSchoolPhone,
          email: newSchoolEmail,
          teacher_quota: newSchoolQuota,
          is_active: true,
          subscription_tier: 'STANDARD',
        },
        currentUser
      );
      setShowCreateTenantModal(false);
      // Reset form
      setNewSchoolName('');
      setNewSchoolNpsn('');
      setNewSchoolCity('');
      setNewSchoolProvince('');
      setNewSchoolPhone('');
      setNewSchoolEmail('');
    } catch (err: any) {
      setTenantCreateError(err.message || 'Gagal membuat tenant sekolah.');
    }
  };

  const handleToggleStatus = async (tenant: Tenant) => {
    if (!currentUser) return;
    const newStatus = !tenant.is_active;
    const confirmText = newStatus
      ? `Aktifkan kembali akses tenant "${tenant.name}"?`
      : `Nonaktifkan tenant "${tenant.name}"? User sekolah ini tidak akan bisa login, tetapi riwayat data tetap tersimpan aman.`;

    if (window.confirm(confirmText)) {
      await toggleTenantStatus(
        tenant.id,
        newStatus,
        currentUser,
        newStatus ? 'Aktivasi tenant sekolah' : 'Penonaktifan sementara oleh Master'
      );
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-purple-900 to-indigo-900 text-white rounded-3xl p-6 shadow-xl relative overflow-hidden">
        <div className="relative z-10 flex flex-wrap items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2 text-purple-300 text-xs font-semibold uppercase tracking-wider">
              <Lock className="w-4 h-4" />
              <span>Platform Control & Master Governance</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-black tracking-tight">
              Master Platform Dashboard
            </h1>
            <p className="text-xs text-purple-200 max-w-2xl leading-relaxed">
              Otoritas tertinggi pengelolaan multi-tenant sekolah SMA/SMK, penetapan kuota lisensi guru (Rp15.000/guru/bulan), dan audit keamanan lintas sekolah.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => setShowCreateTenantModal(true)}
              className="px-4 py-2.5 bg-white text-purple-900 hover:bg-purple-50 text-xs font-bold rounded-xl transition-all shadow-md flex items-center gap-2 cursor-pointer"
            >
              <PlusCircle className="w-4 h-4 text-purple-700" />
              <span>Daftarkan Sekolah Baru</span>
            </button>
            <button
              type="button"
              onClick={() => setShowHistoryModal(true)}
              className="px-4 py-2.5 bg-purple-800/80 hover:bg-purple-700 text-white border border-purple-600 text-xs font-bold rounded-xl transition-all flex items-center gap-2 cursor-pointer"
            >
              <History className="w-4 h-4" />
              <span>Riwayat Audit Kuota</span>
            </button>
          </div>
        </div>
      </div>

      {/* Metric Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Total Sekolah */}
        <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-2">
          <div className="flex items-center justify-between text-slate-500 text-xs font-bold uppercase tracking-wider">
            <span>Total Sekolah (Tenant)</span>
            <Building2 className="w-4 h-4 text-blue-600" />
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl font-black text-slate-900 dark:text-white">
              {totalTenants}
            </span>
            <span className="text-xs text-emerald-600 font-semibold">
              ({activeTenants} Aktif)
            </span>
          </div>
          <p className="text-[11px] text-slate-400">
            Terbagi SMA dan SMK dengan isolasi data RLS
          </p>
        </div>

        {/* Guru Aktif Terlisensi */}
        <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-2">
          <div className="flex items-center justify-between text-slate-500 text-xs font-bold uppercase tracking-wider">
            <span>Guru Aktif Terlisensi</span>
            <Users className="w-4 h-4 text-purple-600" />
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl font-black text-slate-900 dark:text-white">
              {totalActiveTeachers}
            </span>
            <span className="text-xs text-slate-400 font-medium">
              / {totalAllocatedQuota} Kuota
            </span>
          </div>
          <p className="text-[11px] text-slate-400">
            Utilisasi {Math.round((totalActiveTeachers / (totalAllocatedQuota || 1)) * 100)}% dari kapasitas
          </p>
        </div>

        {/* Tarif Lisensi Guru */}
        <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-2">
          <div className="flex items-center justify-between text-slate-500 text-xs font-bold uppercase tracking-wider">
            <span>Tarif Lisensi Guru</span>
            <CreditCard className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="flex items-baseline gap-1">
            <span className="text-2xl font-black text-emerald-600 dark:text-emerald-400">
              Rp15.000
            </span>
            <span className="text-xs text-slate-400">/ guru / bln</span>
          </div>
          <p className="text-[11px] text-slate-400">
            Aturan Baku: Hanya MASTER yang berhak mengubah kuota
          </p>
        </div>

        {/* Estimasi Billing Bulanan */}
        <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-2">
          <div className="flex items-center justify-between text-slate-500 text-xs font-bold uppercase tracking-wider">
            <span>Billing Bulanan</span>
            <FileSpreadsheet className="w-4 h-4 text-amber-600" />
          </div>
          <div className="text-2xl font-black text-slate-900 dark:text-white font-mono">
            Rp {totalEstimatedMonthlyRevenue.toLocaleString('id-ID')}
          </div>
          <p className="text-[11px] text-slate-400">
            Dihitung realtime berdasarkan guru berstatus ACTIVE
          </p>
        </div>
      </div>

      {/* Tenant Table Section */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl overflow-hidden shadow-xs">
        <div className="p-5 border-b border-slate-200 dark:border-slate-800 flex flex-wrap items-center justify-between gap-3">
          <div>
            <h2 className="text-base font-bold text-slate-900 dark:text-white">
              Daftar Sekolah Terdaftar (Multi-Tenant)
            </h2>
            <p className="text-xs text-slate-500">
              Setiap baris adalah tenant terisolasi yang diatur oleh Supabase PostgreSQL Row Level Security
            </p>
          </div>
          <div className="text-xs font-semibold px-3 py-1 rounded-full bg-blue-50 text-blue-700 dark:bg-blue-950 dark:text-blue-300 border border-blue-200 dark:border-blue-800">
            PostgreSQL RLS Active
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-700 dark:text-slate-300">
            <thead className="bg-slate-50 dark:bg-slate-850 text-[11px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider border-b border-slate-200 dark:border-slate-800">
              <tr>
                <th className="py-3.5 px-4">Sekolah & NPSN</th>
                <th className="py-3.5 px-4">Tipe & Akreditasi</th>
                <th className="py-3.5 px-4">Lokasi</th>
                <th className="py-3.5 px-4">Guru Aktif / Kuota</th>
                <th className="py-3.5 px-4">Billing Bulanan</th>
                <th className="py-3.5 px-4">Status Tenant</th>
                <th className="py-3.5 px-4 text-right">Aksi Kelola</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800 font-medium">
              {allTenants.map((t) => {
                const activeCount = getActiveTeachersForTenant(t.id);
                const quota = t.teacher_quota || 25;
                const monthlyBill = activeCount * PRICE_PER_TEACHER;
                const isFull = activeCount >= quota;

                return (
                  <tr
                    key={t.id}
                    className="hover:bg-slate-50/70 dark:hover:bg-slate-800/50 transition-colors"
                  >
                    <td className="py-3.5 px-4">
                      <div className="flex items-center gap-2.5">
                        <div className="w-8 h-8 rounded-xl bg-purple-50 dark:bg-purple-950/40 border border-purple-200 dark:border-purple-800 flex items-center justify-center font-bold text-purple-700 dark:text-purple-300">
                          <School className="w-4 h-4" />
                        </div>
                        <div>
                          <span className="font-bold text-slate-900 dark:text-white block">
                            {t.name}
                          </span>
                          <span className="text-[11px] font-mono text-slate-400">
                            NPSN: {t.npsn}
                          </span>
                        </div>
                      </div>
                    </td>

                    <td className="py-3.5 px-4">
                      <div className="flex items-center gap-1.5">
                        <span
                          className={`font-bold px-2 py-0.5 rounded text-[11px] ${
                            t.type === 'SMK'
                              ? 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300'
                              : 'bg-blue-100 text-blue-800 dark:bg-blue-950 dark:text-blue-300'
                          }`}
                        >
                          {t.type}
                        </span>
                        <span className="text-slate-500">
                          Akreditasi {t.accreditation || 'A'}
                        </span>
                      </div>
                    </td>

                    <td className="py-3.5 px-4 text-slate-600 dark:text-slate-400">
                      {t.city}, {t.province}
                    </td>

                    <td className="py-3.5 px-4">
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <span className="font-mono font-bold text-slate-900 dark:text-white">
                            {activeCount} / {quota} Guru
                          </span>
                          {isFull && (
                            <span className="text-[10px] px-1.5 py-0.2 rounded bg-rose-100 text-rose-700 dark:bg-rose-950 dark:text-rose-300 font-bold">
                              PENUH
                            </span>
                          )}
                        </div>
                        <div className="w-28 h-1.5 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
                          <div
                            className={`h-full ${
                              isFull ? 'bg-rose-600' : 'bg-emerald-500'
                            }`}
                            style={{
                              width: `${Math.min(100, (activeCount / quota) * 100)}%`,
                            }}
                          />
                        </div>
                      </div>
                    </td>

                    <td className="py-3.5 px-4 font-mono font-bold text-slate-900 dark:text-white">
                      Rp {monthlyBill.toLocaleString('id-ID')}
                    </td>

                    <td className="py-3.5 px-4">
                      <button
                        type="button"
                        onClick={() => handleToggleStatus(t)}
                        className="flex items-center gap-1.5 font-bold cursor-pointer transition-opacity hover:opacity-80"
                      >
                        {t.is_active ? (
                          <>
                            <ToggleRight className="w-5 h-5 text-emerald-600" />
                            <span className="text-emerald-700 dark:text-emerald-400 text-xs">
                              Aktif
                            </span>
                          </>
                        ) : (
                          <>
                            <ToggleLeft className="w-5 h-5 text-slate-400" />
                            <span className="text-slate-500 text-xs">
                              Nonaktif
                            </span>
                          </>
                        )}
                      </button>
                    </td>

                    <td className="py-3.5 px-4 text-right">
                      <div className="flex items-center justify-end gap-2">
                        <button
                          type="button"
                          onClick={() => handleOpenQuotaModal(t)}
                          className="px-3 py-1.5 rounded-xl bg-purple-100 hover:bg-purple-200 text-purple-800 dark:bg-purple-950 dark:hover:bg-purple-900 dark:text-purple-300 font-bold text-xs transition-colors cursor-pointer"
                        >
                          Ubah Kuota
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Quota Modification Modal */}
      {selectedTenantForQuota && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl max-w-md w-full p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <div className="p-2 rounded-xl bg-purple-100 text-purple-700 dark:bg-purple-950 dark:text-purple-300">
                  <Users className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-sm text-slate-900 dark:text-white">
                    Ubah Kuota Lisensi Guru
                  </h3>
                  <p className="text-[11px] text-slate-500">
                    {selectedTenantForQuota.name}
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setSelectedTenantForQuota(null)}
                className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {quotaSuccess && (
              <div className="p-3 rounded-xl bg-emerald-50 text-emerald-800 border border-emerald-200 text-xs font-bold flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 shrink-0" />
                <span>{quotaSuccess}</span>
              </div>
            )}
            {quotaError && (
              <div className="p-3 rounded-xl bg-rose-50 text-rose-800 border border-rose-200 text-xs font-bold flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 shrink-0" />
                <span>{quotaError}</span>
              </div>
            )}

            <form onSubmit={handleSaveQuota} className="space-y-4 text-xs">
              <div className="p-3 rounded-xl bg-purple-50 dark:bg-purple-950/40 border border-purple-200 dark:border-purple-800 space-y-1">
                <div className="flex justify-between font-bold text-purple-900 dark:text-purple-200">
                  <span>Guru Aktif Saat Ini:</span>
                  <span className="font-mono">
                    {getActiveTeachersForTenant(selectedTenantForQuota.id)} Guru
                  </span>
                </div>
                <div className="flex justify-between text-[11px] text-purple-700 dark:text-purple-300">
                  <span>Kuota Eksisting:</span>
                  <span className="font-mono">{selectedTenantForQuota.teacher_quota || 25} Guru</span>
                </div>
                <p className="text-[10px] text-purple-600 dark:text-purple-400 pt-1">
                  Aturan: Kuota baru tidak boleh lebih kecil dari jumlah guru aktif ({getActiveTeachersForTenant(selectedTenantForQuota.id)} guru).
                </p>
              </div>

              <div className="space-y-1.5">
                <label className="font-bold text-slate-700 dark:text-slate-300">
                  Alokasi Kuota Guru Baru *
                </label>
                <input
                  type="number"
                  min={getActiveTeachersForTenant(selectedTenantForQuota.id)}
                  max={200}
                  required
                  value={newQuotaValue}
                  onChange={(e) => setNewQuotaValue(parseInt(e.target.value) || 0)}
                  className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-mono font-bold"
                />
              </div>

              <div className="space-y-1.5">
                <label className="font-bold text-slate-700 dark:text-slate-300">
                  Alasan Perubahan Kuota (Audit Trail Mandatory) *
                </label>
                <textarea
                  required
                  rows={3}
                  value={quotaReason}
                  onChange={(e) => setQuotaReason(e.target.value)}
                  placeholder="Contoh: Upgrade paket semester ganjil untuk penambahan 5 staf pengajar baru"
                  className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs"
                />
              </div>

              <div className="pt-2 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setSelectedTenantForQuota(null)}
                  className="px-4 py-2 border border-slate-200 dark:border-slate-700 rounded-xl font-semibold hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  disabled={isUpdatingQuota}
                  className="px-5 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded-xl font-bold cursor-pointer shadow-sm disabled:opacity-50"
                >
                  {isUpdatingQuota ? 'Menyimpan...' : 'Simpan Kuota Baru'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Create New Tenant Modal */}
      {showCreateTenantModal && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl max-w-xl w-full max-h-[90vh] flex flex-col shadow-2xl overflow-hidden">
            <div className="bg-slate-900 text-white p-4 flex items-center justify-between border-b border-slate-800">
              <div className="flex items-center gap-2">
                <div className="p-2 rounded-xl bg-purple-600 text-white">
                  <Building2 className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm font-bold">
                    Pendaftaran Tenant Sekolah Baru
                  </h3>
                  <p className="text-[11px] text-slate-400">
                    Otoritas MASTER: Skema data sekolah terisolasi otomatis
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setShowCreateTenantModal(false)}
                className="text-slate-400 hover:text-white p-1 rounded-lg cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateTenantSubmit} className="p-5 overflow-y-auto space-y-4 text-xs">
              {tenantCreateError && (
                <div className="p-3 rounded-xl bg-rose-50 text-rose-800 border border-rose-200 font-semibold">
                  {tenantCreateError}
                </div>
              )}

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="font-bold text-slate-700 dark:text-slate-300">
                    Nama Sekolah *
                  </label>
                  <input
                    type="text"
                    required
                    value={newSchoolName}
                    onChange={(e) => setNewSchoolName(e.target.value)}
                    placeholder="Contoh: SMAN 5 Bandung"
                    className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl"
                  />
                </div>

                <div className="space-y-1">
                  <label className="font-bold text-slate-700 dark:text-slate-300">
                    NPSN (8 Digit) *
                  </label>
                  <input
                    type="text"
                    required
                    value={newSchoolNpsn}
                    onChange={(e) => setNewSchoolNpsn(e.target.value)}
                    placeholder="20108999"
                    className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="space-y-1">
                  <label className="font-bold text-slate-700 dark:text-slate-300">
                    Tipe Jenjang *
                  </label>
                  <select
                    value={newSchoolType}
                    onChange={(e) => setNewSchoolType(e.target.value as any)}
                    className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl font-semibold"
                  >
                    <option value="SMA">SMA</option>
                    <option value="SMK">SMK</option>
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="font-bold text-slate-700 dark:text-slate-300">
                    Akreditasi
                  </label>
                  <select
                    value={newSchoolAccreditation}
                    onChange={(e) => setNewSchoolAccreditation(e.target.value as any)}
                    className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl font-semibold"
                  >
                    <option value="A">A (Unggul)</option>
                    <option value="B">B (Baik)</option>
                    <option value="C">C (Cukup)</option>
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="font-bold text-slate-700 dark:text-slate-300">
                    Alokasi Kuota Guru Awal *
                  </label>
                  <input
                    type="number"
                    min={5}
                    max={100}
                    value={newSchoolQuota}
                    onChange={(e) => setNewSchoolQuota(parseInt(e.target.value) || 25)}
                    className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl font-mono font-bold"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="font-bold text-slate-700 dark:text-slate-300">
                    Kota / Kabupaten *
                  </label>
                  <input
                    type="text"
                    required
                    value={newSchoolCity}
                    onChange={(e) => setNewSchoolCity(e.target.value)}
                    placeholder="Bandung"
                    className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl"
                  />
                </div>
                <div className="space-y-1">
                  <label className="font-bold text-slate-700 dark:text-slate-300">
                    Provinsi *
                  </label>
                  <input
                    type="text"
                    required
                    value={newSchoolProvince}
                    onChange={(e) => setNewSchoolProvince(e.target.value)}
                    placeholder="Jawa Barat"
                    className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="font-bold text-slate-700 dark:text-slate-300">
                    Nomor Telepon
                  </label>
                  <input
                    type="text"
                    value={newSchoolPhone}
                    onChange={(e) => setNewSchoolPhone(e.target.value)}
                    placeholder="(022) 7208888"
                    className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl"
                  />
                </div>
                <div className="space-y-1">
                  <label className="font-bold text-slate-700 dark:text-slate-300">
                    Email Resmi Sekolah
                  </label>
                  <input
                    type="email"
                    value={newSchoolEmail}
                    onChange={(e) => setNewSchoolEmail(e.target.value)}
                    placeholder="info@sman5bdg.sch.id"
                    className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl"
                  />
                </div>
              </div>

              <div className="pt-2 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowCreateTenantModal(false)}
                  className="px-4 py-2 border border-slate-200 dark:border-slate-700 rounded-xl font-semibold hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded-xl font-bold cursor-pointer shadow-sm"
                >
                  Daftarkan Sekolah
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Quota Audit Modal */}
      <QuotaAuditHistoryModal
        isOpen={showHistoryModal}
        onClose={() => setShowHistoryModal(false)}
        logs={auditLogs}
      />
    </div>
  );
};
