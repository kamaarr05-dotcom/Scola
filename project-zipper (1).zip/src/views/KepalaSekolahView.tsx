import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { useTenant } from '../context/TenantContext';
import { UserProfile, TeacherAssignmentType, StudentClass, TeacherAssignment } from '../types';
import { QuotaIndicator } from '../components/common/QuotaIndicator';
import { AssignmentPill } from '../components/common/AssignmentPill';
import { teacherRepository } from '../repositories/teacherRepository';
import { academicRepository } from '../repositories/academicRepository';
import { userRepository } from '../repositories/userRepository';
import { teacherLicenseService } from '../services/teacherLicenseService';
import { ASSIGNMENT_LABELS } from '../lib/permissions';
import {
  Users,
  GraduationCap,
  Plus,
  BookOpen,
  CalendarCheck,
  Building2,
  AlertCircle,
  CheckCircle2,
  X,
  UserX,
  UserCheck,
  Sliders,
  ShieldCheck,
  Briefcase,
} from 'lucide-react';
import { SmkManagementModule } from '../components/smk/SmkManagementModule';
import { SmaManagementModule } from '../components/sma/SmaManagementModule';

export const KepalaSekolahView: React.FC = () => {
  const { currentUser, createTeacher, availableUsers } = useAuth();
  const { currentTenant } = useTenant();

  const [activeTab, setActiveTab] = useState<'teachers' | 'school_module'>('teachers');
  const [teachers, setTeachers] = useState<UserProfile[]>([]);
  const [classes, setClasses] = useState<StudentClass[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [actionError, setActionError] = useState<string | null>(null);
  const [actionSuccess, setActionSuccess] = useState<string | null>(null);

  // Modal: Add Teacher
  const [showAddTeacherModal, setShowAddTeacherModal] = useState(false);
  const [newTeacherName, setNewTeacherName] = useState('');
  const [newTeacherEmail, setNewTeacherEmail] = useState('');
  const [newTeacherPhone, setNewTeacherPhone] = useState('');
  const [newTeacherAssignments, setNewTeacherAssignments] = useState<TeacherAssignmentType[]>(['GURU']);

  // Modal: Manage Assignments
  const [selectedTeacherForAssignment, setSelectedTeacherForAssignment] = useState<UserProfile | null>(null);
  const [tempAssignments, setTempAssignments] = useState<TeacherAssignmentType[]>([]);

  const loadData = async () => {
    if (!currentTenant || !currentUser) return;
    setIsLoading(true);
    try {
      const teacherData = await teacherRepository.getByTenant(currentTenant.id, currentUser);
      setTeachers(teacherData);
      const classData = await academicRepository.getClassesByTenant(currentTenant.id, currentUser);
      setClasses(classData);
    } catch (err: any) {
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, [currentTenant?.id]);

  const activeTeachers = teachers.filter((t) => t.status === 'ACTIVE');
  const activeTeacherCount = activeTeachers.length;
  const quota = currentTenant?.teacher_quota || 25;

  const handleCreateTeacher = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentTenant || !currentUser) return;
    setActionError(null);
    setActionSuccess(null);

    try {
      await createTeacher({
        tenant_id: currentTenant.id,
        full_name: newTeacherName,
        email: newTeacherEmail,
        phone: newTeacherPhone,
        assignments: newTeacherAssignments,
      });

      setActionSuccess(`Guru ${newTeacherName} berhasil ditambahkan dan lisensi aktif.`);
      setShowAddTeacherModal(false);
      setNewTeacherName('');
      setNewTeacherEmail('');
      setNewTeacherPhone('');
      setNewTeacherAssignments(['GURU']);
      await loadData();
    } catch (err: any) {
      setActionError(err.message || 'Gagal menambahkan guru baru.');
    }
  };

  const handleToggleTeacherStatus = async (teacher: UserProfile) => {
    if (!currentTenant || !currentUser) return;
    setActionError(null);
    setActionSuccess(null);

    const isDeactivating = teacher.status === 'ACTIVE';

    if (isDeactivating) {
      const confirmDeact = window.confirm(
        `Nonaktifkan guru "${teacher.full_name}"?\n\nPerhatian: Kuota lisensi akan dilepas (+1 slot tersedia), namun semua riwayat data nilai, presensi, dan histori mengajar tetap tersimpan aman di database.`
      );
      if (!confirmDeact) return;

      try {
        await teacherLicenseService.deactivateTeacher({
          tenantId: currentTenant.id,
          teacherId: teacher.id,
          actor: currentUser,
          reason: 'Penonaktifan guru oleh Kepala Sekolah (slot lisensi dilepas)',
        });
        setActionSuccess(`Guru ${teacher.full_name} berhasil dinonaktifkan. 1 slot lisensi guru kembali tersedia.`);
        await loadData();
      } catch (err: any) {
        setActionError(err.message || 'Gagal menonaktifkan guru.');
      }
    } else {
      // Re-activating: check quota
      try {
        await teacherLicenseService.activateTeacher({
          tenantId: currentTenant.id,
          teacherId: teacher.id,
          actor: currentUser,
        });
        setActionSuccess(`Guru ${teacher.full_name} berhasil diaktifkan kembali.`);
        await loadData();
      } catch (err: any) {
        setActionError(err.message || 'Gagal mengaktifkan guru.');
      }
    }
  };

  const handleOpenAssignmentModal = (teacher: UserProfile) => {
    setSelectedTeacherForAssignment(teacher);
    setTempAssignments(teacher.assignments?.map((a) => a.type) || ['GURU']);
    setActionError(null);
    setActionSuccess(null);
  };

  const handleSaveAssignments = async () => {
    if (!selectedTeacherForAssignment || !currentUser || !currentTenant) return;
    try {
      const updatedAssignments: TeacherAssignment[] = tempAssignments.map((t, idx) => ({
        id: `asg-${Date.now()}-${idx}`,
        tenant_id: currentTenant.id,
        teacher_id: selectedTeacherForAssignment.id,
        teacher_user_id: selectedTeacherForAssignment.id,
        type: t,
        assignment_type: t,
        academic_year_id: 'ay-2024-ganjil',
        active: true,
        assigned_at: new Date().toISOString(),
      }));

      await userRepository.update(selectedTeacherForAssignment.id, {
        assignments: updatedAssignments,
      });
      setActionSuccess(`Penugasan ${selectedTeacherForAssignment.full_name} berhasil diperbarui.`);
      setSelectedTeacherForAssignment(null);
      await loadData();
    } catch (err: any) {
      setActionError(err.message || 'Gagal memperbarui penugasan.');
    }
  };

  const toggleAssignmentCheckbox = (asg: TeacherAssignmentType) => {
    if (tempAssignments.includes(asg)) {
      if (tempAssignments.length === 1) return; // Must have at least one
      setTempAssignments(tempAssignments.filter((a) => a !== asg));
    } else {
      setTempAssignments([...tempAssignments, asg]);
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-blue-900 to-indigo-900 text-white rounded-3xl p-6 shadow-xl relative overflow-hidden">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2 text-blue-300 text-xs font-semibold uppercase tracking-wider">
              <Building2 className="w-4 h-4" />
              <span>Portal Kepala Sekolah • {currentTenant?.name}</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-black tracking-tight">
              Manajemen Sekolah & Lisensi Guru
            </h1>
            <p className="text-xs text-blue-200 max-w-2xl leading-relaxed">
              Pengelolaan guru pengajar, penugasan struktural (Wali Kelas, Waka Kurikulum/Kesiswaan, Kaprog), monitoring kuota lisensi, dan pengawasan akademik terpadu.
            </p>
          </div>

          <button
            type="button"
            onClick={() => setShowAddTeacherModal(true)}
            className="px-4 py-2.5 bg-white text-blue-900 hover:bg-blue-50 text-xs font-bold rounded-xl transition-all shadow-md flex items-center gap-2 cursor-pointer"
          >
            <Plus className="w-4 h-4 text-blue-600" />
            <span>Tambah Guru Pengajar</span>
          </button>
        </div>
      </div>

      {/* Action Messages */}
      {actionSuccess && (
        <div className="p-3.5 rounded-2xl bg-emerald-50 text-emerald-800 border border-emerald-200 text-xs font-bold flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 shrink-0" />
          <span>{actionSuccess}</span>
        </div>
      )}
      {actionError && (
        <div className="p-3.5 rounded-2xl bg-rose-50 text-rose-800 border border-rose-200 text-xs font-bold flex items-center gap-2">
          <AlertCircle className="w-4 h-4 shrink-0" />
          <span>{actionError}</span>
        </div>
      )}

      {/* View Tabs */}
      <div className="flex border-b border-slate-200 dark:border-slate-800 gap-2 overflow-x-auto pb-1">
        <button
          type="button"
          onClick={() => setActiveTab('teachers')}
          className={`px-4 py-2.5 rounded-xl text-xs font-bold transition-all whitespace-nowrap cursor-pointer flex items-center gap-2 ${
            activeTab === 'teachers'
              ? 'bg-blue-600 text-white shadow-md'
              : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
          }`}
        >
          <Users className="w-4 h-4" />
          <span>Kondisi Sekolah, Guru & Penugasan</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('school_module')}
          className={`px-4 py-2.5 rounded-xl text-xs font-bold transition-all whitespace-nowrap cursor-pointer flex items-center gap-2 ${
            activeTab === 'school_module'
              ? 'bg-blue-600 text-white shadow-md'
              : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
          }`}
        >
          {currentTenant?.type === 'SMK' ? (
            <>
              <Briefcase className="w-4 h-4" />
              <span>Modul SMK: Program Keahlian, PKL & DUDI</span>
            </>
          ) : (
            <>
              <GraduationCap className="w-4 h-4" />
              <span>Modul SMA: Peminatan, Kurikulum & e-Rapor</span>
            </>
          )}
        </button>
      </div>

      {activeTab === 'teachers' ? (
        <>
      {/* Quota & School Metrics */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Quota Indicator Component */}
        <div className="lg:col-span-1">
          {currentTenant && (
            <QuotaIndicator
              tenant={currentTenant}
              activeTeacherCount={activeTeacherCount}
              canModify={false} // Only Master can modify
            />
          )}
        </div>

        {/* School Overview Cards */}
        <div className="lg:col-span-2 grid grid-cols-1 sm:grid-cols-3 gap-3">
          <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-1">
            <div className="flex items-center justify-between text-slate-500 text-xs font-bold uppercase">
              <span>Total Rombel / Kelas</span>
              <GraduationCap className="w-4 h-4 text-blue-600" />
            </div>
            <div className="text-2xl font-black text-slate-900 dark:text-white">
              {classes.length} Kelas
            </div>
            <p className="text-[11px] text-slate-400">
              {currentTenant?.type === 'SMK' ? 'Program Keahlian SMK' : 'Peminatan SMA'}
            </p>
          </div>

          <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-1">
            <div className="flex items-center justify-between text-slate-500 text-xs font-bold uppercase">
              <span>Rata-Rata Kehadiran</span>
              <CalendarCheck className="w-4 h-4 text-emerald-600" />
            </div>
            <div className="text-2xl font-black text-emerald-600 dark:text-emerald-400">
              96.4%
            </div>
            <p className="text-[11px] text-slate-400">Presensi semester berjalan</p>
          </div>

          <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-1">
            <div className="flex items-center justify-between text-slate-500 text-xs font-bold uppercase">
              <span>Kepatuhan RLS</span>
              <ShieldCheck className="w-4 h-4 text-purple-600" />
            </div>
            <div className="text-base font-black text-purple-600 dark:text-purple-400 pt-1">
              Terisolasi Aman
            </div>
            <p className="text-[11px] text-slate-400">Data terlindungi per-tenant</p>
          </div>
        </div>
      </div>

      {/* Teacher Management Table */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl overflow-hidden shadow-xs">
        <div className="p-5 border-b border-slate-200 dark:border-slate-800 flex flex-wrap items-center justify-between gap-3">
          <div>
            <h2 className="text-base font-bold text-slate-900 dark:text-white">
              Daftar Dewan Guru & Penugasan Tugas Tambahan
            </h2>
            <p className="text-xs text-slate-500">
              Prinsip SCOLA: Semua guru bertindak dengan Role GURU. Tugas Wali Kelas, Waka, dan Kaprog dikelola secara dinamis.
            </p>
          </div>
          <div className="text-xs font-semibold text-slate-500">
            {activeTeacherCount} Aktif • {teachers.length - activeTeacherCount} Nonaktif
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-700 dark:text-slate-300">
            <thead className="bg-slate-50 dark:bg-slate-850 text-[11px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider border-b border-slate-200 dark:border-slate-800">
              <tr>
                <th className="py-3.5 px-4">Nama Guru & Kontak</th>
                <th className="py-3.5 px-4">Role Sistem</th>
                <th className="py-3.5 px-4">Tugas Tambahan (Assignment)</th>
                <th className="py-3.5 px-4">Status Lisensi</th>
                <th className="py-3.5 px-4 text-right">Aksi Penugasan</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800 font-medium">
              {teachers.map((teacher) => {
                const isActive = teacher.status === 'ACTIVE';

                return (
                  <tr
                    key={teacher.id}
                    className="hover:bg-slate-50/70 dark:hover:bg-slate-800/50 transition-colors"
                  >
                    <td className="py-3.5 px-4">
                      <div className="flex items-center gap-2.5">
                        <div className="w-8 h-8 rounded-full bg-blue-100 dark:bg-blue-950 text-blue-700 dark:text-blue-300 font-bold flex items-center justify-center text-xs">
                          {teacher.full_name.charAt(0)}
                        </div>
                        <div>
                          <span className="font-bold text-slate-900 dark:text-white block">
                            {teacher.full_name}
                          </span>
                          <span className="text-[11px] text-slate-400">
                            {teacher.email} • {teacher.phone || '-'}
                          </span>
                        </div>
                      </div>
                    </td>

                    <td className="py-3.5 px-4">
                      <span className="px-2 py-0.5 rounded bg-blue-50 text-blue-700 dark:bg-blue-950 dark:text-blue-300 border border-blue-200 dark:border-blue-800 font-bold text-[10px]">
                        ROLE: GURU
                      </span>
                    </td>

                    <td className="py-3.5 px-4">
                      <div className="flex flex-wrap items-center gap-1.5">
                        {teacher.assignments && teacher.assignments.length > 0 ? (
                          teacher.assignments.map((asg) => (
                            <AssignmentPill
                              key={asg.id}
                              type={asg.type}
                              active={asg.active}
                            />
                          ))
                        ) : (
                          <span className="text-slate-400 italic text-[11px]">
                            Guru Mata Pelajaran
                          </span>
                        )}
                      </div>
                    </td>

                    <td className="py-3.5 px-4">
                      <span
                        className={`inline-flex items-center gap-1 font-bold text-[11px] px-2 py-0.5 rounded-full ${
                          isActive
                            ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                            : 'bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-400'
                        }`}
                      >
                        <span
                          className={`w-1.5 h-1.5 rounded-full ${
                            isActive ? 'bg-emerald-500' : 'bg-slate-400'
                          }`}
                        />
                        {isActive ? 'Aktif (Berlisensi)' : 'Nonaktif (Slot Lepas)'}
                      </span>
                    </td>

                    <td className="py-3.5 px-4 text-right">
                      <div className="flex items-center justify-end gap-2">
                        <button
                          type="button"
                          onClick={() => handleOpenAssignmentModal(teacher)}
                          className="px-2.5 py-1 rounded-lg bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 font-bold text-xs flex items-center gap-1 cursor-pointer"
                          title="Kelola tugas tambahan guru"
                        >
                          <Sliders className="w-3.5 h-3.5" />
                          <span>Tugas</span>
                        </button>

                        <button
                          type="button"
                          onClick={() => handleToggleTeacherStatus(teacher)}
                          className={`px-2.5 py-1 rounded-lg font-bold text-xs flex items-center gap-1 cursor-pointer transition-colors ${
                            isActive
                              ? 'bg-rose-50 hover:bg-rose-100 text-rose-700 dark:bg-rose-950/40 dark:text-rose-300'
                              : 'bg-emerald-50 hover:bg-emerald-100 text-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-300'
                          }`}
                          title={
                            isActive
                              ? 'Nonaktifkan guru (melepaskan slot lisensi tapi data historis tetap aman)'
                              : 'Aktifkan kembali guru (memeriksa kuota lisensi)'
                          }
                        >
                          {isActive ? (
                            <>
                              <UserX className="w-3.5 h-3.5" />
                              <span>Nonaktifkan</span>
                            </>
                          ) : (
                            <>
                              <UserCheck className="w-3.5 h-3.5" />
                              <span>Aktifkan</span>
                            </>
                          )}
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
        </>
      ) : (
        <div className="space-y-4">
          {currentTenant?.type === 'SMK' ? (
            <SmkManagementModule />
          ) : (
            <SmaManagementModule />
          )}
        </div>
      )}

      {/* Add Teacher Modal */}
      {showAddTeacherModal && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl max-w-md w-full p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <div className="p-2 rounded-xl bg-blue-100 text-blue-700 dark:bg-blue-950 dark:text-blue-300">
                  <Users className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-sm text-slate-900 dark:text-white">
                    Tambah Guru Pengajar Baru
                  </h3>
                  <p className="text-[11px] text-slate-500">
                    Otoritas Kepala Sekolah • Kuota {activeTeacherCount}/{quota}
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setShowAddTeacherModal(false)}
                className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateTeacher} className="space-y-4 text-xs">
              <div className="space-y-1">
                <label className="font-bold text-slate-700 dark:text-slate-300">
                  Nama Lengkap Guru & Gelar *
                </label>
                <input
                  type="text"
                  required
                  value={newTeacherName}
                  onChange={(e) => setNewTeacherName(e.target.value)}
                  placeholder="Contoh: Dra. Sri Wahyuni, M.Pd."
                  className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl"
                />
              </div>

              <div className="space-y-1">
                <label className="font-bold text-slate-700 dark:text-slate-300">
                  Alamat Email Guru *
                </label>
                <input
                  type="email"
                  required
                  value={newTeacherEmail}
                  onChange={(e) => setNewTeacherEmail(e.target.value)}
                  placeholder="sri.wahyuni@sekolah.sch.id"
                  className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl"
                />
              </div>

              <div className="space-y-1">
                <label className="font-bold text-slate-700 dark:text-slate-300">
                  Nomor WhatsApp
                </label>
                <input
                  type="text"
                  value={newTeacherPhone}
                  onChange={(e) => setNewTeacherPhone(e.target.value)}
                  placeholder="081234567890"
                  className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl"
                />
              </div>

              <div className="space-y-2">
                <label className="font-bold text-slate-700 dark:text-slate-300">
                  Tugas Tambahan Awal
                </label>
                <div className="grid grid-cols-2 gap-2">
                  {(['GURU', 'WALI_KELAS', 'WAKA_KURIKULUM', 'WAKA_KESISWAAN', 'KAPROG', 'BK'] as TeacherAssignmentType[]).map((asg) => (
                    <label
                      key={asg}
                      className="flex items-center gap-2 p-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50 cursor-pointer text-[11px]"
                    >
                      <input
                        type="checkbox"
                        checked={newTeacherAssignments.includes(asg)}
                        onChange={() => {
                          if (newTeacherAssignments.includes(asg)) {
                            setNewTeacherAssignments(newTeacherAssignments.filter((a) => a !== asg));
                          } else {
                            setNewTeacherAssignments([...newTeacherAssignments, asg]);
                          }
                        }}
                        className="rounded"
                      />
                      <span>{ASSIGNMENT_LABELS[asg]}</span>
                    </label>
                  ))}
                </div>
              </div>

              <div className="pt-2 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowAddTeacherModal(false)}
                  className="px-4 py-2 border border-slate-200 dark:border-slate-700 rounded-xl font-semibold hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-bold cursor-pointer shadow-sm"
                >
                  Tambahkan Guru
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Manage Assignments Modal */}
      {selectedTeacherForAssignment && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl max-w-md w-full p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
              <div>
                <h3 className="font-bold text-sm text-slate-900 dark:text-white">
                  Kelola Penugasan Struktural Guru
                </h3>
                <p className="text-[11px] text-slate-500">
                  {selectedTeacherForAssignment.full_name}
                </p>
              </div>
              <button
                type="button"
                onClick={() => setSelectedTeacherForAssignment(null)}
                className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <p className="text-[11px] text-slate-500">
                Pilih tugas yang diemban oleh guru ini pada tahun ajaran aktif:
              </p>

              <div className="space-y-2">
                {(
                  [
                    'GURU',
                    'WALI_KELAS',
                    'WAKA_KURIKULUM',
                    'WAKA_KESISWAAN',
                    'WAKA_SARPRAS',
                    'WAKA_HUMAS',
                    'KAPROG',
                    'BK',
                  ] as TeacherAssignmentType[]
                ).map((asg) => {
                  const isChecked = tempAssignments.includes(asg);
                  return (
                    <div
                      key={asg}
                      onClick={() => toggleAssignmentCheckbox(asg)}
                      className={`p-3 rounded-xl border flex items-center justify-between cursor-pointer transition-colors ${
                        isChecked
                          ? 'border-blue-500 bg-blue-50/60 dark:bg-blue-950/40 text-blue-900 dark:text-blue-100'
                          : 'border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800/50 text-slate-700 dark:text-slate-300'
                      }`}
                    >
                      <div className="font-semibold text-xs">
                        {ASSIGNMENT_LABELS[asg]}
                      </div>
                      <input
                        type="checkbox"
                        checked={isChecked}
                        onChange={() => {}}
                        className="rounded"
                      />
                    </div>
                  );
                })}
              </div>

              <div className="pt-3 flex items-center justify-end gap-2 border-t border-slate-100 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setSelectedTeacherForAssignment(null)}
                  className="px-4 py-2 border border-slate-200 dark:border-slate-700 rounded-xl font-semibold hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
                >
                  Batal
                </button>
                <button
                  type="button"
                  onClick={handleSaveAssignments}
                  className="px-5 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-bold cursor-pointer shadow-sm"
                >
                  Simpan Penugasan
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
