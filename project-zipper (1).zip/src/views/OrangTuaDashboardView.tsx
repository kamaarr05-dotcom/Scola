import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { useTenant } from '../context/TenantContext';
import { GradeRecord, AttendanceRecord, StudentReportCard } from '../types';
import { academicRepository } from '../repositories/academicRepository';
import { ERaportPrintModal } from '../components/common/ERaportPrintModal';
import {
  Baby,
  CalendarCheck,
  Award,
  HeartHandshake,
  CheckCircle2,
  Phone,
  MessageCircle,
  ShieldCheck,
  Printer,
  FileText,
} from 'lucide-react';

export const OrangTuaDashboardView: React.FC = () => {
  const { currentUser, selectedChildId, setSelectedChildId } = useAuth();
  const { currentTenant } = useTenant();

  const [grades, setGrades] = useState<GradeRecord[]>([]);
  const [attendance, setAttendance] = useState<AttendanceRecord[]>([]);
  const [reportCard, setReportCard] = useState<StudentReportCard | null>(null);
  const [isPrintModalOpen, setIsPrintModalOpen] = useState(false);
  const [consultationText, setConsultationText] = useState('');
  const [consultationSent, setConsultationSent] = useState(false);

  const linkedChildren = currentUser?.linked_students || [];
  const activeChild = linkedChildren.find((c) => c.id === selectedChildId) || linkedChildren[0];

  useEffect(() => {
    const fetchData = async () => {
      if (!activeChild || !currentUser || !currentTenant) return;
      try {
        const [grd, att, rptCards] = await Promise.all([
          academicRepository.getGrades(currentTenant.id, currentUser, {
            student_id: activeChild.id,
          }),
          academicRepository.getAttendance(currentTenant.id, currentUser, {
            student_id: activeChild.id,
          }),
          academicRepository.getReportCards(currentTenant.id, currentUser, {
            student_id: activeChild.id,
          }),
        ]);
        setGrades(grd as GradeRecord[]);
        setAttendance(att);
        if (rptCards && rptCards.length > 0) {
          setReportCard(rptCards[0]);
        }
      } catch (err) {
        console.error(err);
      }
    };
    fetchData();
  }, [activeChild?.id, currentUser?.id, currentTenant?.id]);

  const handleSendConsultation = (e: React.FormEvent) => {
    e.preventDefault();
    if (!consultationText) return;
    setConsultationSent(true);
    setConsultationText('');
    setTimeout(() => setConsultationSent(false), 4000);
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-amber-900 to-orange-900 text-white rounded-3xl p-6 shadow-xl relative overflow-hidden">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2 text-amber-300 text-xs font-semibold uppercase tracking-wider">
              <Baby className="w-4 h-4" />
              <span>Portal Pengawasan Orang Tua • {currentTenant?.name}</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-black tracking-tight">
              Selamat Datang, Bapak/Ibu {currentUser?.full_name}
            </h1>
            <p className="text-xs text-amber-200 max-w-2xl leading-relaxed">
              Pantau perkembangan belajar dan kedisiplinan putra/putri Anda secara transparan. Akun Anda telah diverifikasi oleh Wali Kelas.
            </p>
          </div>

          {/* Child Selector Dropdown if multiple */}
          {linkedChildren.length > 0 && (
            <div className="bg-amber-950/70 backdrop-blur-xs p-2.5 rounded-2xl border border-amber-700/60 flex items-center gap-2 text-xs">
              <span className="font-semibold text-amber-300">Pilih Anak:</span>
              <select
                value={activeChild?.id || ''}
                onChange={(e) => setSelectedChildId(e.target.value)}
                className="bg-amber-900 border border-amber-600 rounded-xl px-2.5 py-1 text-white font-bold text-xs"
              >
                {linkedChildren.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.full_name} ({c.class_name || 'Kelas'})
                  </option>
                ))}
              </select>
            </div>
          )}
        </div>
      </div>

      {/* Security Verification Notice */}
      <div className="p-3.5 rounded-2xl bg-emerald-50 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-800 text-emerald-800 dark:text-emerald-200 text-xs flex items-center gap-2.5">
        <ShieldCheck className="w-5 h-5 text-emerald-600 shrink-0" />
        <div>
          <span className="font-bold">Akun Terverifikasi Wali Kelas: </span>
          <span>
            Sesuai aturan keamanan SCOLA, akun orang tua tidak dapat mendaftar mandiri. Akses ini diaktifkan resmi oleh pihak sekolah dan terikat dengan data siswa: <strong>{activeChild?.full_name}</strong>.
          </span>
        </div>
      </div>

      {/* Child Profile Card */}
      {activeChild && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-5 shadow-xs flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-amber-100 dark:bg-amber-950 text-amber-800 dark:text-amber-300 font-bold flex items-center justify-center text-lg">
              {activeChild.full_name.charAt(0)}
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900 dark:text-white">
                {activeChild.full_name}
              </h2>
              <div className="flex items-center gap-2 text-xs text-slate-500">
                <span className="font-mono">NIS: {activeChild.nis}</span>
                <span>•</span>
                <span className="font-semibold text-blue-600 dark:text-blue-400">
                  {activeChild.class_name}
                </span>
                <span>•</span>
                <span>{currentTenant?.type === 'SMK' ? 'SMK Vokasi' : 'SMA Reguler'}</span>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <a
              href={`https://wa.me/${currentTenant?.phone || '628123456789'}`}
              target="_blank"
              rel="noreferrer"
              className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs flex items-center gap-1.5 cursor-pointer shadow-xs"
            >
              <MessageCircle className="w-4 h-4" />
              <span>WhatsApp Wali Kelas</span>
            </a>
          </div>
        </div>
      )}

      {/* Two Column Layout: Attendance & Grades */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Attendance Card */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-5 shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <CalendarCheck className="w-4 h-4 text-blue-600" />
              <span>Presensi Kehadiran Terakhir</span>
            </h3>
            <span className="text-[11px] font-bold text-emerald-600">
              100% Kehadiran
            </span>
          </div>

          <div className="space-y-2 text-xs">
            {attendance.length === 0 ? (
              <div className="text-center py-6 text-slate-400">Belum ada catatan presensi.</div>
            ) : (
              attendance.map((a) => (
                <div
                  key={a.id}
                  className="p-3 rounded-xl border border-slate-100 dark:border-slate-800 bg-slate-50 dark:bg-slate-850 flex items-center justify-between"
                >
                  <span className="font-mono text-slate-500 font-semibold">{a.date}</span>
                  <span className="px-2.5 py-0.5 rounded-full font-bold text-[11px] bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300">
                    {a.status}
                  </span>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Grades Card */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-5 shadow-xs space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div>
              <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <Award className="w-4 h-4 text-amber-600" />
                <span>Capaian Nilai &amp; e-Rapor Siswa</span>
              </h3>
              <p className="text-[11px] text-slate-400">Semester Ganjil 2024/2025</p>
            </div>
            <button
              type="button"
              onClick={() => setIsPrintModalOpen(true)}
              className="px-3 py-1.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold flex items-center gap-1.5 shadow-xs cursor-pointer transition-colors"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Cetak / Lihat e-Rapor</span>
            </button>
          </div>

          <div className="space-y-2 text-xs">
            {grades.length === 0 ? (
              <div className="text-center py-6 text-slate-400">Belum ada nilai yang diinput guru.</div>
            ) : (
              grades.map((g) => (
                <div
                  key={g.id}
                  className="p-3 rounded-xl border border-slate-100 dark:border-slate-800 bg-slate-50 dark:bg-slate-850 flex items-center justify-between"
                >
                  <div>
                    <span className="font-bold text-slate-900 dark:text-white block">
                      {g.subject_name}
                    </span>
                    <span className="text-[11px] text-slate-400">
                      Tugas: {g.tugas_score} • UTS: {g.uts_score} • UAS: {g.uas_score}
                    </span>
                  </div>
                  <div className="text-right">
                    <span className="font-mono font-black text-sm text-slate-900 dark:text-white block">
                      {g.final_score}
                    </span>
                    <span className="text-[10px] font-bold px-1.5 py-0.2 rounded bg-emerald-100 text-emerald-800">
                      Predikat {g.predicate}
                    </span>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>

      {/* Consultation Message to Wali Kelas */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-5 shadow-xs space-y-3">
        <div className="flex items-center gap-2">
          <HeartHandshake className="w-5 h-5 text-amber-600" />
          <h3 className="text-sm font-bold text-slate-900 dark:text-white">
            Konsultasi atau Catatan untuk Wali Kelas
          </h3>
        </div>
        <p className="text-xs text-slate-500">
          Sampaikan informasi izin sakit, permohonan dispensasi, atau kendala belajar anak langsung ke wali kelas.
        </p>

        {consultationSent && (
          <div className="p-3 rounded-xl bg-emerald-50 text-emerald-800 text-xs font-bold flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4" />
            <span>Pesan konsultasi telah diteruskan ke Wali Kelas {activeChild?.class_name}.</span>
          </div>
        )}

        <form onSubmit={handleSendConsultation} className="space-y-2">
          <textarea
            rows={3}
            value={consultationText}
            onChange={(e) => setConsultationText(e.target.value)}
            placeholder="Tulis pesan atau pertanyaan Anda di sini..."
            className="w-full p-3 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs focus:ring-2 focus:ring-amber-500 focus:outline-none"
          />
          <div className="flex justify-end">
            <button
              type="submit"
              className="px-4 py-2 bg-amber-600 hover:bg-amber-700 text-white font-bold rounded-xl text-xs cursor-pointer shadow-xs"
            >
              Kirim Pesan Konsultasi
            </button>
          </div>
        </form>
      </div>

      {/* Official Printable E-Rapor Modal for Parents */}
      <ERaportPrintModal
        isOpen={isPrintModalOpen}
        onClose={() => setIsPrintModalOpen(false)}
        reportCard={reportCard}
      />
    </div>
  );
};
