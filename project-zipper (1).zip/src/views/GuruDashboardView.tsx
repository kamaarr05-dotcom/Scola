import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { useTenant } from '../context/TenantContext';
import {
  StudentProfile,
  StudentClass,
  GradeRecord,
  AttendanceRecord,
  AttendanceStatus,
  TeacherAssignmentType,
  StudentReportCard,
} from '../types';
import { academicRepository } from '../repositories/academicRepository';
import { AssignmentPill } from '../components/common/AssignmentPill';
import { SmkManagementModule } from '../components/smk/SmkManagementModule';
import { WakaDashboardView } from '../components/dashboard/WakaDashboardView';
import { BkDashboardView } from '../components/dashboard/BkDashboardView';
import { ERaportPrintModal } from '../components/common/ERaportPrintModal';
import {
  BookOpen,
  Users,
  CheckCircle2,
  CalendarCheck,
  Award,
  FileSpreadsheet,
  Baby,
  Plus,
  AlertCircle,
  X,
  Send,
  Briefcase,
  Check,
  HeartHandshake,
  Printer,
} from 'lucide-react';

export const GuruDashboardView: React.FC = () => {
  const { currentUser, activeTeacherAssignment, setActiveTeacherAssignment, createParentAccount } = useAuth();
  const { currentTenant } = useTenant();

  const [classes, setClasses] = useState<StudentClass[]>([]);
  const [selectedClassId, setSelectedClassId] = useState<string>('');
  const [students, setStudents] = useState<StudentProfile[]>([]);
  const [grades, setGrades] = useState<GradeRecord[]>([]);
  const [attendanceList, setAttendanceList] = useState<AttendanceRecord[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  // Active Tab
  const [activeTab, setActiveTab] = useState<'presensi' | 'nilai' | 'wali_kelas' | 'kaprog' | 'waka' | 'bk'>('presensi');

  // Attendance submission state
  const [attendanceDate, setAttendanceDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [attendanceStatusMap, setAttendanceStatusMap] = useState<Record<string, 'HADIR' | 'SAKIT' | 'IZIN' | 'ALPA'>>({});
  const [saveSuccessMsg, setSaveSuccessMsg] = useState<string | null>(null);

  // Grading state
  const [newSubject, setNewSubject] = useState('Matematika Wajib');
  const [gradeInputMap, setGradeInputMap] = useState<Record<string, { tugas: number; uts: number; uas: number }>>({});

  // Parent activation modal (Wali Kelas privilege)
  const [showParentModal, setShowParentModal] = useState(false);
  const [selectedStudentForParent, setSelectedStudentForParent] = useState<StudentProfile | null>(null);
  const [parentFullName, setParentFullName] = useState('');
  const [parentEmail, setParentEmail] = useState('');
  const [parentPhone, setParentPhone] = useState('');
  const [parentRelation, setParentRelation] = useState<'AYAH' | 'IBU' | 'WALI'>('AYAH');
  const [parentActionMsg, setParentActionMsg] = useState<string | null>(null);
  const [parentErrorMsg, setParentErrorMsg] = useState<string | null>(null);

  // E-Rapor Preview & Print State
  const [waliReportCard, setWaliReportCard] = useState<StudentReportCard | null>(null);
  const [isPrintModalOpen, setIsPrintModalOpen] = useState(false);

  const handleViewStudentReport = async (student: StudentProfile) => {
    if (!currentTenant || !currentUser) return;
    try {
      const cards = await academicRepository.getReportCards(currentTenant.id, currentUser, {
        student_id: student.id,
      });
      if (cards && cards.length > 0) {
        setWaliReportCard(cards[0]);
        setIsPrintModalOpen(true);
      }
    } catch (err) {
      console.error('Error fetching student report card:', err);
    }
  };

  const teacherAssignments = currentUser?.assignments?.map((a) => a.type) || ['GURU'];
  const hasWaliKelas = teacherAssignments.includes('WALI_KELAS');
  const hasKaprog = teacherAssignments.includes('KAPROG');
  const hasWaka = teacherAssignments.some((a) => a.startsWith('WAKA'));
  const hasBk = teacherAssignments.includes('BK') || teacherAssignments.includes('GURU_BK');

  const loadClassesAndStudents = async () => {
    if (!currentTenant || !currentUser) return;
    setIsLoading(true);
    try {
      const cls = await academicRepository.getClassesByTenant(currentTenant.id, currentUser);
      setClasses(cls);
      if (cls.length > 0) {
        const firstClsId = cls[0].id;
        setSelectedClassId(firstClsId);
        await loadClassData(firstClsId);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  const loadClassData = async (classId: string) => {
    if (!currentTenant || !currentUser) return;
    const std = await academicRepository.getStudentsByTenant(currentTenant.id, currentUser, { class_id: classId });
    setStudents(std);

    // Init attendance map default to HADIR
    const attMap: Record<string, 'HADIR' | 'SAKIT' | 'IZIN' | 'ALPA'> = {};
    const grdMap: Record<string, { tugas: number; uts: number; uas: number }> = {};
    std.forEach((s) => {
      attMap[s.id] = 'HADIR';
      grdMap[s.id] = { tugas: 85, uts: 80, uas: 88 };
    });
    setAttendanceStatusMap(attMap);
    setGradeInputMap(grdMap);

    const attRecords = await academicRepository.getAttendance(currentTenant.id, currentUser, {
      class_id: classId,
      date: attendanceDate,
    });
    setAttendanceList(attRecords);

    const grdRecords = await academicRepository.getGrades(currentTenant.id, currentUser, {
      class_id: classId,
    });
    setGrades(grdRecords);
  };

  useEffect(() => {
    loadClassesAndStudents();
  }, [currentTenant?.id]);

  const handleClassChange = async (classId: string) => {
    setSelectedClassId(classId);
    await loadClassData(classId);
  };

  const handleSaveAttendance = async () => {
    if (!currentTenant || !currentUser || !selectedClassId) return;
    setSaveSuccessMsg(null);

    const bulkPayload = {
      tenant_id: currentTenant.id,
      class_id: selectedClassId,
      date: attendanceDate,
      attendance: Object.entries(attendanceStatusMap).map(([studentId, status]) => ({
        student_id: studentId,
        status: status as AttendanceStatus,
      })),
    };

    await academicRepository.recordBulkAttendance(bulkPayload, currentUser);
    setSaveSuccessMsg(`Presensi kelas untuk tanggal ${attendanceDate} berhasil disimpan!`);
    await loadClassData(selectedClassId);
    setTimeout(() => setSaveSuccessMsg(null), 3000);
  };

  const handleSaveGrades = async () => {
    if (!currentTenant || !currentUser || !selectedClassId) return;
    setSaveSuccessMsg(null);

    const promises = Object.entries(gradeInputMap).map(([studentId, marks]: [string, { tugas: number; uts: number; uas: number }]) => {
      const student = students.find((s) => s.id === studentId);
      const studentName = student?.full_name || 'Siswa';
      const finalScore = Math.round(marks.tugas * 0.3 + marks.uts * 0.3 + marks.uas * 0.4);

      return academicRepository.recordGrade(
        {
          tenant_id: currentTenant.id,
          class_id: selectedClassId,
          student_id: studentId,
          student_name: studentName,
          subject_id: `sbj-${newSubject.toLowerCase().replace(/\s+/g, '-')}`,
          subject_name: newSubject,
          assessment_type: 'FORMATIF_DAN_SUMATIF',
          assessment_title: `Penilaian Semester Ganjil - ${newSubject}`,
          score: finalScore,
          max_score: 100,
          weight: 100,
          competency_achievement: finalScore >= 75 ? 'Mencapai KKM dengan predikat baik' : 'Perlu bimbingan remedial',
        },
        currentUser
      );
    });

    await Promise.all(promises);
    setSaveSuccessMsg(`Nilai mata pelajaran ${newSubject} berhasil diperbarui!`);
    await loadClassData(selectedClassId);
    setTimeout(() => setSaveSuccessMsg(null), 3000);
  };

  const handleOpenParentModal = (student: StudentProfile) => {
    setSelectedStudentForParent(student);
    setParentFullName(student.parent_name || `Orang Tua ${student.full_name}`);
    setParentEmail(`ortu.${student.nis}@scola.id`);
    setParentPhone(student.parent_whatsapp || '081234567890');
    setParentRelation(student.parent_relation || 'AYAH');
    setParentActionMsg(null);
    setParentErrorMsg(null);
    setShowParentModal(true);
  };

  const handleActivateParentSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedStudentForParent || !currentTenant || !currentUser) return;
    setParentErrorMsg(null);
    setParentActionMsg(null);

    try {
      await createParentAccount({
        tenant_id: currentTenant.id,
        full_name: parentFullName,
        email: parentEmail,
        phone: parentPhone,
        relation_type: parentRelation,
        student_ids: [selectedStudentForParent.id],
        class_id: selectedClassId,
      });

      setParentActionMsg(`Akun Orang Tua (${parentFullName}) berhasil diaktivasi dan ditautkan ke ${selectedStudentForParent.full_name}!`);
      setTimeout(() => {
        setShowParentModal(false);
        setParentActionMsg(null);
      }, 1500);
    } catch (err: any) {
      setParentErrorMsg(err.message || 'Gagal mengaktivasi akun orang tua.');
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-blue-800 to-cyan-900 text-white rounded-3xl p-6 shadow-xl relative overflow-hidden">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2 text-cyan-300 text-xs font-semibold uppercase tracking-wider">
              <BookOpen className="w-4 h-4" />
              <span>Portal Akademik & Pembelajaran Guru</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-black tracking-tight">
              Selamat Mengajar, {currentUser?.full_name}
            </h1>
            <p className="text-xs text-cyan-200 max-w-2xl leading-relaxed">
              Manajemen agenda mengajar, absensi harian siswa, penilaian raport berkala, serta tugas khusus pembinaan siswa.
            </p>
          </div>

          {/* Assignment Switcher Pills */}
          <div className="bg-slate-900/60 backdrop-blur-xs p-2 rounded-2xl border border-white/10 flex flex-wrap items-center gap-1.5 text-xs">
            <span className="text-[11px] font-semibold text-slate-300 px-1">
              Penugasan Aktif:
            </span>
            {teacherAssignments.map((asg) => (
              <AssignmentPill
                key={asg}
                type={asg}
                selected={activeTeacherAssignment === asg}
                onClick={() => setActiveTeacherAssignment(asg)}
              />
            ))}
          </div>
        </div>
      </div>

      {saveSuccessMsg && (
        <div className="p-3.5 rounded-2xl bg-emerald-50 text-emerald-800 border border-emerald-200 text-xs font-bold flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 shrink-0" />
          <span>{saveSuccessMsg}</span>
        </div>
      )}

      {/* Class Selector & Sub-Navigation */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
        <div className="flex items-center gap-2 text-xs">
          <span className="font-bold text-slate-700 dark:text-slate-300">
            Pilih Kelas / Rombel:
          </span>
          <select
            value={selectedClassId}
            onChange={(e) => handleClassChange(e.target.value)}
            className="p-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl font-bold text-xs text-slate-900 dark:text-white"
          >
            {classes.map((c) => (
              <option key={c.id} value={c.id}>
                {c.name} ({c.grade_level} {c.major_or_program || ''})
              </option>
            ))}
          </select>
        </div>

        {/* Tab Buttons */}
        <div className="flex items-center gap-1 bg-slate-100 dark:bg-slate-800 p-1 rounded-xl text-xs">
          <button
            type="button"
            onClick={() => setActiveTab('presensi')}
            className={`px-3 py-1.5 rounded-lg font-bold transition-all cursor-pointer ${
              activeTab === 'presensi'
                ? 'bg-white dark:bg-slate-900 text-blue-600 shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
            }`}
          >
            Presensi Siswa
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('nilai')}
            className={`px-3 py-1.5 rounded-lg font-bold transition-all cursor-pointer ${
              activeTab === 'nilai'
                ? 'bg-white dark:bg-slate-900 text-blue-600 shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
            }`}
          >
            Penilaian & Raport
          </button>

          {hasWaliKelas && (
            <button
              type="button"
              onClick={() => setActiveTab('wali_kelas')}
              className={`px-3 py-1.5 rounded-lg font-bold transition-all cursor-pointer flex items-center gap-1 ${
                activeTab === 'wali_kelas'
                  ? 'bg-emerald-600 text-white shadow-xs'
                  : 'text-emerald-700 dark:text-emerald-400 hover:text-emerald-900'
              }`}
            >
              <Users className="w-3.5 h-3.5" />
              <span>Wali Kelas</span>
            </button>
          )}

          {hasKaprog && (
            <button
              type="button"
              onClick={() => setActiveTab('kaprog')}
              className={`px-3 py-1.5 rounded-lg font-bold transition-all cursor-pointer flex items-center gap-1 ${
                activeTab === 'kaprog'
                  ? 'bg-amber-600 text-white shadow-xs'
                  : 'text-amber-700 dark:text-amber-400 hover:text-amber-900'
              }`}
            >
              <Briefcase className="w-3.5 h-3.5" />
              <span>Kaprog SMK & PKL</span>
            </button>
          )}

          {hasWaka && (
            <button
              type="button"
              onClick={() => setActiveTab('waka')}
              className={`px-3 py-1.5 rounded-lg font-bold transition-all cursor-pointer flex items-center gap-1 ${
                activeTab === 'waka'
                  ? 'bg-indigo-600 text-white shadow-xs'
                  : 'text-indigo-700 dark:text-indigo-400 hover:text-indigo-900'
              }`}
            >
              <Award className="w-3.5 h-3.5" />
              <span>Tugas WAKA</span>
            </button>
          )}

          {hasBk && (
            <button
              type="button"
              onClick={() => setActiveTab('bk')}
              className={`px-3 py-1.5 rounded-lg font-bold transition-all cursor-pointer flex items-center gap-1 ${
                activeTab === 'bk'
                  ? 'bg-teal-600 text-white shadow-xs'
                  : 'text-teal-700 dark:text-teal-400 hover:text-teal-900'
              }`}
            >
              <HeartHandshake className="w-3.5 h-3.5" />
              <span>Guru BK</span>
            </button>
          )}
        </div>
      </div>

      {/* TAB 1: Presensi Siswa */}
      {activeTab === 'presensi' && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl overflow-hidden shadow-xs space-y-4">
          <div className="p-5 border-b border-slate-200 dark:border-slate-800 flex flex-wrap items-center justify-between gap-3">
            <div>
              <h2 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <CalendarCheck className="w-5 h-5 text-blue-600" />
                <span>Lembar Presensi Harian Siswa</span>
              </h2>
              <p className="text-xs text-slate-500">
                Pilih status kehadiran untuk setiap siswa dan simpan ke database
              </p>
            </div>

            <div className="flex items-center gap-3">
              <input
                type="date"
                value={attendanceDate}
                onChange={(e) => setAttendanceDate(e.target.value)}
                className="p-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold text-slate-800 dark:text-white"
              />
              <button
                type="button"
                onClick={handleSaveAttendance}
                className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer shadow-sm"
              >
                <Check className="w-4 h-4" />
                <span>Simpan Presensi</span>
              </button>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-slate-700 dark:text-slate-300">
              <thead className="bg-slate-50 dark:bg-slate-850 text-[11px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider border-b border-slate-200 dark:border-slate-800">
                <tr>
                  <th className="py-3.5 px-4">No</th>
                  <th className="py-3.5 px-4">Nama Siswa</th>
                  <th className="py-3.5 px-4">NIS / NISN</th>
                  <th className="py-3.5 px-4">JK</th>
                  <th className="py-3.5 px-4 text-center">Status Kehadiran</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800 font-medium">
                {students.map((student, idx) => {
                  const currentStatus = attendanceStatusMap[student.id] || 'HADIR';
                  return (
                    <tr key={student.id} className="hover:bg-slate-50/70 dark:hover:bg-slate-800/50">
                      <td className="py-3.5 px-4 font-mono text-slate-400">{idx + 1}</td>
                      <td className="py-3.5 px-4 font-bold text-slate-900 dark:text-white">
                        {student.full_name}
                      </td>
                      <td className="py-3.5 px-4 font-mono text-slate-500">
                        {student.nis} / {student.nisn}
                      </td>
                      <td className="py-3.5 px-4 font-semibold text-slate-500">
                        {student.gender}
                      </td>
                      <td className="py-3.5 px-4">
                        <div className="flex items-center justify-center gap-1">
                          {(['HADIR', 'SAKIT', 'IZIN', 'ALPA'] as const).map((st) => (
                            <button
                              key={st}
                              type="button"
                              onClick={() =>
                                setAttendanceStatusMap((prev) => ({ ...prev, [student.id]: st }))
                              }
                              className={`px-3 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                                currentStatus === st
                                  ? st === 'HADIR'
                                    ? 'bg-emerald-600 text-white shadow-xs'
                                    : st === 'SAKIT'
                                    ? 'bg-amber-500 text-white shadow-xs'
                                    : st === 'IZIN'
                                    ? 'bg-blue-600 text-white shadow-xs'
                                    : 'bg-rose-600 text-white shadow-xs'
                                  : 'bg-slate-100 dark:bg-slate-800 text-slate-500 hover:bg-slate-200'
                              }`}
                            >
                              {st}
                            </button>
                          ))}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 2: Penilaian & Raport */}
      {activeTab === 'nilai' && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl overflow-hidden shadow-xs space-y-4">
          <div className="p-5 border-b border-slate-200 dark:border-slate-800 flex flex-wrap items-center justify-between gap-3">
            <div>
              <h2 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <FileSpreadsheet className="w-5 h-5 text-indigo-600" />
                <span>Input Nilai Formatif, Sumatif & Raport</span>
              </h2>
              <p className="text-xs text-slate-500">
                Nilai yang disimpan dapat langsung dipantau secara realtime oleh Siswa dan Orang Tua
              </p>
            </div>

            <div className="flex items-center gap-3">
              <select
                value={newSubject}
                onChange={(e) => setNewSubject(e.target.value)}
                className="p-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-bold"
              >
                <option value="Matematika Wajib">Matematika Wajib</option>
                <option value="Bahasa Indonesia">Bahasa Indonesia</option>
                <option value="Bahasa Inggris">Bahasa Inggris</option>
                <option value="Fisika">Fisika</option>
                <option value="Pemrograman Web & Perangkat Bergerak">
                  Pemrograman Web (SMK)
                </option>
              </select>
              <button
                type="button"
                onClick={handleSaveGrades}
                className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer shadow-sm"
              >
                <Send className="w-4 h-4" />
                <span>Publikasikan Nilai</span>
              </button>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-slate-700 dark:text-slate-300">
              <thead className="bg-slate-50 dark:bg-slate-850 text-[11px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider border-b border-slate-200 dark:border-slate-800">
                <tr>
                  <th className="py-3.5 px-4">Nama Siswa</th>
                  <th className="py-3.5 px-4 text-center">Tugas & Formatif (30%)</th>
                  <th className="py-3.5 px-4 text-center">UTS / PTS (30%)</th>
                  <th className="py-3.5 px-4 text-center">UAS / PAS (40%)</th>
                  <th className="py-3.5 px-4 text-center">Nilai Akhir</th>
                  <th className="py-3.5 px-4 text-center">Predikat</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800 font-medium">
                {students.map((student) => {
                  const currentMarks = gradeInputMap[student.id] || { tugas: 80, uts: 80, uas: 80 };
                  const finalScore = Math.round(
                    currentMarks.tugas * 0.3 + currentMarks.uts * 0.3 + currentMarks.uas * 0.4
                  );
                  const predikat = finalScore >= 90 ? 'A' : finalScore >= 80 ? 'B' : finalScore >= 70 ? 'C' : 'D';

                  return (
                    <tr key={student.id} className="hover:bg-slate-50/70 dark:hover:bg-slate-800/50">
                      <td className="py-3.5 px-4 font-bold text-slate-900 dark:text-white">
                        {student.full_name}
                      </td>
                      <td className="py-3.5 px-4 text-center">
                        <input
                          type="number"
                          min={0}
                          max={100}
                          value={currentMarks.tugas}
                          onChange={(e) => {
                            const val = parseInt(e.target.value) || 0;
                            setGradeInputMap((prev) => ({
                              ...prev,
                              [student.id]: { ...prev[student.id], tugas: val },
                            }));
                          }}
                          className="w-16 p-1.5 text-center bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg font-mono font-bold"
                        />
                      </td>
                      <td className="py-3.5 px-4 text-center">
                        <input
                          type="number"
                          min={0}
                          max={100}
                          value={currentMarks.uts}
                          onChange={(e) => {
                            const val = parseInt(e.target.value) || 0;
                            setGradeInputMap((prev) => ({
                              ...prev,
                              [student.id]: { ...prev[student.id], uts: val },
                            }));
                          }}
                          className="w-16 p-1.5 text-center bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg font-mono font-bold"
                        />
                      </td>
                      <td className="py-3.5 px-4 text-center">
                        <input
                          type="number"
                          min={0}
                          max={100}
                          value={currentMarks.uas}
                          onChange={(e) => {
                            const val = parseInt(e.target.value) || 0;
                            setGradeInputMap((prev) => ({
                              ...prev,
                              [student.id]: { ...prev[student.id], uas: val },
                            }));
                          }}
                          className="w-16 p-1.5 text-center bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg font-mono font-bold"
                        />
                      </td>
                      <td className="py-3.5 px-4 text-center font-mono font-black text-slate-900 dark:text-white">
                        {finalScore}
                      </td>
                      <td className="py-3.5 px-4 text-center">
                        <span
                          className={`px-2 py-0.5 rounded font-bold text-xs ${
                            predikat === 'A'
                              ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                              : predikat === 'B'
                              ? 'bg-blue-100 text-blue-800 dark:bg-blue-950 dark:text-blue-300'
                              : 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300'
                          }`}
                        >
                          {predikat}
                        </span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 3: Wali Kelas Module (Privileged) */}
      {activeTab === 'wali_kelas' && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl overflow-hidden shadow-xs space-y-4">
          <div className="p-5 border-b border-slate-200 dark:border-slate-800 flex flex-wrap items-center justify-between gap-3">
            <div>
              <div className="flex items-center gap-2">
                <span className="p-2 rounded-xl bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300">
                  <Users className="w-5 h-5" />
                </span>
                <h2 className="text-base font-bold text-slate-900 dark:text-white">
                  Modul Tugas Tambahan: Pembinaan Wali Kelas
                </h2>
              </div>
              <p className="text-xs text-slate-500 mt-1">
                Aturan Khusus: Orang Tua tidak dapat mendaftar mandiri. Wali Kelas memvalidasi dan mengaktifkan akun orang tua di sini.
              </p>
            </div>
          </div>

          <div className="p-5">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {students.map((student) => (
                <div
                  key={student.id}
                  className="p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-850 flex flex-col justify-between gap-3"
                >
                  <div className="space-y-1">
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-sm text-slate-900 dark:text-white">
                        {student.full_name}
                      </span>
                      <span className="font-mono text-xs text-slate-500">
                        NIS: {student.nis}
                      </span>
                    </div>
                    <p className="text-xs text-slate-500 dark:text-slate-400">
                      Orang Tua Tercatat: {student.parent_name || 'Belum terdata'} ({student.parent_relation || 'WALI'})
                    </p>
                    <p className="text-xs text-slate-500 dark:text-slate-400">
                      WhatsApp: {student.parent_whatsapp || '-'}
                    </p>
                  </div>

                  <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-slate-200 dark:border-slate-800">
                    <button
                      type="button"
                      onClick={() => handleViewStudentReport(student)}
                      className="px-2.5 py-1.5 rounded-xl bg-blue-50 dark:bg-blue-950/50 hover:bg-blue-100 text-blue-700 dark:text-blue-300 font-bold text-xs flex items-center gap-1.5 cursor-pointer transition-colors"
                    >
                      <Printer className="w-3.5 h-3.5" />
                      <span>Lihat &amp; Cetak e-Rapor</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => handleOpenParentModal(student)}
                      className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs flex items-center gap-1.5 cursor-pointer shadow-xs"
                    >
                      <Baby className="w-4 h-4" />
                      <span>Aktivasi Akun Ortu</span>
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* TAB 4: Kaprog SMK Module (for SMK teachers with KAPROG assignment) */}
      {activeTab === 'kaprog' && (
        <div className="space-y-4">
          <SmkManagementModule initialTab="pkl" />
        </div>
      )}

      {/* TAB 5: Waka Module */}
      {activeTab === 'waka' && (
        <div className="space-y-4">
          <WakaDashboardView />
        </div>
      )}

      {/* TAB 6: BK Module */}
      {activeTab === 'bk' && (
        <div className="space-y-4">
          <BkDashboardView />
        </div>
      )}

      {/* Parent Activation Modal */}
      {showParentModal && selectedStudentForParent && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl max-w-md w-full p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <div className="p-2 rounded-xl bg-emerald-100 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300">
                  <Baby className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-sm text-slate-900 dark:text-white">
                    Aktivasi Akun Orang Tua Siswa
                  </h3>
                  <p className="text-[11px] text-slate-500">
                    Oleh Wali Kelas untuk: {selectedStudentForParent.full_name}
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setShowParentModal(false)}
                className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {parentActionMsg && (
              <div className="p-3 rounded-xl bg-emerald-50 text-emerald-800 border border-emerald-200 text-xs font-bold">
                {parentActionMsg}
              </div>
            )}
            {parentErrorMsg && (
              <div className="p-3 rounded-xl bg-rose-50 text-rose-800 border border-rose-200 text-xs font-bold">
                {parentErrorMsg}
              </div>
            )}

            <form onSubmit={handleActivateParentSubmit} className="space-y-4 text-xs">
              <div className="space-y-1">
                <label className="font-bold text-slate-700 dark:text-slate-300">
                  Nama Lengkap Orang Tua / Wali *
                </label>
                <input
                  type="text"
                  required
                  value={parentFullName}
                  onChange={(e) => setParentFullName(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl"
                />
              </div>

              <div className="space-y-1">
                <label className="font-bold text-slate-700 dark:text-slate-300">
                  Alamat Email Akun *
                </label>
                <input
                  type="email"
                  required
                  value={parentEmail}
                  onChange={(e) => setParentEmail(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="font-bold text-slate-700 dark:text-slate-300">
                    Hubungan Keluarga *
                  </label>
                  <select
                    value={parentRelation}
                    onChange={(e) => setParentRelation(e.target.value as any)}
                    className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl font-bold"
                  >
                    <option value="AYAH">Ayah Kandung</option>
                    <option value="IBU">Ibu Kandung</option>
                    <option value="WALI">Wali Murid</option>
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="font-bold text-slate-700 dark:text-slate-300">
                    Nomor WhatsApp *
                  </label>
                  <input
                    type="text"
                    required
                    value={parentPhone}
                    onChange={(e) => setParentPhone(e.target.value)}
                    className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl"
                  />
                </div>
              </div>

              <div className="p-3 bg-blue-50 dark:bg-blue-950/30 border border-blue-200 dark:border-blue-800 rounded-xl text-[11px] text-blue-900 dark:text-blue-200">
                Akun yang dibuat akan langsung ditautkan secara eksklusif ke data anak ini ({selectedStudentForParent.full_name}) melalui relasi <code>parent_student_links</code>.
              </div>

              <div className="pt-2 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowParentModal(false)}
                  className="px-4 py-2 border border-slate-200 dark:border-slate-700 rounded-xl font-semibold hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-bold cursor-pointer shadow-sm"
                >
                  Aktivasi Sekarang
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Official Printable E-Rapor Modal for Wali Kelas */}
      <ERaportPrintModal
        isOpen={isPrintModalOpen}
        onClose={() => setIsPrintModalOpen(false)}
        reportCard={waliReportCard}
      />
    </div>
  );
};
