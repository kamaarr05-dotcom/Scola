import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { useTenant } from '../context/TenantContext';
import { AuthAuditEventType } from '../types';
import {
  ShieldCheck,
  ShieldAlert,
  Search,
  Filter,
  RefreshCw,
  Lock,
  CheckCircle2,
} from 'lucide-react';

export const AuditLogView: React.FC = () => {
  const { auditLogs, refreshAuditLogs, currentUser } = useAuth();
  const { currentTenant } = useTenant();

  const [filterEvent, setFilterEvent] = useState<string>('ALL');
  const [searchTerm, setSearchTerm] = useState<string>('');

  const isMaster = currentUser?.role === 'MASTER';

  const filteredLogs = auditLogs.filter((log) => {
    // Tenant filter: Master sees all; Kepsek sees only their tenant
    if (!isMaster && log.tenant_id && log.tenant_id !== currentUser?.tenant_id) {
      return false;
    }

    if (filterEvent !== 'ALL' && log.event !== filterEvent) {
      return false;
    }

    if (searchTerm) {
      const term = searchTerm.toLowerCase();
      const matchEmail = log.email?.toLowerCase().includes(term);
      const matchDetails = log.details?.toLowerCase().includes(term);
      const matchRole = log.role?.toLowerCase().includes(term);
      if (!matchEmail && !matchDetails && !matchRole) return false;
    }

    return true;
  });

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-slate-900 to-indigo-950 text-white rounded-3xl p-6 shadow-xl relative overflow-hidden">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2 text-indigo-300 text-xs font-semibold uppercase tracking-wider">
              <ShieldCheck className="w-4 h-4" />
              <span>Sistem Pengawasan Keamanan & Kepatuhan ISO/IEC 27001</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-black tracking-tight">
              Audit Trail & Security Logs
            </h1>
            <p className="text-xs text-indigo-200 max-w-2xl leading-relaxed">
              Pencatatan real-time seluruh aktivitas otentikasi, alokasi lisensi kuota guru, hak akses RBAC/ABAC, dan isolasi tenant.
            </p>
          </div>

          <button
            type="button"
            onClick={refreshAuditLogs}
            className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold rounded-xl transition-all shadow-md flex items-center gap-2 cursor-pointer"
          >
            <RefreshCw className="w-4 h-4" />
            <span>Segarkan Log</span>
          </button>
        </div>
      </div>

      {/* Security Compliance Guarantee Box */}
      <div className="p-4 rounded-2xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 text-xs text-emerald-900 dark:text-emerald-200 flex items-center justify-between gap-4">
        <div className="flex items-center gap-2.5">
          <Lock className="w-5 h-5 text-emerald-600 shrink-0" />
          <div>
            <span className="font-bold">Zero Credential Exposure Guarantee:</span>{' '}
            <span>
              Log audit ini mematuhi standar privasi tinggi. Password, token rahasia, atau kredensial mentah <strong>TIDAK PERNAH</strong> dicatat atau disimpan dalam basis data audit.
            </span>
          </div>
        </div>
        <div className="shrink-0 flex items-center gap-1 font-bold text-[11px] text-emerald-700 dark:text-emerald-300">
          <CheckCircle2 className="w-4 h-4" />
          <span>Audit Clean</span>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
        <div className="flex items-center gap-2 flex-1 min-w-[240px]">
          <Search className="w-4 h-4 text-slate-400" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Cari berdasarkan email, role, atau kata kunci log..."
            className="w-full bg-transparent text-xs text-slate-900 dark:text-white focus:outline-none"
          />
        </div>

        <div className="flex items-center gap-2 text-xs">
          <Filter className="w-4 h-4 text-slate-400" />
          <span className="font-bold text-slate-600 dark:text-slate-300">
            Tipe Event:
          </span>
          <select
            value={filterEvent}
            onChange={(e) => setFilterEvent(e.target.value)}
            className="p-1.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl font-semibold text-xs text-slate-900 dark:text-white"
          >
            <option value="ALL">Semua Aktivitas</option>
            <option value="LOGIN_SUCCESS">Login Berhasil</option>
            <option value="LOGIN_FAILED">Login Gagal</option>
            <option value="QUOTA_UPDATED">Perubahan Kuota</option>
            <option value="QUOTA_EXCEEDED">Kuota Terlampaui</option>
            <option value="TEACHER_ACTIVATED">Guru Diaktifkan</option>
            <option value="TEACHER_DEACTIVATED">Guru Dinonaktifkan</option>
            <option value="PERMISSION_DENIED">Akses Ditolak (RBAC)</option>
            <option value="SESSION_EXPIRED">Session Expired</option>
          </select>
        </div>
      </div>

      {/* Logs Table */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl overflow-hidden shadow-xs">
        <div className="p-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
          <h2 className="text-sm font-bold text-slate-900 dark:text-white">
            Log Aktivitas Keamanan ({filteredLogs.length} Record)
          </h2>
          <span className="text-[11px] text-slate-400 font-mono">
            Audit Scope: {isMaster ? 'Global Platform' : currentTenant?.name}
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-700 dark:text-slate-300">
            <thead className="bg-slate-50 dark:bg-slate-850 text-[11px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider border-b border-slate-200 dark:border-slate-800">
              <tr>
                <th className="py-3.5 px-4">Waktu (WIB)</th>
                <th className="py-3.5 px-4">Jenis Peristiwa (Event)</th>
                <th className="py-3.5 px-4">Pengguna & Role</th>
                <th className="py-3.5 px-4">Detail Peristiwa</th>
                <th className="py-3.5 px-4">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800 font-medium">
              {filteredLogs.length === 0 ? (
                <tr>
                  <td colSpan={5} className="py-8 text-center text-slate-400">
                    Tidak ada log audit yang sesuai dengan filter pencarian.
                  </td>
                </tr>
              ) : (
                filteredLogs.map((log) => {
                  const isSuccess = log.status === 'SUCCESS';
                  const isWarning = log.status === 'WARNING';
                  const isFailed = log.status === 'FAILED';

                  return (
                    <tr
                      key={log.id}
                      className="hover:bg-slate-50/70 dark:hover:bg-slate-800/50 transition-colors"
                    >
                      <td className="py-3.5 px-4 font-mono text-[11px] text-slate-400 whitespace-nowrap">
                        {new Date(log.timestamp).toLocaleString('id-ID')}
                      </td>

                      <td className="py-3.5 px-4">
                        <span
                          className={`font-mono font-bold text-[11px] px-2 py-0.5 rounded-md ${
                            log.event.includes('LOGIN')
                              ? 'bg-blue-50 text-blue-700 dark:bg-blue-950 dark:text-blue-300'
                              : log.event.includes('QUOTA')
                              ? 'bg-purple-50 text-purple-700 dark:bg-purple-950 dark:text-purple-300'
                              : log.event.includes('PERMISSION')
                              ? 'bg-rose-50 text-rose-700 dark:bg-rose-950 dark:text-rose-300'
                              : 'bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300'
                          }`}
                        >
                          {log.event}
                        </span>
                      </td>

                      <td className="py-3.5 px-4">
                        <span className="font-bold text-slate-900 dark:text-white block">
                          {log.email || 'Anonymous'}
                        </span>
                        <span className="text-[10px] text-slate-400 font-mono">
                          {log.role || 'GUEST'} {log.tenant_name ? `• ${log.tenant_name}` : ''}
                        </span>
                      </td>

                      <td className="py-3.5 px-4 text-slate-700 dark:text-slate-300 max-w-md truncate">
                        {log.details}
                      </td>

                      <td className="py-3.5 px-4">
                        <span
                          className={`inline-flex items-center gap-1 font-bold text-[10px] px-2 py-0.5 rounded-full ${
                            isSuccess
                              ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                              : isWarning
                              ? 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300'
                              : 'bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-300'
                          }`}
                        >
                          {isSuccess ? (
                            <CheckCircle2 className="w-3 h-3" />
                          ) : (
                            <ShieldAlert className="w-3 h-3" />
                          )}
                          <span>{log.status}</span>
                        </span>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
