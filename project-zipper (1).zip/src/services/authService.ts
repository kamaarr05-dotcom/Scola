import { getSupabase, isSupabaseConfigured } from '../config/supabase';
import { UserProfile, TeacherAssignmentType } from '../types';
import { INITIAL_USERS } from '../data/mockDatabase';
import { auditService } from './auditService';
import { canCreateTeacher, canActivateParentAccount } from '../lib/permissions';
import { validateTeacherQuota } from '../lib/quotaValidator';
import { tenantRepository } from '../repositories/tenantRepository';
import { academicRepository } from '../repositories/academicRepository';

export interface AuthSession {
  access_token: string;
  token_type: string;
  expires_in: number;
  expires_at: number;
  user_id: string;
}

export interface AuthResult {
  user: UserProfile | null;
  session: AuthSession | null;
  error: string | null;
}

class AuthService {
  private inMemoryUsers: UserProfile[] = [...INITIAL_USERS];
  private currentSession: AuthSession | null = null;
  private currentProfile: UserProfile | null = null;
  private userPasswords: Record<string, string> = {
    'mdqputra@gmail.com': '990830',
  };

  constructor() {
    // Default session for initial interactive preview (Kepala Sekolah)
    const initialUser = this.inMemoryUsers.find((u) => u.role === 'KEPALA_SEKOLAH') || this.inMemoryUsers[0];
    this.currentProfile = initialUser;
    this.currentSession = this.createMockSession(initialUser.id);
  }

  private createMockSession(userId: string): AuthSession {
    const now = Math.floor(Date.now() / 1000);
    return {
      access_token: `scola_jwt_${userId}_${Date.now()}`,
      token_type: 'bearer',
      expires_in: 3600,
      expires_at: now + 3600,
      user_id: userId,
    };
  }

  /**
   * Universal Login using Supabase Auth
   * Safe Indonesian error messages returned to protect system internals.
   */
  async signInWithPassword(email: string, password: string): Promise<AuthResult> {
    const cleanEmail = email.trim().toLowerCase();

    // 1. Live Supabase Auth when configured
    if (isSupabaseConfigured()) {
      const supabase = getSupabase();
      if (supabase) {
        try {
          const { data, error } = await supabase.auth.signInWithPassword({
            email: cleanEmail,
            password,
          });

          if (!error && data?.user && data?.session) {
            const { data: profileData, error: profileErr } = await supabase
              .from('user_profiles')
              .select('*, assignments:teacher_assignments(*)')
              .eq('id', data.user.id)
              .single();

            if (!profileErr && profileData) {
              const userProfile: UserProfile = {
                id: profileData.id,
                tenant_id: profileData.tenant_id,
                email: profileData.email,
                full_name: profileData.full_name,
                role: profileData.role,
                status: profileData.status,
                created_at: profileData.created_at,
                updated_at: profileData.updated_at,
                assignments: profileData.assignments,
              };

              if (userProfile.status !== 'ACTIVE') {
                return {
                  user: null,
                  session: null,
                  error: 'Akun Anda belum aktif.',
                };
              }

              const session: AuthSession = {
                access_token: data.session.access_token,
                token_type: data.session.token_type,
                expires_in: data.session.expires_in,
                expires_at: data.session.expires_at || Math.floor(Date.now() / 1000) + 3600,
                user_id: userProfile.id,
              };

              this.currentProfile = userProfile;
              this.currentSession = session;

              await auditService.recordEvent({
                event: 'LOGIN_SUCCESS',
                email: userProfile.email,
                user_id: userProfile.id,
                role: userProfile.role,
                tenant_id: userProfile.tenant_id,
                status: 'SUCCESS',
                details: `Supabase live session initiated for role: ${userProfile.role}`,
              });

              return { user: userProfile, session, error: null };
            }
          }
        } catch {
          // Graceful fallback to local inMemory store for demo simulation
        }
      }
    }

    // 2. Demo & Fallback Auth Verification
    if (!password || password.length < 4) {
      await auditService.recordEvent({
        event: 'LOGIN_FAILED',
        email: cleanEmail,
        status: 'FAILED',
        details: 'Password length validation failed',
      });
      return {
        user: null,
        session: null,
        error: 'Email atau password tidak sesuai.',
      };
    }

    const foundUser = this.inMemoryUsers.find(
      (u) => u.email.toLowerCase() === cleanEmail
    );

    if (!foundUser) {
      await auditService.recordEvent({
        event: 'LOGIN_FAILED',
        email: cleanEmail,
        status: 'FAILED',
        details: 'User account not found in database',
      });
      return {
        user: null,
        session: null,
        error: 'Email atau password tidak sesuai.',
      };
    }

    const expectedPassword = this.userPasswords[cleanEmail] || 'password123';
    if (password !== expectedPassword) {
      await auditService.recordEvent({
        event: 'LOGIN_FAILED',
        email: cleanEmail,
        user_id: foundUser.id,
        role: foundUser.role,
        tenant_id: foundUser.tenant_id,
        status: 'FAILED',
        details: 'Invalid password provided for user',
      });
      return {
        user: null,
        session: null,
        error: 'Email atau password tidak sesuai.',
      };
    }

    if (foundUser.status !== 'ACTIVE') {
      await auditService.recordEvent({
        event: 'LOGIN_FAILED',
        email: cleanEmail,
        user_id: foundUser.id,
        role: foundUser.role,
        tenant_id: foundUser.tenant_id,
        status: 'FAILED',
        details: `Account status is ${foundUser.status}`,
      });
      return {
        user: null,
        session: null,
        error: 'Akun Anda belum aktif.',
      };
    }

    // Prompt 5: Tenant INACTIVE blocks non-master school users from logging in,
    // while historical data remains preserved.
    if (foundUser.role !== 'MASTER' && foundUser.tenant_id) {
      const userTenant = await tenantRepository.getById(foundUser.tenant_id);
      if (userTenant && (!userTenant.is_active || userTenant.status === 'INACTIVE')) {
        await auditService.recordEvent({
          event: 'LOGIN_FAILED',
          email: cleanEmail,
          user_id: foundUser.id,
          role: foundUser.role,
          tenant_id: foundUser.tenant_id,
          tenant_name: userTenant.name,
          status: 'FAILED',
          details: `Login ditolak: Tenant "${userTenant.name}" berstatus NONAKTIF.`,
        });
        return {
          user: null,
          session: null,
          error: `Akses Ditolak: Sekolah Anda (${userTenant.name}) saat ini berstatus NONAKTIF. Silakan hubungi administrator SCOLA.`,
        };
      }
    }

    const session = this.createMockSession(foundUser.id);
    this.currentProfile = foundUser;
    this.currentSession = session;

    await auditService.recordEvent({
      event: 'LOGIN_SUCCESS',
      email: foundUser.email,
      user_id: foundUser.id,
      role: foundUser.role,
      tenant_id: foundUser.tenant_id,
      status: 'SUCCESS',
      details: `Authenticated with role ${foundUser.role} in tenant: ${foundUser.tenant_id || 'PLATFORM_WIDE'}`,
    });

    return {
      user: foundUser,
      session,
      error: null,
    };
  }

  /**
   * Logout from all sessions
   */
  async signOut(): Promise<void> {
    if (isSupabaseConfigured()) {
      const supabase = getSupabase();
      if (supabase) {
        try {
          await supabase.auth.signOut();
        } catch {
          // ignore
        }
      }
    }

    if (this.currentProfile) {
      await auditService.recordEvent({
        event: 'LOGOUT',
        email: this.currentProfile.email,
        user_id: this.currentProfile.id,
        role: this.currentProfile.role,
        tenant_id: this.currentProfile.tenant_id,
        status: 'SUCCESS',
        details: 'User explicitly terminated session',
      });
    }

    this.currentProfile = null;
    this.currentSession = null;
  }

  /**
   * Expire session for testing expired session handling
   */
  async expireSession(): Promise<void> {
    if (this.currentProfile) {
      await auditService.recordEvent({
        event: 'SESSION_EXPIRED',
        email: this.currentProfile.email,
        user_id: this.currentProfile.id,
        role: this.currentProfile.role,
        tenant_id: this.currentProfile.tenant_id,
        status: 'WARNING',
        details: 'Session token exceeded TTL',
      });
    }
    this.currentProfile = null;
    this.currentSession = null;
  }

  /**
   * Refresh session
   */
  async refreshSession(): Promise<AuthResult> {
    if (!this.currentProfile) {
      return {
        user: null,
        session: null,
        error: 'Session telah berakhir. Silakan login kembali.',
      };
    }
    this.currentSession = this.createMockSession(this.currentProfile.id);
    return {
      user: this.currentProfile,
      session: this.currentSession,
      error: null,
    };
  }

  /**
   * Student Self-Registration (Permitted for SISWA only)
   */
  async registerStudent(params: {
    tenant_id: string;
    full_name: string;
    email: string;
    password?: string;
    nisn: string;
    nis: string;
    gender?: 'L' | 'P';
    class_id?: string;
    class_name?: string;
    generation_year?: number;
    school_type?: 'SMA' | 'SMK';
    peminatan_or_program?: string;
    sma_peminatan?: string;
    smk_program_id?: string;
    smk_program_name?: string;
    kompetensi_keahlian?: string;
    address?: string;
    phone?: string;
    parent_name?: string;
    parent_relation?: 'AYAH' | 'IBU' | 'WALI';
    parent_whatsapp?: string;
  }): Promise<UserProfile> {
    if (isSupabaseConfigured() && params.password) {
      const supabase = getSupabase();
      if (supabase) {
        try {
          await supabase.auth.signUp({
            email: params.email.trim(),
            password: params.password,
            options: {
              data: {
                full_name: params.full_name.trim(),
                role: 'SISWA',
                tenant_id: params.tenant_id,
              },
            },
          });
        } catch (err) {
          console.warn('Supabase Auth signUp fallback to inMemory:', err);
        }
      }
    }

    let classId = params.class_id;
    if (!classId) {
      const tenantClasses = await academicRepository.getClassesByTenant(params.tenant_id, {
        id: 'system',
        tenant_id: params.tenant_id,
        email: 'system@scola.id',
        full_name: 'System',
        role: 'MASTER',
        status: 'ACTIVE',
        created_at: '',
        updated_at: '',
      });
      classId = tenantClasses.length > 0 ? tenantClasses[0].id : 'cls-sma-10-1';
    }

    const regResult = await academicRepository.selfRegisterStudent({
      tenant_id: params.tenant_id,
      full_name: params.full_name,
      nisn: params.nisn,
      nis: params.nis,
      gender: params.gender || 'L',
      class_id: classId,
      class_name: params.class_name,
      address: params.address,
      phone: params.phone,
      email: params.email,
      password: params.password,
      parent_name: params.parent_name || 'Orang Tua Siswa',
      parent_relation: params.parent_relation || 'AYAH',
      parent_whatsapp: params.parent_whatsapp || '081234567890',
      generation_year: params.generation_year || new Date().getFullYear(),
      sma_peminatan: params.sma_peminatan || (params.school_type === 'SMA' ? params.peminatan_or_program : undefined),
      smk_program_id: params.smk_program_id || (params.school_type === 'SMK' ? params.peminatan_or_program : undefined),
      smk_program_name: params.smk_program_name,
      kompetensi_keahlian: params.kompetensi_keahlian,
    });

    const existingIdx = this.inMemoryUsers.findIndex((u) => u.id === regResult.user.id);
    if (existingIdx >= 0) {
      this.inMemoryUsers[existingIdx] = regResult.user;
    } else {
      this.inMemoryUsers.push(regResult.user);
    }
    if (params.password) {
      this.userPasswords[params.email.trim().toLowerCase()] = params.password;
    }
    return regResult.user;
  }

  /**
   * Create Teacher Account
   * Business Rule: Guru CANNOT self-register. Must be created by MASTER or KEPALA_SEKOLAH.
   */
  async createTeacher(
    params: {
      tenant_id: string;
      full_name: string;
      email: string;
      phone: string;
      assignments?: TeacherAssignmentType[];
    },
    actor: UserProfile
  ): Promise<UserProfile> {
    if (!canCreateTeacher(actor.role)) {
      await auditService.recordEvent({
        event: 'PERMISSION_DENIED',
        email: actor.email,
        user_id: actor.id,
        role: actor.role,
        tenant_id: actor.tenant_id,
        status: 'FAILED',
        details: `Unauthorized attempt to create teacher by role: ${actor.role}`,
      });
      throw new Error('Anda tidak memiliki akses untuk membuat akun guru.');
    }

    if (actor.role === 'KEPALA_SEKOLAH' && actor.tenant_id !== params.tenant_id) {
      throw new Error('Anda hanya dapat membuat guru untuk sekolah Anda sendiri.');
    }

    const tenant = await tenantRepository.getById(params.tenant_id);
    if (tenant) {
      const activeTeachers = this.inMemoryUsers
        .filter((u) => u.role === 'GURU' && u.tenant_id === params.tenant_id)
        .map((u) => ({
          id: u.id,
          status: u.status,
        }));
      const quotaCheck = validateTeacherQuota(tenant, activeTeachers, undefined, 'ACTIVE');
      if (!quotaCheck.allowed) {
        throw new Error(quotaCheck.reason || 'Kuota lisensi guru tidak mencukupi.');
      }
    }

    const teacherUserId = `usr-guru-${Date.now()}`;
    const newTeacher: UserProfile = {
      id: teacherUserId,
      tenant_id: params.tenant_id,
      email: params.email.toLowerCase(),
      full_name: params.full_name,
      phone: params.phone,
      role: 'GURU', // Strictly GURU
      status: 'ACTIVE',
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
      assignments: (params.assignments || ['GURU']).map((asg, idx) => ({
        id: `asg-${Date.now()}-${idx}`,
        tenant_id: params.tenant_id,
        teacher_id: teacherUserId,
        type: asg,
        academic_year_id: 'ay-2024-ganjil',
        active: true,
        assigned_at: new Date().toISOString(),
      })),
    };

    this.inMemoryUsers.push(newTeacher);
    await auditService.recordEvent({
      event: 'TEACHER_CREATED',
      email: newTeacher.email,
      user_id: newTeacher.id,
      role: 'GURU',
      tenant_id: params.tenant_id,
      status: 'SUCCESS',
      details: `Teacher created by ${actor.role} (${actor.full_name}). Assignments: ${(params.assignments || ['GURU']).join(', ')}`,
    });
    return newTeacher;
  }

  /**
   * Activate / Create Parent Account
   * Business Rule: Parents do NOT self-register.
   * Account is created/activated by Wali Kelas (or Kepala Sekolah / Master) and automatically linked to students.
   */
  async activateParent(
    params: {
      tenant_id: string;
      full_name: string;
      email: string;
      phone: string;
      relation_type: 'AYAH' | 'IBU' | 'WALI';
      student_ids: string[];
      class_id?: string;
    },
    actor: UserProfile
  ): Promise<UserProfile> {
    if (!canActivateParentAccount(actor, params.class_id)) {
      await auditService.recordEvent({
        event: 'PERMISSION_DENIED',
        email: actor.email,
        user_id: actor.id,
        role: actor.role,
        tenant_id: actor.tenant_id,
        status: 'FAILED',
        details: 'Unauthorized attempt to activate parent account without Wali Kelas assignment',
      });
      throw new Error('Hanya Wali Kelas (atau Kepala Sekolah/Master) yang dapat mengaktifkan akun orang tua.');
    }

    const { parent } = await academicRepository.activateParentAccount(
      {
        tenant_id: params.tenant_id,
        full_name: params.full_name,
        email: params.email,
        whatsapp: params.phone,
        relation_type: params.relation_type,
        student_ids: params.student_ids,
        class_id: params.class_id,
      },
      actor
    );

    const existingIdx = this.inMemoryUsers.findIndex((u) => u.id === parent.id);
    if (existingIdx >= 0) {
      this.inMemoryUsers[existingIdx] = parent;
    } else {
      this.inMemoryUsers.push(parent);
    }
    return parent;
  }

  getCurrentUser(): UserProfile | null {
    return this.currentProfile;
  }

  getCurrentSession(): AuthSession | null {
    return this.currentSession;
  }

  getAvailableUsers(): UserProfile[] {
    return [...this.inMemoryUsers];
  }

  setCurrentUser(user: UserProfile): void {
    this.currentProfile = user;
    this.currentSession = this.createMockSession(user.id);
  }
}

export const authService = new AuthService();
