import { AuthAuditLog, ScolaRole } from '../types';
import { getSupabase, isSupabaseConfigured } from '../config/supabase';

// Seed initial authentic audit logs for demonstration
const INITIAL_AUDIT_LOGS: AuthAuditLog[] = [
  {
    id: 'audit-001',
    timestamp: new Date(Date.now() - 3600000 * 2).toISOString(),
    event: 'LOGIN_SUCCESS',
    user_id: 'usr-master',
    email: 'mdqputra@gmail.com',
    role: 'MASTER',
    tenant_id: null,
    ip_address: '10.0.4.12',
    user_agent: 'SCOLA-Web/1.0 (Chrome on macOS)',
    status: 'SUCCESS',
    details: 'Super Master Platform authentication verified via Supabase Auth JWT',
  },
  {
    id: 'audit-002',
    timestamp: new Date(Date.now() - 3600000 * 1.5).toISOString(),
    event: 'LOGIN_SUCCESS',
    user_id: 'usr-kepsek-sma',
    email: 'kepsek@sman1nusantara.sch.id',
    role: 'KEPALA_SEKOLAH',
    tenant_id: 'tenant-sma-01',
    ip_address: '182.253.14.88',
    user_agent: 'SCOLA-Web/1.0 (Firefox on Windows)',
    status: 'SUCCESS',
    details: 'Kepala Sekolah verified for SMAN 1 Nusantara (tenant-sma-01)',
  },
  {
    id: 'audit-003',
    timestamp: new Date(Date.now() - 3600000).toISOString(),
    event: 'LOGIN_FAILED',
    email: 'unknown.user@sekolah.id',
    role: undefined,
    tenant_id: null,
    ip_address: '114.125.77.20',
    user_agent: 'SCOLA-Mobile/Android (Capacitor)',
    status: 'FAILED',
    details: 'Invalid credentials. Password omitted for security compliance.',
  },
  {
    id: 'audit-004',
    timestamp: new Date(Date.now() - 1800000).toISOString(),
    event: 'LOGIN_SUCCESS',
    user_id: 'usr-guru-budi',
    email: 'budi.santoso@sman1nusantara.sch.id',
    role: 'GURU',
    tenant_id: 'tenant-sma-01',
    ip_address: '182.253.14.90',
    user_agent: 'SCOLA-Web/1.0 (Chrome on macOS)',
    status: 'SUCCESS',
    details: 'Guru with assignments [WALI_KELAS, WAKA_KURIKULUM] logged in',
  },
];

class AuditService {
  private logs: AuthAuditLog[] = [...INITIAL_AUDIT_LOGS];

  /**
   * Records an authentication or security event.
   * STRICT SECURITY RULE: Passwords MUST NEVER be included in details or parameters.
   */
  async recordEvent(params: {
    event: AuthAuditLog['event'];
    email: string;
    user_id?: string;
    role?: ScolaRole;
    tenant_id?: string | null;
    status: 'SUCCESS' | 'FAILED' | 'WARNING';
    details?: string;
    quota_before?: number;
    quota_after?: number;
    reason?: string;
    teacher_id?: string;
    teacher_name?: string;
    student_id?: string;
    student_name?: string;
    nisn?: string;
    old_value?: string;
    new_value?: string;
    tenant_name?: string;
    principal_name?: string;
  }): Promise<AuthAuditLog> {
    const logEntry: AuthAuditLog = {
      id: `audit-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
      timestamp: new Date().toISOString(),
      event: params.event,
      email: params.email,
      user_id: params.user_id,
      role: params.role,
      tenant_id: params.tenant_id,
      tenant_name: params.tenant_name,
      ip_address: '127.0.0.1 (Client Gateway)',
      user_agent: typeof navigator !== 'undefined' ? navigator.userAgent : 'SCOLA-Client/1.0',
      status: params.status,
      details: params.details,
      quota_before: params.quota_before,
      quota_after: params.quota_after,
      reason: params.reason,
      teacher_id: params.teacher_id,
      teacher_name: params.teacher_name,
      student_id: params.student_id,
      student_name: params.student_name,
      nisn: params.nisn,
      old_value: params.old_value,
      new_value: params.new_value,
      principal_name: params.principal_name,
    };

    // Prepend to local memory store (capped at 100 entries)
    this.logs = [logEntry, ...this.logs.slice(0, 99)];

    // If live Supabase is configured with an active session, write to audit_logs table
    if (isSupabaseConfigured()) {
      const supabase = getSupabase();
      if (supabase) {
        try {
          await supabase.from('audit_logs').insert([
            {
              event: logEntry.event,
              email: logEntry.email,
              user_id: logEntry.user_id,
              role: logEntry.role,
              tenant_id: logEntry.tenant_id,
              ip_address: logEntry.ip_address,
              user_agent: logEntry.user_agent,
              status: logEntry.status,
              details: logEntry.details,
            },
          ]);
        } catch {
          // Graceful fallback: local memory store preserves audit records
        }
      }
    }

    return logEntry;
  }

  /**
   * Retrieves audit logs respecting tenant boundaries.
   * Master sees all; School Admins only see logs for their tenant.
   */
  getLogs(currentUserTenantId?: string | null, isMaster = false): AuthAuditLog[] {
    if (isMaster) {
      return [...this.logs];
    }
    if (!currentUserTenantId) {
      return [];
    }
    return this.logs.filter((log) => log.tenant_id === currentUserTenantId);
  }

  clearLogs(): void {
    this.logs = [];
  }
}

export const auditService = new AuditService();
