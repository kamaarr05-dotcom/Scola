import { getSupabase, isSupabaseConfigured } from '../config/supabase';
import {
  INITIAL_TENANTS,
  INITIAL_USERS,
  INITIAL_CLASSES,
  INITIAL_STUDENTS,
  INITIAL_SUBJECTS,
  INITIAL_ATTENDANCE,
  INITIAL_GRADES,
  INITIAL_ACADEMIC_TASKS,
} from '../data/mockDatabase';
import { Tenant, UserProfile, SchoolClass, StudentProfile, Subject, DailyAttendance, GradeItem, AcademicTask } from '../types';

class SupabaseSyncService {
  private isInitialized = false;
  private isSeeding = false;
  private syncListeners: (() => void)[] = [];

  /**
   * Subscribe to live updates from Supabase Realtime
   */
  public onSync(callback: () => void) {
    this.syncListeners.push(callback);
    return () => {
      this.syncListeners = this.syncListeners.filter((cb) => cb !== callback);
    };
  }

  private notifySync() {
    this.syncListeners.forEach((cb) => cb());
  }

  /**
   * Checks if Supabase connection is active and initializes/seeds tables if empty.
   */
  async initializeDatabase(): Promise<{ success: boolean; message: string }> {
    if (this.isInitialized) return { success: true, message: 'Already initialized' };
    if (!isSupabaseConfigured()) {
      return { success: false, message: 'Supabase credentials not configured in environment or settings' };
    }

    const supabase = getSupabase();
    if (!supabase) return { success: false, message: 'Supabase client unavailable' };

    try {
      this.isSeeding = true;
      // 1. Check if user_profiles table has any records
      const { data: users, error: usersErr } = await supabase.from('user_profiles').select('id').limit(1);

      if (usersErr) {
        this.isSeeding = false;
        console.warn('Supabase query notice on user_profiles:', usersErr.message);
        return {
          success: false,
          message: `Koneksi tercapai namun tabel belum dibuat di Supabase (${usersErr.message}). Silakan salin & jalankan Skrip SQL di SQL Editor Supabase.`,
        };
      }

      if (users && users.length === 0) {
        console.log('⚡ Initializing Supabase cloud tables with baseline data...');
        // Seed Tenants
        await supabase.from('tenants').upsert(INITIAL_TENANTS, { onConflict: 'id' });

        // Seed Users (including master mdqputra@gmail.com)
        await supabase.from('user_profiles').upsert(
          INITIAL_USERS.map((u) => ({
            id: u.id,
            tenant_id: u.tenant_id,
            email: u.email,
            full_name: u.full_name,
            phone: u.phone,
            role: u.role,
            status: u.status,
            created_at: u.created_at,
            updated_at: u.updated_at,
            assignments: u.assignments || [],
            linked_students: u.linked_students || [],
          })),
          { onConflict: 'id' }
        );

        // Seed Classes
        await supabase.from('classes').upsert(INITIAL_CLASSES, { onConflict: 'id' });

        // Seed Students
        await supabase.from('students').upsert(INITIAL_STUDENTS, { onConflict: 'id' });

        // Seed Subjects
        await supabase.from('subjects').upsert(INITIAL_SUBJECTS, { onConflict: 'id' });

        // Seed Attendance & Grades
        await supabase.from('daily_attendance').upsert(INITIAL_ATTENDANCE, { onConflict: 'id' });
        await supabase.from('grades').upsert(INITIAL_GRADES, { onConflict: 'id' });
        await supabase.from('academic_tasks').upsert(INITIAL_ACADEMIC_TASKS, { onConflict: 'id' });

        console.log('✅ Supabase cloud tables populated successfully with master account mdqputra@gmail.com!');
      }

      // Setup Realtime subscriptions
      this.setupRealtimeListeners(supabase);

      this.isInitialized = true;
      this.isSeeding = false;
      return { success: true, message: 'Supabase synced successfully' };
    } catch (err: any) {
      this.isSeeding = false;
      console.warn('Supabase sync initialization notice:', err?.message || err);
      return { success: false, message: err?.message || 'Error connecting to Supabase' };
    }
  }

  private setupRealtimeListeners(supabase: any) {
    try {
      supabase
        .channel('scola-realtime-sync')
        .on('postgres_changes', { event: '*', schema: 'public' }, () => {
          this.notifySync();
        })
        .subscribe();
    } catch {
      // Ignored if realtime is not supported or restricted
    }
  }

  // ----------------------------------------------------
  // TENANT OPERATIONS
  // ----------------------------------------------------
  async fetchTenants(): Promise<Tenant[] | null> {
    const supabase = getSupabase();
    if (!supabase || !isSupabaseConfigured()) return null;
    const { data, error } = await supabase.from('tenants').select('*').order('created_at', { ascending: true });
    if (error || !data) return null;
    return data as Tenant[];
  }

  async upsertTenant(tenant: Tenant): Promise<boolean> {
    const supabase = getSupabase();
    if (!supabase || !isSupabaseConfigured()) return false;
    const { error } = await supabase.from('tenants').upsert(tenant, { onConflict: 'id' });
    return !error;
  }

  // ----------------------------------------------------
  // USER OPERATIONS
  // ----------------------------------------------------
  async fetchUsers(): Promise<UserProfile[] | null> {
    const supabase = getSupabase();
    if (!supabase || !isSupabaseConfigured()) return null;
    const { data, error } = await supabase.from('user_profiles').select('*');
    if (error || !data) return null;
    return data as UserProfile[];
  }

  async upsertUser(user: UserProfile): Promise<boolean> {
    const supabase = getSupabase();
    if (!supabase || !isSupabaseConfigured()) return false;
    const { error } = await supabase.from('user_profiles').upsert(
      {
        id: user.id,
        tenant_id: user.tenant_id,
        email: user.email,
        full_name: user.full_name,
        phone: user.phone,
        role: user.role,
        status: user.status,
        assignments: user.assignments || [],
        linked_students: user.linked_students || [],
        created_at: user.created_at || new Date().toISOString(),
        updated_at: new Date().toISOString(),
      },
      { onConflict: 'id' }
    );
    return !error;
  }

  // ----------------------------------------------------
  // ACADEMIC OPERATIONS
  // ----------------------------------------------------
  async fetchClasses(tenantId?: string): Promise<SchoolClass[] | null> {
    const supabase = getSupabase();
    if (!supabase || !isSupabaseConfigured()) return null;
    let query = supabase.from('classes').select('*');
    if (tenantId) query = query.eq('tenant_id', tenantId);
    const { data, error } = await query;
    if (error || !data) return null;
    return data as SchoolClass[];
  }

  async upsertClass(item: SchoolClass): Promise<boolean> {
    const supabase = getSupabase();
    if (!supabase || !isSupabaseConfigured()) return false;
    const { error } = await supabase.from('classes').upsert(item, { onConflict: 'id' });
    return !error;
  }

  async fetchStudents(tenantId?: string): Promise<StudentProfile[] | null> {
    const supabase = getSupabase();
    if (!supabase || !isSupabaseConfigured()) return null;
    let query = supabase.from('students').select('*');
    if (tenantId) query = query.eq('tenant_id', tenantId);
    const { data, error } = await query;
    if (error || !data) return null;
    return data as StudentProfile[];
  }

  async upsertStudent(item: StudentProfile): Promise<boolean> {
    const supabase = getSupabase();
    if (!supabase || !isSupabaseConfigured()) return false;
    const { error } = await supabase.from('students').upsert(item, { onConflict: 'id' });
    return !error;
  }

  async fetchAttendance(tenantId?: string, classId?: string, date?: string): Promise<DailyAttendance[] | null> {
    const supabase = getSupabase();
    if (!supabase || !isSupabaseConfigured()) return null;
    let query = supabase.from('daily_attendance').select('*');
    if (tenantId) query = query.eq('tenant_id', tenantId);
    if (classId) query = query.eq('class_id', classId);
    if (date) query = query.eq('date', date);
    const { data, error } = await query;
    if (error || !data) return null;
    return data as DailyAttendance[];
  }

  async upsertAttendance(item: DailyAttendance): Promise<boolean> {
    const supabase = getSupabase();
    if (!supabase || !isSupabaseConfigured()) return false;
    const { error } = await supabase.from('daily_attendance').upsert(item, { onConflict: 'id' });
    return !error;
  }

  async fetchGrades(tenantId?: string, studentId?: string, subjectId?: string): Promise<GradeItem[] | null> {
    const supabase = getSupabase();
    if (!supabase || !isSupabaseConfigured()) return null;
    let query = supabase.from('grades').select('*');
    if (tenantId) query = query.eq('tenant_id', tenantId);
    if (studentId) query = query.eq('student_id', studentId);
    if (subjectId) query = query.eq('subject_id', subjectId);
    const { data, error } = await query;
    if (error || !data) return null;
    return data as GradeItem[];
  }

  async upsertGrade(item: GradeItem): Promise<boolean> {
    const supabase = getSupabase();
    if (!supabase || !isSupabaseConfigured()) return false;
    const { error } = await supabase.from('grades').upsert(item, { onConflict: 'id' });
    return !error;
  }

  async fetchSubjects(tenantId?: string): Promise<Subject[] | null> {
    const supabase = getSupabase();
    if (!supabase || !isSupabaseConfigured()) return null;
    let query = supabase.from('subjects').select('*');
    if (tenantId) query = query.eq('tenant_id', tenantId);
    const { data, error } = await query;
    if (error || !data) return null;
    return data as Subject[];
  }

  async upsertSubject(item: Subject): Promise<boolean> {
    const supabase = getSupabase();
    if (!supabase || !isSupabaseConfigured()) return false;
    const { error } = await supabase.from('subjects').upsert(item, { onConflict: 'id' });
    return !error;
  }

  async fetchTasks(tenantId?: string, classId?: string): Promise<AcademicTask[] | null> {
    const supabase = getSupabase();
    if (!supabase || !isSupabaseConfigured()) return null;
    let query = supabase.from('academic_tasks').select('*');
    if (tenantId) query = query.eq('tenant_id', tenantId);
    if (classId) query = query.eq('class_id', classId);
    const { data, error } = await query;
    if (error || !data) return null;
    return data as AcademicTask[];
  }

  async upsertTask(item: AcademicTask): Promise<boolean> {
    const supabase = getSupabase();
    if (!supabase || !isSupabaseConfigured()) return false;
    const { error } = await supabase.from('academic_tasks').upsert(item, { onConflict: 'id' });
    return !error;
  }
}

export const supabaseSyncService = new SupabaseSyncService();
