/**
 * SCOLA - School Operating System Core Types
 * Pure TypeScript definitions decoupled from UI for cross-platform portability (Web, Android, iOS).
 */

export type PlatformType = 'web' | 'android' | 'ios';
export type SchoolType = 'SMA' | 'SMK';
export type SchoolAccreditation = 'A' | 'B' | 'C' | 'Belum Terakreditasi' | 'BELUM_TERAKREDITASI';
export type UserStatus = 'ACTIVE' | 'INACTIVE' | 'SUSPENDED' | 'PENDING_VERIFICATION';
export type StudentStatus = 'PENDING' | 'ACTIVE' | 'INACTIVE' | 'GRADUATED';

/**
 * SCOLA ROLES (Locked by Master Blueprint)
 * All teachers ALWAYS have role = 'GURU'.
 * Additional functions like Wali Kelas, Waka, etc. are ASSIGNMENTS, not roles.
 */
export type ScolaRole =
  | 'MASTER'
  | 'KEPALA_SEKOLAH'
  | 'GURU'
  | 'SISWA'
  | 'ORANG_TUA'
  | 'TENAGA_KEPENDIDIKAN';

/**
 * SCOLA TEACHER ASSIGNMENTS (Decoupled from Role)
 * A teacher with role = 'GURU' can have 0 to multiple active assignments.
 * All teachers ALWAYS retain role = 'GURU'.
 */
export type TeacherAssignmentType =
  | 'GURU'
  | 'WALI_KELAS'
  | 'WAKA_KURIKULUM'
  | 'WAKA_KESISWAAN'
  | 'WAKA_SARPRAS'
  | 'WAKA_HUMAS' // WAKA_HUMAS/HUBIN
  | 'KAPROG' // SMK only: Kepala Program Keahlian
  | 'BK' // Bimbingan Konseling
  | 'GURU_BK'; // Bimbingan Konseling (alias)

export interface AuthAuditLog {
  id: string;
  timestamp: string;
  event:
    | 'LOGIN_SUCCESS'
    | 'LOGIN_FAILED'
    | 'LOGOUT'
    | 'SESSION_EXPIRED'
    | 'PERMISSION_DENIED'
    | 'STUDENT_SELF_REGISTER'
    | 'STUDENT_PROFILE_UPDATED'
    | 'STUDENT_ACTIVATED'
    | 'STUDENT_DEACTIVATED'
    | 'STUDENT_CLASS_CHANGED'
    | 'STUDENT_STATUS_CHANGED'
    | 'PARENT_ACTIVATED'
    | 'STUDENT_GUARDIAN_LINKED'
    | 'ATTENDANCE_RECORDED'
    | 'GRADE_RECORDED'
    | 'REPORT_CARD_GENERATED'
    | 'REPORT_CARD_PUBLISHED'
    | 'TASK_CREATED'
    | 'TASK_SUBMITTED'
    | 'TASK_GRADED'
    | 'SCHEDULE_CREATED'
    | 'SCHEDULE_DELETED'
    | 'SUBJECT_CREATED'
    | 'ACADEMIC_YEAR_CREATED'
    | 'TEACHER_CREATED'
    | 'PASSWORD_RESET_REQUEST'
    | 'QUOTA_CHANGED'
    | 'TEACHER_ACTIVATED'
    | 'TEACHER_DEACTIVATED'
    | 'TEACHER_ACTIVATION_REJECTED'
    | 'TENANT_CREATED'
    | 'TENANT_UPDATED'
    | 'TENANT_ACTIVATED'
    | 'TENANT_DEACTIVATED'
    | 'KEPALA_SEKOLAH_CREATED'
    | 'SCHOOL_PROFILE_UPDATED'
    | 'ACADEMIC_CONFIG_UPDATED'
    | 'CLASS_CREATED'
    | 'ASSIGNMENT_UPDATED';
  user_id?: string;
  email: string;
  role?: ScolaRole;
  tenant_id?: string | null;
  tenant_name?: string;
  ip_address?: string;
  user_agent?: string;
  status: 'SUCCESS' | 'FAILED' | 'WARNING';
  details?: string;
  quota_before?: number;
  quota_after?: number;
  reason?: string;
  teacher_id?: string;
  teacher_name?: string;
  principal_name?: string;
  student_id?: string;
  student_name?: string;
  nisn?: string;
  old_value?: string;
  new_value?: string;
}

export type AuthAuditEventType = AuthAuditLog['event'];

export interface TeacherAssignment {
  id: string;
  tenant_id: string;
  teacher_id: string;
  teacher_user_id?: string;
  class_name?: string;
  type: TeacherAssignmentType;
  assignment_type?: TeacherAssignmentType;
  class_id?: string; // If WALI_KELAS
  program_id?: string; // If KAPROG (SMK)
  academic_year_id: string;
  active: boolean;
  notes?: string;
  assigned_at: string;
}

/**
 * TENANT (Each School is an isolated tenant)
 */
export interface Tenant {
  id: string;
  npsn: string;
  name: string;
  slug: string;
  type: SchoolType;
  accreditation: SchoolAccreditation;
  province: string;
  city: string;
  address: string;
  phone: string;
  email: string;
  logo_url?: string;
  // School Branding (Hex Color & custom accents)
  brand_color?: string; // e.g. '#1e40af', '#059669', etc.
  // Teacher License & Quota (Managed exclusively by MASTER)
  teacher_quota: number;
  active_teacher_count: number;
  is_active: boolean;
  status?: 'ACTIVE' | 'INACTIVE';
  subscription_tier: 'TRIAL' | 'STANDARD' | 'ENTERPRISE';
  valid_until: string;
  created_at: string;
  updated_at: string;
}

/**
 * USER PROFILE (Mapped to Supabase auth.users)
 */
export interface UserProfile {
  id: string;
  tenant_id: string | null; // NULL for MASTER
  email: string;
  full_name: string;
  phone?: string;
  avatar_url?: string;
  role: ScolaRole;
  status: UserStatus;
  created_at: string;
  updated_at: string;
  // Dynamic fields hydrated on login
  assignments?: TeacherAssignment[];
  linked_students?: StudentSummary[]; // For ORANG_TUA
}

export interface TeacherProfile {
  id: string;
  tenant_id: string;
  user_id: string;
  nip?: string;
  full_name: string;
  gender: 'L' | 'P';
  phone: string;
  email: string;
  subject_specialty: string[];
  employment_type: 'PNS' | 'PPPK' | 'GTY' | 'GTT';
  status: UserStatus;
  join_date: string;
  exit_date?: string;
  created_by: string; // Must be MASTER or KEPALA_SEKOLAH
}

export interface StudentProfile {
  id: string;
  tenant_id: string;
  tenant_name?: string;
  user_id: string;
  nisn: string; // 10 digit unik Dapodik
  nis: string; // Unik dalam sekolah
  full_name: string;
  gender: 'L' | 'P';
  class_id: string;
  class_name?: string;
  school_type?: SchoolType;
  generation_year: number; // e.g. 2024
  status: StudentStatus;
  self_registered: boolean;
  registration_date: string;
  sma_peminatan?: string; // For SMA (e.g. 'MIPA', 'IPS', 'Fase E - MIPA Eksplorasi')
  smk_program_id?: string; // For SMK
  smk_program_name?: string;
  kompetensi_keahlian?: string;
  address?: string;
  phone?: string;
  email?: string;
  parent_name?: string;
  parent_relation?: 'AYAH' | 'IBU' | 'WALI';
  parent_whatsapp?: string;
  created_at?: string;
  updated_at?: string;
}

export interface StudentSummary {
  id: string;
  nisn: string;
  full_name: string;
  class_name: string;
  tenant_name: string;
  school_type: SchoolType;
  tenant_id?: string;
  nis?: string;
  class_id?: string;
}

export interface ParentProfile {
  id: string;
  tenant_id: string;
  user_id: string;
  full_name: string;
  phone: string;
  email: string;
  relation_type: 'AYAH' | 'IBU' | 'WALI';
  activated_by_wali_kelas_id: string; // Business Rule: created/activated by Wali Kelas
  is_verified: boolean;
  created_at: string;
}

export interface ParentStudentRelation {
  id: string;
  tenant_id: string;
  parent_id: string;
  student_id: string;
  created_at: string;
}

export interface StaffProfile {
  id: string;
  tenant_id: string;
  user_id: string;
  nip?: string;
  full_name: string;
  division: 'TATA_USAHA' | 'PERPUSTAKAAN' | 'LABORATORIUM' | 'KEUANGAN_OPS' | 'KEAMANAN';
  phone: string;
  email: string;
  status: UserStatus;
}
