export * from './auth';
export * from './academic';
export * from './license';

export interface DashboardMetric {
  label: string;
  value: string | number;
  change?: string;
  trend?: 'up' | 'down' | 'neutral';
  description?: string;
  badge?: string;
}

export type ViewportMode = 'desktop' | 'tablet' | 'mobile';
