import React from 'react';

interface State {
  hasError: boolean;
  message: string;
}

export class AppErrorBoundary extends React.Component<React.PropsWithChildren, State> {
  state: State = { hasError: false, message: '' };

  static getDerivedStateFromError(error: unknown): State {
    return {
      hasError: true,
      message: error instanceof Error ? error.message : 'Terjadi kesalahan saat memuat SCOLA.',
    };
  }

  componentDidCatch(error: unknown) {
    console.error('[SCOLA] Unhandled render error:', error);
  }

  private reload = () => window.location.reload();

  render() {
    if (!this.state.hasError) return this.props.children;
    return (
      <div className="min-h-screen bg-slate-950 text-slate-100 flex items-center justify-center p-6">
        <div className="w-full max-w-lg rounded-2xl border border-red-500/30 bg-slate-900 p-6 shadow-2xl">
          <h1 className="text-lg font-bold text-white">SCOLA gagal memuat halaman</h1>
          <p className="mt-2 text-sm text-slate-400">
            Aplikasi mengalami kesalahan JavaScript saat dirender. Data akun tidak dihapus.
          </p>
          <pre className="mt-4 max-h-40 overflow-auto rounded-lg bg-slate-950 p-3 text-xs text-red-300 whitespace-pre-wrap">{this.state.message}</pre>
          <button
            type="button"
            onClick={this.reload}
            className="mt-4 rounded-lg bg-blue-600 px-4 py-2 text-sm font-semibold text-white hover:bg-blue-500"
          >
            Muat Ulang SCOLA
          </button>
        </div>
      </div>
    );
  }
}
