import React, { useState, useEffect } from 'react';
import { authService } from './services/authService';
import { UserProfile, ViewportMode } from './types';
import { LoginView } from './components/auth/LoginView';
import { DashboardLayout } from './components/layout/DashboardLayout';

// Views
import { MasterDashboardView } from './components/views/MasterDashboardView';
import { KepalaSekolahView } from './components/views/KepalaSekolahView';
import { GuruDashboardView } from './components/views/GuruDashboardView';
import { SiswaDashboardView } from './components/views/SiswaDashboardView';
import { OrangTuaDashboardView } from './components/views/OrangTuaDashboardView';
import { TenagaKependidikanView } from './components/views/TenagaKependidikanView';
import { SmkSpecificView } from './components/views/SmkSpecificView';
import { SmaSpecificView } from './components/views/SmaSpecificView';
import { WakaDashboardView } from './components/views/WakaDashboardView';
import { BimbinganKonselingView } from './components/views/BimbinganKonselingView';
import { AuditLogsView } from './components/views/AuditLogsView';

export default function App() {
  const [currentUser, setCurrentUser] = useState<UserProfile | null>(null);
  const [currentRoute, setCurrentRoute] = useState<string>('/');
  const [viewportMode, setViewportMode] = useState<ViewportMode>('DESKTOP');
  const [loading, setLoading] = useState(true);
  const [bootError, setBootError] = useState<string | null>(null);

  useEffect(() => {
    // Subscribe to auth session changes. A hard timeout prevents a network/auth
    // problem from leaving the production UI stuck on an indefinite loader.
    let settled = false;
    const timeout = window.setTimeout(() => {
      if (!settled) {
        console.warn('[SCOLA] Auth bootstrap timeout; opening login screen.');
        setBootError('Sesi sebelumnya tidak dapat diverifikasi tepat waktu. Silakan login kembali.');
        setLoading(false);
      }
    }, 10000);

    const unsub = authService.subscribe((user) => {
      settled = true;
      window.clearTimeout(timeout);
      setCurrentUser(user);
      setLoading(false);
    });
    return () => {
      settled = true;
      window.clearTimeout(timeout);
      unsub();
    };
  }, []);

  const handleLogout = async () => {
    await authService.logout();
    setCurrentRoute('/');
  };

  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-slate-950 text-slate-400">
        <div className="flex flex-col items-center gap-3">
          <div className="h-8 w-8 animate-spin rounded-full border-2 border-blue-500 border-t-transparent"></div>
          <span className="text-xs font-semibold">Memuat SCOLA OS...</span>
        </div>
      </div>
    );
  }

  if (!currentUser) {
    return (
      <>
        {bootError && (
          <div className="fixed left-0 right-0 top-0 z-[100] border-b border-amber-500/30 bg-amber-500/10 px-4 py-2 text-center text-xs text-amber-200">
            {bootError}
          </div>
        )}
        <LoginView onLoginSuccess={() => { setBootError(null); setCurrentRoute('/'); }} />
      </>
    );
  }

  // Determine view based on current route and user role.
  // Every portal has an explicit route; module routes are guarded by role/assignment.
  const renderCurrentView = () => {
    const role = currentUser.role;
    const hasAssignment = (type: string) =>
      role === 'GURU' && currentUser.assignments?.some((a) => a.type === type && a.active);

    // Explicit portal routes (the Sidebar uses these canonical paths).
    switch (currentRoute) {
      case '/master':
        return role === 'MASTER' ? <MasterDashboardView currentUser={currentUser} /> : renderDefaultPortal();
      case '/kepsek':
        return role === 'KEPALA_SEKOLAH' ? <KepalaSekolahView currentUser={currentUser} onNavigate={setCurrentRoute} /> : renderDefaultPortal();
      case '/guru':
        return role === 'GURU' ? <GuruDashboardView currentUser={currentUser} /> : renderDefaultPortal();
      case '/siswa':
        return role === 'SISWA' ? <SiswaDashboardView currentUser={currentUser} onNavigate={setCurrentRoute} /> : renderDefaultPortal();
      case '/parent':
        return role === 'ORANG_TUA' ? <OrangTuaDashboardView currentUser={currentUser} /> : renderDefaultPortal();
      case '/tu':
        return role === 'TENAGA_KEPENDIDIKAN' ? <TenagaKependidikanView currentUser={currentUser} /> : renderDefaultPortal();
      case '/dashboard':
      case '/':
        return renderDefaultPortal();

      // MASTER modules
      case '/tenants':
      case '/users':
        return role === 'MASTER' ? <MasterDashboardView currentUser={currentUser} /> : renderDefaultPortal();
      case '/audit':
        return role === 'MASTER' || role === 'KEPALA_SEKOLAH' ? <AuditLogsView currentUser={currentUser} /> : renderDefaultPortal();

      // SCHOOL MANAGEMENT modules
      case '/teachers':
        return role === 'MASTER'
          ? <MasterDashboardView currentUser={currentUser} />
          : role === 'KEPALA_SEKOLAH'
          ? <KepalaSekolahView currentUser={currentUser} onNavigate={setCurrentRoute} />
          : renderDefaultPortal();
      case '/academic':
        return role === 'GURU'
          ? <GuruDashboardView currentUser={currentUser} />
          : role === 'KEPALA_SEKOLAH'
          ? <KepalaSekolahView currentUser={currentUser} onNavigate={setCurrentRoute} />
          : renderDefaultPortal();
      case '/waka':
        return role === 'KEPALA_SEKOLAH' || hasAssignment('WAKA_KURIKULUM') || hasAssignment('WAKA_KESISWAAN') || hasAssignment('WAKA_SARPRAS') || hasAssignment('WAKA_HUMAS')
          ? <WakaDashboardView currentUser={currentUser} />
          : renderDefaultPortal();
      case '/bk':
        return role === 'KEPALA_SEKOLAH' || hasAssignment('BK') || hasAssignment('GURU_BK')
          ? <BimbinganKonselingView currentUser={currentUser} />
          : renderDefaultPortal();
      case '/smk':
        return (role === 'MASTER' || role === 'KEPALA_SEKOLAH' || role === 'SISWA' || (role === 'GURU' && (hasAssignment('KAPROG') || hasAssignment('GURU'))))
          ? <SmkSpecificView currentUser={currentUser} />
          : renderDefaultPortal();
      case '/sma':
        return role === 'MASTER' || role === 'KEPALA_SEKOLAH' || role === 'GURU'
          ? <SmaSpecificView currentUser={currentUser} />
          : renderDefaultPortal();
      case '/student-portal':
        return role === 'SISWA' ? <SiswaDashboardView currentUser={currentUser} onNavigate={setCurrentRoute} /> : renderDefaultPortal();
      case '/parent-portal':
        return role === 'ORANG_TUA' ? <OrangTuaDashboardView currentUser={currentUser} /> : renderDefaultPortal();
      default:
        return renderDefaultPortal();
    }
  };

  function renderDefaultPortal() {
    switch (currentUser.role) {
      case 'MASTER':
        return <MasterDashboardView currentUser={currentUser} />;
      case 'KEPALA_SEKOLAH':
        return <KepalaSekolahView currentUser={currentUser} onNavigate={setCurrentRoute} />;
      case 'GURU':
        return <GuruDashboardView currentUser={currentUser} />;
      case 'SISWA':
        return <SiswaDashboardView currentUser={currentUser} onNavigate={setCurrentRoute} />;
      case 'ORANG_TUA':
        return <OrangTuaDashboardView currentUser={currentUser} />;
      case 'TENAGA_KEPENDIDIKAN':
        return <TenagaKependidikanView currentUser={currentUser} />;
      default:
        return <LoginView onLoginSuccess={() => setCurrentRoute('/')} />;
    }
  }

  return (
    <DashboardLayout
      currentUser={currentUser}
      currentRoute={currentRoute}
      viewportMode={viewportMode}
      onNavigate={setCurrentRoute}
      onViewportChange={setViewportMode}
      onLogout={handleLogout}
    >
      {renderCurrentView()}
    </DashboardLayout>
  );
}
