import React, { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import './index.css';
import { AppErrorBoundary } from './components/common/AppErrorBoundary';

const rootElement = document.getElementById('root');

if (!rootElement) {
  throw new Error('SCOLA root element (#root) tidak ditemukan.');
}

const boot = async () => {
  try {
    const { default: App } = await import('./App.tsx');
    createRoot(rootElement).render(
      <StrictMode>
        <AppErrorBoundary>
          <App />
        </AppErrorBoundary>
      </StrictMode>,
    );
  } catch (error) {
    console.error('[SCOLA] Boot failed:', error);
    const message = error instanceof Error ? error.message : String(error);
    rootElement.innerHTML = `
      <div style="min-height:100vh;background:#020617;color:#e2e8f0;display:flex;align-items:center;justify-content:center;padding:24px;font-family:system-ui,sans-serif">
        <div style="width:100%;max-width:560px;border:1px solid rgba(248,113,113,.35);background:#0f172a;border-radius:18px;padding:24px;box-sizing:border-box">
          <h1 style="margin:0;font-size:20px">SCOLA gagal memulai</h1>
          <p style="color:#94a3b8;line-height:1.6">File JavaScript aplikasi gagal dimuat. Periksa hasil build/deployment dan console browser.</p>
          <pre style="white-space:pre-wrap;overflow:auto;background:#020617;padding:12px;border-radius:10px;color:#fca5a5;font-size:12px">${message.replace(/[&<>"']/g, (c) => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c] || c))}</pre>
          <button onclick="location.reload()" style="margin-top:12px;border:0;border-radius:9px;background:#2563eb;color:white;padding:10px 14px;font-weight:700;cursor:pointer">Muat Ulang</button>
        </div>
      </div>`;
  }
};

void boot();
