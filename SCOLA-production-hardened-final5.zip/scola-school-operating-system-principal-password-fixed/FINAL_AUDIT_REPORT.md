# SCOLA Final Repair & Audit Report — 2026-09-17

## Status
Final 5 source package prepared after repairing findings from Final 4.

## Repairs
- Live class update now loads the target class from Supabase before authorization/update.
- Student class transfer moved to an atomic `scola_move_student_class` SECURITY DEFINER RPC with tenant/role checks, class-capacity validation, class counters, and audit logging.
- Teacher ACTIVE/INACTIVE changes moved to atomic `scola_set_teacher_status` RPC so teacher row, user profile, and license counter commit/rollback together.
- Teacher assignment is treated as source of truth and synchronized to legacy `teachers.assignments` by database trigger.
- Active Wali Kelas uniqueness and active assignment uniqueness indexes added.
- `student_guardians` persistence + tenant/ownership RLS added; Live guardian reads query Supabase instead of browser memory.
- Student staff-write RLS narrowed so GURU requires an active Wali Kelas assignment for the student's class.
- SQL setup modal updated with guardian schema, atomic RPCs, assignment trigger/indexes, and narrowed student policy.
- Waka attendance fallback 98% removed; no-data state is shown instead.

## Verification
- ZIP archive integrity: PASS.
- No `USING (true)` / `WITH CHECK (true)` in source SQL.
- No service-role secret in frontend source; service-role mentions in SQL documentation/function grants are intentional and do not expose a key.
- Basic TypeScript/TSX delimiter balance: PASS.
- Required repair symbols/functions present: PASS.
- Full dependency install/build was not claimed because `node_modules` is absent in the uploaded package and network installation is not reliable in this environment.

## Remaining production prerequisites
- Run all Supabase migrations in order, including `20260919_final_hardening.sql`.
- Configure `SCOLA_ALLOWED_ORIGIN` in each Edge Function deployment to the real production origin.
- Parent account creation itself remains intentionally blocked in Live until a server-side parent provisioning flow with explicit password/temporary-password policy is wired to the UI; the portal now reads persisted guardian relationships rather than local memory.
- Modules without Supabase persistence remain blocked/local-demo as appropriate rather than silently pretending to persist.
