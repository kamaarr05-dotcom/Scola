import { createClient } from 'npm:@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': Deno.env.get('SCOLA_ALLOWED_ORIGIN') || 'http://localhost:5173',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
};

type TeacherAssignment = {
  id: string;
  type: string;
  active: boolean;
  class_id?: string;
  start_date: string;
};

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    if (req.method !== 'POST') {
      return json({ error: 'Method Not Allowed' }, 405);
    }

    const supabaseUrl = Deno.env.get('SUPABASE_URL');
    const serviceRoleKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');
    if (!supabaseUrl || !serviceRoleKey) {
      return json({ error: 'Konfigurasi Supabase server belum lengkap.' }, 500);
    }

    const authHeader = req.headers.get('Authorization');
    if (!authHeader?.startsWith('Bearer ')) {
      return json({ error: 'Sesi login tidak ditemukan.' }, 401);
    }

    const admin = createClient(supabaseUrl, serviceRoleKey, {
      auth: { autoRefreshToken: false, persistSession: false },
    });

    const token = authHeader.replace('Bearer ', '');
    const { data: authUser, error: authError } = await admin.auth.getUser(token);
    if (authError || !authUser.user) {
      return json({ error: 'Sesi login tidak valid atau sudah kedaluwarsa.' }, 401);
    }

    const { data: actor, error: actorError } = await admin
      .from('user_profiles')
      .select('id, tenant_id, email, full_name, role, status')
      .eq('id', authUser.user.id)
      .single();

    if (actorError || !actor) {
      return json({ error: 'Profil pengguna pembuat akun tidak ditemukan.' }, 403);
    }

    if (actor.role !== 'MASTER' && actor.role !== 'KEPALA_SEKOLAH') {
      return json({ error: 'Akses Ditolak: hanya MASTER atau KEPALA_SEKOLAH yang dapat mendaftarkan guru.' }, 403);
    }

    const body = await req.json();
    const tenantId = String(body.tenant_id || '').trim();
    const fullName = String(body.full_name || '').trim();
    const email = String(body.email || '').trim().toLowerCase();
    const password = String(body.password || '');
    const gender = body.gender === 'P' ? 'P' : 'L';
    const employmentType = ['PNS', 'PPPK', 'GTY', 'GTT'].includes(body.employment_type)
      ? body.employment_type
      : 'GTY';
    const specialty = Array.isArray(body.subject_specialty) && body.subject_specialty.length
      ? body.subject_specialty.map((x: unknown) => String(x)).slice(0, 10)
      : ['Umum'];
    const assignments: TeacherAssignment[] = Array.isArray(body.assignments) ? body.assignments : [];

    if (!tenantId || !fullName || !email || !password) {
      return json({ error: 'Nama, sekolah, email, dan password wajib diisi.' }, 400);
    }
    if (password.length < 8) {
      return json({ error: 'Password minimal 8 karakter.' }, 400);
    }
    if (actor.role === 'KEPALA_SEKOLAH' && actor.tenant_id !== tenantId) {
      return json({ error: 'Akses Ditolak: Kepala Sekolah hanya dapat mendaftarkan guru di sekolahnya sendiri.' }, 403);
    }

    const { data: tenant, error: tenantError } = await admin
      .from('tenants')
      .select('id, name, teacher_quota, active_teacher_count, is_active')
      .eq('id', tenantId)
      .single();
    if (tenantError || !tenant) return json({ error: 'Sekolah tidak ditemukan.' }, 404);
    if (!tenant.is_active) return json({ error: `Sekolah "${tenant.name}" sedang nonaktif.` }, 400);

    const { data: slotReserved, error: reserveError } = await admin.rpc('scola_reserve_teacher_slot', { p_tenant_id: tenantId });
    if (reserveError) return json({ error: `Gagal mengunci kuota guru: ${reserveError.message}` }, 500);
    if (!slotReserved) return json({ error: 'Kuota guru telah habis. Silakan hubungi administrator SCOLA untuk menambah lisensi.' }, 409);
    const { data: duplicateProfile } = await admin
      .from('user_profiles')
      .select('id, email')
      .eq('email', email)
      .maybeSingle();
    if (duplicateProfile) { await admin.rpc('scola_release_teacher_slot', { p_tenant_id: tenantId }); return json({ error: `Email ${email} sudah terdaftar di platform.` }, 409);}

    const { data: createdAuth, error: createAuthError } = await admin.auth.admin.createUser({
      email,
      password,
      email_confirm: true,
      user_metadata: {
        full_name: fullName,
        role: 'GURU',
        tenant_id: tenantId,
      },
    });

    if (createAuthError || !createdAuth.user) {
      const message = createAuthError?.message || 'Supabase Auth gagal membuat pengguna.';
      await admin.rpc('scola_release_teacher_slot', { p_tenant_id: tenantId });
      return json({ error: message }, 400);
    }

    const userId = createdAuth.user.id;
    const now = new Date().toISOString();
    const teacherId = `t-${crypto.randomUUID()}`;

    const profile = {
      id: userId,
      tenant_id: tenantId,
      email,
      full_name: fullName,
      phone: body.phone || null,
      role: 'GURU',
      status: 'ACTIVE',
      assignments,
      created_at: now,
      updated_at: now,
    };

    const teacher = {
      id: teacherId,
      tenant_id: tenantId,
      user_id: userId,
      nip: body.nip || null,
      nuptk: body.nuptk || null,
      full_name: fullName,
      gender,
      email,
      phone: body.phone || null,
      status: 'ACTIVE',
      created_by: actor.id,
      subject_specialty: specialty,
      employment_type: employmentType,
      assignments,
      role: 'GURU',
      created_at: now,
      updated_at: now,
    };

    const { error: profileError } = await admin.from('user_profiles').insert(profile);
    if (profileError) {
      await admin.auth.admin.deleteUser(userId);
      await admin.rpc('scola_release_teacher_slot', { p_tenant_id: tenantId });
      return json({ error: `Profil akun gagal disimpan: ${profileError.message}` }, 500);
    }

    const { data: insertedTeacher, error: teacherError } = await admin
      .from('teachers')
      .insert(teacher)
      .select('*')
      .single();

    if (teacherError || !insertedTeacher) {
      await admin.from('user_profiles').delete().eq('id', userId);
      await admin.auth.admin.deleteUser(userId);
      await admin.rpc('scola_release_teacher_slot', { p_tenant_id: tenantId });
      return json({ error: `Data guru gagal disimpan: ${teacherError?.message || 'unknown error'}` }, 500);
    }


    return json({
      success: true,
      teacher: insertedTeacher,
      account: {
        id: userId,
        email,
        status: 'ACTIVE',
        role: 'GURU',
        login_ready: true,
      },
    });
  } catch (error) {
    console.error('provision-teacher-account error:', error);
    return json({ error: error instanceof Error ? error.message : 'Terjadi kesalahan server.' }, 500);
  }
});

function json(payload: unknown, status = 200) {
  return new Response(JSON.stringify(payload), {
    status,
    headers: { ...corsHeaders, 'Content-Type': 'application/json' },
  });
}
