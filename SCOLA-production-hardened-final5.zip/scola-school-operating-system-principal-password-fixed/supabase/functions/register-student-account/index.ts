import { createClient } from 'npm:@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': Deno.env.get('SCOLA_ALLOWED_ORIGIN') || 'http://localhost:5173',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
};

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });
  if (req.method !== 'POST') return json({ error: 'Method Not Allowed' }, 405);

  try {
    const url = Deno.env.get('SUPABASE_URL');
    const serviceRoleKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');
    if (!url || !serviceRoleKey) return json({ error: 'Konfigurasi Supabase server belum lengkap.' }, 500);

    const admin = createClient(url, serviceRoleKey, {
      auth: { autoRefreshToken: false, persistSession: false },
    });
    const body = await req.json();

    const tenantId = String(body.tenant_id || '').trim();
    const classId = String(body.class_id || '').trim();
    const fullName = String(body.full_name || '').trim();
    const email = String(body.email || '').trim().toLowerCase();
    const password = String(body.password || '');
    const nisn = String(body.nisn || '').trim();
    const nis = String(body.nis || '').trim();

    if (!tenantId || !classId || !fullName || !email || !password || !nisn || !nis) {
      return json({ error: 'Sekolah, kelas, nama, email, password, NISN, dan NIS wajib diisi.' }, 400);
    }
    if (password.length < 8) return json({ error: 'Password minimal 8 karakter.' }, 400);
    if (!/^[0-9]{10}$/.test(nisn)) return json({ error: 'NISN wajib tepat 10 digit angka.' }, 400);

    const { data: tenant } = await admin.from('tenants').select('id,name,is_active,type').eq('id', tenantId).single();
    if (!tenant) return json({ error: 'Sekolah tidak ditemukan.' }, 404);
    if (!tenant.is_active) return json({ error: 'Sekolah sedang tidak menerima pendaftaran.' }, 400);

    const { data: targetClass } = await admin
      .from('classes')
      .select('id,name,tenant_id,grade_level,major_or_stream')
      .eq('id', classId).eq('tenant_id', tenantId).single();
    if (!targetClass) return json({ error: 'Kelas/rombel tidak ditemukan pada sekolah tujuan.' }, 404);

    // A class must have an active Wali Kelas before students can register.
    const { data: assignment } = await admin
      .from('teacher_assignments')
      .select('teacher_user_id')
      .eq('tenant_id', tenantId)
      .eq('type', 'WALI_KELAS')
      .eq('class_id', classId)
      .eq('active', true)
      .maybeSingle();
    let wali: any = null;
    if (assignment?.teacher_user_id) {
      const { data: waliProfile } = await admin.from('user_profiles').select('id,full_name').eq('id', assignment.teacher_user_id).eq('role','GURU').eq('status','ACTIVE').single();
      wali = waliProfile;
    }
    if (!wali) return json({ error: 'Kelas yang dipilih belum memiliki Wali Kelas aktif. Pendaftaran belum dapat dilanjutkan.' }, 409);

    const { data: duplicateEmail } = await admin.from('user_profiles').select('id').eq('email', email).maybeSingle();
    if (duplicateEmail) return json({ error: 'Email sudah terdaftar di platform.' }, 409);

    const { data: duplicateNisn } = await admin.from('students').select('id').eq('nisn', nisn).maybeSingle();
    if (duplicateNisn) return json({ error: 'NISN sudah terdaftar.' }, 409);

    const { data: duplicateNis } = await admin.from('students').select('id').eq('tenant_id', tenantId).eq('nis', nis).maybeSingle();
    if (duplicateNis) return json({ error: 'NIS sekolah sudah digunakan.' }, 409);

    const { data: created, error: authError } = await admin.auth.admin.createUser({
      email,
      password,
      email_confirm: true,
      user_metadata: {
        full_name: fullName,
        role: 'SISWA',
        tenant_id: tenantId,
        class_id: classId,
      },
    });
    if (authError || !created.user) return json({ error: authError?.message || 'Gagal membuat akun Auth siswa.' }, 400);

    const userId = created.user.id;
    const now = new Date().toISOString();
    const studentId = crypto.randomUUID();

    const profile = {
      id: userId,
      tenant_id: tenantId,
      email,
      full_name: fullName,
      phone: body.phone || null,
      role: 'SISWA',
      status: 'PENDING_VERIFICATION',
      created_at: now,
      updated_at: now,
    };

    const student = {
      id: studentId,
      tenant_id: tenantId,
      user_id: userId,
      nisn,
      nis,
      full_name: fullName,
      gender: body.gender === 'P' ? 'P' : 'L',
      class_id: classId,
      class_name: targetClass.name,
      school_type: tenant.type,
      grade_level: targetClass.grade_level,
      major_or_stream: targetClass.major_or_stream,
      generation_year: Number(body.generation_year || new Date().getFullYear()),
      status: 'PENDING',
      self_registered: true,
      registration_date: now.slice(0, 10),
      address: body.address || null,
      phone: body.phone || null,
      email,
      parent_name: String(body.parent_name || '').trim(),
      parent_relation: body.parent_relation || 'WALI',
      parent_whatsapp: String(body.parent_whatsapp || '').trim(),
      sma_peminatan: body.sma_peminatan || null,
      smk_program_id: body.smk_program_id || null,
      smk_program_name: body.smk_program_name || null,
      kompetensi_keahlian: body.kompetensi_keahlian || null,
      created_at: now,
      updated_at: now,
    };

    const { error: profileError } = await admin.from('user_profiles').insert(profile);
    if (profileError) {
      await admin.auth.admin.deleteUser(userId);
      return json({ error: `Profil siswa gagal disimpan: ${profileError.message}` }, 500);
    }

    const { data: insertedStudent, error: studentError } = await admin.from('students').insert(student).select('*').single();
    if (studentError || !insertedStudent) {
      await admin.from('user_profiles').delete().eq('id', userId);
      await admin.auth.admin.deleteUser(userId);
      return json({ error: `Data siswa gagal disimpan: ${studentError?.message || 'unknown error'}` }, 500);
    }

    return json({
      success: true,
      message: `Pendaftaran diterima. Menunggu persetujuan Wali Kelas ${targetClass.name}.`,
      student: insertedStudent,
      user: profile,
      wali_kelas: { id: wali.user_id, name: wali.full_name, class_id: classId },
      status: 'PENDING',
    });
  } catch (error) {
    console.error('register-student-account error:', error);
    return json({ error: error instanceof Error ? error.message : 'Terjadi kesalahan server.' }, 500);
  }
});

function json(payload: unknown, status = 200) {
  return new Response(JSON.stringify(payload), {
    status,
    headers: { ...corsHeaders, 'Content-Type': 'application/json' },
  });
}
