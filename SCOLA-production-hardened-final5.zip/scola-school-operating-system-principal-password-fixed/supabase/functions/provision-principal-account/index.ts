import { createClient } from 'npm:@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': Deno.env.get('SCOLA_ALLOWED_ORIGIN') || 'http://localhost:5173',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
};

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });

  try {
    if (req.method !== 'POST') return json({ error: 'Method Not Allowed' }, 405);

    const supabaseUrl = Deno.env.get('SUPABASE_URL');
    const serviceRoleKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');
    if (!supabaseUrl || !serviceRoleKey) {
      return json({ error: 'Konfigurasi Supabase server belum lengkap.' }, 500);
    }

    const authHeader = req.headers.get('Authorization');
    if (!authHeader?.startsWith('Bearer ')) return json({ error: 'Sesi login tidak ditemukan.' }, 401);

    const admin = createClient(supabaseUrl, serviceRoleKey, {
      auth: { autoRefreshToken: false, persistSession: false },
    });

    const token = authHeader.replace('Bearer ', '');
    const { data: authUser, error: authError } = await admin.auth.getUser(token);
    if (authError || !authUser.user) return json({ error: 'Sesi login tidak valid atau sudah kedaluwarsa.' }, 401);

    const { data: actor, error: actorError } = await admin
      .from('user_profiles')
      .select('id, tenant_id, email, full_name, role, status')
      .eq('id', authUser.user.id)
      .single();

    if (actorError || !actor || actor.role !== 'MASTER') {
      return json({ error: 'Akses Ditolak: hanya MASTER yang dapat mendaftarkan Kepala Sekolah.' }, 403);
    }

    const body = await req.json();
    const tenantId = String(body.tenant_id || '').trim();
    const fullName = String(body.full_name || '').trim();
    const email = String(body.email || '').trim().toLowerCase();
    const password = String(body.password || '');
    const phone = body.phone ? String(body.phone).trim() : null;
    const nip = body.nip ? String(body.nip).trim() : null;

    if (!tenantId || !fullName || !email || !password) {
      return json({ error: 'Sekolah, nama lengkap, email, dan password wajib diisi.' }, 400);
    }
    if (password.length < 8) return json({ error: 'Password minimal 8 karakter.' }, 400);

    const { data: tenant, error: tenantError } = await admin
      .from('tenants')
      .select('id, name, is_active')
      .eq('id', tenantId)
      .single();
    if (tenantError || !tenant) return json({ error: 'Sekolah tidak ditemukan.' }, 404);
    if (!tenant.is_active) return json({ error: `Sekolah "${tenant.name}" sedang nonaktif.` }, 400);

    const { data: existingProfile } = await admin
      .from('user_profiles')
      .select('id, email')
      .eq('email', email)
      .maybeSingle();
    if (existingProfile) return json({ error: `Email ${email} sudah terdaftar di platform.` }, 409);

    const { data: existingPrincipal } = await admin
      .from('user_profiles')
      .select('id')
      .eq('tenant_id', tenantId)
      .eq('role', 'KEPALA_SEKOLAH')
      .maybeSingle();
    if (existingPrincipal) return json({ error: 'Sekolah ini sudah memiliki akun Kepala Sekolah.' }, 409);

    const { data: createdAuth, error: createAuthError } = await admin.auth.admin.createUser({
      email,
      password,
      email_confirm: true,
      user_metadata: {
        full_name: fullName,
        role: 'KEPALA_SEKOLAH',
        tenant_id: tenantId,
      },
    });
    if (createAuthError || !createdAuth.user) {
      return json({ error: createAuthError?.message || 'Supabase Auth gagal membuat pengguna.' }, 400);
    }

    const userId = createdAuth.user.id;
    const now = new Date().toISOString();
    const principal = {
      id: userId,
      tenant_id: tenantId,
      email,
      full_name: fullName,
      phone,
      nip,
      role: 'KEPALA_SEKOLAH',
      status: 'ACTIVE',
      created_at: now,
      updated_at: now,
    };

    const { error: profileError } = await admin.from('user_profiles').insert(principal);
    if (profileError) {
      await admin.auth.admin.deleteUser(userId);
      return json({ error: `Profil akun gagal disimpan: ${profileError.message}` }, 500);
    }

    return json({
      success: true,
      principal,
      account: {
        id: userId,
        email,
        status: 'ACTIVE',
        role: 'KEPALA_SEKOLAH',
        login_ready: true,
      },
    });
  } catch (error) {
    console.error('provision-principal-account error:', error);
    return json({ error: error instanceof Error ? error.message : 'Terjadi kesalahan server.' }, 500);
  }
});

function json(payload: unknown, status = 200) {
  return new Response(JSON.stringify(payload), {
    status,
    headers: { ...corsHeaders, 'Content-Type': 'application/json' },
  });
}
