import { createClient } from 'npm:@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': Deno.env.get('SCOLA_ALLOWED_ORIGIN') || 'http://localhost:5173',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
};

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });
  if (req.method !== 'POST') return json({ error: 'Method Not Allowed' }, 405);

  try {
    const url = Deno.env.get('SUPABASE_URL');
    const serviceRoleKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');
    if (!url || !serviceRoleKey) return json({ error: 'Konfigurasi Supabase server belum lengkap.' }, 500);

    const admin = createClient(url, serviceRoleKey, {
      auth: { autoRefreshToken: false, persistSession: false },
    });

    const authHeader = req.headers.get('Authorization');
    if (!authHeader?.startsWith('Bearer ')) return json({ error: 'Sesi login tidak ditemukan.' }, 401);

    const token = authHeader.replace('Bearer ', '');
    const { data: authUser, error: authError } = await admin.auth.getUser(token);
    if (authError || !authUser.user) return json({ error: 'Sesi login tidak valid.' }, 401);

    const { data: actor, error: actorError } = await admin
      .from('user_profiles')
      .select('id,tenant_id,role,status,full_name,email')
      .eq('id', authUser.user.id)
      .single();
    if (actorError || !actor || actor.status !== 'ACTIVE') return json({ error: 'Akun reviewer tidak aktif.' }, 403);

    const body = await req.json();
    const studentId = String(body.student_id || '').trim();
    const decision = String(body.decision || '').toUpperCase();
    const reason = body.reason ? String(body.reason) : null;
    if (!studentId || !['APPROVE', 'REJECT'].includes(decision)) return json({ error: 'Permintaan review tidak valid.' }, 400);

    const { data: student, error: studentError } = await admin.from('students').select('*').eq('id', studentId).single();
    if (studentError || !student) return json({ error: 'Data siswa tidak ditemukan.' }, 404);
    if (actor.role !== 'MASTER' && actor.tenant_id !== String(student.tenant_id)) return json({ error: 'Akses lintas sekolah ditolak.' }, 403);

    if (actor.role === 'GURU') {
      const { data: assignment } = await admin.from('teacher_assignments')
        .select('id')
        .eq('teacher_user_id', actor.id)
        .eq('tenant_id', student.tenant_id)
        .eq('type', 'WALI_KELAS')
        .eq('class_id', student.class_id)
        .eq('active', true)
        .maybeSingle();
      if (!assignment) return json({ error: 'Hanya Wali Kelas dari rombel siswa yang dapat memproses pendaftaran ini.' }, 403);
    } else if (actor.role !== 'MASTER' && actor.role !== 'KEPALA_SEKOLAH') {
      return json({ error: 'Hanya Wali Kelas, Kepala Sekolah, atau Master yang dapat memproses pendaftaran siswa.' }, 403);
    }

    const now = new Date().toISOString();
    const nextStatus = decision === 'APPROVE' ? 'ACTIVE' : 'INACTIVE';

    const { error: studentUpdateError } = await admin.from('students')
      .update({ status: nextStatus, updated_at: now }).eq('id', student.id);
    if (studentUpdateError) return json({ error: studentUpdateError.message }, 500);

    const { error: profileUpdateError } = await admin.from('user_profiles')
      .update({ status: nextStatus, updated_at: now }).eq('id', student.user_id);
    if (profileUpdateError) {
      await admin.from('students').update({ status: student.status, updated_at: now }).eq('id', student.id);
      return json({ error: profileUpdateError.message }, 500);
    }

    // Keep the Auth user present so rejected registrations remain auditable.
    // Login is blocked by the profile status in the application and can be reactivated
    // later by an authorized workflow if the student is admitted.
    return json({
      success: true,
      message: decision === 'APPROVE'
        ? `Akun siswa ${student.full_name} telah aktif.`
        : `Pendaftaran siswa ${student.full_name} ditolak.`,
      status: nextStatus,
      reason,
    });
  } catch (error) {
    console.error('review-student-account error:', error);
    return json({ error: error instanceof Error ? error.message : 'Terjadi kesalahan server.' }, 500);
  }
});

function json(payload: unknown, status = 200) {
  return new Response(JSON.stringify(payload), {
    status,
    headers: { ...corsHeaders, 'Content-Type': 'application/json' },
  });
}
