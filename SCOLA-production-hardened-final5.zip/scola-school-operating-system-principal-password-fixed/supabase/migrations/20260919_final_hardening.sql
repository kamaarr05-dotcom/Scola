-- SCOLA final hardening migration. Safe to run after all prior migrations.
-- Fixes transactional teacher status, assignment consistency, guardian persistence, and student write scope.

-- FINAL TRANSACTIONAL HARDENING
-- Teacher status + license counter must change in one database transaction.
CREATE OR REPLACE FUNCTION public.scola_set_teacher_status(p_teacher_id TEXT, p_new_status TEXT)
RETURNS public.teachers
LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
DECLARE
  me public.user_profiles%ROWTYPE;
  t public.teachers%ROWTYPE;
  out_t public.teachers%ROWTYPE;
BEGIN
  IF p_new_status NOT IN ('ACTIVE','INACTIVE') THEN RAISE EXCEPTION 'Status guru tidak valid'; END IF;
  SELECT * INTO me FROM public.user_profiles WHERE id=auth.uid()::text LIMIT 1;
  SELECT * INTO t FROM public.teachers WHERE id=p_teacher_id FOR UPDATE;
  IF t.id IS NULL THEN RAISE EXCEPTION 'Data guru tidak ditemukan'; END IF;
  IF auth.role() <> 'service_role' AND (me.id IS NULL OR me.status <> 'ACTIVE' OR (me.role <> 'MASTER' AND NOT (me.role='KEPALA_SEKOLAH' AND me.tenant_id=t.tenant_id))) THEN
    RAISE EXCEPTION 'Akses Ditolak';
  END IF;
  IF t.status = p_new_status THEN RETURN t; END IF;

  IF p_new_status='ACTIVE' AND t.status <> 'ACTIVE' THEN
    UPDATE public.tenants
      SET active_teacher_count=active_teacher_count+1, updated_at=now()
      WHERE id=t.tenant_id AND is_active=true AND active_teacher_count < teacher_quota;
    IF NOT FOUND THEN RAISE EXCEPTION 'Kuota guru telah habis'; END IF;
  ELSIF p_new_status='INACTIVE' AND t.status='ACTIVE' THEN
    UPDATE public.tenants SET active_teacher_count=GREATEST(active_teacher_count-1,0), updated_at=now() WHERE id=t.tenant_id;
  END IF;

  UPDATE public.teachers
    SET status=p_new_status,
        exit_date=CASE WHEN p_new_status='INACTIVE' THEN COALESCE(exit_date,CURRENT_DATE) ELSE NULL END,
        updated_at=now()
    WHERE id=t.id
    RETURNING * INTO out_t;

  UPDATE public.user_profiles
    SET status=CASE WHEN p_new_status='ACTIVE' THEN 'ACTIVE' ELSE 'INACTIVE' END, updated_at=now()
    WHERE id=t.user_id;
  IF NOT FOUND THEN RAISE EXCEPTION 'Profil pengguna guru tidak ditemukan'; END IF;

  INSERT INTO public.audit_logs(event,email,user_id,role,tenant_id,status,details,teacher_id,teacher_name)
  VALUES(CASE WHEN p_new_status='ACTIVE' THEN 'TEACHER_ACTIVATED' ELSE 'TEACHER_DEACTIVATED' END,COALESCE(me.email,''),me.id,me.role,t.tenant_id,'SUCCESS',
         format('Status guru %s diubah menjadi %s.',t.full_name,p_new_status),t.id,t.full_name);
  RETURN out_t;
END; $$;
REVOKE ALL ON FUNCTION public.scola_set_teacher_status(TEXT,TEXT) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.scola_set_teacher_status(TEXT,TEXT) TO authenticated, service_role;

-- Teacher assignment is the source of truth. Keep legacy teachers.assignments synchronized by trigger.
CREATE OR REPLACE FUNCTION public.scola_sync_teacher_assignments_json() RETURNS trigger
LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
DECLARE payload jsonb;
BEGIN
  SELECT COALESCE(jsonb_agg(to_jsonb(x) ORDER BY x.assigned_at DESC),'[]'::jsonb)
  INTO payload
  FROM public.teacher_assignments x
  WHERE x.teacher_user_id=COALESCE(NEW.teacher_user_id,OLD.teacher_user_id) AND x.active=true;
  UPDATE public.teachers SET assignments=payload, updated_at=now()
  WHERE user_id=COALESCE(NEW.teacher_user_id,OLD.teacher_user_id);
  RETURN COALESCE(NEW,OLD);
END; $$;
DROP TRIGGER IF EXISTS trg_scola_sync_teacher_assignments ON public.teacher_assignments;
CREATE TRIGGER trg_scola_sync_teacher_assignments
AFTER INSERT OR UPDATE OR DELETE ON public.teacher_assignments
FOR EACH ROW EXECUTE FUNCTION public.scola_sync_teacher_assignments_json();

CREATE UNIQUE INDEX IF NOT EXISTS uq_teacher_active_wali_class
  ON public.teacher_assignments(tenant_id,class_id,academic_year_id)
  WHERE active=true AND type='WALI_KELAS' AND class_id IS NOT NULL;
CREATE UNIQUE INDEX IF NOT EXISTS uq_teacher_active_assignment
  ON public.teacher_assignments(tenant_id,teacher_user_id,type,class_id,program_id,academic_year_id)
  WHERE active=true;

-- Parent/guardian relationship must be persisted in the database, never only in browser memory.
CREATE TABLE IF NOT EXISTS public.student_guardians (
  id TEXT PRIMARY KEY,
  tenant_id TEXT NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  guardian_user_id TEXT NOT NULL REFERENCES public.user_profiles(id) ON DELETE CASCADE,
  guardian_name TEXT NOT NULL,
  guardian_whatsapp TEXT,
  guardian_email TEXT,
  student_id TEXT NOT NULL REFERENCES public.students(id) ON DELETE CASCADE,
  student_name TEXT,
  student_nisn TEXT,
  class_id TEXT REFERENCES public.classes(id) ON DELETE SET NULL,
  class_name TEXT,
  relation_type TEXT NOT NULL CHECK (relation_type IN ('AYAH','IBU','WALI')),
  status TEXT NOT NULL DEFAULT 'ACTIVE' CHECK (status IN ('ACTIVE','INACTIVE')),
  is_primary BOOLEAN NOT NULL DEFAULT false,
  activated_by_wali_kelas_id TEXT,
  activated_by_name TEXT,
  activation_mode TEXT NOT NULL DEFAULT 'SUPABASE_AUTH_INTERNAL_PROVISION',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_student_guardians_guardian ON public.student_guardians(guardian_user_id,status);
CREATE INDEX IF NOT EXISTS idx_student_guardians_student ON public.student_guardians(student_id,status);
ALTER TABLE public.student_guardians ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "SCOLA guardians read" ON public.student_guardians;
CREATE POLICY "SCOLA guardians read" ON public.student_guardians FOR SELECT TO authenticated
USING (
  (SELECT role FROM public.scola_current_profile() LIMIT 1)='MASTER'
  OR (tenant_id=(SELECT tenant_id FROM public.scola_current_profile() LIMIT 1) AND (SELECT role FROM public.scola_current_profile() LIMIT 1) IN ('KEPALA_SEKOLAH','GURU','TENAGA_KEPENDIDIKAN'))
  OR guardian_user_id=auth.uid()::text
  OR EXISTS (SELECT 1 FROM public.students s WHERE s.id=student_guardians.student_id AND s.user_id=auth.uid()::text)
);
-- Relationship writes are server-side only (Edge Function/service role).
DROP POLICY IF EXISTS "SCOLA guardians write" ON public.student_guardians;

-- Tighten student writes: GURU/TU may not edit arbitrary student rows; only admins and Wali Kelas can.
DROP POLICY IF EXISTS "SCOLA students staff write" ON public.students;
CREATE POLICY "SCOLA students staff write" ON public.students FOR UPDATE TO authenticated
USING (
  (SELECT role FROM public.scola_current_profile() LIMIT 1)='MASTER'
  OR ((SELECT role FROM public.scola_current_profile() LIMIT 1)='KEPALA_SEKOLAH' AND tenant_id=(SELECT tenant_id FROM public.scola_current_profile() LIMIT 1))
  OR ((SELECT role FROM public.scola_current_profile() LIMIT 1)='TENAGA_KEPENDIDIKAN' AND tenant_id=(SELECT tenant_id FROM public.scola_current_profile() LIMIT 1))
  OR ((SELECT role FROM public.scola_current_profile() LIMIT 1)='GURU' AND tenant_id=(SELECT tenant_id FROM public.scola_current_profile() LIMIT 1) AND EXISTS (
      SELECT 1 FROM public.teacher_assignments ta WHERE ta.teacher_user_id=auth.uid()::text AND ta.class_id=students.class_id AND ta.type='WALI_KELAS' AND ta.active=true
  ))
)
WITH CHECK (tenant_id=(SELECT tenant_id FROM public.scola_current_profile() LIMIT 1));

-- Fail closed if production CORS has not been configured in the Edge Functions.


-- Atomic student class transfer: updates student + both class counters in one transaction.
CREATE OR REPLACE FUNCTION public.scola_move_student_class(p_student_id TEXT, p_new_class_id TEXT)
RETURNS public.students
LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
DECLARE me public.user_profiles%ROWTYPE; st public.students%ROWTYPE; old_c public.classes%ROWTYPE; new_c public.classes%ROWTYPE; out_st public.students%ROWTYPE;
BEGIN
  SELECT * INTO me FROM public.user_profiles WHERE id=auth.uid()::text LIMIT 1;
  SELECT * INTO st FROM public.students WHERE id=p_student_id FOR UPDATE;
  IF st.id IS NULL THEN RAISE EXCEPTION 'Data siswa tidak ditemukan'; END IF;
  IF me.id IS NULL OR me.status<>'ACTIVE' OR (me.role<>'MASTER' AND NOT(me.role='KEPALA_SEKOLAH' AND me.tenant_id=st.tenant_id)) THEN RAISE EXCEPTION 'Akses Ditolak'; END IF;
  SELECT * INTO new_c FROM public.classes WHERE id=p_new_class_id AND tenant_id=st.tenant_id FOR UPDATE;
  IF new_c.id IS NULL THEN RAISE EXCEPTION 'Kelas tujuan tidak valid'; END IF;
  IF st.class_id=p_new_class_id THEN RETURN st; END IF;
  IF st.class_id IS NOT NULL THEN
    SELECT * INTO old_c FROM public.classes WHERE id=st.class_id AND tenant_id=st.tenant_id FOR UPDATE;
    IF old_c.id IS NOT NULL THEN UPDATE public.classes SET total_students=GREATEST(total_students-1,0),updated_at=now() WHERE id=old_c.id; END IF;
  END IF;
  IF new_c.total_students >= new_c.capacity THEN RAISE EXCEPTION 'Kapasitas kelas tujuan sudah penuh'; END IF;
  UPDATE public.classes SET total_students=total_students+1,updated_at=now() WHERE id=new_c.id;
  UPDATE public.students SET class_id=new_c.id,class_name=new_c.name,updated_at=now() WHERE id=st.id RETURNING * INTO out_st;
  INSERT INTO public.audit_logs(event,email,user_id,role,tenant_id,status,details,student_id,student_name,nisn,old_value,new_value)
  VALUES('STUDENT_CLASS_CHANGED',COALESCE(me.email,''),me.id,me.role,st.tenant_id,'SUCCESS',format('Siswa %s dipindahkan ke %s.',st.full_name,new_c.name),st.id,st.full_name,st.nisn,st.class_name,new_c.name);
  RETURN out_st;
END; $$;
REVOKE ALL ON FUNCTION public.scola_move_student_class(TEXT,TEXT) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.scola_move_student_class(TEXT,TEXT) TO authenticated, service_role;
