-- SCOLA production hardening migration
-- Safe to re-run. Does not seed demo data.

ALTER TABLE public.students ADD COLUMN IF NOT EXISTS updated_at TIMESTAMPTZ DEFAULT now();
ALTER TABLE public.classes ADD COLUMN IF NOT EXISTS updated_at TIMESTAMPTZ DEFAULT now();
ALTER TABLE public.teachers ADD COLUMN IF NOT EXISTS updated_at TIMESTAMPTZ DEFAULT now();
ALTER TABLE public.tenants ADD COLUMN IF NOT EXISTS updated_at TIMESTAMPTZ DEFAULT now();

CREATE INDEX IF NOT EXISTS idx_user_profiles_tenant ON public.user_profiles(tenant_id);
CREATE INDEX IF NOT EXISTS idx_teachers_tenant_status ON public.teachers(tenant_id,status);
CREATE INDEX IF NOT EXISTS idx_classes_tenant ON public.classes(tenant_id);
CREATE INDEX IF NOT EXISTS idx_students_tenant_class ON public.students(tenant_id,class_id);
CREATE INDEX IF NOT EXISTS idx_students_tenant_status ON public.students(tenant_id,status);
CREATE INDEX IF NOT EXISTS idx_attendance_tenant_date ON public.daily_attendance(tenant_id,date);
CREATE INDEX IF NOT EXISTS idx_grades_tenant_student ON public.grades(tenant_id,student_id);
CREATE INDEX IF NOT EXISTS idx_audit_tenant_timestamp ON public.audit_logs(tenant_id,timestamp DESC);

ALTER TABLE public.tenants ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.teachers ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.classes ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.students ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.daily_attendance ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.grades ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.audit_logs ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "SCOLA audit insert" ON public.audit_logs;
DROP POLICY IF EXISTS "SCOLA audit read" ON public.audit_logs;
CREATE POLICY "SCOLA audit read" ON public.audit_logs FOR SELECT TO authenticated
USING ((SELECT role FROM public.scola_current_profile() LIMIT 1)='MASTER' OR tenant_id=(SELECT tenant_id FROM public.scola_current_profile() LIMIT 1));
-- Audit writes are reserved for trusted server-side code.

CREATE OR REPLACE FUNCTION public.scola_touch_updated_at() RETURNS trigger
LANGUAGE plpgsql SET search_path=public AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END; $$;
DROP TRIGGER IF EXISTS trg_scola_students_updated_at ON public.students;
CREATE TRIGGER trg_scola_students_updated_at BEFORE UPDATE ON public.students FOR EACH ROW EXECUTE FUNCTION public.scola_touch_updated_at();
DROP TRIGGER IF EXISTS trg_scola_classes_updated_at ON public.classes;
CREATE TRIGGER trg_scola_classes_updated_at BEFORE UPDATE ON public.classes FOR EACH ROW EXECUTE FUNCTION public.scola_touch_updated_at();

CREATE OR REPLACE FUNCTION public.scola_record_audit(
  p_event TEXT, p_status TEXT, p_details TEXT DEFAULT NULL, p_email TEXT DEFAULT NULL, p_tenant_id TEXT DEFAULT NULL, p_role TEXT DEFAULT NULL
) RETURNS UUID
LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
DECLARE me public.user_profiles%ROWTYPE; audit_id UUID;
BEGIN
  SELECT * INTO me FROM public.user_profiles WHERE id=auth.uid()::text LIMIT 1;
  IF me.id IS NULL OR me.status <> 'ACTIVE' THEN RAISE EXCEPTION 'Akun audit tidak aktif'; END IF;
  INSERT INTO public.audit_logs(event,email,user_id,role,tenant_id,status,details)
  VALUES (p_event, COALESCE(me.email,p_email,''), me.id, me.role, me.tenant_id, p_status, p_details)
  RETURNING id INTO audit_id;
  RETURN audit_id;
END; $$;
REVOKE ALL ON FUNCTION public.scola_record_audit(TEXT,TEXT,TEXT,TEXT,TEXT,TEXT) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.scola_record_audit(TEXT,TEXT,TEXT,TEXT,TEXT,TEXT) TO authenticated;

CREATE OR REPLACE FUNCTION public.scola_reserve_teacher_slot(p_tenant_id TEXT) RETURNS BOOLEAN
LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
DECLARE ok BOOLEAN; me public.user_profiles%ROWTYPE;
BEGIN
  SELECT * INTO me FROM public.user_profiles WHERE id=auth.uid()::text LIMIT 1;
  IF auth.role() <> 'service_role' AND (me.id IS NULL OR (me.role <> 'MASTER' AND NOT (me.role='KEPALA_SEKOLAH' AND me.tenant_id=p_tenant_id))) THEN
    RAISE EXCEPTION 'Akses Ditolak';
  END IF;
  UPDATE public.tenants SET active_teacher_count=active_teacher_count+1, updated_at=now()
  WHERE id=p_tenant_id AND is_active=true AND active_teacher_count < teacher_quota
  RETURNING true INTO ok;
  RETURN COALESCE(ok,false);
END; $$;
REVOKE ALL ON FUNCTION public.scola_reserve_teacher_slot(TEXT) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.scola_reserve_teacher_slot(TEXT) TO authenticated, service_role;

CREATE OR REPLACE FUNCTION public.scola_release_teacher_slot(p_tenant_id TEXT) RETURNS VOID
LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
DECLARE me public.user_profiles%ROWTYPE;
BEGIN
  SELECT * INTO me FROM public.user_profiles WHERE id=auth.uid()::text LIMIT 1;
  IF auth.role() <> 'service_role' AND (me.id IS NULL OR (me.role <> 'MASTER' AND NOT (me.role='KEPALA_SEKOLAH' AND me.tenant_id=p_tenant_id))) THEN
    RAISE EXCEPTION 'Akses Ditolak';
  END IF;
  UPDATE public.tenants SET active_teacher_count=GREATEST(active_teacher_count-1,0),updated_at=now() WHERE id=p_tenant_id;
END; $$;
REVOKE ALL ON FUNCTION public.scola_release_teacher_slot(TEXT) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.scola_release_teacher_slot(TEXT) TO authenticated, service_role;


-- Operational configuration: academic years and teacher assignments
CREATE TABLE IF NOT EXISTS public.academic_years (
  id TEXT PRIMARY KEY,
  tenant_id TEXT NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  name VARCHAR(20) NOT NULL,
  semester VARCHAR(10) NOT NULL CHECK (semester IN ('GANJIL','GENAP')),
  is_active BOOLEAN NOT NULL DEFAULT false,
  start_date DATE NOT NULL,
  end_date DATE NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, name, semester)
);
CREATE INDEX IF NOT EXISTS idx_academic_years_tenant ON public.academic_years(tenant_id, start_date DESC);
CREATE UNIQUE INDEX IF NOT EXISTS uq_academic_year_active_tenant ON public.academic_years(tenant_id) WHERE is_active;
ALTER TABLE public.academic_years ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "SCOLA academic years read" ON public.academic_years;
DROP POLICY IF EXISTS "SCOLA academic years write" ON public.academic_years;
CREATE POLICY "SCOLA academic years read" ON public.academic_years FOR SELECT TO authenticated
USING ((SELECT role FROM public.scola_current_profile() LIMIT 1)='MASTER' OR tenant_id=(SELECT tenant_id FROM public.scola_current_profile() LIMIT 1));
CREATE POLICY "SCOLA academic years write" ON public.academic_years FOR ALL TO authenticated
USING ((SELECT role FROM public.scola_current_profile() LIMIT 1)='MASTER' OR ((SELECT role FROM public.scola_current_profile() LIMIT 1)='KEPALA_SEKOLAH' AND tenant_id=(SELECT tenant_id FROM public.scola_current_profile() LIMIT 1)))
WITH CHECK ((SELECT role FROM public.scola_current_profile() LIMIT 1)='MASTER' OR ((SELECT role FROM public.scola_current_profile() LIMIT 1)='KEPALA_SEKOLAH' AND tenant_id=(SELECT tenant_id FROM public.scola_current_profile() LIMIT 1)));

DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE schemaname='public' AND indexname='uq_students_tenant_nis') THEN
    CREATE UNIQUE INDEX uq_students_tenant_nis ON public.students(tenant_id, nis) WHERE nis IS NOT NULL;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE schemaname='public' AND indexname='uq_students_tenant_nisn') THEN
    CREATE UNIQUE INDEX uq_students_tenant_nisn ON public.students(tenant_id, nisn) WHERE nisn IS NOT NULL;
  END IF;
END $$;

CREATE TABLE IF NOT EXISTS public.teacher_assignments (
  id TEXT PRIMARY KEY, tenant_id TEXT NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  teacher_id TEXT NOT NULL REFERENCES public.user_profiles(id) ON DELETE CASCADE,
  teacher_user_id TEXT NOT NULL REFERENCES public.user_profiles(id) ON DELETE CASCADE,
  type VARCHAR(50) NOT NULL, assignment_type VARCHAR(50), class_id TEXT REFERENCES public.classes(id) ON DELETE SET NULL,
  program_id TEXT, academic_year_id TEXT NOT NULL REFERENCES public.academic_years(id) ON DELETE RESTRICT,
  active BOOLEAN NOT NULL DEFAULT true, notes TEXT, assigned_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_teacher_assignments_tenant ON public.teacher_assignments(tenant_id,active);
CREATE INDEX IF NOT EXISTS idx_teacher_assignments_teacher ON public.teacher_assignments(teacher_user_id,active);
ALTER TABLE public.teacher_assignments ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "SCOLA assignments read" ON public.teacher_assignments;
DROP POLICY IF EXISTS "SCOLA assignments write" ON public.teacher_assignments;
CREATE POLICY "SCOLA assignments read" ON public.teacher_assignments FOR SELECT TO authenticated USING ((SELECT role FROM public.scola_current_profile() LIMIT 1)='MASTER' OR tenant_id=(SELECT tenant_id FROM public.scola_current_profile() LIMIT 1));
CREATE POLICY "SCOLA assignments write" ON public.teacher_assignments FOR ALL TO authenticated USING ((SELECT role FROM public.scola_current_profile() LIMIT 1)='MASTER' OR (SELECT role FROM public.scola_current_profile() LIMIT 1)='KEPALA_SEKOLAH' AND tenant_id=(SELECT tenant_id FROM public.scola_current_profile() LIMIT 1)) WITH CHECK ((SELECT role FROM public.scola_current_profile() LIMIT 1)='MASTER' OR (SELECT role FROM public.scola_current_profile() LIMIT 1)='KEPALA_SEKOLAH' AND tenant_id=(SELECT tenant_id FROM public.scola_current_profile() LIMIT 1));


-- FINAL TRANSACTIONAL HARDENING
-- Teacher status + license counter must change in one database transaction.
CREATE OR REPLACE FUNCTION public.scola_set_teacher_status(p_teacher_id TEXT, p_new_status TEXT)
RETURNS public.teachers
LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
DECLARE
  me public.user_profiles%ROWTYPE;
  t public.teachers%ROWTYPE;
  out_t public.teachers%ROWTYPE;
  changed BOOLEAN := false;
BEGIN
  IF p_new_status NOT IN ('ACTIVE','INACTIVE') THEN RAISE EXCEPTION 'Status guru tidak valid'; END IF;
  SELECT * INTO me FROM public.user_profiles WHERE id=auth.uid()::text LIMIT 1;
  SELECT * INTO t FROM public.teachers WHERE id=p_teacher_id FOR UPDATE;
  IF t.id IS NULL THEN RAISE EXCEPTION 'Data guru tidak ditemukan'; END IF;
  IF auth.role() <> 'service_role' AND (me.id IS NULL OR me.status <> 'ACTIVE' OR (me.role <> 'MASTER' AND NOT (me.role='KEPALA_SEKOLAH' AND me.tenant_id=t.tenant_id))) THEN
    RAISE EXCEPTION 'Akses Ditolak';
  END IF;
  IF t.status = p_new_status THEN RETURN t; END IF;

  IF p_new_status='ACTIVE' AND t.status <> 'ACTIVE' THEN
    UPDATE public.tenants
      SET active_teacher_count=active_teacher_count+1, updated_at=now()
      WHERE id=t.tenant_id AND is_active=true AND active_teacher_count < teacher_quota;
    IF NOT FOUND THEN RAISE EXCEPTION 'Kuota guru telah habis'; END IF;
    changed := true;
  ELSIF p_new_status='INACTIVE' AND t.status='ACTIVE' THEN
    UPDATE public.tenants SET active_teacher_count=GREATEST(active_teacher_count-1,0), updated_at=now() WHERE id=t.tenant_id;
    changed := true;
  END IF;

  UPDATE public.teachers
    SET status=p_new_status,
        exit_date=CASE WHEN p_new_status='INACTIVE' THEN COALESCE(exit_date,CURRENT_DATE) ELSE NULL END,
        updated_at=now()
    WHERE id=t.id
    RETURNING * INTO out_t;

  UPDATE public.user_profiles
    SET status=CASE WHEN p_new_status='ACTIVE' THEN 'ACTIVE' ELSE 'INACTIVE' END, updated_at=now()
    WHERE id=t.user_id;
  IF NOT FOUND THEN RAISE EXCEPTION 'Profil pengguna guru tidak ditemukan'; END IF;

  INSERT INTO public.audit_logs(event,email,user_id,role,tenant_id,status,details,teacher_id,teacher_name)
  VALUES('TEACHER_STATUS_UPDATED',COALESCE(me.email,''),me.id,me.role,t.tenant_id,'SUCCESS',
         format('Status guru %s diubah menjadi %s.',t.full_name,p_new_status),t.id,t.full_name);
  RETURN out_t;
END; $$;
REVOKE ALL ON FUNCTION public.scola_set_teacher_status(TEXT,TEXT) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.scola_set_teacher_status(TEXT,TEXT) TO authenticated, service_role;

-- Teacher assignment is the source of truth. Keep legacy teachers.assignments synchronized by trigger.
CREATE OR REPLACE FUNCTION public.scola_sync_teacher_assignments_json() RETURNS trigger
LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
DECLARE payload jsonb;
BEGIN
  SELECT COALESCE(jsonb_agg(to_jsonb(x) ORDER BY x.assigned_at DESC),'[]'::jsonb)
  INTO payload
  FROM public.teacher_assignments x
  WHERE x.teacher_user_id=COALESCE(NEW.teacher_user_id,OLD.teacher_user_id) AND x.active=true;
  UPDATE public.teachers SET assignments=payload, updated_at=now()
  WHERE user_id=COALESCE(NEW.teacher_user_id,OLD.teacher_user_id);
  RETURN COALESCE(NEW,OLD);
END; $$;
DROP TRIGGER IF EXISTS trg_scola_sync_teacher_assignments ON public.teacher_assignments;
CREATE TRIGGER trg_scola_sync_teacher_assignments
AFTER INSERT OR UPDATE OR DELETE ON public.teacher_assignments
FOR EACH ROW EXECUTE FUNCTION public.scola_sync_teacher_assignments_json();

CREATE UNIQUE INDEX IF NOT EXISTS uq_teacher_active_wali_class
  ON public.teacher_assignments(tenant_id,class_id,academic_year_id)
  WHERE active=true AND type='WALI_KELAS' AND class_id IS NOT NULL;
CREATE UNIQUE INDEX IF NOT EXISTS uq_teacher_active_assignment
  ON public.teacher_assignments(tenant_id,teacher_user_id,type,class_id,program_id,academic_year_id)
  WHERE active=true;

-- Parent/guardian relationship must be persisted in the database, never only in browser memory.
CREATE TABLE IF NOT EXISTS public.student_guardians (
  id TEXT PRIMARY KEY,
  tenant_id TEXT NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  guardian_user_id TEXT NOT NULL REFERENCES public.user_profiles(id) ON DELETE CASCADE,
  guardian_name TEXT NOT NULL,
  guardian_whatsapp TEXT,
  guardian_email TEXT,
  student_id TEXT NOT NULL REFERENCES public.students(id) ON DELETE CASCADE,
  student_name TEXT,
  student_nisn TEXT,
  class_id TEXT REFERENCES public.classes(id) ON DELETE SET NULL,
  class_name TEXT,
  relation_type TEXT NOT NULL CHECK (relation_type IN ('AYAH','IBU','WALI')),
  status TEXT NOT NULL DEFAULT 'ACTIVE' CHECK (status IN ('ACTIVE','INACTIVE')),
  is_primary BOOLEAN NOT NULL DEFAULT false,
  activated_by_wali_kelas_id TEXT,
  activated_by_name TEXT,
  activation_mode TEXT NOT NULL DEFAULT 'SUPABASE_AUTH_INTERNAL_PROVISION',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_student_guardians_guardian ON public.student_guardians(guardian_user_id,status);
CREATE INDEX IF NOT EXISTS idx_student_guardians_student ON public.student_guardians(student_id,status);
ALTER TABLE public.student_guardians ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "SCOLA guardians read" ON public.student_guardians;
CREATE POLICY "SCOLA guardians read" ON public.student_guardians FOR SELECT TO authenticated
USING (
  (SELECT role FROM public.scola_current_profile() LIMIT 1)='MASTER'
  OR (tenant_id=(SELECT tenant_id FROM public.scola_current_profile() LIMIT 1) AND (SELECT role FROM public.scola_current_profile() LIMIT 1) IN ('KEPALA_SEKOLAH','GURU','TENAGA_KEPENDIDIKAN'))
  OR guardian_user_id=auth.uid()::text
  OR EXISTS (SELECT 1 FROM public.students s WHERE s.id=student_guardians.student_id AND s.user_id=auth.uid()::text)
);
-- Relationship writes are server-side only (Edge Function/service role).
DROP POLICY IF EXISTS "SCOLA guardians write" ON public.student_guardians;

-- Tighten student writes: GURU/TU may not edit arbitrary student rows; only admins and Wali Kelas can.
DROP POLICY IF EXISTS "SCOLA students staff write" ON public.students;
CREATE POLICY "SCOLA students staff write" ON public.students FOR UPDATE TO authenticated
USING (
  (SELECT role FROM public.scola_current_profile() LIMIT 1)='MASTER'
  OR ((SELECT role FROM public.scola_current_profile() LIMIT 1)='KEPALA_SEKOLAH' AND tenant_id=(SELECT tenant_id FROM public.scola_current_profile() LIMIT 1))
  OR ((SELECT role FROM public.scola_current_profile() LIMIT 1)='TENAGA_KEPENDIDIKAN' AND tenant_id=(SELECT tenant_id FROM public.scola_current_profile() LIMIT 1))
  OR ((SELECT role FROM public.scola_current_profile() LIMIT 1)='GURU' AND tenant_id=(SELECT tenant_id FROM public.scola_current_profile() LIMIT 1) AND EXISTS (
      SELECT 1 FROM public.teacher_assignments ta WHERE ta.teacher_user_id=auth.uid()::text AND ta.class_id=students.class_id AND ta.type='WALI_KELAS' AND ta.active=true
  ))
)
WITH CHECK (tenant_id=(SELECT tenant_id FROM public.scola_current_profile() LIMIT 1));

-- Fail closed if production CORS has not been configured in the Edge Functions.
