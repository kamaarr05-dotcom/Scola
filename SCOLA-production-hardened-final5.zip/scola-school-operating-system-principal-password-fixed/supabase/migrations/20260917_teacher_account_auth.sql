-- SCOLA: fields required by the Teacher Account provisioning Edge Function.
-- Safe to run on an existing project.

ALTER TABLE public.teachers
  ADD COLUMN IF NOT EXISTS subject_specialty JSONB DEFAULT '["Umum"]'::jsonb,
  ADD COLUMN IF NOT EXISTS employment_type VARCHAR(20) DEFAULT 'GTY',
  ADD COLUMN IF NOT EXISTS assignments JSONB DEFAULT '[]'::jsonb,
  ADD COLUMN IF NOT EXISTS role VARCHAR(30) DEFAULT 'GURU';

-- Keep legacy rows usable by the dashboard.
UPDATE public.teachers
SET
  subject_specialty = COALESCE(subject_specialty, '["Umum"]'::jsonb),
  employment_type = COALESCE(employment_type, 'GTY'),
  assignments = COALESCE(assignments, '[]'::jsonb),
  role = COALESCE(role, 'GURU')
WHERE subject_specialty IS NULL
   OR employment_type IS NULL
   OR assignments IS NULL
   OR role IS NULL;
