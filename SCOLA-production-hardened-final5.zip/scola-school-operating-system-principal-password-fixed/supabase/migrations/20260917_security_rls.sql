-- SCOLA production security hardening. user_profiles.id is TEXT and mirrors auth.users.id.

create or replace function public.scola_current_profile()
returns table (id text, tenant_id text, role text, status text)
language sql security definer stable set search_path = public
as $$ select id, tenant_id, role, status from public.user_profiles where id = auth.uid()::text limit 1; $$;
revoke all on function public.scola_current_profile() from public; grant execute on function public.scola_current_profile() to authenticated;

DO $$ DECLARE t text; BEGIN FOREACH t IN ARRAY ARRAY['tenants','user_profiles','teachers','classes','students','daily_attendance','grades','audit_logs'] LOOP IF to_regclass('public.'||t) IS NOT NULL THEN EXECUTE format('ALTER TABLE public.%I ENABLE ROW LEVEL SECURITY',t); END IF; END LOOP; END $$;

DO $$ DECLARE p record; BEGIN FOR p IN SELECT policyname,tablename FROM pg_policies WHERE schemaname='public' AND (policyname ILIKE '%Public Read%' OR policyname ILIKE '%Insert %' OR policyname ILIKE '%Update %') LOOP EXECUTE format('DROP POLICY IF EXISTS %I ON public.%I',p.policyname,p.tablename); END LOOP; END $$;

CREATE POLICY "SCOLA tenants read" ON public.tenants FOR SELECT TO authenticated USING (id=(SELECT tenant_id FROM public.scola_current_profile() LIMIT 1) OR (SELECT role FROM public.scola_current_profile() LIMIT 1)='MASTER');
CREATE POLICY "SCOLA profiles read" ON public.user_profiles FOR SELECT TO authenticated USING (id=auth.uid()::text OR (SELECT role FROM public.scola_current_profile() LIMIT 1)='MASTER' OR tenant_id=(SELECT tenant_id FROM public.scola_current_profile() LIMIT 1));
CREATE POLICY "SCOLA profiles self update" ON public.user_profiles FOR UPDATE TO authenticated USING (id=auth.uid()::text) WITH CHECK (id=auth.uid()::text);

-- Prevent a normal user from changing authorization/tenant fields in their own profile.
CREATE OR REPLACE FUNCTION public.scola_protect_profile_self_update() RETURNS trigger
LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
BEGIN
  IF auth.uid() IS NOT NULL AND auth.uid()::text = OLD.id THEN
    NEW.id := OLD.id; NEW.tenant_id := OLD.tenant_id; NEW.role := OLD.role; NEW.status := OLD.status; NEW.email := OLD.email;
    NEW.assignments := OLD.assignments; NEW.linked_students := OLD.linked_students;
  END IF;
  RETURN NEW;
END; $$;
DROP TRIGGER IF EXISTS trg_scola_protect_profile_self_update ON public.user_profiles;
CREATE TRIGGER trg_scola_protect_profile_self_update BEFORE UPDATE ON public.user_profiles FOR EACH ROW EXECUTE FUNCTION public.scola_protect_profile_self_update();
CREATE POLICY "SCOLA teachers read" ON public.teachers FOR SELECT TO authenticated USING (user_id=auth.uid()::text OR tenant_id=(SELECT tenant_id FROM public.scola_current_profile() LIMIT 1) OR (SELECT role FROM public.scola_current_profile() LIMIT 1)='MASTER');
CREATE POLICY "SCOLA teachers admin write" ON public.teachers FOR ALL TO authenticated USING ((SELECT role FROM public.scola_current_profile() LIMIT 1)='MASTER' OR (tenant_id=(SELECT tenant_id FROM public.scola_current_profile() LIMIT 1) AND (SELECT role FROM public.scola_current_profile() LIMIT 1)='KEPALA_SEKOLAH')) WITH CHECK (tenant_id=(SELECT tenant_id FROM public.scola_current_profile() LIMIT 1) OR (SELECT role FROM public.scola_current_profile() LIMIT 1)='MASTER');
CREATE POLICY "SCOLA classes read" ON public.classes FOR SELECT TO authenticated USING (tenant_id=(SELECT tenant_id FROM public.scola_current_profile() LIMIT 1) OR (SELECT role FROM public.scola_current_profile() LIMIT 1)='MASTER');
CREATE POLICY "SCOLA classes admin write" ON public.classes FOR ALL TO authenticated USING ((SELECT role FROM public.scola_current_profile() LIMIT 1)='MASTER' OR (tenant_id=(SELECT tenant_id FROM public.scola_current_profile() LIMIT 1) AND (SELECT role FROM public.scola_current_profile() LIMIT 1)='KEPALA_SEKOLAH')) WITH CHECK (tenant_id=(SELECT tenant_id FROM public.scola_current_profile() LIMIT 1) OR (SELECT role FROM public.scola_current_profile() LIMIT 1)='MASTER');
CREATE POLICY "SCOLA students read" ON public.students FOR SELECT TO authenticated USING (user_id=auth.uid()::text OR tenant_id=(SELECT tenant_id FROM public.scola_current_profile() LIMIT 1) OR (SELECT role FROM public.scola_current_profile() LIMIT 1)='MASTER');
CREATE POLICY "SCOLA students self update" ON public.students FOR UPDATE TO authenticated USING (user_id=auth.uid()::text) WITH CHECK (user_id=auth.uid()::text);
CREATE POLICY "SCOLA students staff write" ON public.students FOR UPDATE TO authenticated USING ((SELECT role FROM public.scola_current_profile() LIMIT 1) IN ('MASTER','KEPALA_SEKOLAH','GURU','TENAGA_KEPENDIDIKAN') AND tenant_id=(SELECT tenant_id FROM public.scola_current_profile() LIMIT 1)) WITH CHECK (tenant_id=(SELECT tenant_id FROM public.scola_current_profile() LIMIT 1));

CREATE OR REPLACE FUNCTION public.scola_protect_student_self_update() RETURNS trigger
LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
BEGIN
  IF auth.uid() IS NOT NULL AND OLD.user_id = auth.uid()::text AND (SELECT role FROM public.scola_current_profile() LIMIT 1) = 'SISWA' THEN
    NEW.id := OLD.id; NEW.user_id := OLD.user_id; NEW.tenant_id := OLD.tenant_id; NEW.nisn := OLD.nisn; NEW.nis := OLD.nis; NEW.full_name := OLD.full_name; NEW.gender := OLD.gender; NEW.class_id := OLD.class_id; NEW.class_name := OLD.class_name; NEW.status := OLD.status;
  END IF;
  RETURN NEW;
END; $$;
DROP TRIGGER IF EXISTS trg_scola_protect_student_self_update ON public.students;
CREATE TRIGGER trg_scola_protect_student_self_update BEFORE UPDATE ON public.students FOR EACH ROW EXECUTE FUNCTION public.scola_protect_student_self_update();
CREATE POLICY "SCOLA attendance read" ON public.daily_attendance FOR SELECT TO authenticated USING (tenant_id=(SELECT tenant_id FROM public.scola_current_profile() LIMIT 1) OR (SELECT role FROM public.scola_current_profile() LIMIT 1)='MASTER');
CREATE POLICY "SCOLA attendance write" ON public.daily_attendance FOR ALL TO authenticated USING (tenant_id=(SELECT tenant_id FROM public.scola_current_profile() LIMIT 1) AND (SELECT role FROM public.scola_current_profile() LIMIT 1) IN ('MASTER','KEPALA_SEKOLAH','GURU','TENAGA_KEPENDIDIKAN')) WITH CHECK (tenant_id=(SELECT tenant_id FROM public.scola_current_profile() LIMIT 1) AND (SELECT role FROM public.scola_current_profile() LIMIT 1) IN ('MASTER','KEPALA_SEKOLAH','GURU','TENAGA_KEPENDIDIKAN'));
CREATE POLICY "SCOLA grades read" ON public.grades FOR SELECT TO authenticated USING (tenant_id=(SELECT tenant_id FROM public.scola_current_profile() LIMIT 1) OR (SELECT role FROM public.scola_current_profile() LIMIT 1)='MASTER');
CREATE POLICY "SCOLA grades write" ON public.grades FOR ALL TO authenticated USING (tenant_id=(SELECT tenant_id FROM public.scola_current_profile() LIMIT 1) AND (SELECT role FROM public.scola_current_profile() LIMIT 1) IN ('MASTER','KEPALA_SEKOLAH','GURU')) WITH CHECK (tenant_id=(SELECT tenant_id FROM public.scola_current_profile() LIMIT 1) AND (SELECT role FROM public.scola_current_profile() LIMIT 1) IN ('MASTER','KEPALA_SEKOLAH','GURU'));
-- audit_logs has no client write policy.

-- audit_logs has no client INSERT/UPDATE policy.

CREATE POLICY "SCOLA audit insert" ON public.audit_logs FOR INSERT TO authenticated WITH CHECK (user_id = auth.uid()::text);
CREATE OR REPLACE FUNCTION public.scola_normalize_audit_log() RETURNS trigger
LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
DECLARE me record;
BEGIN
  SELECT * INTO me FROM public.scola_current_profile() LIMIT 1;
  IF me.id IS NULL OR me.status <> 'ACTIVE' THEN RAISE EXCEPTION 'Akun audit tidak aktif'; END IF;
  NEW.user_id := me.id;
  NEW.tenant_id := me.tenant_id;
  NEW.role := me.role;
  NEW.email := (SELECT email FROM public.user_profiles WHERE id=me.id);
  NEW.ip_address := COALESCE(NULLIF(NEW.ip_address,''),'CLIENT');
  NEW.timestamp := COALESCE(NEW.timestamp,NOW());
  RETURN NEW;
END; $$;
DROP TRIGGER IF EXISTS trg_scola_normalize_audit_log ON public.audit_logs;
CREATE TRIGGER trg_scola_normalize_audit_log BEFORE INSERT ON public.audit_logs FOR EACH ROW EXECUTE FUNCTION public.scola_normalize_audit_log();


-- Final role-scoped privacy policies (replaces broad tenant-wide reads for students/parents).
DROP POLICY IF EXISTS "SCOLA profiles read" ON public.user_profiles;
CREATE POLICY "SCOLA profiles read" ON public.user_profiles FOR SELECT TO authenticated
USING (
  id = auth.uid()::text
  OR (SELECT role FROM public.scola_current_profile() LIMIT 1)='MASTER'
  OR ((SELECT role FROM public.scola_current_profile() LIMIT 1) IN ('KEPALA_SEKOLAH','GURU','TENAGA_KEPENDIDIKAN') AND tenant_id=(SELECT tenant_id FROM public.scola_current_profile() LIMIT 1))
);

DROP POLICY IF EXISTS "SCOLA students read" ON public.students;
CREATE POLICY "SCOLA students read" ON public.students FOR SELECT TO authenticated
USING (
  (SELECT role FROM public.scola_current_profile() LIMIT 1)='MASTER'
  OR ((SELECT role FROM public.scola_current_profile() LIMIT 1) IN ('KEPALA_SEKOLAH','GURU','TENAGA_KEPENDIDIKAN') AND tenant_id=(SELECT tenant_id FROM public.scola_current_profile() LIMIT 1))
  OR ((SELECT role FROM public.scola_current_profile() LIMIT 1)='SISWA' AND user_id=auth.uid()::text)
  OR ((SELECT role FROM public.scola_current_profile() LIMIT 1)='ORANG_TUA' AND EXISTS (SELECT 1 FROM public.user_profiles up WHERE up.id=auth.uid()::text AND up.tenant_id=students.tenant_id AND up.linked_students @> jsonb_build_array(jsonb_build_object('id',students.id))))
);

DROP POLICY IF EXISTS "SCOLA attendance read" ON public.daily_attendance;
CREATE POLICY "SCOLA attendance read" ON public.daily_attendance FOR SELECT TO authenticated
USING (
  (SELECT role FROM public.scola_current_profile() LIMIT 1)='MASTER'
  OR ((SELECT role FROM public.scola_current_profile() LIMIT 1) IN ('KEPALA_SEKOLAH','GURU','TENAGA_KEPENDIDIKAN') AND tenant_id=(SELECT tenant_id FROM public.scola_current_profile() LIMIT 1))
  OR ((SELECT role FROM public.scola_current_profile() LIMIT 1)='SISWA' AND EXISTS (SELECT 1 FROM public.students s WHERE s.id=daily_attendance.student_id AND s.user_id=auth.uid()::text))
  OR ((SELECT role FROM public.scola_current_profile() LIMIT 1)='ORANG_TUA' AND EXISTS (SELECT 1 FROM public.students s JOIN public.user_profiles up ON up.id=auth.uid()::text WHERE s.id=daily_attendance.student_id AND up.linked_students @> jsonb_build_array(jsonb_build_object('id',s.id))))
);

DROP POLICY IF EXISTS "SCOLA grades read" ON public.grades;
CREATE POLICY "SCOLA grades read" ON public.grades FOR SELECT TO authenticated
USING (
  (SELECT role FROM public.scola_current_profile() LIMIT 1)='MASTER'
  OR ((SELECT role FROM public.scola_current_profile() LIMIT 1) IN ('KEPALA_SEKOLAH','GURU') AND tenant_id=(SELECT tenant_id FROM public.scola_current_profile() LIMIT 1))
  OR ((SELECT role FROM public.scola_current_profile() LIMIT 1)='SISWA' AND EXISTS (SELECT 1 FROM public.students s WHERE s.id=grades.student_id AND s.user_id=auth.uid()::text))
  OR ((SELECT role FROM public.scola_current_profile() LIMIT 1)='ORANG_TUA' AND EXISTS (SELECT 1 FROM public.students s JOIN public.user_profiles up ON up.id=auth.uid()::text WHERE s.id=grades.student_id AND up.linked_students @> jsonb_build_array(jsonb_build_object('id',s.id))))
);
