-- SCOLA: Principal/Kepala Sekolah account provisioning.
-- Passwords are managed by Supabase Auth and are never stored in user_profiles.

-- Keep the role/status columns compatible with the application if they already exist.
ALTER TABLE public.user_profiles
  ADD COLUMN IF NOT EXISTS role VARCHAR(30),
  ADD COLUMN IF NOT EXISTS status VARCHAR(20) DEFAULT 'ACTIVE',
  ADD COLUMN IF NOT EXISTS phone VARCHAR(50),
  ADD COLUMN IF NOT EXISTS nip VARCHAR(50),
  ADD COLUMN IF NOT EXISTS updated_at TIMESTAMPTZ DEFAULT now();

CREATE UNIQUE INDEX IF NOT EXISTS user_profiles_email_lower_unique
  ON public.user_profiles (lower(email));

CREATE UNIQUE INDEX IF NOT EXISTS one_active_principal_per_tenant
  ON public.user_profiles (tenant_id)
  WHERE role = 'KEPALA_SEKOLAH' AND status = 'ACTIVE';
