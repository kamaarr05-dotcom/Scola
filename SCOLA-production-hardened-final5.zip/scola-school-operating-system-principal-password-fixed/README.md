<div align="center">
<img width="1200" height="475" alt="GHBanner" src="https://ai.google.dev/static/site-assets/images/share-ais-513315318.png" />
</div>

# Run and deploy your AI Studio app

This contains everything you need to run your app locally.

View your app in AI Studio: https://ai.studio/apps/ebcb27ad-f401-4ed9-a938-0da84df2e662

## Run Locally

**Prerequisites:**  Node.js


1. Install dependencies:
   `npm install`
2. Set the `GEMINI_API_KEY` in [.env.local](.env.local) to your Gemini API key
3. Run the app:
   `npm run dev`

## Dashboard KPI Charts

Dashboard Guru dan Kepala Sekolah sekarang menggunakan Recharts untuk menampilkan:
- Distribusi status kehadiran
- Tren persentase kehadiran
- Distribusi rentang nilai siswa
- KPI rata-rata nilai dan persentase hadir

Dependency grafik: `recharts` dan `react-is`.


## Akun Guru: registrasi oleh Kepala Sekolah / Master

Form **Registrasi Akun Guru** sekarang meminta email + password + konfirmasi password. Akun guru dibuat dengan status **ACTIVE** dan dapat login menggunakan kredensial tersebut.

Pada mode Supabase live, pembuatan user Auth dilakukan oleh Edge Function agar `SUPABASE_SERVICE_ROLE_KEY` tidak pernah masuk ke browser. Deploy fungsi dari root proyek: 

```bash
supabase functions deploy provision-teacher-account
```

Fungsi menggunakan `SUPABASE_URL` dan `SUPABASE_SERVICE_ROLE_KEY` bawaan environment Edge Functions. Jangan memasukkan service-role key ke `.env`, Vite, ZIP frontend, atau source browser.

Sebelum memakai registrasi guru pada database lama, jalankan ulang SQL pada **SupabaseSqlModal** agar kolom `subject_specialty`, `employment_type`, `assignments`, dan `role` tersedia di tabel `teachers`. Script sudah memakai `ADD COLUMN IF NOT EXISTS`, sehingga aman untuk instalasi yang sudah memiliki tabel.

Portal **Master** sekarang memiliki tombol **Daftar Guru** pada setiap tenant aktif. Master dapat memilih sekolah lalu membuat akun guru; Kepala Sekolah hanya dapat membuat akun guru untuk tenant sekolahnya sendiri.

### Alur login akun guru

1. Kepala Sekolah atau Master mengisi **Email Login** dan **Password** pada form registrasi guru.
2. Server membuat user di **Supabase Auth** dengan `email_confirm: true`.
3. Server membuat `user_profiles` dengan role `GURU` dan status `ACTIVE`.
4. Server membuat record `teachers` dan menghubungkannya ke `auth.users` melalui `user_profiles.id`.
5. Guru dapat langsung masuk melalui halaman Login SCOLA menggunakan email dan password yang baru dibuat.

> Password tidak disimpan di tabel `teachers` atau `user_profiles` pada mode Supabase live. Password ditangani oleh Supabase Auth.


## Production account workflow

- Student self-registration creates Auth + profile + student record in pending state.
- Registration requires an active Wali Kelas for the selected class.
- Only the Wali Kelas assigned to that class (or school/master administration) can approve/reject.
- Student login is blocked until `user_profiles.status = ACTIVE`.
- Apply `supabase/migrations/20260917_security_rls.sql` before production use.
- Deploy all Supabase functions in `supabase/functions/`.
- Never expose `SUPABASE_SERVICE_ROLE_KEY` to the frontend.
