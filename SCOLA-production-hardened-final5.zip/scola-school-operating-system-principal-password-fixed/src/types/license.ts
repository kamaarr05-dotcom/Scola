import { ScolaRole, SchoolType } from './auth';

export const TEACHER_LICENSE_PRICE_PER_MONTH = 15000; // Rp15.000 / guru aktif / bulan (Locked business rule)

export interface LicenseUsage {
  tenant_id: string;
  tenant_name: string;
  tenant_slug: string;
  tenant_type: SchoolType;
  subscription_tier: string;
  total_quota: number;
  used_licenses: number; // Active teachers
  available_licenses: number; // max(0, total_quota - used_licenses)
  usage_percentage: number; // Math.round((used_licenses / total_quota) * 100)
  is_full: boolean;
  price_per_teacher: number; // 15000
  estimated_monthly_cost: number; // used_licenses * 15000
  last_updated: string;
}

export type QuotaAuditEventType =
  | 'QUOTA_CHANGED'
  | 'TEACHER_ACTIVATED'
  | 'TEACHER_DEACTIVATED'
  | 'TEACHER_ACTIVATION_REJECTED';

export interface QuotaAuditLog {
  id: string;
  timestamp: string;
  tenant_id: string;
  tenant_name?: string;
  actor_id: string;
  actor_email: string;
  actor_role: ScolaRole;
  action: QuotaAuditEventType;
  quota_before?: number;
  quota_after?: number;
  teacher_id?: string;
  teacher_name?: string;
  reason?: string;
  status: 'SUCCESS' | 'REJECTED';
  details?: string;
}
