export * from './auth';
export * from './academic';
export * from './license';

import { ScolaRole, AuthAuditLog } from './auth';
import { GradeItem } from './academic';

export type UserRole = ScolaRole;
export type AuditLogEntry = AuthAuditLog;
export type GradeRecord = GradeItem;
export type AssessmentType = 'FORMATIF' | 'SUMATIF_LINGKUP_MATERI' | 'SUMATIF_AKHIR_SEMESTER' | 'PROYEK_P5' | 'UKK' | string;

export interface DashboardMetric {
  label: string;
  value: string | number;
  change?: string;
  trend?: 'up' | 'down' | 'neutral';
  description?: string;
  badge?: string;
}

export type ViewportMode = 'DESKTOP' | 'TABLET' | 'MOBILE' | 'desktop' | 'tablet' | 'mobile';
