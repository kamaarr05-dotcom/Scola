/**
 * Academic, Classes, and School Structure Types
 */

import { SchoolType } from './auth';

export interface AcademicYear {
  id: string;
  tenant_id: string;
  name: string; // e.g. "2024/2025"
  semester: 'GANJIL' | 'GENAP';
  is_active: boolean;
  start_date: string;
  end_date: string;
}

export interface SchoolClass {
  id: string;
  tenant_id: string;
  name: string; // e.g. "X MIPA 1", "XI TKJ 2"
  grade_level: 10 | 11 | 12;
  school_type: SchoolType;
  major_or_stream: string; // SMA: Peminatan/Fase, SMK: Program Keahlian
  major?: string;
  major_or_program?: string;
  academic_year_id: string;
  wali_kelas_teacher_id?: string;
  wali_kelas_name?: string;
  homeroom_teacher_name?: string;
  room_number?: string;
  capacity: number;
  total_students: number;
}

export interface Subject {
  id: string;
  tenant_id: string;
  code: string;
  name: string;
  category: 'UMUM' | 'KEJURUAN' | 'PEMINATAN' | 'MUATAN_LOKAL' | 'P5' | 'MULOK' | string;
  curriculum?: 'KURIKULUM_MERDEKA' | 'KURIKULUM_2013' | string;
  grade_level?: number[];
  credit_hours?: number;
  hours_per_week?: number;
  kkm?: number;
  school_type?: string;
  teacher_id?: string;
  teacher_name?: string;
}

export type AttendanceStatus = 'HADIR' | 'SAKIT' | 'IZIN' | 'ALPA' | 'DISPENSASI';

export interface DailyAttendance {
  id: string;
  tenant_id: string;
  student_id: string;
  student_name: string;
  class_id: string;
  date: string;
  status: AttendanceStatus;
  recorded_by_user_id: string;
  recorded_by_name?: string;
  notes?: string;
  // Dual-tier & Anchor fields
  period_number?: number; // 1 for first period anchor, 2, 3 etc.
  subject_id?: string;
  subject_name?: string;
  source?: 'FIRST_PERIOD_ANCHOR' | 'SUBJECT_SESSION' | 'PARENT_PERMISSION' | 'PIKET_GERBANG' | 'WALI_OVERRIDE';
}

export type AttendanceRecord = DailyAttendance;

export interface GradeItem {
  id: string;
  tenant_id: string;
  student_id: string;
  student_name: string;
  subject_id: string;
  subject_name: string;
  class_id: string;
  academic_year_id?: string;
  semester?: 'GANJIL' | 'GENAP';
  assessment_type: string;
  assessment_title?: string;
  score: number;
  max_score?: number;
  weight?: number;
  competency_desc?: string;
  competency_achievement?: string;
  created_at: string;
  letter_grade?: string;
  final_score?: number;
  predicate?: string;
  tugas_score?: number;
  uts_score?: number;
  uas_score?: number;
}

export interface StudentGrade extends GradeItem {
  letter_grade?: string;
  final_score?: number;
  predicate?: string;
  tugas_score?: number;
  uts_score?: number;
  uas_score?: number;
}

export type GradeRecord = StudentGrade;
export type StudentClass = SchoolClass;

export type DayOfWeek = 'SENIN' | 'SELASA' | 'RABU' | 'KAMIS' | 'JUMAT' | 'SABTU';

export interface ClassSchedule {
  id: string;
  tenant_id: string;
  class_id: string;
  class_name: string;
  subject_id: string;
  subject_name: string;
  teacher_id: string;
  teacher_name: string;
  academic_year_id?: string;
  day: DayOfWeek | string;
  day_of_week?: string;
  start_time: string; // e.g. "07:30"
  end_time: string; // e.g. "09:00"
  room: string;
}

export interface AcademicTask {
  id: string;
  tenant_id: string;
  class_id: string;
  class_name: string;
  subject_id: string;
  subject_name: string;
  teacher_id: string;
  teacher_name: string;
  title: string;
  description: string;
  task_type?: 'TUGAS' | 'PR' | 'PROYEK' | 'ULANGAN';
  due_date: string; // ISO string e.g. "2026-09-20T23:59:00Z"
  max_score: number;
  created_at: string;
  submissions_count?: number;
  submission_count?: number;
}

export interface TaskSubmission {
  id: string;
  tenant_id: string;
  task_id: string;
  student_id: string;
  student_name: string;
  student_nisn?: string;
  submission_content: string;
  attachment_url?: string;
  status: 'SUBMITTED' | 'GRADED' | 'LATE';
  score?: number;
  feedback?: string;
  submitted_at: string;
  graded_at?: string;
  graded_by?: string;
}

export interface TeacherSubjectAssignment {
  id: string;
  tenant_id: string;
  teacher_id: string;
  teacher_name: string;
  subject_id: string;
  subject_name: string;
  class_id: string;
  class_name: string;
  academic_year_id: string;
}

export interface StudentGuardian {
  id: string;
  tenant_id: string;
  guardian_user_id: string;
  guardian_name: string;
  guardian_whatsapp: string;
  guardian_email: string;
  student_id: string;
  student_name: string;
  student_nisn: string;
  class_id: string;
  class_name: string;
  relation_type: 'AYAH' | 'IBU' | 'WALI';
  status: 'ACTIVE' | 'INACTIVE';
  is_primary: boolean;
  activated_by_wali_kelas_id?: string;
  activated_by_name?: string;
  activation_mode: 'SUPABASE_AUTH_INTERNAL_PROVISION';
  created_at: string;
}

export interface ReportCard {
  id: string;
  tenant_id: string;
  student_id: string;
  student_name: string;
  nisn: string;
  student_nisn?: string;
  class_id: string;
  class_name?: string;
  academic_year_id?: string;
  academic_year?: string;
  semester: 'GANJIL' | 'GENAP';
  status?: 'DRAFT' | 'PUBLISHED';
  published: boolean;
  published_at?: string;
  homeroom_teacher_name?: string;
  wali_kelas_notes?: string;
  homeroom_notes?: string;
  general_average?: number;
  average_score?: number;
  subject_grades?: Array<{
    subject_id: string;
    subject_name: string;
    final_score: number;
    predicate: string;
    competency_achievement: string;
    letter_grade?: string;
  }>;
  grades?: Array<{
    subject_id: string;
    subject_name: string;
    final_score: number;
    letter_grade: string;
    predicate?: string;
    competency_achievement: string;
  }>;
  extracurriculars?: Array<{
    name: string;
    score: string;
    description: string;
    notes?: string;
  }>;
  extracurricular_activities?: Array<{
    name: string;
    score: string;
    notes: string;
  }>;
  attendance_summary?: {
    hadir?: number;
    sakit?: number;
    sick?: number;
    izin?: number;
    permission?: number;
    alpa?: number;
    unexcused?: number;
  };
  teacher_notes?: string;
}

export type StudentReportCard = ReportCard & {
  grades: Array<{
    subject_id: string;
    subject_name: string;
    final_score: number;
    letter_grade: string;
    competency_achievement: string;
  }>;
  extracurriculars: Array<{
    name: string;
    score: string;
    description: string;
  }>;
};

export interface SMAPeminatanOption {
  id: string;
  tenant_id: string;
  name: string; // e.g. "Kelompok MIPA", "Kelompok IPS", "Fase F - Rekayasa & Teknologi"
  subjects: string[];
  capacity: number;
  enrolled: number;
}

export interface SMKProgramKeahlian {
  id: string;
  tenant_id: string;
  bidang_keahlian: string; // e.g. "Teknologi Informasi"
  program_keahlian: string; // e.g. "Pengembangan Perangkat Lunak & Gim"
  konsentrasi_keahlian: string[]; // e.g. ["Rekayasa Perangkat Lunak", "Game Development"]
  kaprog_teacher_id?: string;
  kaprog_name?: string;
  industrial_partners: number;
}

export interface SMKPklRecord {
  id: string;
  tenant_id: string;
  student_id: string;
  student_name: string;
  company_name: string;
  industry_mentor: string;
  school_supervisor_id: string;
  school_supervisor_name: string;
  start_date: string;
  end_date: string;
  status: 'BERLANGSUNG' | 'SELESAI' | 'PERSIAPAN';
  grade?: number;
}

export interface SMKUKKRecord {
  id: string;
  tenant_id: string;
  student_id: string;
  student_name: string;
  scheme_name: string; // e.g. "Junior Web Developer - BNSP"
  examiner_internal: string;
  examiner_external: string;
  institution_partner: string;
  test_date: string;
  status: 'KOMPETEN' | 'BELUM_KOMPETEN' | 'TERDAFTAR';
  score: number;
}

export interface SMKIndustryPartner {
  id: string;
  tenant_id: string;
  name: string;
  industry_sector: string; // e.g. "Software House", "Telekomunikasi", "Manufaktur Otomotif"
  address: string;
  city: string;
  pic_name: string;
  pic_role: string;
  pic_phone: string;
  pic_email: string;
  quota: number;
  active_interns_count: number;
  mou_number: string;
  mou_valid_until: string;
  is_active: boolean;
}

export interface SMKPklJournal {
  id: string;
  pkl_id: string;
  tenant_id: string;
  student_id: string;
  student_name: string;
  date: string;
  activity_title?: string;
  activity_description?: string;
  activity_summary?: string;
  competencies_learned: string;
  mentor_notes?: string;
  mentor_verified: boolean;
  supervisor_verified?: boolean;
  school_supervisor_reviewed: boolean;
  placement_id?: string;
  created_at: string;
}

export interface SMKPklAttendance {
  id: string;
  pkl_id: string;
  tenant_id: string;
  student_id: string;
  student_name: string;
  date: string;
  check_in_time: string;
  check_out_time: string;
  status: 'HADIR' | 'SAKIT' | 'IZIN' | 'ALPA';
  verified_by_mentor: boolean;
  notes?: string;
  placement_id?: string;
}

export interface SMKPklAssessment {
  id: string;
  pkl_id: string;
  tenant_id: string;
  student_id: string;
  student_name: string;
  technical_competence_score: number; // 0-100
  work_ethic_score: number; // 0-100
  discipline_attendance_score: number; // 0-100
  communication_teamwork_score: number; // 0-100
  final_score: number;
  letter_grade: 'A' | 'B' | 'C' | 'D';
  mentor_comment: string;
  certificate_number?: string;
  completed_at: string;
}

export interface SMKBkkJob {
  id: string;
  tenant_id: string;
  company_name: string;
  job_title: string;
  job_type: 'MAGANG' | 'FULL_TIME' | 'KONTRAK';
  target_programs: string[];
  location: string;
  description: string;
  requirements: string[];
  deadline: string;
  contact_or_apply_url: string;
  status: 'OPEN' | 'CLOSED';
}

export interface SMKTracerStudy {
  id: string;
  tenant_id: string;
  student_name: string;
  nisn: string;
  graduation_year: number;
  program_name: string;
  status: 'BEKERJA' | 'MELANJUTKAN' | 'WIRAUSAHA' | 'MENCARI_KERJA';
  institution_or_company: string;
  position_or_major: string;
  monthly_income_range?: string;
  curriculum_relevance_rating: number; // 1-5
}

export interface BKCounselingRecord {
  id: string;
  tenant_id: string;
  student_id: string;
  student_name: string;
  class_name: string;
  counselor_name: string;
  category: 'PRIBADI' | 'SOSIAL' | 'BELAJAR' | 'KARIR' | 'KEDISIPLINAN' | 'KARIR_STUDI_LANJUT';
  date: string;
  issue_summary: string;
  action_plan: string;
  status: 'OPEN' | 'IN_PROGRESS' | 'RESOLVED';
  follow_up_date?: string;
  confidentiality_level: 'STANDARD' | 'STRICT';
  parent_notified?: boolean;
}

export interface StudentDisciplineRecord {
  id: string;
  tenant_id: string;
  student_id: string;
  student_name: string;
  class_name: string;
  type?: 'PELANGGARAN' | 'PENGHARGAAN' | 'PRESTASI';
  record_type?: 'PELANGGARAN' | 'PENGHARGAAN' | 'PRESTASI';
  category: string;
  points: number;
  description: string;
  date: string;
  recorded_by?: string;
  recorded_by_name?: string;
  follow_up_action?: string;
}

export interface SchoolFacility {
  id: string;
  tenant_id: string;
  code?: string;
  name: string;
  type?: 'RUANG_KELAS' | 'LABORATORIUM' | 'BENGKEL_PRAKTIK' | 'PERPUSTAKAAN' | 'AULA' | 'LAPANGAN' | string;
  category?: string;
  condition: 'BAIK' | 'RUSAK_RINGAN' | 'RUSAK_BERAT' | string;
  capacity: number;
  pic_name?: string;
  pic_user_name?: string;
  location?: string;
  last_inspected?: string;
  notes?: string;
}

export interface SchoolLetter {
  id: string;
  tenant_id: string;
  letter_number: string;
  letter_type?: string;
  type?: string;
  subject: string;
  sender_or_recipient?: string;
  recipient?: string;
  date?: string;
  created_date?: string;
  created_by_name?: string;
  signed_by?: string;
  status: string;
}

export type OfficialLetter = SchoolLetter;

// ==========================================
// WAKA SUITE ENTERPRISE OPERATIONAL TYPES
// ==========================================

export interface InvalDutyAssignment {
  id: string;
  tenant_id: string;
  date: string;
  period_numbers: number[]; // e.g. [1, 2]
  time_range: string; // e.g. "07:00 - 08:30"
  class_id: string;
  class_name: string;
  original_teacher_id: string;
  original_teacher_name: string;
  inval_teacher_id: string;
  inval_teacher_name: string;
  subject_id: string;
  subject_name: string;
  reason: 'SAKIT' | 'IZIN_DINAS' | 'KEMALANGAN' | 'CUTI' | 'LAINNYA';
  lesson_plan_or_task: string;
  sk_number: string;
  status: 'ASSIGNED' | 'IN_PROGRESS' | 'COMPLETED';
  created_at: string;
}

export interface AcademicSupervisionRecord {
  id: string;
  tenant_id: string;
  teacher_id: string;
  teacher_name: string;
  subject_name: string;
  class_name: string;
  supervisor_name: string; // Waka Kurikulum or Kepsek
  scheduled_date: string;
  modul_ajar_score: number; // 0-100
  pedagogic_score: number; // 0-100
  classroom_management_score: number; // 0-100
  student_engagement_score: number; // 0-100
  final_grade: 'A' | 'B' | 'C' | 'D';
  feedback_notes: string;
  status: 'SCHEDULED' | 'COMPLETED';
}

export interface ExtracurricularActivity {
  id: string;
  tenant_id: string;
  name: string;
  category: 'OLAHRAGA' | 'SENI_BUDAYA' | 'KEAGAMAAN' | 'KIR_SAINS' | 'PRAMUKA_PMR';
  coach_teacher_id: string;
  coach_name: string;
  schedule_day: DayOfWeek;
  time_range: string;
  location: string;
  member_count: number;
  annual_budget: number;
  status: 'ACTIVE' | 'INACTIVE';
}

export interface StudentScholarshipRecord {
  id: string;
  tenant_id: string;
  student_id: string;
  student_name: string;
  class_name: string;
  nisn: string;
  program_type: 'PIP_KEMDIKBUD' | 'KIP_KULIAH' | 'YAYASAN' | 'PRESTASI' | 'LAZIS';
  nominal_per_year: number;
  disbursement_stage: string; // e.g. "Tahap 1 - 2024"
  disbursement_status: 'PENGAJUAN' | 'TERVERIFIKASI' | 'CAIR' | 'SELESAI';
  disbursed_date?: string;
}

export interface FacilityMaintenanceTicket {
  id: string;
  tenant_id: string;
  ticket_number: string;
  facility_id: string;
  facility_name: string;
  reported_by_name: string;
  reported_by_role: string;
  report_date: string;
  urgency: 'RENDAH' | 'SEDANG' | 'TINGGI' | 'DARURAT';
  issue_description: string;
  estimated_cost: number;
  funding_source: 'BOS_REGULER' | 'BOS_KINERJA' | 'DANA_KOMITE' | 'YAYASAN';
  assigned_technician?: string;
  completion_date?: string;
  status: 'PENDING' | 'DISPOSISI' | 'DALAM_PENGERJAAN' | 'SELESAI' | 'DITOLAK';
}

export interface RoomReservationRecord {
  id: string;
  tenant_id: string;
  facility_id: string;
  facility_name: string;
  borrower_name: string;
  borrower_role: string;
  reservation_date: string;
  start_time: string;
  end_time: string;
  purpose: string;
  status: 'APPROVED' | 'PENDING' | 'REJECTED';
}

export interface IndustryMoUPartner {
  id: string;
  tenant_id: string;
  partner_name: string;
  field_of_work: string;
  city: string;
  mou_number: string;
  sign_date: string;
  expiry_date: string;
  pkl_quota: number;
  contact_person: string;
  phone: string;
  status: 'AKTIF' | 'MENJELANG_KADALUWARSA' | 'KADALUWARSA';
}
