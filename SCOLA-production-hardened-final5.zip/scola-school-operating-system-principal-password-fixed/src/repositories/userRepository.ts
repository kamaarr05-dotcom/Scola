import { UserProfile } from '../types';
import { INITIAL_USERS } from '../data/mockDatabase';
import { getSupabase, isSupabaseConfigured } from '../config/supabase';
import { canActivateParentAccount } from '../lib/permissions';

class UserRepository {
  private users: UserProfile[] = [...INITIAL_USERS];

  async getAll(): Promise<UserProfile[]> {
    const supabase = getSupabase();
    if (supabase) {
      try {
        const { data, error } = await supabase.from('user_profiles').select('*');
        if (!error && data) return data as UserProfile[];
        if (isSupabaseConfigured()) return [];
      } catch (err) {
        console.warn('Supabase fetch users failed:', err);
        if (isSupabaseConfigured()) return [];
      }
    }
    return [...this.users];
  }

  async getById(userId: string): Promise<UserProfile | null> {
    const supabase = getSupabase();
    if (supabase) {
      try {
        const { data, error } = await supabase
          .from('user_profiles')
          .select('*')
          .eq('id', userId)
          .single();
        if (!error && data) return data as UserProfile;
      } catch (err) {
        console.warn('Supabase fetch user by id failed:', err);
      }
      if (isSupabaseConfigured()) return null;
    }
    return this.users.find((u) => u.id === userId) || null;
  }

  async getByEmail(email: string): Promise<UserProfile | null> {
    const cleanEmail = email.toLowerCase().trim();
    const supabase = getSupabase();
    if (supabase) {
      try {
        const { data, error } = await supabase
          .from('user_profiles')
          .select('*')
          .eq('email', cleanEmail)
          .single();
        if (!error && data) return data as UserProfile;
      } catch (err) {
        console.warn('Supabase fetch user by email failed:', err);
      }
      if (isSupabaseConfigured()) return null;
    }
    return this.users.find((u) => u.email.toLowerCase() === cleanEmail) || null;
  }

  async addUser(user: UserProfile): Promise<UserProfile> {
    const existingIdx = this.users.findIndex((u) => u.id === user.id || u.email.toLowerCase() === user.email.toLowerCase());
    if (existingIdx >= 0) {
      this.users[existingIdx] = user;
    } else {
      this.users.push(user);
    }
    const supabase=getSupabase();
    if(isSupabaseConfigured()&&supabase){ const {error}=await supabase.from('user_profiles').upsert(user,{onConflict:'id'}); if(error) throw new Error(`Gagal menyimpan profil pengguna: ${error.message}`); return user; }
    return user;
  }

  async create(user: UserProfile): Promise<UserProfile> {
    return this.addUser(user);
  }

  async update(userId: string, data: Partial<UserProfile>): Promise<UserProfile | null> {
    const now = new Date().toISOString();
    const supabase = getSupabase();
    if (isSupabaseConfigured() && supabase) {
      const { data: updated, error } = await supabase.from('user_profiles').update({ ...data, updated_at: now }).eq('id', userId).select().single();
      if (error) throw new Error(`Gagal memperbarui pengguna: ${error.message}`);
      return updated as UserProfile;
    }
    const user = this.users.find((u) => u.id === userId);
    if (!user) return null;
    Object.assign(user, data, { updated_at: now });
    return user;
  }

  async updateUserStatus(userId: string, status: UserProfile['status']): Promise<UserProfile | null> {
    const now = new Date().toISOString();
    const supabase = getSupabase();
    if (isSupabaseConfigured() && supabase) {
      const { data: updated, error } = await supabase.from('user_profiles').update({ status, updated_at: now }).eq('id', userId).select().single();
      if (error) throw new Error(`Gagal memperbarui status pengguna: ${error.message}`);
      return updated as UserProfile;
    }
    const user = this.users.find((u) => u.id === userId);
    if (!user) return null;
    user.status = status;
    user.updated_at = now;
    return user;
  }

  /**
   * Business Rule: Student self-registration allowed.
   */
  async registerStudent(params: {
    tenant_id: string;
    full_name: string;
    email: string;
    nisn: string;
    nis: string;
    generation_year: number;
    school_type: 'SMA' | 'SMK';
    peminatan_or_program: string;
    password?: string;
  }): Promise<UserProfile> {
    if (isSupabaseConfigured()) throw new Error('Gunakan alur pendaftaran siswa resmi melalui RegisterStudentModal.');
    const newUserId = `usr-std-${Date.now()}`;
    const newUserProfile: UserProfile = {
      id: newUserId,
      tenant_id: params.tenant_id,
      email: params.email,
      full_name: params.full_name,
      role: 'SISWA',
      status: 'PENDING_VERIFICATION',
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    };

    const supabase = getSupabase();
    if (supabase) {
      try {
        await supabase.from('user_profiles').upsert(newUserProfile, { onConflict: 'id' });
        await supabase.from('students').upsert([
          {
            id: `std-${newUserId}`,
            tenant_id: params.tenant_id,
            nisn: params.nisn,
            nis: params.nis,
            full_name: params.full_name,
            grade_level: 10,
            school_type: params.school_type,
            major_or_stream: params.peminatan_or_program,
            status: 'ACTIVE',
          },
        ], { onConflict: 'id' });
      } catch (err) {
        console.warn('Supabase student registration fallback:', err);
      }
    }

    this.users.push(newUserProfile);
    return newUserProfile;
  }

  /**
   * Business Rule: Parent accounts CANNOT self-register.
   * Created / Activated by Wali Kelas or Kepala Sekolah.
   * 1 parent can be linked to multiple students.
   */
  async createParentAccount(
    params: {
      tenant_id: string;
      full_name: string;
      email: string;
      phone: string;
      relation_type: 'AYAH' | 'IBU' | 'WALI';
      student_ids: string[];
    },
    actorUser: UserProfile
  ): Promise<UserProfile> {
    if (!canActivateParentAccount(actorUser)) {
      throw new Error('Akses Ditolak: Hanya Wali Kelas atau Kepala Sekolah yang dapat membuat/mengaktifkan akun Orang Tua.');
    }

    if (isSupabaseConfigured()) throw new Error('Aktivasi akun Orang Tua Live wajib melalui provisioning server-side. Akun dummy browser diblokir.');
    const newUserId = `usr-parent-${Date.now()}`;
    const newParent: UserProfile = {
      id: newUserId,
      tenant_id: params.tenant_id,
      email: params.email,
      full_name: params.full_name,
      phone: params.phone,
      role: 'ORANG_TUA',
      status: 'ACTIVE',
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
      linked_students: params.student_ids.map((sid, idx) => ({
        id: sid,
        nisn: `007${idx}${Date.now().toString().slice(-4)}`,
        full_name: `Anak ke-${idx + 1} (${params.full_name})`,
        class_name: 'X MIPA 1',
        tenant_name: 'Sekolah Terdaftar',
        school_type: 'SMA',
      })),
    };

    const supabase = getSupabase();
    if (supabase) {
      try {
        await supabase.from('user_profiles').upsert(newParent, { onConflict: 'id' });
      } catch (err) {
        console.warn('Supabase parent creation fallback:', err);
      }
    }

    this.users.push(newParent);
    return newParent;
  }

  /**
   * MASTER dapat membuat akun Kepala Sekolah & menghubungkannya dengan tenant.
   * Hanya MASTER yang berwenang membuat akun Kepala Sekolah.
   * Kepala Sekolah tidak boleh self-register.
   */
  async createPrincipalAccount(
    params: {
      tenant_id: string;
      full_name: string;
      email: string;
      password: string;
      phone?: string;
      nip?: string;
    },
    actor: UserProfile
  ): Promise<UserProfile> {
    // Backward-compatible wrapper. Real/live provisioning belongs to the
    // principal account service so the browser never stores a live Auth password.
    const { principalAccountService } = await import('../services/principalAccountService');
    return principalAccountService.createPrincipalAccount(params, actor);
  }

  async getPrincipals(): Promise<UserProfile[]> {
    const supabase=getSupabase();
    if(isSupabaseConfigured()&&supabase){ const {data,error}=await supabase.from('user_profiles').select('*').eq('role','KEPALA_SEKOLAH'); if(error) throw new Error(`Gagal mengambil Kepala Sekolah: ${error.message}`); return (data||[]) as UserProfile[]; }
    return this.users.filter(u=>u.role==='KEPALA_SEKOLAH');
  }
  async getPrincipalByTenant(tenantId:string):Promise<UserProfile|null>{
    const supabase=getSupabase();
    if(isSupabaseConfigured()&&supabase){ const {data,error}=await supabase.from('user_profiles').select('*').eq('role','KEPALA_SEKOLAH').eq('tenant_id',tenantId).maybeSingle(); if(error) throw new Error(`Gagal mengambil Kepala Sekolah: ${error.message}`); return data as UserProfile|null; }
    return this.users.find(u=>u.role==='KEPALA_SEKOLAH'&&u.tenant_id===tenantId)||null;
  }
  async getUsersByTenant(tenantId: string, actor: UserProfile): Promise<UserProfile[]> {
    if (actor.role !== 'MASTER' && actor.tenant_id !== tenantId) {
      throw new Error('Akses Ditolak: Pelanggaran isolasi data tenant.');
    }
    const supabase=getSupabase();
    if(isSupabaseConfigured()&&supabase){ const {data,error}=await supabase.from('user_profiles').select('*').eq('tenant_id',tenantId).order('created_at',{ascending:false}); if(error) throw new Error(`Gagal mengambil pengguna tenant: ${error.message}`); return (data||[]) as UserProfile[]; }
    return this.users.filter((u) => u.tenant_id === tenantId);
  }
}

export const userRepository = new UserRepository();
