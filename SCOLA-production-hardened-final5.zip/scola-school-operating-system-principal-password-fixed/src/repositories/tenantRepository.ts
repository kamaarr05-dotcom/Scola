import { Tenant, UserProfile } from '../types';
import { INITIAL_TENANTS } from '../data/mockDatabase';
import { getSupabase, isSupabaseConfigured } from '../config/supabase';
import { auditService } from '../services/auditService';

class TenantRepository {
  private tenants: Tenant[] = [...INITIAL_TENANTS];

  async getAll(): Promise<Tenant[]> {
    const supabase = getSupabase();
    if (supabase && isSupabaseConfigured()) {
      const { data, error } = await supabase.from('tenants').select('*');
      if (!error && data) return data as Tenant[];
      return [];
    }
    return [...this.tenants];
  }

  async getById(id: string): Promise<Tenant | null> {
    const supabase = getSupabase();
    if (supabase) {
      const { data, error } = await supabase
        .from('tenants')
        .select('*')
        .eq('id', id)
        .single();
      if (!error && data) return data as Tenant;
      if (isSupabaseConfigured()) return null;
    }
    return this.tenants.find((t) => t.id === id) || null;
  }

  /**
   * MASTER dapat membuat tenant baru & data sekolah.
   * Hanya MASTER yang berwenang membuat tenant.
   */
  async createTenant(
    data: {
      name: string;
      npsn: string;
      type: 'SMA' | 'SMK';
      accreditation?: 'A' | 'B' | 'C' | 'BELUM_TERAKREDITASI';
      address: string;
      city: string;
      province: string;
      phone: string;
      email: string;
      logo_url?: string;
      brand_color?: string;
      teacher_quota?: number;
      is_active?: boolean;
      subscription_tier?: 'TRIAL' | 'STANDARD' | 'ENTERPRISE';
    },
    actor: UserProfile
  ): Promise<Tenant> {
    if (actor.role !== 'MASTER') {
      await auditService.recordEvent({
        event: 'PERMISSION_DENIED',
        email: actor.email,
        user_id: actor.id,
        role: actor.role,
        tenant_id: actor.tenant_id,
        status: 'FAILED',
        details: 'Percobaan membuat tenant ditolak: Hanya MASTER yang berwenang.',
      });
      throw new Error('Akses Ditolak: Hanya MASTER yang dapat membuat tenant sekolah baru.');
    }

    const supabase = getSupabase();
    if (isSupabaseConfigured() && supabase) {
      const { data: existingNpsn } = await supabase.from('tenants').select('id,name').eq('npsn', data.npsn).maybeSingle();
      if (existingNpsn) throw new Error(`NPSN ${data.npsn} sudah terdaftar untuk sekolah "${existingNpsn.name}".`);
    } else {
      const existingNpsn = this.tenants.find((t) => t.npsn === data.npsn);
      if (existingNpsn) throw new Error(`NPSN ${data.npsn} sudah terdaftar untuk sekolah "${existingNpsn.name}".`);
    }

    const tenantId = `tenant-${data.type.toLowerCase()}-${Date.now().toString().slice(-6)}`;
    const isActive = data.is_active ?? true;
    const quota = data.teacher_quota !== undefined ? data.teacher_quota : 20;

    const newTenant: Tenant = {
      id: tenantId,
      npsn: data.npsn,
      name: data.name,
      slug: data.name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, ''),
      subdomain: data.name.toLowerCase().replace(/[^a-z0-9]+/g, ''),
      type: data.type,
      accreditation: data.accreditation || 'A',
      province: data.province,
      city: data.city,
      address: data.address,
      phone: data.phone,
      email: data.email,
      logo_url: data.logo_url || 'https://images.unsplash.com/photo-1546410531-bb4caa6b424d?w=128&auto=format&fit=crop&q=80',
      brand_color: data.brand_color || (data.type === 'SMA' ? '#1e40af' : '#047857'),
      teacher_quota: quota,
      active_teacher_count: 0,
      is_active: isActive,
      status: isActive ? 'ACTIVE' : 'INACTIVE',
      subscription_tier: data.subscription_tier || 'STANDARD',
      valid_until: new Date(Date.now() + 365 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    };

    if (isSupabaseConfigured() && supabase) {
      const { data: inserted, error } = await supabase.from('tenants').insert([newTenant]).select().single();
      if (error || !inserted) throw new Error(`Gagal membuat tenant: ${error?.message || 'Database tidak mengembalikan data.'}`);
      await auditService.recordEvent({ event:'TENANT_CREATED', email:actor.email, user_id:actor.id, role:actor.role, tenant_id:inserted.id, tenant_name:inserted.name, status:'SUCCESS', quota_after:inserted.teacher_quota, details:`Tenant baru ${inserted.name} berhasil dibuat.` });
      return inserted as Tenant;
    }
    this.tenants.push(newTenant);

    await auditService.recordEvent({
      event: 'TENANT_CREATED',
      email: actor.email,
      user_id: actor.id,
      role: actor.role,
      tenant_id: newTenant.id,
      tenant_name: newTenant.name,
      status: 'SUCCESS',
      quota_after: newTenant.teacher_quota,
      details: `Tenant baru ${newTenant.name} (${newTenant.type}, NPSN: ${newTenant.npsn}) berhasil dibuat oleh Master dengan kuota awal ${newTenant.teacher_quota} guru.`,
    });

    return newTenant;
  }

  /**
   * Mengubah profil sekolah & school branding.
   * Dilakukan oleh MASTER atau KEPALA SEKOLAH pada tenant miliknya sendiri.
   * Kepala Sekolah TIDAK BISA mengubah kuota atau status aktif tenant.
   */
  async updateSchoolProfile(
    tenantId: string,
    data: {
      name?: string;
      address?: string;
      city?: string;
      province?: string;
      phone?: string;
      email?: string;
      logo_url?: string;
      brand_color?: string;
      accreditation?: 'A' | 'B' | 'C' | 'BELUM_TERAKREDITASI';
      teacher_quota?: number;
      is_active?: boolean;
    },
    actor: UserProfile
  ): Promise<Tenant> {
    const isMaster = actor.role === 'MASTER';
    const isOwnPrincipal = actor.role === 'KEPALA_SEKOLAH' && actor.tenant_id === tenantId;

    if (!isMaster && !isOwnPrincipal) {
      await auditService.recordEvent({
        event: 'PERMISSION_DENIED',
        email: actor.email,
        user_id: actor.id,
        role: actor.role,
        tenant_id: tenantId,
        status: 'FAILED',
        details: 'Percobaan modifikasi profil sekolah ditolak: Bukan Kepala Sekolah dari tenant ini atau Master.',
      });
      throw new Error('Akses Ditolak: Anda hanya berwenang mengelola profil sekolah Anda sendiri.');
    }

    // Strict Rule: Non-master cannot change teacher quota or activation status
    if (!isMaster) {
      if (data.teacher_quota !== undefined) {
        throw new Error('Akses Ditolak: Hanya MASTER yang dapat mengubah quota Guru.');
      }
      if (data.is_active !== undefined) {
        throw new Error('Akses Ditolak: Hanya MASTER yang dapat mengaktifkan/menonaktifkan tenant sekolah.');
      }
    }

    const supabase = getSupabase();
    if (isSupabaseConfigured() && supabase) {
      const { data: current, error: loadError } = await supabase.from('tenants').select('*').eq('id', tenantId).single();
      if (loadError || !current) throw new Error('Tenant sekolah tidak ditemukan.');
      const patch: Record<string, unknown> = { ...data, updated_at: new Date().toISOString() };
      if (!isMaster) { delete patch.teacher_quota; delete patch.is_active; }
      if (isMaster && data.is_active !== undefined) patch.status = data.is_active ? 'ACTIVE' : 'INACTIVE';
      const { data: updated, error } = await supabase.from('tenants').update(patch).eq('id', tenantId).select().single();
      if (error || !updated) throw new Error(`Gagal memperbarui tenant: ${error?.message || 'Database error'}`);
      await auditService.recordEvent({ event:'SCHOOL_PROFILE_UPDATED', email:actor.email, user_id:actor.id, role:actor.role, tenant_id:tenantId, tenant_name:updated.name, status:'SUCCESS', details:`Profil sekolah "${updated.name}" diperbarui.` });
      return updated as Tenant;
    }

    const index = this.tenants.findIndex((t) => t.id === tenantId);
    if (index === -1) throw new Error('Tenant sekolah tidak ditemukan.');
    const oldTenant = this.tenants[index];
    const updatedTenant: Tenant = {
      ...oldTenant,
      ...data,
      teacher_quota: isMaster && data.teacher_quota !== undefined ? data.teacher_quota : oldTenant.teacher_quota,
      is_active: isMaster && data.is_active !== undefined ? data.is_active : oldTenant.is_active,
      status: isMaster && data.is_active !== undefined ? (data.is_active ? 'ACTIVE' : 'INACTIVE') : oldTenant.status,
      updated_at: new Date().toISOString(),
    };
    this.tenants[index]=updatedTenant;

    await auditService.recordEvent({
      event: 'SCHOOL_PROFILE_UPDATED',
      email: actor.email,
      user_id: actor.id,
      role: actor.role,
      tenant_id: tenantId,
      tenant_name: updatedTenant.name,
      status: 'SUCCESS',
      details: `Profil & branding sekolah "${updatedTenant.name}" diperbarui oleh ${actor.full_name} (${actor.role}).`,
    });

    return updatedTenant;
  }

  /**
   * MASTER dapat mengaktifkan/menonaktifkan tenant.
   * Tenant INACTIVE memblokir login pengguna sekolah tetapi mempertahankan historical data.
   */
  async toggleTenantStatus(
    tenantId: string,
    isActive: boolean,
    actor: UserProfile,
    reason?: string
  ): Promise<Tenant> {
    if (actor.role !== 'MASTER') {
      await auditService.recordEvent({
        event: 'PERMISSION_DENIED',
        email: actor.email,
        user_id: actor.id,
        role: actor.role,
        tenant_id: tenantId,
        status: 'FAILED',
        details: 'Percobaan aktivasi/penonaktifan tenant ditolak: Hanya MASTER yang berwenang.',
      });
      throw new Error('Akses Ditolak: Hanya MASTER yang dapat mengaktifkan atau menonaktifkan tenant sekolah.');
    }

    const supabase = getSupabase();
    if (isSupabaseConfigured() && supabase) {
      const { data: updated, error } = await supabase.from('tenants').update({ is_active: isActive, status: isActive ? 'ACTIVE' : 'INACTIVE', updated_at: new Date().toISOString() }).eq('id', tenantId).select().single();
      if (error || !updated) throw new Error(`Gagal mengubah status tenant: ${error?.message || 'Tenant tidak ditemukan.'}`);
      const targetTenant = updated as Tenant;
      const event = isActive ? 'TENANT_ACTIVATED' : 'TENANT_DEACTIVATED';
      await auditService.recordEvent({ event, email:actor.email, user_id:actor.id, role:actor.role, tenant_id:tenantId, tenant_name:targetTenant.name, status:'SUCCESS', reason:reason || undefined, details:`Tenant "${targetTenant.name}" ${isActive?'diaktifkan':'dinonaktifkan'}.` });
      return targetTenant;
    }
    const index = this.tenants.findIndex((t) => t.id === tenantId);
    if (index === -1) throw new Error('Tenant sekolah tidak ditemukan.');
    const targetTenant = this.tenants[index];
    targetTenant.is_active = isActive; targetTenant.status = isActive ? 'ACTIVE' : 'INACTIVE'; targetTenant.updated_at = new Date().toISOString();
    const event = isActive ? 'TENANT_ACTIVATED' : 'TENANT_DEACTIVATED';
    await auditService.recordEvent({
      event,
      email: actor.email,
      user_id: actor.id,
      role: actor.role,
      tenant_id: tenantId,
      tenant_name: targetTenant.name,
      status: 'SUCCESS',
      reason: reason || (isActive ? 'Reaktivasi layanan' : 'Penangguhan operasional'),
      details: `Tenant "${targetTenant.name}" ${
        isActive ? 'diaktifkan kembali' : 'dinonaktifkan'
      } oleh Master. Alasan: ${reason || '-'}. Integritas historical data tetap dipertahankan.`,
    });

    return { ...targetTenant };
  }

  async updateQuota(
    tenantId: string,
    newQuota: number,
    actor?: UserProfile,
    reason?: string
  ): Promise<Tenant> {
    if (actor && actor.role !== 'MASTER') {
      throw new Error('Akses Ditolak: Hanya MASTER yang dapat mengubah quota Guru.');
    }

    const supabase = getSupabase();
    if (isSupabaseConfigured() && supabase) {
      const { data: current, error: currentError } = await supabase.from('tenants').select('teacher_quota,active_teacher_count').eq('id',tenantId).single();
      if (currentError || !current) throw new Error(`Tenant tidak ditemukan: ${currentError?.message || 'Database error'}`);
      if (newQuota < Number(current.active_teacher_count || 0)) throw new Error(`Kuota baru tidak boleh lebih kecil dari jumlah guru aktif (${current.active_teacher_count}).`);
      const { data, error } = await supabase.from('tenants').update({ teacher_quota: newQuota, updated_at: new Date().toISOString() }).eq('id', tenantId).select().single();
      if (error || !data) throw new Error(`Gagal mengubah quota: ${error?.message || 'Database error'}`);
      if(actor) await auditService.recordEvent({event:'QUOTA_CHANGED',email:actor.email,user_id:actor.id,role:actor.role,tenant_id:tenantId,status:'SUCCESS',quota_before:current.teacher_quota,quota_after:newQuota,reason,details:`Kuota guru diubah dari ${current.teacher_quota} menjadi ${newQuota}.`});
      return data as Tenant;
    }

    const index = this.tenants.findIndex((t) => t.id === tenantId);
    if (index === -1) throw new Error('Tenant tidak ditemukan');

    const quotaBefore = this.tenants[index].teacher_quota;
    this.tenants[index] = {
      ...this.tenants[index],
      teacher_quota: newQuota,
      updated_at: new Date().toISOString(),
    };

    if (actor) {
      await auditService.recordEvent({
        event: 'QUOTA_CHANGED',
        email: actor.email,
        user_id: actor.id,
        role: actor.role,
        tenant_id: tenantId,
        tenant_name: this.tenants[index].name,
        status: 'SUCCESS',
        quota_before: quotaBefore,
        quota_after: newQuota,
        reason: reason || 'Penyesuaian kuota lisensi guru',
        details: `Kuota guru tenant ${this.tenants[index].name} diubah dari ${quotaBefore} menjadi ${newQuota}`,
      });
    }

    return this.tenants[index];
  }

  async updateActiveTeacherCount(tenantId: string, delta: number): Promise<void> {
    const supabase = getSupabase();
    if (isSupabaseConfigured() && supabase) {
      const fn = delta > 0 ? 'scola_reserve_teacher_slot' : 'scola_release_teacher_slot';
      if (delta !== 1 && delta !== -1) throw new Error('Perubahan counter guru harus ±1.');
      const { data, error } = await supabase.rpc(fn, { p_tenant_id: tenantId });
      if (error) throw new Error(`Gagal memperbarui counter guru: ${error.message}`);
      if (delta > 0 && !data) throw new Error('Kuota guru telah habis.');
      return;
    }
    const index = this.tenants.findIndex((t) => t.id === tenantId);
    if (index !== -1) this.tenants[index].active_teacher_count = Math.max(0, this.tenants[index].active_teacher_count + delta);
  }
}

export const tenantRepository = new TenantRepository();
