import { TeacherProfile, UserProfile } from '../types';
import { INITIAL_TEACHERS, INITIAL_USERS } from '../data/mockDatabase';
import { getSupabase, isSupabaseConfigured } from '../config/supabase';
import { validateTeacherQuota } from '../lib/quotaValidator';
import { tenantRepository } from './tenantRepository';
import { userRepository } from './userRepository';

class TeacherRepository {
  private teachers: TeacherProfile[] = [...INITIAL_TEACHERS];

  async getByTenant(tenantId: string, currentUser: UserProfile | null): Promise<TeacherProfile[]> {
    // Multi-tenant isolation rule
    if (!currentUser) return [];
    if (currentUser.role !== 'MASTER' && currentUser.tenant_id !== tenantId) {
      return [];
    }
    const supabase = getSupabase();
    if (supabase) {
      const { data, error } = await supabase
        .from('teachers')
        .select('*')
        .eq('tenant_id', tenantId);
      if (!error && data) return data as TeacherProfile[];
      if (isSupabaseConfigured()) throw new Error(`Gagal mengambil data guru: ${error?.message || 'Supabase error'}`);
    }
    if (isSupabaseConfigured()) return [];
    return this.teachers
      .filter((t) => t.tenant_id === tenantId)
      .map((t) => {
        const u = INITIAL_USERS.find((user) => user.id === t.user_id || user.id === t.id);
        return {
          ...t,
          assignments: t.assignments || u?.assignments || [],
        };
      });
  }

  async createTeacher(
    data: Partial<TeacherProfile> & {
      tenant_id: string;
      full_name: string;
      email: string;
      gender?: 'L' | 'P';
      status?: 'ACTIVE' | 'INACTIVE' | 'SUSPENDED' | 'PENDING_VERIFICATION';
    },
    creatorUser: UserProfile
  ): Promise<TeacherProfile> {
    if (isSupabaseConfigured()) throw new Error('Pembuatan akun guru live wajib melalui Teacher Account Service/Edge Function.');
    // Business Rule Check: Guru cannot self-register, must be created by MASTER or KEPALA_SEKOLAH
    if (creatorUser.role !== 'MASTER' && creatorUser.role !== 'KEPALA_SEKOLAH') {
      throw new Error('Akses Ditolak: Hanya MASTER atau KEPALA SEKOLAH yang berwenang menambah akun guru.');
    }

    // Teacher Quota check
    const tenant = await tenantRepository.getById(data.tenant_id);
    if (!tenant) throw new Error('Tenant sekolah tidak ditemukan.');

    const currentTeachers = await this.getByTenant(data.tenant_id, creatorUser);
    const teacherStatus = data.status || 'ACTIVE';
    const quotaCheck = validateTeacherQuota(tenant, currentTeachers, undefined, teacherStatus);
    if (!quotaCheck.allowed) {
      throw new Error(quotaCheck.reason || 'Kuota guru terlampaui');
    }

    const newTeacher: TeacherProfile = {
      id: `t-${Date.now()}`,
      tenant_id: data.tenant_id,
      user_id: data.user_id || `usr-guru-${Date.now()}`,
      nip: data.nip,
      nuptk: data.nuptk,
      full_name: data.full_name,
      gender: data.gender || 'L',
      phone: data.phone || '',
      email: data.email,
      subject_specialty: data.subject_specialty || ['Umum'],
      employment_type: data.employment_type || 'GTY',
      status: teacherStatus,
      join_date: data.join_date || new Date().toISOString().split('T')[0],
      created_by: creatorUser.id,
      assignments: data.assignments || [],
      role: data.role || 'GURU',
    };

    const supabase = getSupabase();
    if (supabase) {
      const { data: inserted, error } = await supabase
        .from('teachers')
        .insert([newTeacher])
        .select()
        .single();
      if (!error && inserted) {
        if (teacherStatus === 'ACTIVE') {
          await tenantRepository.updateActiveTeacherCount(data.tenant_id, 1);
        }
        return inserted as TeacherProfile;
      }
    }

    this.teachers.push(newTeacher);

    // Automatically provision user profile for login & permission access
    const newUserProfile: UserProfile = {
      id: newTeacher.user_id,
      tenant_id: newTeacher.tenant_id,
      email: newTeacher.email.toLowerCase().trim(),
      full_name: newTeacher.full_name,
      phone: newTeacher.phone,
      role: newTeacher.role || 'GURU',
      status: teacherStatus === 'ACTIVE' ? 'ACTIVE' : 'INACTIVE',
      assignments: newTeacher.assignments || [],
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    };
    await userRepository.addUser(newUserProfile);

    if (teacherStatus === 'ACTIVE') {
      await tenantRepository.updateActiveTeacherCount(data.tenant_id, 1);
    }
    return newTeacher;
  }

  async updateTeacherStatus(teacherId: string, newStatus: 'ACTIVE' | 'INACTIVE', actorUser: UserProfile): Promise<TeacherProfile> {
    const supabase = getSupabase();
    if (isSupabaseConfigured() && supabase) {
      const { data: updated, error } = await supabase.rpc('scola_set_teacher_status', {
        p_teacher_id: teacherId,
        p_new_status: newStatus,
      });
      if (error) throw new Error(`Gagal memperbarui status guru: ${error.message}`);
      if (!updated) throw new Error('Perubahan status guru tidak menghasilkan data.');
      return updated as TeacherProfile;
    }
    const teacher = this.teachers.find(t => t.id === teacherId);
    if (!teacher) throw new Error('Data guru tidak ditemukan');
    if (actorUser.role !== 'MASTER' && actorUser.tenant_id !== teacher.tenant_id) throw new Error('Akses ditolak: Tenant mismatch');
    if (actorUser.role !== 'MASTER' && actorUser.role !== 'KEPALA_SEKOLAH') throw new Error('Akses ditolak.');
    if (newStatus !== teacher.status) {
      const oldStatus = teacher.status;
      teacher.status = newStatus;
      if (newStatus === 'INACTIVE' && !teacher.exit_date) teacher.exit_date = new Date().toISOString().split('T')[0];
      else if (newStatus === 'ACTIVE') teacher.exit_date = undefined;
      if (oldStatus !== 'ACTIVE' && newStatus === 'ACTIVE') await tenantRepository.updateActiveTeacherCount(teacher.tenant_id, 1);
      else if (oldStatus === 'ACTIVE' && newStatus === 'INACTIVE') await tenantRepository.updateActiveTeacherCount(teacher.tenant_id, -1);
    }
    return teacher;
  }
}

export const teacherRepository = new TeacherRepository();
