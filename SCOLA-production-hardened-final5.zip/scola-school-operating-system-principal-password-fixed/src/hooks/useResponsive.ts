import { useState, useEffect } from 'react';
import { ViewportMode } from '../types';

export function useResponsive() {
  const [viewportMode, setViewportMode] = useState<ViewportMode>('desktop');
  const [windowWidth, setWindowWidth] = useState<number>(
    typeof window !== 'undefined' ? window.innerWidth : 1200
  );

  useEffect(() => {
    const handleResize = () => {
      setWindowWidth(window.innerWidth);
    };
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  const isNativeMobile = windowWidth < 768;
  const isNativeTablet = windowWidth >= 768 && windowWidth < 1024;
  const isNativeDesktop = windowWidth >= 1024;

  // Effective mode takes simulated viewport into account
  const effectiveIsMobile = viewportMode === 'mobile' || (viewportMode === 'desktop' && isNativeMobile);
  const effectiveIsTablet = viewportMode === 'tablet' || (viewportMode === 'desktop' && isNativeTablet);
  const effectiveIsDesktop = viewportMode === 'desktop' && isNativeDesktop;

  return {
    viewportMode,
    setViewportMode,
    isMobile: effectiveIsMobile,
    isTablet: effectiveIsTablet,
    isDesktop: effectiveIsDesktop,
    windowWidth,
  };
}
