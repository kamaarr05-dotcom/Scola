import {
  Tenant,
  TeacherProfile,
  UserProfile,
  LicenseUsage,
  QuotaAuditLog,
  TEACHER_LICENSE_PRICE_PER_MONTH,
} from '../types';
import { tenantRepository } from '../repositories/tenantRepository';
import { teacherRepository } from '../repositories/teacherRepository';
import { auditService } from './auditService';
import { validateQuotaModificationAuthority } from '../lib/quotaValidator';

/**
 * Per-tenant Async Mutex to prevent race conditions during concurrent teacher activations.
 * Guarantees that two simultaneous activation requests serialize strictly on the tenant lock.
 */
class TenantMutex {
  private locks = new Map<string, Promise<void>>();

  async runExclusive<T>(tenantId: string, fn: () => Promise<T>): Promise<T> {
    while (this.locks.has(tenantId)) {
      await this.locks.get(tenantId);
    }
    let releaseLock: () => void = () => {};
    const lockPromise = new Promise<void>((resolve) => {
      releaseLock = resolve;
    });
    this.locks.set(tenantId, lockPromise);
    try {
      return await fn();
    } finally {
      this.locks.delete(tenantId);
      releaseLock();
    }
  }
}

// Initial seed quota change audit logs
const INITIAL_QUOTA_AUDITS: QuotaAuditLog[] = [
  {
    id: 'qa-001',
    timestamp: new Date(Date.now() - 86400000 * 10).toISOString(),
    tenant_id: 'tenant-sma-01',
    tenant_name: 'SMA Negeri 1 Nusantara',
    actor_id: 'usr-master',
    actor_email: 'mdqputra@gmail.com',
    actor_role: 'MASTER',
    action: 'QUOTA_CHANGED',
    quota_before: 30,
    quota_after: 40,
    reason: 'Penambahan rombel baru Semester Ganjil 2024/2025',
    status: 'SUCCESS',
    details: 'Alokasi kuota ditingkatkan dari 30 menjadi 40 slot guru oleh Master Platform.',
  },
  {
    id: 'qa-002',
    timestamp: new Date(Date.now() - 86400000 * 5).toISOString(),
    tenant_id: 'tenant-smk-02',
    tenant_name: 'SMK Teknologi Unggul',
    actor_id: 'usr-master',
    actor_email: 'mdqputra@gmail.com',
    actor_role: 'MASTER',
    action: 'QUOTA_CHANGED',
    quota_before: 20,
    quota_after: 25,
    reason: 'Pembukaan konsentrasi keahlian Rekayasa Perangkat Lunak',
    status: 'SUCCESS',
    details: 'Alokasi kuota ditingkatkan dari 20 menjadi 25 slot guru oleh Master Platform.',
  },
  {
    id: 'qa-003',
    timestamp: new Date(Date.now() - 86400000 * 2).toISOString(),
    tenant_id: 'tenant-sma-01',
    tenant_name: 'SMA Negeri 1 Nusantara',
    actor_id: 'usr-kepsek-sma',
    actor_email: 'kepsek@sman1nusantara.sch.id',
    actor_role: 'KEPALA_SEKOLAH',
    action: 'TEACHER_DEACTIVATED',
    quota_before: 40,
    quota_after: 40,
    teacher_id: 't-retno-history',
    teacher_name: 'Dra. Hj. Retno Wulandari',
    reason: 'Pensiun guru senior. Slot lisensi dibebaskan, seluruh nilai & absensi historis dipertahankan.',
    status: 'SUCCESS',
    details: 'Guru pensiun dinonaktifkan. 1 slot lisensi aktif dibebaskan.',
  },
];

class TeacherLicenseService {
  private tenantMutex = new TenantMutex();
  private auditLogs: QuotaAuditLog[] = [...INITIAL_QUOTA_AUDITS];

  private recordQuotaAudit(log: QuotaAuditLog): void {
    this.auditLogs.unshift(log);
  }

  /**
   * Calculates monthly license cost based on SCOLA's locked business rule (Rp15.000 / guru aktif / bulan)
   */
  calculateMonthlyCost(activeTeachersCount: number): number {
    return Math.max(0, activeTeachersCount) * TEACHER_LICENSE_PRICE_PER_MONTH;
  }

  /**
   * Retrieves accurate license usage metric for a specific tenant.
   */
  async getLicenseUsage(tenantId: string): Promise<LicenseUsage> {
    const tenant = await tenantRepository.getById(tenantId);
    if (!tenant) {
      throw new Error(`Tenant '${tenantId}' tidak ditemukan.`);
    }

    const masterBypass: UserProfile = {
      id: 'sys-license',
      tenant_id: null,
      email: 'sys@scola.id',
      full_name: 'System License Worker',
      role: 'MASTER',
      status: 'ACTIVE',
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    };

    const teachers = await teacherRepository.getByTenant(tenantId, masterBypass);
    
    // Count strictly active teachers (status === 'ACTIVE').
    // Crucial rule: Assignments do NOT affect license count. 1 teacher with 5 assignments = 1 license.
    const uniqueActiveTeacherIds = new Set(
      teachers.filter((t) => t.status === 'ACTIVE').map((t) => t.id)
    );

    const activeCount = uniqueActiveTeacherIds.size;
    const totalQuota = tenant.teacher_quota;
    const availableSlots = Math.max(0, totalQuota - activeCount);
    const usagePercentage = totalQuota > 0 ? Math.min(100, Math.round((activeCount / totalQuota) * 100)) : 0;
    const isFull = activeCount >= totalQuota;

    return {
      tenant_id: tenant.id,
      tenant_name: tenant.name,
      tenant_slug: tenant.slug,
      tenant_type: tenant.type,
      subscription_tier: tenant.subscription_tier,
      total_quota: totalQuota,
      used_licenses: activeCount,
      available_licenses: availableSlots,
      usage_percentage: usagePercentage,
      is_full: isFull,
      price_per_teacher: TEACHER_LICENSE_PRICE_PER_MONTH,
      estimated_monthly_cost: this.calculateMonthlyCost(activeCount),
      last_updated: tenant.updated_at,
    };
  }

  /**
   * Retrieves license usage for all tenants (Master Platform Dashboard).
   */
  async getAllTenantsLicenseUsage(): Promise<LicenseUsage[]> {
    const allTenants = await tenantRepository.getAll();
    const usages: LicenseUsage[] = [];
    for (const t of allTenants) {
      const usage = await this.getLicenseUsage(t.id);
      usages.push(usage);
    }
    return usages;
  }

  /**
   * Pre-check whether an active teacher can be added or reactivated.
   */
  async validateActivationAvailability(
    tenantId: string,
    targetTeacherId?: string
  ): Promise<{ allowed: boolean; reason?: string; used: number; quota: number; available: number }> {
    const usage = await this.getLicenseUsage(tenantId);
    
    // If target teacher is already active, no new slot is required
    if (targetTeacherId) {
      const masterBypass: UserProfile = {
        id: 'sys-check',
        tenant_id: null,
        email: 'sys@scola.id',
        full_name: 'Sys',
        role: 'MASTER',
        status: 'ACTIVE',
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      };
      const teachers = await teacherRepository.getByTenant(tenantId, masterBypass);
      const teacher = teachers.find((t) => t.id === targetTeacherId);
      if (teacher && teacher.status === 'ACTIVE') {
        return {
          allowed: true,
          used: usage.used_licenses,
          quota: usage.total_quota,
          available: usage.available_licenses,
        };
      }
    }

    if (usage.is_full) {
      return {
        allowed: false,
        reason: 'Kuota guru telah habis. Silakan hubungi administrator SCOLA untuk menambah lisensi.',
        used: usage.used_licenses,
        quota: usage.total_quota,
        available: 0,
      };
    }

    return {
      allowed: true,
      used: usage.used_licenses,
      quota: usage.total_quota,
      available: usage.available_licenses,
    };
  }

  /**
   * Activates a teacher with Strict Server-Side Concurrency Row Locking (Mutex).
   * Throws exact message when quota full: "Kuota guru telah habis. Silakan hubungi administrator SCOLA untuk menambah lisensi."
   */
  async activateTeacher(params: {
    tenantId: string;
    teacherId: string;
    actor: UserProfile;
  }): Promise<{ success: boolean; teacher: TeacherProfile; auditLog: QuotaAuditLog }> {
    const { tenantId, teacherId, actor } = params;

    // Authorization check
    if (actor.role !== 'MASTER' && (actor.role !== 'KEPALA_SEKOLAH' || actor.tenant_id !== tenantId)) {
      throw new Error('Akses Ditolak: Hanya MASTER atau Kepala Sekolah yang berwenang mengaktifkan guru.');
    }

    // Execute under per-tenant mutex lock to prevent concurrent over-activation race condition
    return await this.tenantMutex.runExclusive(tenantId, async () => {
      const tenant = await tenantRepository.getById(tenantId);
      if (!tenant) throw new Error('Tenant sekolah tidak ditemukan.');

      const teachers = await teacherRepository.getByTenant(tenantId, actor);
      const teacher = teachers.find((t) => t.id === teacherId);
      if (!teacher) throw new Error('Data guru tidak ditemukan dalam sekolah ini.');

      if (teacher.status === 'ACTIVE') {
        const auditLog: QuotaAuditLog = {
          id: `qa-${Date.now()}`,
          timestamp: new Date().toISOString(),
          tenant_id: tenantId,
          tenant_name: tenant.name,
          actor_id: actor.id,
          actor_email: actor.email,
          actor_role: actor.role,
          action: 'TEACHER_ACTIVATED',
          teacher_id: teacher.id,
          teacher_name: teacher.full_name,
          status: 'SUCCESS',
          details: `Guru ${teacher.full_name} sudah dalam status aktif.`,
        };
        return { success: true, teacher, auditLog };
      }

      // Count active teachers strictly
      const activeCount = teachers.filter((t) => t.status === 'ACTIVE' && t.id !== teacherId).length;

      if (activeCount + 1 > tenant.teacher_quota) {
        const rejectedLog: QuotaAuditLog = {
          id: `qa-${Date.now()}`,
          timestamp: new Date().toISOString(),
          tenant_id: tenantId,
          tenant_name: tenant.name,
          actor_id: actor.id,
          actor_email: actor.email,
          actor_role: actor.role,
          action: 'TEACHER_ACTIVATION_REJECTED',
          quota_before: tenant.teacher_quota,
          quota_after: tenant.teacher_quota,
          teacher_id: teacher.id,
          teacher_name: teacher.full_name,
          reason: 'Aktivasi ditolak karena kuota guru penuh.',
          status: 'REJECTED',
          details: `Aktivasi ${teacher.full_name} ditolak. Kapasitas penuh: ${activeCount}/${tenant.teacher_quota}.`,
        };
        this.recordQuotaAudit(rejectedLog);

        await auditService.recordEvent({
          event: 'TEACHER_ACTIVATION_REJECTED',
          email: actor.email,
          user_id: actor.id,
          role: actor.role,
          tenant_id: tenantId,
          status: 'WARNING',
          details: `Aktivasi guru ${teacher.full_name} ditolak: kuota penuh (${activeCount}/${tenant.teacher_quota}).`,
          quota_before: tenant.teacher_quota,
          quota_after: tenant.teacher_quota,
          teacher_id: teacher.id,
          teacher_name: teacher.full_name,
        });

        // Exact business rule error message requested:
        throw new Error('Kuota guru telah habis. Silakan hubungi administrator SCOLA untuk menambah lisensi.');
      }

      // Perform activation
      const updatedTeacher = await teacherRepository.updateTeacherStatus(teacherId, 'ACTIVE', actor);

      const auditLog: QuotaAuditLog = {
        id: `qa-${Date.now()}`,
        timestamp: new Date().toISOString(),
        tenant_id: tenantId,
        tenant_name: tenant.name,
        actor_id: actor.id,
        actor_email: actor.email,
        actor_role: actor.role,
        action: 'TEACHER_ACTIVATED',
        quota_before: tenant.teacher_quota,
        quota_after: tenant.teacher_quota,
        teacher_id: updatedTeacher.id,
        teacher_name: updatedTeacher.full_name,
        reason: 'Aktivasi akun guru pengajar',
        status: 'SUCCESS',
        details: `Guru ${updatedTeacher.full_name} diaktifkan. Penggunaan lisensi: ${activeCount + 1}/${tenant.teacher_quota}.`,
      };
      this.recordQuotaAudit(auditLog);

      await auditService.recordEvent({
        event: 'TEACHER_ACTIVATED',
        email: actor.email,
        user_id: actor.id,
        role: actor.role,
        tenant_id: tenantId,
        status: 'SUCCESS',
        details: `Guru ${updatedTeacher.full_name} aktif. Lisensi terpakai: ${activeCount + 1}/${tenant.teacher_quota}.`,
        teacher_id: updatedTeacher.id,
        teacher_name: updatedTeacher.full_name,
      });

      return { success: true, teacher: updatedTeacher, auditLog };
    });
  }

  /**
   * Deactivates a teacher.
   * Freeing 1 license slot without deleting any historical data (grades, attendance, timetable, assignments).
   */
  async deactivateTeacher(params: {
    tenantId: string;
    teacherId: string;
    actor: UserProfile;
    reason?: string;
  }): Promise<{ success: boolean; teacher: TeacherProfile; auditLog: QuotaAuditLog }> {
    const { tenantId, teacherId, actor, reason = 'Nonaktif / Pensiun' } = params;

    if (actor.role !== 'MASTER' && (actor.role !== 'KEPALA_SEKOLAH' || actor.tenant_id !== tenantId)) {
      throw new Error('Akses Ditolak: Hanya MASTER atau Kepala Sekolah yang berwenang menonaktifkan guru.');
    }

    return await this.tenantMutex.runExclusive(tenantId, async () => {
      const tenant = await tenantRepository.getById(tenantId);
      if (!tenant) throw new Error('Tenant sekolah tidak ditemukan.');

      const teachers = await teacherRepository.getByTenant(tenantId, actor);
      const teacher = teachers.find((t) => t.id === teacherId);
      if (!teacher) throw new Error('Data guru tidak ditemukan.');

      if (teacher.status === 'INACTIVE') {
        const auditLog: QuotaAuditLog = {
          id: `qa-${Date.now()}`,
          timestamp: new Date().toISOString(),
          tenant_id: tenantId,
          tenant_name: tenant.name,
          actor_id: actor.id,
          actor_email: actor.email,
          actor_role: actor.role,
          action: 'TEACHER_DEACTIVATED',
          teacher_id: teacher.id,
          teacher_name: teacher.full_name,
          status: 'SUCCESS',
          details: `Guru ${teacher.full_name} sudah dalam status nonaktif.`,
        };
        return { success: true, teacher, auditLog };
      }

      const updatedTeacher = await teacherRepository.updateTeacherStatus(teacherId, 'INACTIVE', actor);

      const auditLog: QuotaAuditLog = {
        id: `qa-${Date.now()}`,
        timestamp: new Date().toISOString(),
        tenant_id: tenantId,
        tenant_name: tenant.name,
        actor_id: actor.id,
        actor_email: actor.email,
        actor_role: actor.role,
        action: 'TEACHER_DEACTIVATED',
        quota_before: tenant.teacher_quota,
        quota_after: tenant.teacher_quota,
        teacher_id: updatedTeacher.id,
        teacher_name: updatedTeacher.full_name,
        reason,
        status: 'SUCCESS',
        details: `Guru ${updatedTeacher.full_name} dinonaktifkan (${reason}). 1 slot lisensi guru dibebaskan. Data historis nilai dan absensi tetap utuh.`,
      };
      this.recordQuotaAudit(auditLog);

      await auditService.recordEvent({
        event: 'TEACHER_DEACTIVATED',
        email: actor.email,
        user_id: actor.id,
        role: actor.role,
        tenant_id: tenantId,
        status: 'SUCCESS',
        details: `Guru ${updatedTeacher.full_name} dinonaktifkan (${reason}). 1 slot lisensi dibebaskan. Data historis dipertahankan.`,
        teacher_id: updatedTeacher.id,
        teacher_name: updatedTeacher.full_name,
      });

      return { success: true, teacher: updatedTeacher, auditLog };
    });
  }

  /**
   * Updates Tenant Quota.
   * STRICT SECURITY RULE: ONLY MASTER CAN UPDATE QUOTA.
   */
  async updateTenantQuota(params: {
    tenantId: string;
    newQuota: number;
    actor: UserProfile;
    reason?: string;
  }): Promise<{ success: boolean; tenant: Tenant; auditLog: QuotaAuditLog }> {
    const { tenantId, newQuota, actor, reason = 'Penyesuaian kuota lisensi oleh Master' } = params;

    const tenant = await tenantRepository.getById(tenantId);
    if (!tenant) throw new Error('Tenant sekolah tidak ditemukan.');

    const usage = await this.getLicenseUsage(tenantId);
    const authCheck = validateQuotaModificationAuthority(actor.role, newQuota, usage.used_licenses);
    if (!authCheck.allowed) {
      throw new Error(authCheck.reason);
    }

    const quotaBefore = tenant.teacher_quota;
    const updatedTenant = await tenantRepository.updateQuota(tenantId, newQuota);

    const auditLog: QuotaAuditLog = {
      id: `qa-${Date.now()}`,
      timestamp: new Date().toISOString(),
      tenant_id: tenantId,
      tenant_name: tenant.name,
      actor_id: actor.id,
      actor_email: actor.email,
      actor_role: actor.role,
      action: 'QUOTA_CHANGED',
      quota_before: quotaBefore,
      quota_after: newQuota,
      reason,
      status: 'SUCCESS',
      details: `Kuota diubah dari ${quotaBefore} menjadi ${newQuota} oleh Master (${actor.email}). Alasan: ${reason}.`,
    };
    this.recordQuotaAudit(auditLog);

    await auditService.recordEvent({
      event: 'QUOTA_CHANGED',
      email: actor.email,
      user_id: actor.id,
      role: actor.role,
      tenant_id: tenantId,
      status: 'SUCCESS',
      details: `Kuota lisensi ${tenant.name} diubah (${quotaBefore} -> ${newQuota}). Alasan: ${reason}.`,
      quota_before: quotaBefore,
      quota_after: newQuota,
      reason,
    });

    return { success: true, tenant: updatedTenant, auditLog };
  }

  /**
   * Retrieves Quota Audit History respecting tenant boundary.
   * Master sees all tenants; Principal only sees own tenant.
   */
  async getQuotaAuditLogs(
    tenantId?: string | null,
    isMaster = false
  ): Promise<QuotaAuditLog[]> {
    if (isMaster) {
      return [...this.auditLogs];
    }
    if (!tenantId) {
      return [];
    }
    return this.auditLogs.filter((log) => log.tenant_id === tenantId);
  }

  clearAuditLogs(): void {
    this.auditLogs = [];
  }
}

export const teacherLicenseService = new TeacherLicenseService();
