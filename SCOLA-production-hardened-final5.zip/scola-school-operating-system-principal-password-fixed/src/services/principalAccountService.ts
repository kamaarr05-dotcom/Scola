import { getSupabase, isSupabaseConfigured } from '../config/supabase';
import { UserProfile } from '../types';
import { userRepository } from '../repositories/userRepository';

export interface PrincipalAccountInput {
  tenant_id: string;
  full_name: string;
  email: string;
  password: string;
  phone?: string;
  nip?: string;
}

/**
 * Provisions a real Supabase Auth account for a Kepala Sekolah.
 * In demo/offline mode the existing in-memory login flow is preserved.
 */
class PrincipalAccountService {
  async createPrincipalAccount(input: PrincipalAccountInput, actor: UserProfile): Promise<UserProfile> {
    if (actor.role !== 'MASTER') {
      throw new Error('Akses Ditolak: Hanya MASTER yang dapat membuat akun Kepala Sekolah.');
    }

    const email = input.email.toLowerCase().trim();
    const fullName = input.full_name.trim();
    if (!fullName || !email || !input.tenant_id) {
      throw new Error('Sekolah, nama lengkap, dan email wajib diisi.');
    }
    if (input.password.length < 8) {
      throw new Error('Password minimal 8 karakter.');
    }

    if (isSupabaseConfigured()) {
      const supabase = getSupabase();
      if (!supabase) throw new Error('Koneksi Supabase belum siap.');

      const { data, error } = await supabase.functions.invoke('provision-principal-account', {
        body: {
          tenant_id: input.tenant_id,
          full_name: fullName,
          email,
              phone: input.phone || null,
          nip: input.nip || null,
        },
      });

      if (error) {
        throw new Error(
          error.message ||
            'Gagal membuat akun Kepala Sekolah. Pastikan Edge Function provision-principal-account sudah dideploy di Supabase.'
        );
      }
      if (!data?.principal) {
        throw new Error('Akun Kepala Sekolah tidak berhasil diprovisioning oleh server.');
      }
      return data.principal as UserProfile;
    }

    // Demo/offline mode: password is intentionally retained for demo login/audit.
    const newPrincipal: UserProfile = {
      id: `usr-kepsek-${Date.now()}`,
      tenant_id: input.tenant_id,
      email,
      full_name: fullName,
      phone: input.phone,
      nip: input.nip,
      role: 'KEPALA_SEKOLAH',
      status: 'ACTIVE',
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    };
    await userRepository.addUser(newPrincipal);
    return newPrincipal;
  }
}

export const principalAccountService = new PrincipalAccountService();
