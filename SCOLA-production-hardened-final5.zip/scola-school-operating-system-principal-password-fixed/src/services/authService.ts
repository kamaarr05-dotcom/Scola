import { UserProfile, ScolaRole } from '../types';
import { INITIAL_USERS } from '../data/mockDatabase';
import { getSupabase, isSupabaseConfigured } from '../config/supabase';
import { auditService } from './auditService';
import { userRepository } from '../repositories/userRepository';
import { tenantRepository } from '../repositories/tenantRepository';

export interface AuthSession {
  user: UserProfile;
  access_token: string;
  expires_at: number;
}

class AuthService {
  private currentUser: UserProfile | null = null;
  private currentSession: AuthSession | null = null;
  private listeners: ((user: UserProfile | null) => void)[] = [];
  private ready = false;

  constructor() {
    if (isSupabaseConfigured()) {
      void this.restoreLiveSession();
    } else if (typeof window !== 'undefined') {
      try {
        const saved = localStorage.getItem('scola_current_user');
        if (saved) this.currentUser = JSON.parse(saved);
      } catch { this.currentUser = null; }
      this.ready = true;
    }
  }

  private async restoreLiveSession(): Promise<void> {
    const supabase = getSupabase();
    if (!supabase) { this.ready = true; this.notify(null); return; }
    try {
      const { data } = await supabase.auth.getSession();
      if (!data.session?.user) { this.currentSession = null; this.ready = true; this.notify(null); return; }
      const { data: profile, error } = await supabase.from('user_profiles').select('*').eq('id', data.session.user.id).single();
      if (error || !profile) { await supabase.auth.signOut(); this.currentSession = null; this.ready = true; this.notify(null); return; }
      const user = await this.hydrateLiveAssignments(profile as UserProfile);
      if (user.status !== 'ACTIVE') { await supabase.auth.signOut(); this.currentSession = null; this.ready = true; this.notify(null); return; }
      if (user.role !== 'MASTER' && user.tenant_id) {
        const { data: tenant } = await supabase.from('tenants').select('is_active').eq('id', user.tenant_id).single();
        if (!tenant?.is_active) { await supabase.auth.signOut(); this.currentSession = null; this.ready = true; this.notify(null); return; }
      }
      this.currentSession = { user, access_token: data.session.access_token, expires_at: (data.session.expires_at || Math.floor(Date.now()/1000)+3600)*1000 };
      this.ready = true; this.notify(user);
    } catch { this.currentSession = null; this.ready = true; this.notify(null); }
  }

  onAuthStateChanged(callback: (user: UserProfile | null) => void): () => void {
    this.listeners.push(callback);
    if (this.ready) callback(this.currentUser);
    return () => {
      this.listeners = this.listeners.filter((l) => l !== callback);
    };
  }

  subscribe(callback: (user: UserProfile | null) => void): () => void {
    return this.onAuthStateChanged(callback);
  }


  private async hydrateLiveAssignments(user: UserProfile): Promise<UserProfile> {
    if (!isSupabaseConfigured() || !user.tenant_id || user.role !== 'GURU') return user;
    const supabase = getSupabase();
    if (!supabase) return user;
    const { data: assignments, error } = await supabase
      .from('teacher_assignments')
      .select('*')
      .eq('tenant_id', user.tenant_id)
      .eq('teacher_user_id', user.id)
      .eq('active', true)
      .order('assigned_at', { ascending: false });
    if (error) throw new Error(`Gagal memuat penugasan guru: ${error.message}`);
    return { ...user, assignments: (assignments || []) as UserProfile['assignments'] };
  }

  private notify(user: UserProfile | null) {
    this.currentUser = user;
    if (typeof window !== 'undefined') {
      if (user) {
        localStorage.setItem('scola_current_user', JSON.stringify(user));
      } else {
        localStorage.removeItem('scola_current_user');
      }
    }
    this.listeners.forEach((l) => l(user));
  }

  getCurrentUser(): UserProfile | null {
    return this.currentUser;
  }

  getCurrentSession(): AuthSession | null {
    return this.currentSession;
  }

  /**
   * Universal Login Handler:
   * Uses Supabase Auth in live mode; repository credentials are used only in offline/demo mode.
   * Special Rule: Master user (mdqputra@gmail.com) has global bypass access.
   */
  async login(
    email: string,
    password?: string,
    tenantId?: string | null
  ): Promise<{ user: UserProfile; session: AuthSession }> {
    const cleanEmail = email.toLowerCase().trim();

    // Check if live Supabase Auth is configured and usable
    if (isSupabaseConfigured() && password) {
      const supabase = getSupabase();
      if (supabase) {
        try {
          const { data: authData, error: authError } = await supabase.auth.signInWithPassword({
            email: cleanEmail,
            password,
          });

          if (authError) {
            await auditService.recordEvent({
              event: 'LOGIN_FAILED',
              email: cleanEmail,
              status: 'FAILED',
              details: `Supabase Auth login failed: ${authError.message}`,
            });
            throw new Error('Email atau kata sandi salah.');
          }

          if (authData.user) {
            const { data: profile, error: profileError } = await supabase
              .from('user_profiles')
              .select('*')
              .eq('id', authData.user.id)
              .single();

            if (profileError || !profile) {
              await supabase.auth.signOut();
              throw new Error('Profil akun SCOLA belum tersedia. Hubungi administrator sekolah.');
            }

            const userProfile = await this.hydrateLiveAssignments(profile as UserProfile);
            if (userProfile.role !== 'MASTER' && userProfile.tenant_id) {
              const { data: tenant, error: tenantError } = await supabase.from('tenants').select('is_active').eq('id', userProfile.tenant_id).single();
              if (tenantError || !tenant?.is_active) {
                await supabase.auth.signOut();
                throw new Error('Layanan untuk sekolah sedang dinonaktifkan atau belum tersedia.');
              }
            }
            if (userProfile.status !== 'ACTIVE') {
              await supabase.auth.signOut();
              await auditService.recordEvent({
                event: 'LOGIN_FAILED',
                email: userProfile.email,
                user_id: userProfile.id,
                role: userProfile.role,
                tenant_id: userProfile.tenant_id,
                status: 'FAILED',
                details: `Login blocked. User status is ${userProfile.status}.`,
              });
              if (userProfile.status === 'PENDING_VERIFICATION') {
                throw new Error('Akun siswa belum aktif. Pendaftaran masih menunggu persetujuan Wali Kelas.');
              }
              throw new Error(`Akun Anda berstatus ${userProfile.status}. Silakan hubungi pihak sekolah.`);
            }

            const session: AuthSession = {
              user: userProfile,
              access_token: authData.session?.access_token || 'sb-jwt-token',
              expires_at: Date.now() + 3600 * 1000,
            };
            this.currentSession = session;
            this.notify(userProfile);

            await auditService.recordEvent({
              event: 'LOGIN_SUCCESS',
              email: userProfile.email,
              user_id: userProfile.id,
              role: userProfile.role,
              tenant_id: userProfile.tenant_id,
              status: 'SUCCESS',
              details: `Live Supabase Auth authenticated for ${userProfile.email}`,
            });

            return { user: userProfile, session };
          }
        } catch (error) {
          if (error instanceof Error) throw error;
          throw new Error('Login Supabase gagal diproses.');
        }
      }
    }

    if (isSupabaseConfigured()) throw new Error('Login live memerlukan email dan kata sandi yang valid.');

    // Repository & Mock User Lookup (offline/demo only)
    const users = await userRepository.getAll();
    let found = users.find((u) => u.email.toLowerCase() === cleanEmail);

    if (!found) {
      found = INITIAL_USERS.find((u) => u.email.toLowerCase() === cleanEmail);
    }

    // Specific provision for mdqputra@gmail.com
    if (!found && cleanEmail === 'mdqputra@gmail.com') {
      found = {
        id: 'usr-master',
        tenant_id: null,
        email: 'mdqputra@gmail.com',
        full_name: 'M. Daffa Q. Putra (Super Master)',
        role: 'MASTER',
        status: 'ACTIVE',
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      };
      await userRepository.addUser(found);
    }

    if (!found) {
      await auditService.recordEvent({
        event: 'LOGIN_FAILED',
        email: cleanEmail,
        status: 'FAILED',
        details: 'User with provided email not found in directory.',
      });
      throw new Error(`Email "${cleanEmail}" belum terdaftar dalam sistem SCOLA.`);
    }

    if (found.status !== 'ACTIVE') {
      await auditService.recordEvent({
        event: 'LOGIN_FAILED',
        email: cleanEmail,
        user_id: found.id,
        role: found.role,
        tenant_id: found.tenant_id,
        status: 'FAILED',
        details: `Login blocked. User status is ${found.status}.`,
      });
      throw new Error(`Akun Anda berstatus ${found.status}. Silakan hubungi pihak sekolah.`);
    }

    // Password validation for stored users (if user has a password set and password is provided)
    const storedPassword = (found as UserProfile & { password?: string }).password;
    if (password && storedPassword && storedPassword !== password) {
      await auditService.recordEvent({
        event: 'LOGIN_FAILED',
        email: cleanEmail,
        user_id: found.id,
        role: found.role,
        tenant_id: found.tenant_id,
        status: 'FAILED',
        details: 'Invalid password provided.',
      });
      throw new Error('Kata sandi salah. Silakan periksa kembali kata sandi akun Anda.');
    }

    // Tenant Check (Master can access without tenant)
    if (found.role !== 'MASTER' && found.tenant_id) {
      const tenant = await tenantRepository.getById(found.tenant_id);
      if (tenant && !tenant.is_active) {
        await auditService.recordEvent({
          event: 'LOGIN_FAILED',
          email: cleanEmail,
          user_id: found.id,
          role: found.role,
          tenant_id: found.tenant_id,
          status: 'FAILED',
          details: `Login blocked. Tenant "${tenant.name}" is INACTIVE.`,
        });
        throw new Error(
          `Layanan untuk sekolah "${tenant.name}" sedang dinonaktifkan oleh administrator platform.`
        );
      }
    }

    const session: AuthSession = {
      user: found,
      access_token: `scola-token-${found.id}-${Date.now()}`,
      expires_at: Date.now() + 24 * 3600 * 1000,
    };

    this.currentSession = session;
    this.notify(found);

    await auditService.recordEvent({
      event: 'LOGIN_SUCCESS',
      email: found.email,
      user_id: found.id,
      role: found.role,
      tenant_id: found.tenant_id,
      status: 'SUCCESS',
      details: `User ${found.full_name} (${found.role}) authenticated successfully.`,
    });

    return { user: found, session };
  }

  /**
   * Fast Demo Login by Email directly
   */
  async loginAsDemoEmail(targetEmail: string): Promise<UserProfile> {
    if (isSupabaseConfigured()) throw new Error('Login demo tidak tersedia pada mode live.');
    const { user } = await this.login(targetEmail);
    return user;
  }

  /**
   * Fast Demo / Testing Role Switcher
   */
  async switchRole(targetRole: ScolaRole, tenantType: 'SMA' | 'SMK' = 'SMA'): Promise<UserProfile> {
    if (isSupabaseConfigured()) throw new Error('Ganti Role hanya tersedia pada mode Demo/Offline. Silakan logout dan login dengan akun masing-masing.');
    const targetEmailMap: Record<ScolaRole, string> = {
      MASTER: 'mdqputra@gmail.com',
      KEPALA_SEKOLAH:
        tenantType === 'SMA'
          ? 'kepsek@sman1nusantara.sch.id'
          : 'kepsek@smkteknologiunggul.sch.id',
      GURU:
        tenantType === 'SMA'
          ? 'wali.kelas@sman1nusantara.sch.id'
          : 'hendra.kusuma@smkteknologiunggul.sch.id',
      SISWA:
        tenantType === 'SMA'
          ? 'rizky.pratama@siswa.scola.id'
          : 'rizky.firmansyah@student.smk.sch.id',
      ORANG_TUA: 'santoso.father@gmail.com',
      TENAGA_KEPENDIDIKAN: 'tu.admin@sman1nusantara.sch.id',
    };

    const targetEmail = targetEmailMap[targetRole];
    const { user } = await this.login(targetEmail);
    return user;
  }

  async logout(): Promise<void> {
    if (this.currentUser) {
      await auditService.recordEvent({
        event: 'LOGOUT',
        email: this.currentUser.email,
        user_id: this.currentUser.id,
        role: this.currentUser.role,
        tenant_id: this.currentUser.tenant_id,
        status: 'SUCCESS',
        details: `User ${this.currentUser.full_name} logged out.`,
      });
    }

    if (isSupabaseConfigured()) {
      const supabase = getSupabase();
      if (supabase) {
        try {
          await supabase.auth.signOut();
        } catch {
          // ignore
        }
      }
    }

    this.currentSession = null;
    this.notify(null);
  }

  /**
   * List of pre-configured demo credentials for the login modal
   * Note: Excludes MASTER as Master is the system owner.
   */
  getMockCredentials(): Array<{
    role: ScolaRole;
    label: string;
    email: string;
    description: string;
    tenant: string;
    passwordHint: string;
    category?: 'PIMPINAN' | 'GURU' | 'KOMUNITAS';
  }> {
    if (isSupabaseConfigured()) return [];
    return [
      {
        role: 'KEPALA_SEKOLAH',
        label: 'Kepala Sekolah (Executive Command)',
        email: 'kepsek@sman1nusantara.sch.id',
        description: 'Monitoring KBM real-time, disposisi surat tugas, manajemen guru & supervisi akademik',
        tenant: 'SMA Negeri 1 Nusantara',
        passwordHint: 'Password123!',
        category: 'PIMPINAN',
      },
      {
        role: 'GURU',
        label: 'Waka Kurikulum',
        email: 'waka.kurikulum@sman1nusantara.sch.id',
        description: 'Manajemen struktur kurikulum merdeka, supervisi modul ajar, dan jadwal KBM',
        tenant: 'SMA Negeri 1 Nusantara',
        passwordHint: 'Password123!',
        category: 'PIMPINAN',
      },
      {
        role: 'GURU',
        label: 'Waka Kesiswaan',
        email: 'waka.kesiswaan@sman1nusantara.sch.id',
        description: 'Rekap kedisiplinan, izin/dispensasi siswa, OSIS, & pembinaan karakter',
        tenant: 'SMA Negeri 1 Nusantara',
        passwordHint: 'Password123!',
        category: 'PIMPINAN',
      },
      {
        role: 'GURU',
        label: 'Waka Sarana & Prasarana',
        email: 'waka.sarpras@sman1nusantara.sch.id',
        description: 'Inventarisasi ruang kelas, peminjaman lab/alat, & tiket perbaikan',
        tenant: 'SMA Negeri 1 Nusantara',
        passwordHint: 'Password123!',
        category: 'PIMPINAN',
      },
      {
        role: 'GURU',
        label: 'Waka Hubungan Masyarakat (Humas)',
        email: 'waka.humas@sman1nusantara.sch.id',
        description: 'Kemitraan dunia usaha/industri, publikasi prestasi, & agenda sekolah',
        tenant: 'SMA Negeri 1 Nusantara',
        passwordHint: 'Password123!',
        category: 'PIMPINAN',
      },
      {
        role: 'GURU',
        label: 'Wali Kelas (X MIPA 1)',
        email: 'wali.kelas@sman1nusantara.sch.id',
        description: 'Approval pendaftaran siswa baru, matriks absensi per jam pelajaran, & kontak ortu',
        tenant: 'SMA Negeri 1 Nusantara',
        passwordHint: 'Password123!',
        category: 'GURU',
      },
      {
        role: 'GURU',
        label: 'Guru Mata Pelajaran (Fisika)',
        email: 'guru.mapel@sman1nusantara.sch.id',
        description: 'Presensi per jam pelajaran, input nilai formatif/sumatif, & penugasan tugas',
        tenant: 'SMA Negeri 1 Nusantara',
        passwordHint: 'Password123!',
        category: 'GURU',
      },
      {
        role: 'GURU',
        label: 'Guru Bimbingan Konseling (BK)',
        email: 'guru.bk@sman1nusantara.sch.id',
        description: 'Sesi konseling siswa, penelusuran minat bakat, & pendampingan SNBP',
        tenant: 'SMA Negeri 1 Nusantara',
        passwordHint: 'Password123!',
        category: 'GURU',
      },
      {
        role: 'TENAGA_KEPENDIDIKAN',
        label: 'Tenaga Kependidikan / TU',
        email: 'tu.admin@sman1nusantara.sch.id',
        description: 'Buku nomor surat, SPPD, administrasi kepegawaian, & fasilitas sekolah',
        tenant: 'SMA Negeri 1 Nusantara',
        passwordHint: 'Password123!',
        category: 'KOMUNITAS',
      },
      {
        role: 'SISWA',
        label: 'Siswa Aktif',
        email: 'rizky.pratama@siswa.scola.id',
        description: 'Jadwal belajar, presensi harian, nilai tugas, materi & e-Rapor',
        tenant: 'SMA Negeri 1 Nusantara',
        passwordHint: 'Password123!',
        category: 'KOMUNITAS',
      },
      {
        role: 'ORANG_TUA',
        label: 'Orang Tua Murid',
        email: 'santoso.father@gmail.com',
        description: 'Pantau presensi real-time anak (pagi & siang), nilai, dan komunikasi wali kelas',
        tenant: 'SMA Negeri 1 Nusantara',
        passwordHint: 'Password123!',
        category: 'KOMUNITAS',
      },
    ];
  }
}

export const authService = new AuthService();
