import { AuthAuditLog, ScolaRole } from '../types';
import { getSupabase, isSupabaseConfigured } from '../config/supabase';

// Seed initial authentic audit logs for demonstration
const INITIAL_AUDIT_LOGS: AuthAuditLog[] = [
  {
    id: 'audit-001',
    timestamp: new Date(Date.now() - 3600000 * 2).toISOString(),
    event: 'LOGIN_SUCCESS',
    user_id: 'usr-master',
    email: 'mdqputra@gmail.com',
    role: 'MASTER',
    tenant_id: null,
    ip_address: '10.0.4.12',
    user_agent: 'SCOLA-Web/1.0 (Chrome on macOS)',
    status: 'SUCCESS',
    details: 'Super Master Platform authentication verified via Supabase Auth JWT',
  },
  {
    id: 'audit-002',
    timestamp: new Date(Date.now() - 3600000 * 1.5).toISOString(),
    event: 'LOGIN_SUCCESS',
    user_id: 'usr-kepsek-sma',
    email: 'kepsek@sman1nusantara.sch.id',
    role: 'KEPALA_SEKOLAH',
    tenant_id: 'tenant-sma-01',
    ip_address: '182.253.14.88',
    user_agent: 'SCOLA-Web/1.0 (Firefox on Windows)',
    status: 'SUCCESS',
    details: 'Kepala Sekolah verified for SMAN 1 Nusantara (tenant-sma-01)',
  },
  {
    id: 'audit-003',
    timestamp: new Date(Date.now() - 3600000).toISOString(),
    event: 'LOGIN_FAILED',
    email: 'unknown.user@sekolah.id',
    role: undefined,
    tenant_id: null,
    ip_address: '114.125.77.20',
    user_agent: 'SCOLA-Mobile/Android (Capacitor)',
    status: 'FAILED',
    details: 'Invalid credentials. Password omitted for security compliance.',
  },
  {
    id: 'audit-004',
    timestamp: new Date(Date.now() - 1800000).toISOString(),
    event: 'LOGIN_SUCCESS',
    user_id: 'usr-guru-budi',
    email: 'budi.santoso@sman1nusantara.sch.id',
    role: 'GURU',
    tenant_id: 'tenant-sma-01',
    ip_address: '182.253.14.90',
    user_agent: 'SCOLA-Web/1.0 (Chrome on macOS)',
    status: 'SUCCESS',
    details: 'Guru with assignments [WALI_KELAS, WAKA_KURIKULUM] logged in',
  },
];

class AuditService {
  private logs: AuthAuditLog[] = isSupabaseConfigured() ? [] : [...INITIAL_AUDIT_LOGS];

  /**
   * Records an authentication or security event.
   * STRICT SECURITY RULE: Passwords MUST NEVER be included in details or parameters.
   */
  async recordEvent(params: {
    event: AuthAuditLog['event'];
    email: string;
    user_id?: string;
    role?: ScolaRole;
    tenant_id?: string | null;
    status: 'SUCCESS' | 'FAILED' | 'WARNING';
    details?: string;
    quota_before?: number;
    quota_after?: number;
    reason?: string;
    teacher_id?: string;
    teacher_name?: string;
    student_id?: string;
    student_name?: string;
    nisn?: string;
    old_value?: string;
    new_value?: string;
    tenant_name?: string;
    principal_name?: string;
  }): Promise<AuthAuditLog> {
    const logEntry: AuthAuditLog = {
      id: `audit-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
      timestamp: new Date().toISOString(),
      event: params.event,
      email: params.email,
      user_id: params.user_id,
      role: params.role,
      tenant_id: params.tenant_id,
      tenant_name: params.tenant_name,
      ip_address: '127.0.0.1 (Client Gateway)',
      user_agent: typeof navigator !== 'undefined' ? navigator.userAgent : 'SCOLA-Client/1.0',
      status: params.status,
      details: params.details,
      quota_before: params.quota_before,
      quota_after: params.quota_after,
      reason: params.reason,
      teacher_id: params.teacher_id,
      teacher_name: params.teacher_name,
      student_id: params.student_id,
      student_name: params.student_name,
      nisn: params.nisn,
      old_value: params.old_value,
      new_value: params.new_value,
      principal_name: params.principal_name,
    };

    // Prepend to local memory store (capped at 100 entries)
    this.logs = [logEntry, ...this.logs.slice(0, 99)];

    // If live Supabase is configured with an active session, write to audit_logs table
    if (isSupabaseConfigured()) {
      const supabase = getSupabase();
      if (supabase) {
        try {
          const { data: auditId, error } = await supabase.rpc('scola_record_audit', {
            p_event: logEntry.event,
            p_status: logEntry.status,
            p_details: logEntry.details || null,
            p_email: logEntry.email || null,
            p_tenant_id: logEntry.tenant_id || null,
            p_role: logEntry.role || null,
          });
          if (error) throw error;
          if (auditId) logEntry.id = String(auditId);
        } catch (error) {
          // Login-failure events can occur before a Supabase session exists, so the
          // authenticated-only RPC cannot persist them. Keep a local diagnostic
          // record in that unauthenticated case; for authenticated operations,
          // surface the failure so critical writes are not silently un-audited.
          const { data: sessionData } = await supabase.auth.getSession();
          if (sessionData.session) {
            throw new Error(`Audit log gagal disimpan ke Supabase: ${error instanceof Error ? error.message : 'Database error'}`);
          }
          console.warn('Audit log belum dapat dikirim: sesi Supabase belum tersedia.', error);
        }
      }
    }

    return logEntry;
  }

  /**
   * Retrieves audit logs respecting tenant boundaries.
   * Master sees all; School Admins only see logs for their tenant.
   */
  async getLogs(
    tenantIdOrOptions?: string | null | { tenant_id?: string | null; limit?: number },
    isMaster = false
  ): Promise<AuthAuditLog[]> {
    let tenantId: string | null | undefined;
    let master = isMaster;
    let limit = 100;
    if (typeof tenantIdOrOptions === 'object' && tenantIdOrOptions !== null) {
      tenantId = tenantIdOrOptions.tenant_id;
      limit = Math.min(Math.max(tenantIdOrOptions.limit ?? 100, 1), 500);
      master = !tenantId;
    } else if (typeof tenantIdOrOptions === 'string') {
      tenantId = tenantIdOrOptions;
    }
    if (isSupabaseConfigured()) {
      const supabase = getSupabase();
      if (!supabase) return [];
      let query = supabase.from('audit_logs').select('*').order('timestamp', { ascending: false }).limit(limit);
      if (!master && tenantId) query = query.eq('tenant_id', tenantId);
      if (!master && !tenantId) return [];
      const { data, error } = await query;
      if (error) throw new Error(`Gagal mengambil audit log: ${error.message}`);
      return (data || []) as AuthAuditLog[];
    }
    let results = master ? [...this.logs] : tenantId ? this.logs.filter((log) => log.tenant_id === tenantId) : [];
    return results.slice(0, limit);
  }

  clearLogs(): void {
    this.logs = [];
  }
}

export const auditService = new AuditService();
