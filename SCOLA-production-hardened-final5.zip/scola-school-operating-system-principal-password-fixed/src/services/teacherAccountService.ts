import { getSupabase, isSupabaseConfigured } from '../config/supabase';
import { canCreateTeacher } from '../lib/permissions';
import { teacherRepository } from '../repositories/teacherRepository';
import { TeacherProfile, UserProfile, TeacherAssignment } from '../types';

export interface TeacherAccountInput {
  tenant_id: string;
  full_name: string;
  email: string;
  password: string;
  phone?: string;
  nip?: string;
  nuptk?: string;
  gender?: 'L' | 'P';
  employment_type?: 'PNS' | 'PPPK' | 'GTY' | 'GTT';
  subject_specialty?: string[];
  assignments?: TeacherAssignment[];
}

/**
 * Provisions a real Supabase Auth account plus the SCOLA teacher/profile rows.
 *
 * Important: creating another Auth user requires the Supabase service-role key,
 * which must never be exposed to the browser. When live Supabase is configured,
 * this service calls the `provision-teacher-account` Edge Function. In demo/local
 * mode it falls back to the in-memory repository used by the app's demo mode.
 */
class TeacherAccountService {
  async createTeacherAccount(input: TeacherAccountInput, actor: UserProfile): Promise<TeacherProfile> {
    if (!canCreateTeacher(actor.role)) {
      throw new Error('Akses Ditolak: Hanya MASTER atau KEPALA SEKOLAH yang dapat mendaftarkan akun guru.');
    }

    const email = input.email.toLowerCase().trim();
    if (!email) throw new Error('Email login wajib diisi.');
    if (input.password.length < 8) {
      throw new Error('Password minimal 8 karakter.');
    }

    if (isSupabaseConfigured()) {
      const supabase = getSupabase();
      if (!supabase) throw new Error('Koneksi Supabase belum siap.');

      const { data, error } = await supabase.functions.invoke('provision-teacher-account', {
        body: {
          ...input,
          email,
          actor_role: actor.role,
        },
      });

      if (error) {
        throw new Error(
          error.message ||
            'Gagal membuat akun Auth guru. Pastikan Edge Function provision-teacher-account sudah dideploy di Supabase.'
        );
      }
      if (!data?.teacher) {
        throw new Error('Akun guru tidak berhasil diprovisioning oleh server.');
      }

      return data.teacher as TeacherProfile;
    }

    // Demo/offline mode: keep the existing local login flow working.
    return teacherRepository.createTeacher(
      {
        ...input,
        email,
          status: 'ACTIVE',
        role: 'GURU',
      },
      actor
    );
  }
}

export const teacherAccountService = new TeacherAccountService();
