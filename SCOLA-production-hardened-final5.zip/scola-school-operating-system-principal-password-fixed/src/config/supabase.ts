import { createClient, SupabaseClient } from '@supabase/supabase-js';
import { ENV } from './env';

let supabaseInstance: SupabaseClient | null = null;

/**
 * Returns the initialized Supabase client singleton.
 * Fallback gracefully if keys are pending configuration in environment.
 */
export function getSupabase(): SupabaseClient | null {
  if (supabaseInstance) {
    return supabaseInstance;
  }
  const url = ENV.SUPABASE_URL;
  const key = ENV.SUPABASE_ANON_KEY;
  if (url && key && url.startsWith('http') && !url.includes('your-project')) {
    try {
      supabaseInstance = createClient(url, key, {
        auth: {
          persistSession: true,
          autoRefreshToken: true,
          detectSessionInUrl: true,
          storage: typeof window !== 'undefined' ? window.localStorage : undefined,
        },
      });
      return supabaseInstance;
    } catch (err) {
      console.warn('Failed to initialize Supabase client:', err);
      return null;
    }
  }
  return null;
}

export const isSupabaseConfigured = (): boolean => {
  return ENV.IS_LIVE_SUPABASE && getSupabase() !== null;
};

export const setSupabaseCredentials = (url: string, anonKey: string): boolean => {
  if (typeof window !== 'undefined' && window.localStorage) {
    window.localStorage.setItem('VITE_SUPABASE_URL', url.trim());
    window.localStorage.setItem('VITE_SUPABASE_ANON_KEY', anonKey.trim());
    ENV.SUPABASE_URL = url.trim();
    ENV.SUPABASE_ANON_KEY = anonKey.trim();
    ENV.IS_LIVE_SUPABASE = Boolean(url && anonKey && url.startsWith('http'));
    supabaseInstance = null;
    return getSupabase() !== null;
  }
  return false;
};
