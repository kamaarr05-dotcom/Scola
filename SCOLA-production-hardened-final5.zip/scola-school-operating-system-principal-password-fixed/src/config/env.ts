/**
 * Environment configuration for SCOLA.
 * Securely reads environment variables without leaking secrets to the client.
 * SECURITY RULE:
 * Only public client configuration (VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY)
 * is accepted in the client application (Web, Android, and iOS).
 * SUPABASE_SERVICE_ROLE_KEY must NEVER be exposed or requested on the client side.
 */

const getEnvOrStorage = (key: string, envVal: string | undefined): string => {
  if (envVal && !envVal.includes('your-project') && envVal.trim() !== '') {
    return envVal.trim();
  }
  if (typeof window !== 'undefined' && window.localStorage) {
    const stored = window.localStorage.getItem(key);
    if (stored && stored.trim() !== '') return stored.trim();
  }
  return envVal || '';
};

const supabaseUrl = getEnvOrStorage('VITE_SUPABASE_URL', import.meta.env.VITE_SUPABASE_URL);
const supabaseAnonKey = getEnvOrStorage('VITE_SUPABASE_ANON_KEY', import.meta.env.VITE_SUPABASE_ANON_KEY);

export const ENV = {
  SUPABASE_URL: supabaseUrl,
  SUPABASE_ANON_KEY: supabaseAnonKey,
  IS_PROD: import.meta.env.PROD,
  IS_DEV: import.meta.env.DEV,
  // Indicates if valid live Supabase credentials are provided
  IS_LIVE_SUPABASE: Boolean(
    supabaseUrl &&
    supabaseAnonKey &&
    !supabaseUrl.includes('your-project') &&
    supabaseUrl.startsWith('http')
  ),
};
