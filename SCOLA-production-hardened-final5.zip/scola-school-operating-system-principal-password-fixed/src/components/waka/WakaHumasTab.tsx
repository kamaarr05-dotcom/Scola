import React, { useState, useEffect } from 'react';
import {
  Briefcase,
  Building,
  Calendar,
  Phone,
  FileCheck,
  Search,
  Plus,
  Filter,
  CheckCircle2,
  Clock,
  AlertTriangle,
  Globe,
  ExternalLink,
  Users,
} from 'lucide-react';
import {
  UserProfile,
  IndustryMoUPartner,
} from '../../types';
import { academicRepository } from '../../repositories/academicRepository';

interface WakaHumasTabProps {
  currentUser: UserProfile;
  tenantId: string;
}

export const WakaHumasTab: React.FC<WakaHumasTabProps> = ({ currentUser, tenantId }) => {
  const [subTab, setSubTab] = useState<'MOU' | 'KUNJUNGAN' | 'PUBLIKASI'>('MOU');

  // Data state
  const [mous, setMous] = useState<IndustryMoUPartner[]>([]);

  // Filters & Search
  const [statusFilter, setStatusFilter] = useState<'ALL' | 'AKTIF' | 'MENJELANG_KADALUWARSA' | 'KADALUWARSA'>('ALL');
  const [searchQuery, setSearchQuery] = useState('');

  // Modals
  const [showMouModal, setShowMouModal] = useState(false);
  const [showVisitModal, setShowVisitModal] = useState(false);

  // Form MoU
  const [mouForm, setMouForm] = useState({
    partner_name: '',
    field_of_work: 'Teknologi Informasi & Rekayasa Software',
    city: 'Jakarta',
    mou_number: `MOU/HUM/${Math.floor(100 + Math.random() * 900)}/2024`,
    sign_date: new Date().toISOString().split('T')[0],
    expiry_date: new Date(Date.now() + 365 * 24 * 60 * 60 * 1000 * 2).toISOString().split('T')[0],
    pkl_quota: 10,
    contact_person: '',
    phone: '',
    status: 'AKTIF' as IndustryMoUPartner['status'],
  });

  // Mock Industrial Visits
  const [visits, setVisits] = useState([
    {
      id: 'vis-1',
      title: 'Kunjungan Industri & Observasi AI Cloud Data Center',
      partner: 'PT Telkom Indonesia (Persero) Tbk',
      date: '28 Oktober 2024',
      target: 'Siswa Kelas XI & XII Kejuruan',
      participants_count: 75,
      status: 'TERJADWAL',
    },
    {
      id: 'vis-2',
      title: 'Studi Banding Pengelolaan Kurikulum Merdeka Terpadu',
      partner: 'SMA Unggulan M.H. Thamrin Jakarta',
      date: '15 November 2024',
      target: 'Manajemen Sekolah & Dewan Guru',
      participants_count: 24,
      status: 'PERSIAPAN',
    },
  ]);

  const [visitForm, setVisitForm] = useState({
    title: '',
    partner: '',
    date: new Date().toISOString().split('T')[0],
    target: 'Siswa Tingkat Lanjut',
    participants_count: 40,
  });

  const loadData = async () => {
    try {
      const mouData = await academicRepository.getIndustryMoUs(tenantId);
      setMous(mouData);
    } catch (err) {
      console.error('Error loading Humas data:', err);
    }
  };

  useEffect(() => {
    loadData();
  }, [tenantId]);

  // Create MoU
  const handleCreateMou = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      if (!mouForm.partner_name.trim() || !mouForm.contact_person.trim()) {
        alert('Mohon isi nama mitra industri dan penanggung jawab (PIC).');
        return;
      }

      await academicRepository.createIndustryMoU(
        {
          tenant_id: tenantId,
          partner_name: mouForm.partner_name,
          field_of_work: mouForm.field_of_work,
          city: mouForm.city,
          mou_number: mouForm.mou_number,
          sign_date: mouForm.sign_date,
          expiry_date: mouForm.expiry_date,
          pkl_quota: mouForm.pkl_quota,
          contact_person: mouForm.contact_person,
          phone: mouForm.phone || '+62 812-3456-7890',
          status: mouForm.status,
        },
        currentUser
      );

      setShowMouModal(false);
      await loadData();
      alert('Nota Kesepahaman (MoU) berhasil didaftarkan ke sistem kemitraan!');
    } catch (err: any) {
      alert(`Gagal membuat MoU: ${err.message}`);
    }
  };

  // Create Visit
  const handleCreateVisit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!visitForm.title || !visitForm.partner) {
      alert('Lengkapi judul dan nama institusi mitra kunjungan.');
      return;
    }
    setVisits([
      ...visits,
      {
        id: `vis-${Date.now()}`,
        title: visitForm.title,
        partner: visitForm.partner,
        date: visitForm.date,
        target: visitForm.target,
        participants_count: visitForm.participants_count,
        status: 'TERJADWAL',
      },
    ]);
    setShowVisitModal(false);
    alert('Agenda kunjungan industri berhasil ditambahkan!');
  };

  const filteredMous = mous.filter((m) => {
    if (statusFilter !== 'ALL' && m.status !== statusFilter) return false;
    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      return (
        m.partner_name.toLowerCase().includes(q) ||
        m.field_of_work.toLowerCase().includes(q) ||
        m.city.toLowerCase().includes(q) ||
        m.mou_number.toLowerCase().includes(q)
      );
    }
    return true;
  });

  const totalQuota = mous.reduce((acc, m) => acc + (m.pkl_quota || 0), 0);

  return (
    <div className="space-y-6">
      {/* Sub navigation */}
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-200 pb-3">
        <div className="flex items-center gap-2">
          <button
            onClick={() => setSubTab('MOU')}
            className={`rounded-xl px-3.5 py-1.5 text-xs font-semibold transition-all ${
              subTab === 'MOU'
                ? 'bg-emerald-600 text-white shadow-xs'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            Kemitraan Industri & MoU ({mous.length})
          </button>
          <button
            onClick={() => setSubTab('KUNJUNGAN')}
            className={`rounded-xl px-3.5 py-1.5 text-xs font-semibold transition-all ${
              subTab === 'KUNJUNGAN'
                ? 'bg-emerald-600 text-white shadow-xs'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            Kunjungan Industri & Tamu Dinas ({visits.length})
          </button>
          <button
            onClick={() => setSubTab('PUBLIKASI')}
            className={`rounded-xl px-3.5 py-1.5 text-xs font-semibold transition-all ${
              subTab === 'PUBLIKASI'
                ? 'bg-emerald-600 text-white shadow-xs'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            Agenda Komite Sekolah & Rilis Pers
          </button>
        </div>

        {subTab === 'MOU' && (
          <button
            onClick={() => setShowMouModal(true)}
            className="flex items-center gap-1.5 rounded-xl bg-emerald-600 px-3 py-1.5 text-xs font-bold text-white shadow-sm hover:bg-emerald-700 transition-colors"
          >
            <Plus className="h-4 w-4" />
            <span>Registrasi MoU Baru</span>
          </button>
        )}

        {subTab === 'KUNJUNGAN' && (
          <button
            onClick={() => setShowVisitModal(true)}
            className="flex items-center gap-1.5 rounded-xl bg-emerald-600 px-3 py-1.5 text-xs font-bold text-white shadow-sm hover:bg-emerald-700 transition-colors"
          >
            <Plus className="h-4 w-4" />
            <span>Tambah Jadwal Kunjungan</span>
          </button>
        )}
      </div>

      {/* ================= SUB-TAB 1: MOU KEMITRAAN ================= */}
      {subTab === 'MOU' && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-4">
            <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-xs">
              <span className="text-xs text-slate-500 font-medium">Total Mitra Terjalin:</span>
              <div className="mt-1 text-2xl font-bold text-slate-900">{mous.length} Lembaga</div>
              <div className="mt-0.5 text-[11px] text-slate-400">DUDI & Kampus Mitra</div>
            </div>
            <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-xs">
              <span className="text-xs text-slate-500 font-medium">Perjanjian Aktif:</span>
              <div className="mt-1 text-2xl font-bold text-emerald-600">
                {mous.filter((m) => m.status === 'AKTIF').length} Perusahaan
              </div>
              <div className="mt-0.5 text-[11px] text-slate-400">Legal & Berlaku</div>
            </div>
            <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-xs">
              <span className="text-xs text-slate-500 font-medium">Menjelang Kedaluwarsa:</span>
              <div className="mt-1 text-2xl font-bold text-amber-600">
                {mous.filter((m) => m.status === 'MENJELANG_KADALUWARSA').length} MoU
              </div>
              <div className="mt-0.5 text-[11px] text-slate-400">Perlu Perpanjangan</div>
            </div>
            <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-xs">
              <span className="text-xs text-slate-500 font-medium">Total Kuota PKL/Magang:</span>
              <div className="mt-1 text-2xl font-black text-blue-600">{totalQuota} Siswa</div>
              <div className="mt-0.5 text-[11px] text-slate-400">Kapasitas serapan</div>
            </div>
          </div>

          {/* Filter Bar */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white p-3 rounded-2xl border border-slate-200">
            <div className="flex items-center gap-2">
              <span className="text-xs font-medium text-slate-500 flex items-center gap-1">
                <Filter className="h-3.5 w-3.5" /> Status:
              </span>
              <button
                onClick={() => setStatusFilter('ALL')}
                className={`px-2.5 py-1 text-xs rounded-lg font-medium ${
                  statusFilter === 'ALL' ? 'bg-slate-800 text-white' : 'text-slate-600 hover:bg-slate-100'
                }`}
              >
                Semua
              </button>
              <button
                onClick={() => setStatusFilter('AKTIF')}
                className={`px-2.5 py-1 text-xs rounded-lg font-medium ${
                  statusFilter === 'AKTIF'
                    ? 'bg-emerald-100 text-emerald-800 font-bold'
                    : 'text-slate-600 hover:bg-slate-100'
                }`}
              >
                Aktif
              </button>
              <button
                onClick={() => setStatusFilter('MENJELANG_KADALUWARSA')}
                className={`px-2.5 py-1 text-xs rounded-lg font-medium ${
                  statusFilter === 'MENJELANG_KADALUWARSA'
                    ? 'bg-amber-100 text-amber-800 font-bold'
                    : 'text-slate-600 hover:bg-slate-100'
                }`}
              >
                Perlu Perpanjangan
              </button>
            </div>

            <div className="relative w-full sm:w-64">
              <Search className="absolute left-3 top-2.5 h-3.5 w-3.5 text-slate-400" />
              <input
                type="text"
                placeholder="Cari perusahaan, kota, atau nomor MoU..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full rounded-xl border border-slate-200 pl-9 pr-3 py-1.5 text-xs focus:border-emerald-500 focus:outline-none"
              />
            </div>
          </div>

          {/* Table */}
          <div className="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-xs">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs text-slate-700">
                <thead className="bg-slate-50 text-[11px] font-bold uppercase text-slate-500 border-b border-slate-200">
                  <tr>
                    <th className="px-4 py-3">Nama Mitra & Kota</th>
                    <th className="px-4 py-3">Bidang Kerjasama</th>
                    <th className="px-4 py-3">No. Perjanjian MoU</th>
                    <th className="px-4 py-3">Masa Berlaku</th>
                    <th className="px-4 py-3 text-center">Kuota PKL</th>
                    <th className="px-4 py-3">Narahubung (PIC)</th>
                    <th className="px-4 py-3 text-right">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {filteredMous.length === 0 ? (
                    <tr>
                      <td colSpan={7} className="py-8 text-center text-slate-400">
                        Belum ada data kemitraan yang cocok.
                      </td>
                    </tr>
                  ) : (
                    filteredMous.map((m) => (
                      <tr key={m.id} className="hover:bg-slate-50/80">
                        <td className="px-4 py-3">
                          <div className="font-bold text-slate-900">{m.partner_name}</div>
                          <div className="text-[11px] text-slate-500">{m.city}</div>
                        </td>
                        <td className="px-4 py-3 font-medium text-slate-700">{m.field_of_work}</td>
                        <td className="px-4 py-3 text-[11px] text-slate-600">{m.mou_number}</td>
                        <td className="px-4 py-3">
                          <div className="text-[11px] text-slate-800 font-medium">s/d {m.expiry_date}</div>
                          <div className="text-[10px] text-slate-400">TTD: {m.sign_date}</div>
                        </td>
                        <td className="px-4 py-3 text-center">
                          <span className="rounded-full bg-blue-50 px-2.5 py-0.5 text-xs font-black text-blue-700">
                            {m.pkl_quota} Siswa
                          </span>
                        </td>
                        <td className="px-4 py-3">
                          <div className="font-semibold text-slate-800">{m.contact_person}</div>
                          <div className="text-[11px] text-slate-500 flex items-center gap-1">
                            <Phone className="h-3 w-3 text-slate-400" />
                            {m.phone}
                          </div>
                        </td>
                        <td className="px-4 py-3 text-right">
                          {m.status === 'AKTIF' ? (
                            <span className="inline-flex items-center gap-1 rounded-full bg-emerald-50 px-2.5 py-0.5 text-[10px] font-bold text-emerald-800 border border-emerald-200">
                              <CheckCircle2 className="h-3 w-3" /> Aktif
                            </span>
                          ) : m.status === 'MENJELANG_KADALUWARSA' ? (
                            <span className="inline-flex items-center gap-1 rounded-full bg-amber-50 px-2.5 py-0.5 text-[10px] font-bold text-amber-800 border border-amber-200">
                              <Clock className="h-3 w-3" /> Menjelang Habis
                            </span>
                          ) : (
                            <span className="inline-flex items-center gap-1 rounded-full bg-rose-50 px-2.5 py-0.5 text-[10px] font-bold text-rose-800 border border-rose-200">
                              <AlertTriangle className="h-3 w-3" /> Kedaluwarsa
                            </span>
                          )}
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ================= SUB-TAB 2: KUNJUNGAN INDUSTRI ================= */}
      {subTab === 'KUNJUNGAN' && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            {visits.map((vis) => (
              <div
                key={vis.id}
                className="rounded-2xl border border-slate-200 bg-white p-5 shadow-xs flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between">
                    <span className="rounded-md bg-emerald-50 px-2 py-0.5 text-[10px] font-bold text-emerald-800 border border-emerald-200">
                      {vis.date}
                    </span>
                    <span className="rounded-full bg-blue-50 px-2 py-0.5 text-[10px] font-bold text-blue-700">
                      {vis.status}
                    </span>
                  </div>
                  <h4 className="mt-2 text-base font-bold text-slate-900">{vis.title}</h4>
                  <p className="mt-1 text-xs text-slate-600 flex items-center gap-1.5">
                    <Building className="h-3.5 w-3.5 text-emerald-600" />
                    <span>Lembaga / Perusahaan: <strong>{vis.partner}</strong></span>
                  </p>

                  <div className="mt-3 space-y-1 text-xs text-slate-600 border-t border-slate-100 pt-2.5">
                    <div className="flex items-center justify-between">
                      <span className="text-slate-400">Sasaran Peserta:</span>
                      <span className="font-semibold">{vis.target}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-slate-400">Estimasi Peserta:</span>
                      <span className="font-bold text-slate-800">{vis.participants_count} Orang</span>
                    </div>
                  </div>
                </div>

                <div className="mt-4 flex items-center justify-end border-t border-slate-100 pt-3">
                  <span className="text-xs font-semibold text-emerald-700 flex items-center gap-1">
                    Koordinasi Humas Siap <CheckCircle2 className="h-3.5 w-3.5" />
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ================= SUB-TAB 3: PUBLIKASI & KOMITE ================= */}
      {subTab === 'PUBLIKASI' && (
        <div className="space-y-4">
          <div className="rounded-2xl border border-emerald-100 bg-emerald-50/50 p-5">
            <h4 className="font-bold text-emerald-950 text-sm flex items-center gap-2">
              <Globe className="h-4 w-4 text-emerald-600" />
              <span>Pusat Informasi Humas & Hubungan Masyarakat</span>
            </h4>
            <p className="mt-1 text-xs text-emerald-800">
              Pengelolaan sinergi dengan Komite Sekolah, orang tua siswa, media pers, dan siaran prestasi unggulan sekolah ke publik.
            </p>

            <div className="mt-4 grid grid-cols-1 gap-3 sm:grid-cols-3 text-xs">
              <div className="rounded-xl bg-white p-3 border border-emerald-200/60 shadow-2xs">
                <div className="font-bold text-slate-900">Rapat Pleno Komite Sekolah</div>
                <div className="mt-0.5 text-slate-500">Penyampaian RAPBS & Evaluasi Semester</div>
                <div className="mt-2 text-[11px] font-bold text-emerald-700">Setiap Triwulan</div>
              </div>

              <div className="rounded-xl bg-white p-3 border border-emerald-200/60 shadow-2xs">
                <div className="font-bold text-slate-900">Buletin Digital & Warta Sekolah</div>
                <div className="mt-0.5 text-slate-500">Liputan prestasi olimpiade & kejuaraan</div>
                <div className="mt-2 text-[11px] font-bold text-emerald-700">Edisi Bulanan Aktif</div>
              </div>

              <div className="rounded-xl bg-white p-3 border border-emerald-200/60 shadow-2xs">
                <div className="font-bold text-slate-900">Portal Bursa Kerja Khusus (BKK)</div>
                <div className="mt-0.5 text-slate-500">Penyaluran alumni ke industri mitra</div>
                <div className="mt-2 text-[11px] font-bold text-emerald-700">Tersinkronisasi Tracer Study</div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ================= MODAL: REGISTRASI MOU ================= */}
      {showMouModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 p-4 backdrop-blur-xs">
          <div className="w-full max-w-lg rounded-2xl bg-white p-6 shadow-2xl animate-in fade-in zoom-in-95">
            <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
              <Briefcase className="h-5 w-5 text-emerald-600" />
              <span>Registrasi Nota Kesepahaman (MoU) Kemitraan</span>
            </h3>

            <form onSubmit={handleCreateMou} className="mt-4 space-y-3.5 text-xs">
              <div>
                <label className="font-semibold text-slate-700">Nama Lembaga Mitra / Perusahaan:</label>
                <input
                  type="text"
                  value={mouForm.partner_name}
                  onChange={(e) => setMouForm({ ...mouForm, partner_name: e.target.value })}
                  placeholder="Contoh: PT Telekomunikasi Seluler, Institut Teknologi..."
                  className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-xs focus:border-emerald-500 focus:outline-none"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-semibold text-slate-700">Bidang Kerjasama:</label>
                  <input
                    type="text"
                    value={mouForm.field_of_work}
                    onChange={(e) => setMouForm({ ...mouForm, field_of_work: e.target.value })}
                    className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-xs focus:border-emerald-500 focus:outline-none"
                    required
                  />
                </div>
                <div>
                  <label className="font-semibold text-slate-700">Kota Domisili:</label>
                  <input
                    type="text"
                    value={mouForm.city}
                    onChange={(e) => setMouForm({ ...mouForm, city: e.target.value })}
                    className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-xs focus:border-emerald-500 focus:outline-none"
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-semibold text-slate-700">Nomor Dokumen MoU:</label>
                  <input
                    type="text"
                    value={mouForm.mou_number}
                    onChange={(e) => setMouForm({ ...mouForm, mou_number: e.target.value })}
                    className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-xs focus:border-emerald-500 focus:outline-none"
                    required
                  />
                </div>
                <div>
                  <label className="font-semibold text-slate-700">Kuota PKL/Magang:</label>
                  <input
                    type="number"
                    value={mouForm.pkl_quota}
                    onChange={(e) => setMouForm({ ...mouForm, pkl_quota: Number(e.target.value) })}
                    className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-xs focus:border-emerald-500 focus:outline-none"
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-semibold text-slate-700">Tanggal TTD:</label>
                  <input
                    type="date"
                    value={mouForm.sign_date}
                    onChange={(e) => setMouForm({ ...mouForm, sign_date: e.target.value })}
                    className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-xs focus:border-emerald-500 focus:outline-none"
                    required
                  />
                </div>
                <div>
                  <label className="font-semibold text-slate-700">Tanggal Kedaluwarsa:</label>
                  <input
                    type="date"
                    value={mouForm.expiry_date}
                    onChange={(e) => setMouForm({ ...mouForm, expiry_date: e.target.value })}
                    className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-xs focus:border-emerald-500 focus:outline-none"
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-semibold text-slate-700">Nama PIC Perusahaan:</label>
                  <input
                    type="text"
                    value={mouForm.contact_person}
                    onChange={(e) => setMouForm({ ...mouForm, contact_person: e.target.value })}
                    placeholder="Contoh: Bpk. Bambang Sutrisno"
                    className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-xs focus:border-emerald-500 focus:outline-none"
                    required
                  />
                </div>
                <div>
                  <label className="font-semibold text-slate-700">No. WhatsApp / Telp:</label>
                  <input
                    type="text"
                    value={mouForm.phone}
                    onChange={(e) => setMouForm({ ...mouForm, phone: e.target.value })}
                    placeholder="+62 812-xxxx-xxxx"
                    className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-xs focus:border-emerald-500 focus:outline-none"
                  />
                </div>
              </div>

              <div className="mt-5 flex items-center justify-end gap-2 border-t border-slate-100 pt-3">
                <button
                  type="button"
                  onClick={() => setShowMouModal(false)}
                  className="rounded-xl px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="rounded-xl bg-emerald-600 px-4 py-2 text-xs font-bold text-white shadow-xs hover:bg-emerald-700"
                >
                  Daftarkan Dokumen
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ================= MODAL: KUNJUNGAN ================= */}
      {showVisitModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 p-4 backdrop-blur-xs">
          <div className="w-full max-w-lg rounded-2xl bg-white p-6 shadow-2xl animate-in fade-in zoom-in-95">
            <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
              <Calendar className="h-5 w-5 text-emerald-600" />
              <span>Jadwalkan Kunjungan Industri / Tamu</span>
            </h3>

            <form onSubmit={handleCreateVisit} className="mt-4 space-y-3.5 text-xs">
              <div>
                <label className="font-semibold text-slate-700">Agenda Kegiatan:</label>
                <input
                  type="text"
                  value={visitForm.title}
                  onChange={(e) => setVisitForm({ ...visitForm, title: e.target.value })}
                  placeholder="Contoh: Kunjungan Edukasi Pabrik Perakitan..."
                  className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-xs focus:border-emerald-500 focus:outline-none"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-semibold text-slate-700">Nama Perusahaan Mitra:</label>
                  <input
                    type="text"
                    value={visitForm.partner}
                    onChange={(e) => setVisitForm({ ...visitForm, partner: e.target.value })}
                    className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-xs focus:border-emerald-500 focus:outline-none"
                    required
                  />
                </div>
                <div>
                  <label className="font-semibold text-slate-700">Tanggal Pelaksanaan:</label>
                  <input
                    type="date"
                    value={visitForm.date}
                    onChange={(e) => setVisitForm({ ...visitForm, date: e.target.value })}
                    className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-xs focus:border-emerald-500 focus:outline-none"
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-semibold text-slate-700">Sasaran Peserta:</label>
                  <input
                    type="text"
                    value={visitForm.target}
                    onChange={(e) => setVisitForm({ ...visitForm, target: e.target.value })}
                    className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-xs focus:border-emerald-500 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="font-semibold text-slate-700">Jumlah Siswa / Guru:</label>
                  <input
                    type="number"
                    value={visitForm.participants_count}
                    onChange={(e) => setVisitForm({ ...visitForm, participants_count: Number(e.target.value) })}
                    className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-xs focus:border-emerald-500 focus:outline-none"
                  />
                </div>
              </div>

              <div className="mt-5 flex items-center justify-end gap-2 border-t border-slate-100 pt-3">
                <button
                  type="button"
                  onClick={() => setShowVisitModal(false)}
                  className="rounded-xl px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="rounded-xl bg-emerald-600 px-4 py-2 text-xs font-bold text-white shadow-xs hover:bg-emerald-700"
                >
                  Jadwalkan
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
