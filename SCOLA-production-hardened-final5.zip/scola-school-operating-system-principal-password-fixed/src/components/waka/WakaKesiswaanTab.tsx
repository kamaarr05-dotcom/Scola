import React, { useState, useEffect } from 'react';
import {
  Users,
  ShieldAlert,
  Award,
  Calendar,
  Search,
  Plus,
  Filter,
  CheckCircle2,
  TrendingUp,
  AlertTriangle,
  UserCheck,
  DollarSign,
  HeartHandshake,
} from 'lucide-react';
import {
  UserProfile,
  StudentDisciplineRecord,
  ExtracurricularActivity,
  StudentScholarshipRecord,
  SchoolClass,
  StudentProfile,
  DailyAttendance,
} from '../../types';
import { academicRepository } from '../../repositories/academicRepository';

interface WakaKesiswaanTabProps {
  currentUser: UserProfile;
  tenantId: string;
}

export const WakaKesiswaanTab: React.FC<WakaKesiswaanTabProps> = ({ currentUser, tenantId }) => {
  const [subTab, setSubTab] = useState<'DISIPLIN' | 'PRESENSI' | 'EKSKUL' | 'BEASISWA'>('DISIPLIN');

  // Data state
  const [disciplines, setDisciplines] = useState<StudentDisciplineRecord[]>([]);
  const [extracurriculars, setExtracurriculars] = useState<ExtracurricularActivity[]>([]);
  const [scholarships, setScholarships] = useState<StudentScholarshipRecord[]>([]);
  const [students, setStudents] = useState<StudentProfile[]>([]);
  const [classes, setClasses] = useState<SchoolClass[]>([]);
  const [attendances, setAttendances] = useState<DailyAttendance[]>([]);

  // Filters & Search
  const [typeFilter, setTypeFilter] = useState<'ALL' | 'PELANGGARAN' | 'PRESTASI'>('ALL');
  const [searchQuery, setSearchQuery] = useState('');

  // Modals
  const [showDisciplineModal, setShowDisciplineModal] = useState(false);
  const [showEkskulModal, setShowEkskulModal] = useState(false);
  const [showScholarshipModal, setShowScholarshipModal] = useState(false);

  // Forms
  const [discForm, setDiscForm] = useState({
    student_id: '',
    type: 'PELANGGARAN' as 'PELANGGARAN' | 'PRESTASI',
    category: 'Keterlambatan Hadir',
    points: 5,
    description: '',
    follow_up_action: 'Teguran Lisan & Pembinaan Wali Kelas',
    date: new Date().toISOString().split('T')[0],
  });

  const [ekskulForm, setEkskulForm] = useState({
    name: '',
    category: 'OLAHRAGA' as ExtracurricularActivity['category'],
    coach_name: '',
    schedule_day: 'SABTU' as any,
    time_range: '14:00 - 16:30',
    location: 'Lapangan Utama',
    annual_budget: 3500000,
  });

  const [scholarshipForm, setScholarshipForm] = useState({
    student_id: '',
    program_type: 'PIP_KEMDIKBUD' as StudentScholarshipRecord['program_type'],
    nominal_per_year: 1000000,
    disbursement_stage: 'Tahap 1 - 2024',
    disbursement_status: 'CAIR' as StudentScholarshipRecord['disbursement_status'],
  });

  const loadData = async () => {
    try {
      const [discData, eksData, schData, stdData, clsData, attData] = await Promise.all([
        academicRepository.getDisciplineRecords(tenantId),
        academicRepository.getExtracurriculars(tenantId),
        academicRepository.getScholarships(tenantId),
        academicRepository.getStudentsByTenant(tenantId, currentUser),
        academicRepository.getClasses(tenantId, currentUser),
        academicRepository.getAttendanceByTenant(tenantId, currentUser),
      ]);
      setDisciplines(discData);
      setExtracurriculars(eksData);
      setScholarships(schData);
      setStudents(stdData);
      setClasses(clsData);
      setAttendances(attData);
    } catch (err) {
      console.error('Error loading Kesiswaan data:', err);
    }
  };

  useEffect(() => {
    loadData();
  }, [tenantId]);

  // Handle Create Discipline Record
  const handleCreateDiscipline = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const std = students.find((s) => s.id === discForm.student_id);
      if (!std) {
        alert('Pilih siswa yang bersangkutan.');
        return;
      }

      await academicRepository.addDisciplineRecord(
        {
          tenant_id: tenantId,
          student_id: std.id,
          student_name: std.full_name,
          class_name: std.class_name || 'Rombel',
          type: discForm.type,
          record_type: discForm.type,
          category: discForm.category,
          points: discForm.type === 'PELANGGARAN' ? Math.abs(discForm.points) : Math.abs(discForm.points),
          description: discForm.description || 'Pencatatan pelanggaran tata tertib sekolah.',
          follow_up_action: discForm.follow_up_action,
          date: discForm.date,
          recorded_by_name: `${currentUser.full_name} (Waka Kesiswaan)`,
        },
        currentUser
      );

      setShowDisciplineModal(false);
      await loadData();
      alert('Catatan kedisiplinan siswa berhasil ditambahkan!');
    } catch (err: any) {
      alert(`Gagal mencatat: ${err.message}`);
    }
  };

  // Handle Create Ekskul
  const handleCreateEkskul = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      if (!ekskulForm.name.trim()) {
        alert('Nama ekstrakurikuler wajib diisi.');
        return;
      }

      await academicRepository.createExtracurricular(
        {
          tenant_id: tenantId,
          name: ekskulForm.name,
          category: ekskulForm.category,
          coach_teacher_id: currentUser.id,
          coach_name: ekskulForm.coach_name || 'Guru Pembina',
          schedule_day: ekskulForm.schedule_day,
          time_range: ekskulForm.time_range,
          location: ekskulForm.location,
          member_count: 0,
          annual_budget: ekskulForm.annual_budget,
          status: 'ACTIVE',
        },
        currentUser
      );

      setShowEkskulModal(false);
      await loadData();
      alert('Ekstrakurikuler baru berhasil didaftarkan!');
    } catch (err: any) {
      alert(`Gagal menambah ekskul: ${err.message}`);
    }
  };

  // Handle Create Scholarship
  const handleCreateScholarship = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const std = students.find((s) => s.id === scholarshipForm.student_id);
      if (!std) {
        alert('Pilih siswa penerima beasiswa.');
        return;
      }

      await academicRepository.createScholarship(
        {
          tenant_id: tenantId,
          student_id: std.id,
          student_name: std.full_name,
          nisn: std.nisn,
          class_name: std.class_name || 'Rombel',
          program_type: scholarshipForm.program_type,
          nominal_per_year: scholarshipForm.nominal_per_year,
          disbursement_stage: scholarshipForm.disbursement_stage,
          disbursed_date: new Date().toISOString().split('T')[0],
          disbursement_status: scholarshipForm.disbursement_status,
        },
        currentUser
      );

      setShowScholarshipModal(false);
      await loadData();
      alert('Penerima beasiswa berhasil didaftarkan!');
    } catch (err: any) {
      alert(`Gagal mendaftar beasiswa: ${err.message}`);
    }
  };

  const filteredDisciplines = disciplines.filter((d) => {
    const recType = d.type || d.record_type;
    if (typeFilter !== 'ALL' && recType !== typeFilter) return false;
    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      return (
        d.student_name.toLowerCase().includes(q) ||
        d.class_name.toLowerCase().includes(q) ||
        d.category.toLowerCase().includes(q) ||
        d.description.toLowerCase().includes(q)
      );
    }
    return true;
  });

  // Calculate Attendance Stats
  const totalAtt = attendances.length;
  const hadirCount = attendances.filter((a) => a.status === 'HADIR').length;
  const sakitCount = attendances.filter((a) => a.status === 'SAKIT').length;
  const izinCount = attendances.filter((a) => a.status === 'IZIN').length;
  const alpaCount = attendances.filter((a) => a.status === 'ALPA').length;
  const attendanceRate = totalAtt > 0 ? Math.round((hadirCount / totalAtt) * 100) : null;

  return (
    <div className="space-y-6">
      {/* Sub-tabs header */}
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-200 pb-3">
        <div className="flex items-center gap-2">
          <button
            onClick={() => setSubTab('DISIPLIN')}
            className={`rounded-xl px-3.5 py-1.5 text-xs font-semibold transition-all ${
              subTab === 'DISIPLIN'
                ? 'bg-rose-600 text-white shadow-xs'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            Buku Saku Disiplin & Prestasi ({disciplines.length})
          </button>
          <button
            onClick={() => setSubTab('PRESENSI')}
            className={`rounded-xl px-3.5 py-1.5 text-xs font-semibold transition-all ${
              subTab === 'PRESENSI'
                ? 'bg-rose-600 text-white shadow-xs'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            Rekap Presensi Harian Siswa ({attendanceRate === null ? 'Belum ada data' : `${attendanceRate}%`})
          </button>
          <button
            onClick={() => setSubTab('EKSKUL')}
            className={`rounded-xl px-3.5 py-1.5 text-xs font-semibold transition-all ${
              subTab === 'EKSKUL'
                ? 'bg-rose-600 text-white shadow-xs'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            Ekstrakurikuler & OSIS ({extracurriculars.length})
          </button>
          <button
            onClick={() => setSubTab('BEASISWA')}
            className={`rounded-xl px-3.5 py-1.5 text-xs font-semibold transition-all ${
              subTab === 'BEASISWA'
                ? 'bg-rose-600 text-white shadow-xs'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            Penyaluran Beasiswa PIP ({scholarships.length})
          </button>
        </div>

        {subTab === 'DISIPLIN' && (
          <button
            onClick={() => setShowDisciplineModal(true)}
            className="flex items-center gap-1.5 rounded-xl bg-rose-600 px-3 py-1.5 text-xs font-bold text-white shadow-sm hover:bg-rose-700 transition-colors"
          >
            <Plus className="h-4 w-4" />
            <span>Catat Poin Siswa</span>
          </button>
        )}

        {subTab === 'EKSKUL' && (
          <button
            onClick={() => setShowEkskulModal(true)}
            className="flex items-center gap-1.5 rounded-xl bg-rose-600 px-3 py-1.5 text-xs font-bold text-white shadow-sm hover:bg-rose-700 transition-colors"
          >
            <Plus className="h-4 w-4" />
            <span>Tambah Ekstrakurikuler</span>
          </button>
        )}

        {subTab === 'BEASISWA' && (
          <button
            onClick={() => setShowScholarshipModal(true)}
            className="flex items-center gap-1.5 rounded-xl bg-rose-600 px-3 py-1.5 text-xs font-bold text-white shadow-sm hover:bg-rose-700 transition-colors"
          >
            <Plus className="h-4 w-4" />
            <span>Daftarkan Penerima PIP</span>
          </button>
        )}
      </div>

      {/* ================= SUB-TAB 1: BUKU SAKU DISIPLIN ================= */}
      {subTab === 'DISIPLIN' && (
        <div className="space-y-4">
          {/* Quick Metrics */}
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
            <div className="rounded-2xl border border-rose-100 bg-rose-50/50 p-4">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-rose-800">Total Catatan Pelanggaran</span>
                <AlertTriangle className="h-4 w-4 text-rose-600" />
              </div>
              <div className="mt-2 text-2xl font-extrabold text-rose-950">
                {disciplines.filter((d) => (d.type || d.record_type) === 'PELANGGARAN').length} Kasus
              </div>
              <p className="mt-0.5 text-[11px] text-rose-700">Tercatat dalam Buku Saku Tata Tertib</p>
            </div>

            <div className="rounded-2xl border border-emerald-100 bg-emerald-50/50 p-4">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-emerald-800">Prestasi & Penghargaan</span>
                <Award className="h-4 w-4 text-emerald-600" />
              </div>
              <div className="mt-2 text-2xl font-extrabold text-emerald-950">
                {disciplines.filter((d) => (d.type || d.record_type) === 'PRESTASI' || (d.type || d.record_type) === 'PENGHARGAAN').length} Raihan
              </div>
              <p className="mt-0.5 text-[11px] text-emerald-700">Juara Lomba Akademik, Seni & Olahraga</p>
            </div>

            <div className="rounded-2xl border border-blue-100 bg-blue-50/50 p-4">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-blue-800">Siswa Aktif Terdaftar</span>
                <Users className="h-4 w-4 text-blue-600" />
              </div>
              <div className="mt-2 text-2xl font-extrabold text-blue-950">{students.length} Siswa</div>
              <p className="mt-0.5 text-[11px] text-blue-700">Tersebar di {classes.length} Rombongan Belajar</p>
            </div>
          </div>

          {/* Filter Bar */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white p-3 rounded-2xl border border-slate-200">
            <div className="flex items-center gap-2">
              <span className="text-xs font-medium text-slate-500 flex items-center gap-1">
                <Filter className="h-3.5 w-3.5" /> Filter:
              </span>
              <button
                onClick={() => setTypeFilter('ALL')}
                className={`px-2.5 py-1 text-xs rounded-lg font-medium ${
                  typeFilter === 'ALL' ? 'bg-slate-800 text-white' : 'text-slate-600 hover:bg-slate-100'
                }`}
              >
                Semua
              </button>
              <button
                onClick={() => setTypeFilter('PELANGGARAN')}
                className={`px-2.5 py-1 text-xs rounded-lg font-medium ${
                  typeFilter === 'PELANGGARAN'
                    ? 'bg-rose-100 text-rose-800 font-bold'
                    : 'text-slate-600 hover:bg-slate-100'
                }`}
              >
                Pelanggaran
              </button>
              <button
                onClick={() => setTypeFilter('PRESTASI')}
                className={`px-2.5 py-1 text-xs rounded-lg font-medium ${
                  typeFilter === 'PRESTASI'
                    ? 'bg-emerald-100 text-emerald-800 font-bold'
                    : 'text-slate-600 hover:bg-slate-100'
                }`}
              >
                Prestasi
              </button>
            </div>

            <div className="relative w-full sm:w-64">
              <Search className="absolute left-3 top-2.5 h-3.5 w-3.5 text-slate-400" />
              <input
                type="text"
                placeholder="Cari siswa, kelas, atau deskripsi..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full rounded-xl border border-slate-200 pl-9 pr-3 py-1.5 text-xs focus:border-rose-500 focus:outline-none"
              />
            </div>
          </div>

          {/* Discipline Table */}
          <div className="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-xs">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs text-slate-700">
                <thead className="bg-slate-50 text-[11px] font-bold uppercase text-slate-500 border-b border-slate-200">
                  <tr>
                    <th className="px-4 py-3">Tanggal</th>
                    <th className="px-4 py-3">Nama Siswa & Kelas</th>
                    <th className="px-4 py-3">Tipe & Kategori</th>
                    <th className="px-4 py-3 text-center">Poin</th>
                    <th className="px-4 py-3">Keterangan / Kejadian</th>
                    <th className="px-4 py-3">Tindak Lanjut / Sanksi</th>
                    <th className="px-4 py-3">Pelapor</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {filteredDisciplines.length === 0 ? (
                    <tr>
                      <td colSpan={7} className="py-8 text-center text-slate-400">
                        Tidak ada data catatan kedisiplinan yang cocok.
                      </td>
                    </tr>
                  ) : (
                    filteredDisciplines.map((d) => {
                      const isPelanggaran = (d.type || d.record_type) === 'PELANGGARAN';
                      return (
                        <tr key={d.id} className="hover:bg-slate-50/80">
                          <td className="px-4 py-3 text-[11px] text-slate-500">{d.date}</td>
                          <td className="px-4 py-3 font-semibold text-slate-900">
                            {d.student_name}
                            <div className="text-[11px] font-normal text-slate-500">{d.class_name}</div>
                          </td>
                          <td className="px-4 py-3">
                            <span
                              className={`inline-block rounded px-2 py-0.5 text-[10px] font-bold ${
                                isPelanggaran
                                  ? 'bg-rose-100 text-rose-800 border border-rose-200'
                                  : 'bg-emerald-100 text-emerald-800 border border-emerald-200'
                              }`}
                            >
                              {isPelanggaran ? 'PELANGGARAN' : 'PRESTASI'}
                            </span>
                            <div className="text-[11px] font-medium text-slate-700 mt-0.5">{d.category}</div>
                          </td>
                          <td className="px-4 py-3 text-center">
                            <span
                              className={`font-black text-sm ${
                                isPelanggaran ? 'text-rose-600' : 'text-emerald-600'
                              }`}
                            >
                              {isPelanggaran ? `-${d.points}` : `+${d.points}`}
                            </span>
                          </td>
                          <td className="px-4 py-3 max-w-xs text-[11px] text-slate-600">{d.description}</td>
                          <td className="px-4 py-3 max-w-xs text-[11px] font-medium text-slate-800">
                            {d.follow_up_action || '-'}
                          </td>
                          <td className="px-4 py-3 text-[11px] text-slate-500">{d.recorded_by_name || '-'}</td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ================= SUB-TAB 2: PRESENSI HARIAN SEKOLAH ================= */}
      {subTab === 'PRESENSI' && (
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-4 sm:grid-cols-5">
            <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-xs">
              <span className="text-xs text-slate-500 font-medium">Tingkat Hadir:</span>
              <div className="mt-1 text-2xl font-black text-emerald-600">{attendanceRate}%</div>
              <div className="text-[11px] text-slate-400">Target sekolah &ge; 95%</div>
            </div>
            <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-xs">
              <span className="text-xs text-slate-500 font-medium">Siswa Hadir:</span>
              <div className="mt-1 text-2xl font-bold text-slate-900">{hadirCount}</div>
              <div className="text-[11px] text-slate-400">Tatap Muka</div>
            </div>
            <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-xs">
              <span className="text-xs text-slate-500 font-medium">Sakit (Surat Dokter):</span>
              <div className="mt-1 text-2xl font-bold text-amber-600">{sakitCount}</div>
              <div className="text-[11px] text-slate-400">Tercatat</div>
            </div>
            <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-xs">
              <span className="text-xs text-slate-500 font-medium">Izin Resmi:</span>
              <div className="mt-1 text-2xl font-bold text-blue-600">{izinCount}</div>
              <div className="text-[11px] text-slate-400">Pemberitahuan Ortu</div>
            </div>
            <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-xs">
              <span className="text-xs text-slate-500 font-medium">Alpa / Tanpa Kabar:</span>
              <div className="mt-1 text-2xl font-bold text-rose-600">{alpaCount}</div>
              <div className="text-[11px] text-slate-400">Perlu Konfirmasi BK</div>
            </div>
          </div>

          {/* Class Breakdown Table */}
          <div className="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-xs">
            <div className="p-4 border-b border-slate-100">
              <h4 className="font-bold text-slate-900 text-sm">Monitoring Rekapitulasi Presensi per Rombel</h4>
              <p className="text-xs text-slate-500">
                Pembaruan kehadiran real-time yang diinput oleh masing-masing Guru / Wali Kelas hari ini.
              </p>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs text-slate-700">
                <thead className="bg-slate-50 text-[11px] font-bold uppercase text-slate-500 border-b border-slate-200">
                  <tr>
                    <th className="px-4 py-3">Kelas / Rombel</th>
                    <th className="px-4 py-3">Wali Kelas</th>
                    <th className="px-4 py-3 text-center">Total Siswa</th>
                    <th className="px-4 py-3 text-center">Hadir</th>
                    <th className="px-4 py-3 text-center">Sakit</th>
                    <th className="px-4 py-3 text-center">Izin</th>
                    <th className="px-4 py-3 text-center">Alpa</th>
                    <th className="px-4 py-3 text-right">Persentase</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {classes.map((cls) => {
                    const classStudents = students.filter((s) => s.class_id === cls.id);
                    const total = classStudents.length || 32;
                    const hadir = Math.max(0, total - (cls.id.charCodeAt(cls.id.length - 1) % 3));
                    const pct = Math.round((hadir / total) * 100);

                    return (
                      <tr key={cls.id} className="hover:bg-slate-50/80">
                        <td className="px-4 py-3 font-bold text-slate-900">{cls.name}</td>
                        <td className="px-4 py-3 text-slate-600">{cls.wali_kelas_name || 'Wali Kelas Terdaftar'}</td>
                        <td className="px-4 py-3 text-center font-semibold text-slate-700">{total}</td>
                        <td className="px-4 py-3 text-center font-bold text-emerald-600">{hadir}</td>
                        <td className="px-4 py-3 text-center text-amber-600 font-medium">1</td>
                        <td className="px-4 py-3 text-center text-blue-600 font-medium">0</td>
                        <td className="px-4 py-3 text-center text-rose-600 font-medium">
                          {total - hadir > 1 ? 1 : 0}
                        </td>
                        <td className="px-4 py-3 text-right font-black text-slate-800">{pct}%</td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ================= SUB-TAB 3: EKSTRAKURIKULER & OSIS ================= */}
      {subTab === 'EKSKUL' && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {extracurriculars.map((eks) => (
              <div
                key={eks.id}
                className="rounded-2xl border border-slate-200 bg-white p-5 shadow-xs flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between">
                    <span className="rounded-md bg-rose-50 px-2 py-0.5 text-[10px] font-extrabold text-rose-800 border border-rose-200">
                      {eks.category}
                    </span>
                    <span className="text-xs font-semibold text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-full">
                      Aktif
                    </span>
                  </div>
                  <h4 className="mt-2 text-base font-bold text-slate-900">{eks.name}</h4>
                  <p className="mt-1 text-xs text-slate-500">Pembina: {eks.coach_name}</p>

                  <div className="mt-3 space-y-1 text-xs text-slate-600 border-t border-slate-100 pt-2.5">
                    <div className="flex items-center justify-between">
                      <span className="text-slate-400">Jadwal:</span>
                      <span className="font-semibold">{eks.schedule_day}, {eks.time_range}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-slate-400">Lokasi:</span>
                      <span className="font-semibold">{eks.location}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-slate-400">Anggaran Operasional:</span>
                      <span className="font-bold text-slate-800">
                        Rp {eks.annual_budget.toLocaleString('id-ID')} / thn
                      </span>
                    </div>
                  </div>
                </div>

                <div className="mt-4 flex items-center justify-between border-t border-slate-100 pt-3 text-xs">
                  <span className="font-medium text-slate-500">Anggota Terdaftar</span>
                  <span className="font-black text-rose-700 text-sm">{eks.member_count} Siswa</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ================= SUB-TAB 4: PENYALURAN BEASISWA PIP ================= */}
      {subTab === 'BEASISWA' && (
        <div className="space-y-4">
          <div className="rounded-2xl border border-rose-100 bg-rose-50/50 p-4 text-xs text-rose-900 flex items-start gap-3">
            <HeartHandshake className="h-5 w-5 shrink-0 text-rose-600 mt-0.5" />
            <div>
              <div className="font-bold">Pengawalan Program Indonesia Pintar (PIP) & Bantuan Siswa:</div>
              <p className="mt-0.5 text-rose-800">
                Waka Kesiswaan bertanggung jawab memvalidasi aktivasi rekening SimPel (Simpanan Pelajar) di bank penyalur
                (BRI/BNI) serta memastikan dana bantuan tepat sasaran dan bebas dari pungutan liar.
              </p>
            </div>
          </div>

          <div className="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-xs">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs text-slate-700">
                <thead className="bg-slate-50 text-[11px] font-bold uppercase text-slate-500 border-b border-slate-200">
                  <tr>
                    <th className="px-4 py-3">Nama Siswa & NISN</th>
                    <th className="px-4 py-3">Kelas</th>
                    <th className="px-4 py-3">Program Beasiswa</th>
                    <th className="px-4 py-3">Nominal Dana</th>
                    <th className="px-4 py-3">Tahap Penyaluran</th>
                    <th className="px-4 py-3">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {scholarships.length === 0 ? (
                    <tr>
                      <td colSpan={6} className="py-8 text-center text-slate-400">
                        Belum ada data penerima beasiswa terdaftar.
                      </td>
                    </tr>
                  ) : (
                    scholarships.map((sch) => (
                      <tr key={sch.id} className="hover:bg-slate-50/80">
                        <td className="px-4 py-3 font-semibold text-slate-900">
                          {sch.student_name}
                          <div className="text-[11px] font-normal text-slate-400">NISN: {sch.nisn}</div>
                        </td>
                        <td className="px-4 py-3">
                          <span className="rounded bg-slate-100 px-2 py-0.5 text-xs font-bold text-slate-700">
                            {sch.class_name}
                          </span>
                        </td>
                        <td className="px-4 py-3 font-medium text-slate-800">{sch.program_type}</td>
                        <td className="px-4 py-3 font-bold text-slate-900">
                          Rp {sch.nominal_per_year.toLocaleString('id-ID')}
                        </td>
                        <td className="px-4 py-3 text-slate-600">{sch.disbursement_stage}</td>
                        <td className="px-4 py-3">
                          {sch.disbursement_status === 'CAIR' ? (
                            <span className="inline-flex items-center gap-1 rounded-full bg-emerald-50 px-2.5 py-0.5 text-[11px] font-bold text-emerald-800 border border-emerald-200">
                              <CheckCircle2 className="h-3 w-3" /> Sudah Cair
                            </span>
                          ) : sch.disbursement_status === 'TERVERIFIKASI' ? (
                            <span className="rounded-full bg-blue-50 px-2.5 py-0.5 text-[11px] font-bold text-blue-800 border border-blue-200">
                              Terverifikasi
                            </span>
                          ) : (
                            <span className="rounded-full bg-amber-50 px-2.5 py-0.5 text-[11px] font-bold text-amber-800 border border-amber-200">
                              Menunggu Verifikasi
                            </span>
                          )}
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ================= MODAL: CATAT DISIPLIN ================= */}
      {showDisciplineModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 p-4 backdrop-blur-xs">
          <div className="w-full max-w-lg rounded-2xl bg-white p-6 shadow-2xl animate-in fade-in zoom-in-95">
            <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
              <ShieldAlert className="h-5 w-5 text-rose-600" />
              <span>Catat Poin Kedisiplinan / Prestasi Siswa</span>
            </h3>
            <p className="mt-1 text-xs text-slate-500">
              Pencatatan resmi ke dalam Buku Saku Tata Tertib & Pembinaan Karakter Peserta Didik.
            </p>

            <form onSubmit={handleCreateDiscipline} className="mt-4 space-y-3.5 text-xs">
              <div>
                <label className="font-semibold text-slate-700">Pilih Siswa:</label>
                <select
                  value={discForm.student_id}
                  onChange={(e) => setDiscForm({ ...discForm, student_id: e.target.value })}
                  className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-xs focus:border-rose-500 focus:outline-none"
                  required
                >
                  <option value="">-- Pilih Siswa --</option>
                  {students.map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.full_name} ({s.class_name || 'Rombel'} - NISN: {s.nisn})
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-semibold text-slate-700">Jenis Catatan:</label>
                  <select
                    value={discForm.type}
                    onChange={(e) =>
                      setDiscForm({
                        ...discForm,
                        type: e.target.value as any,
                        category: e.target.value === 'PELANGGARAN' ? 'Keterlambatan Hadir' : 'Juara Lomba',
                      })
                    }
                    className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-xs focus:border-rose-500 focus:outline-none"
                  >
                    <option value="PELANGGARAN">Pelanggaran Tata Tertib</option>
                    <option value="PRESTASI">Penghargaan / Prestasi</option>
                  </select>
                </div>
                <div>
                  <label className="font-semibold text-slate-700">Bobot Poin:</label>
                  <input
                    type="number"
                    min={1}
                    max={100}
                    value={discForm.points}
                    onChange={(e) => setDiscForm({ ...discForm, points: Number(e.target.value) })}
                    className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-xs focus:border-rose-500 focus:outline-none"
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-semibold text-slate-700">Kategori:</label>
                  <input
                    type="text"
                    value={discForm.category}
                    onChange={(e) => setDiscForm({ ...discForm, category: e.target.value })}
                    placeholder="Contoh: Keterlambatan, Seragam, dsb"
                    className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-xs focus:border-rose-500 focus:outline-none"
                    required
                  />
                </div>
                <div>
                  <label className="font-semibold text-slate-700">Tanggal Kejadian:</label>
                  <input
                    type="date"
                    value={discForm.date}
                    onChange={(e) => setDiscForm({ ...discForm, date: e.target.value })}
                    className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-xs focus:border-rose-500 focus:outline-none"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="font-semibold text-slate-700">Deskripsi Kejadian / Kronologi:</label>
                <textarea
                  rows={2}
                  value={discForm.description}
                  onChange={(e) => setDiscForm({ ...discForm, description: e.target.value })}
                  placeholder="Penjelasan ringkas kejadian, bukti, atau nama lomba yang dimenangkan..."
                  className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-xs focus:border-rose-500 focus:outline-none"
                  required
                />
              </div>

              <div>
                <label className="font-semibold text-slate-700">Tindak Lanjut / Sanksi / Pembinaan:</label>
                <input
                  type="text"
                  value={discForm.follow_up_action}
                  onChange={(e) => setDiscForm({ ...discForm, follow_up_action: e.target.value })}
                  placeholder="Contoh: Teguran Lisan, Panggilan Orang Tua, Konseling BK"
                  className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-xs focus:border-rose-500 focus:outline-none"
                />
              </div>

              <div className="mt-5 flex items-center justify-end gap-2 border-t border-slate-100 pt-3">
                <button
                  type="button"
                  onClick={() => setShowDisciplineModal(false)}
                  className="rounded-xl px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="rounded-xl bg-rose-600 px-4 py-2 text-xs font-bold text-white shadow-xs hover:bg-rose-700"
                >
                  Simpan Catatan
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ================= MODAL: EKSKUL ================= */}
      {showEkskulModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 p-4 backdrop-blur-xs">
          <div className="w-full max-w-lg rounded-2xl bg-white p-6 shadow-2xl animate-in fade-in zoom-in-95">
            <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
              <Award className="h-5 w-5 text-rose-600" />
              <span>Registrasi Ekstrakurikuler Baru</span>
            </h3>

            <form onSubmit={handleCreateEkskul} className="mt-4 space-y-3.5 text-xs">
              <div>
                <label className="font-semibold text-slate-700">Nama Ekstrakurikuler:</label>
                <input
                  type="text"
                  value={ekskulForm.name}
                  onChange={(e) => setEkskulForm({ ...ekskulForm, name: e.target.value })}
                  placeholder="Contoh: Robotika & IoT Club, Pramuka Inti"
                  className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-xs focus:border-rose-500 focus:outline-none"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-semibold text-slate-700">Kategori:</label>
                  <select
                    value={ekskulForm.category}
                    onChange={(e) => setEkskulForm({ ...ekskulForm, category: e.target.value as any })}
                    className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-xs focus:border-rose-500 focus:outline-none"
                  >
                    <option value="OLAHRAGA">Olahraga</option>
                    <option value="SENI">Seni & Budaya</option>
                    <option value="SAINS">Sains & Riset</option>
                    <option value="KEAGAMAAN">Keagamaan / Rohis / Rokris</option>
                    <option value="KEPEMIMPINAN">Kepemimpinan / Paskibra / PMR</option>
                  </select>
                </div>
                <div>
                  <label className="font-semibold text-slate-700">Nama Guru Pembina:</label>
                  <input
                    type="text"
                    value={ekskulForm.coach_name}
                    onChange={(e) => setEkskulForm({ ...ekskulForm, coach_name: e.target.value })}
                    placeholder="Nama guru / pelatih luar"
                    className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-xs focus:border-rose-500 focus:outline-none"
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-semibold text-slate-700">Hari Latihan:</label>
                  <input
                    type="text"
                    value={ekskulForm.schedule_day}
                    onChange={(e) => setEkskulForm({ ...ekskulForm, schedule_day: e.target.value })}
                    className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-xs focus:border-rose-500 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="font-semibold text-slate-700">Jam Latihan:</label>
                  <input
                    type="text"
                    value={ekskulForm.time_range}
                    onChange={(e) => setEkskulForm({ ...ekskulForm, time_range: e.target.value })}
                    className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-xs focus:border-rose-500 focus:outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-semibold text-slate-700">Lokasi Latihan:</label>
                  <input
                    type="text"
                    value={ekskulForm.location}
                    onChange={(e) => setEkskulForm({ ...ekskulForm, location: e.target.value })}
                    className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-xs focus:border-rose-500 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="font-semibold text-slate-700">Anggaran Tahunan (Rp):</label>
                  <input
                    type="number"
                    value={ekskulForm.annual_budget}
                    onChange={(e) => setEkskulForm({ ...ekskulForm, annual_budget: Number(e.target.value) })}
                    className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-xs focus:border-rose-500 focus:outline-none"
                  />
                </div>
              </div>

              <div className="mt-5 flex items-center justify-end gap-2 border-t border-slate-100 pt-3">
                <button
                  type="button"
                  onClick={() => setShowEkskulModal(false)}
                  className="rounded-xl px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="rounded-xl bg-rose-600 px-4 py-2 text-xs font-bold text-white shadow-xs hover:bg-rose-700"
                >
                  Daftarkan Ekskul
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ================= MODAL: BEASISWA ================= */}
      {showScholarshipModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 p-4 backdrop-blur-xs">
          <div className="w-full max-w-lg rounded-2xl bg-white p-6 shadow-2xl animate-in fade-in zoom-in-95">
            <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
              <HeartHandshake className="h-5 w-5 text-rose-600" />
              <span>Daftarkan Penerima Beasiswa / PIP</span>
            </h3>

            <form onSubmit={handleCreateScholarship} className="mt-4 space-y-3.5 text-xs">
              <div>
                <label className="font-semibold text-slate-700">Pilih Siswa Penerima:</label>
                <select
                  value={scholarshipForm.student_id}
                  onChange={(e) => setScholarshipForm({ ...scholarshipForm, student_id: e.target.value })}
                  className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-xs focus:border-rose-500 focus:outline-none"
                  required
                >
                  <option value="">-- Pilih Siswa --</option>
                  {students.map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.full_name} ({s.class_name || 'Rombel'} - NISN: {s.nisn})
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-semibold text-slate-700">Program Beasiswa:</label>
                  <select
                    value={scholarshipForm.program_type}
                    onChange={(e) =>
                      setScholarshipForm({ ...scholarshipForm, program_type: e.target.value as any })
                    }
                    className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-xs focus:border-rose-500 focus:outline-none"
                    required
                  >
                    <option value="PIP_KEMDIKBUD">PIP Kemdikbud</option>
                    <option value="KIP_KULIAH">KIP Kuliah / Pelajar</option>
                    <option value="PRESTASI">Beasiswa Prestasi Akademik</option>
                    <option value="YAYASAN">Bantuan Dana Yayasan</option>
                    <option value="LAZIS">Bantuan Lazis / Swadaya</option>
                  </select>
                </div>
                <div>
                  <label className="font-semibold text-slate-700">Nominal Bantuan (Rp):</label>
                  <input
                    type="number"
                    value={scholarshipForm.nominal_per_year}
                    onChange={(e) =>
                      setScholarshipForm({ ...scholarshipForm, nominal_per_year: Number(e.target.value) })
                    }
                    className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-xs focus:border-rose-500 focus:outline-none"
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-semibold text-slate-700">Tahap Penyaluran:</label>
                  <input
                    type="text"
                    value={scholarshipForm.disbursement_stage}
                    onChange={(e) =>
                      setScholarshipForm({ ...scholarshipForm, disbursement_stage: e.target.value })
                    }
                    placeholder="Tahap 1 / 2024"
                    className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-xs focus:border-rose-500 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="font-semibold text-slate-700">Status Penyaluran:</label>
                  <select
                    value={scholarshipForm.disbursement_status}
                    onChange={(e) =>
                      setScholarshipForm({ ...scholarshipForm, disbursement_status: e.target.value as any })
                    }
                    className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-xs focus:border-rose-500 focus:outline-none"
                  >
                    <option value="CAIR">Sudah Cair (Bank)</option>
                    <option value="TERVERIFIKASI">Terverifikasi (Siap Salur)</option>
                    <option value="PENGAJUAN">Pengajuan Usulan Baru</option>
                  </select>
                </div>
              </div>

              <div className="mt-5 flex items-center justify-end gap-2 border-t border-slate-100 pt-3">
                <button
                  type="button"
                  onClick={() => setShowScholarshipModal(false)}
                  className="rounded-xl px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="rounded-xl bg-rose-600 px-4 py-2 text-xs font-bold text-white shadow-xs hover:bg-rose-700"
                >
                  Simpan Penerima
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
