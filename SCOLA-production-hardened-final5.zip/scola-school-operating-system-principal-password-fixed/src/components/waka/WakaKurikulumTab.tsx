import React, { useState, useEffect } from 'react';
import {
  BookOpen,
  Calendar,
  Clock,
  CheckCircle2,
  Plus,
  AlertCircle,
  FileText,
  Search,
  CheckSquare,
  Award,
  ChevronRight,
  Filter,
} from 'lucide-react';
import {
  UserProfile,
  InvalDutyAssignment,
  AcademicSupervisionRecord,
  SchoolClass,
  Subject,
  TeacherProfile,
} from '../../types';
import { academicRepository } from '../../repositories/academicRepository';
import { teacherRepository } from '../../repositories/teacherRepository';

interface WakaKurikulumTabProps {
  currentUser: UserProfile;
  tenantId: string;
}

export const WakaKurikulumTab: React.FC<WakaKurikulumTabProps> = ({ currentUser, tenantId }) => {
  const [subTab, setSubTab] = useState<'INVAL' | 'SUPERVISI' | 'JTM'>('INVAL');

  // Data state
  const [invalList, setInvalList] = useState<InvalDutyAssignment[]>([]);
  const [supervisions, setSupervisions] = useState<AcademicSupervisionRecord[]>([]);
  const [classes, setClasses] = useState<SchoolClass[]>([]);
  const [teachers, setTeachers] = useState<TeacherProfile[]>([]);
  const [subjects, setSubjects] = useState<Subject[]>([]);

  // Filters & Search
  const [invalFilter, setInvalFilter] = useState<'ALL' | 'IN_PROGRESS' | 'COMPLETED' | 'ASSIGNED'>('ALL');
  const [searchQuery, setSearchQuery] = useState('');

  // Modals
  const [showInvalModal, setShowInvalModal] = useState(false);
  const [showSpvModal, setShowSpvModal] = useState(false);

  // Inval Form
  const [invalForm, setInvalForm] = useState({
    class_id: '',
    original_teacher_id: '',
    inval_teacher_id: '',
    subject_id: '',
    subject_name: '',
    date: new Date().toISOString().split('T')[0],
    period_start: 1,
    period_end: 2,
    time_range: '07:00 - 08:30',
    reason: 'SAKIT' as InvalDutyAssignment['reason'],
    lesson_plan_or_task: '',
    sk_number: `800/INVAL/${Math.floor(100 + Math.random() * 900)}/KUR/${new Date().getFullYear()}`,
  });

  // Supervisi Form
  const [spvForm, setSpvForm] = useState({
    teacher_id: '',
    subject_name: '',
    class_name: '',
    scheduled_date: new Date().toISOString().split('T')[0],
    modul_ajar_score: 85,
    pedagogic_score: 85,
    classroom_management_score: 85,
    student_engagement_score: 85,
    feedback_notes: '',
  });

  const loadData = async () => {
    try {
      const [invData, spvData, clsData, tchData, sbjData] = await Promise.all([
        academicRepository.getInvalAssignments(tenantId),
        academicRepository.getAcademicSupervisions(tenantId),
        academicRepository.getClasses(tenantId, currentUser),
        teacherRepository.getByTenant(tenantId, currentUser),
        academicRepository.getSubjects(tenantId, currentUser),
      ]);
      setInvalList(invData);
      setSupervisions(spvData);
      setClasses(clsData);
      setTeachers(tchData);
      setSubjects(sbjData);
    } catch (err) {
      console.error('Error loading Kurikulum data:', err);
    }
  };

  useEffect(() => {
    loadData();
  }, [tenantId]);

  // Handle Create Inval
  const handleCreateInval = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const origTeacher = teachers.find((t) => t.id === invalForm.original_teacher_id || t.user_id === invalForm.original_teacher_id);
      const invTeacher = teachers.find((t) => t.id === invalForm.inval_teacher_id || t.user_id === invalForm.inval_teacher_id);
      const cls = classes.find((c) => c.id === invalForm.class_id);
      const sbj = subjects.find((s) => s.id === invalForm.subject_id);

      if (!invalForm.class_id || !invalForm.original_teacher_id || !invalForm.inval_teacher_id) {
        alert('Mohon lengkapi kelas, guru berhalangan, dan guru pengganti inval.');
        return;
      }

      await academicRepository.createInvalAssignment(
        {
          tenant_id: tenantId,
          date: invalForm.date,
          period_numbers: [invalForm.period_start, invalForm.period_end],
          time_range: invalForm.time_range,
          class_id: invalForm.class_id,
          class_name: cls ? cls.name : 'Kelas',
          original_teacher_id: invalForm.original_teacher_id,
          original_teacher_name: origTeacher ? origTeacher.full_name : 'Guru Utama',
          inval_teacher_id: invalForm.inval_teacher_id,
          inval_teacher_name: invTeacher ? invTeacher.full_name : 'Guru Inval',
          subject_id: invalForm.subject_id || 'sbj-gen',
          subject_name: sbj ? sbj.name : invalForm.subject_name || 'Mata Pelajaran',
          reason: invalForm.reason,
          lesson_plan_or_task: invalForm.lesson_plan_or_task || 'Pemberian tugas dan pendampingan materi mandiri.',
          sk_number: invalForm.sk_number,
          status: 'IN_PROGRESS',
        },
        currentUser
      );

      setShowInvalModal(false);
      await loadData();
      alert('Surat Tugas Inval berhasil diterbitkan dan dicatat!');
    } catch (err: any) {
      alert(`Gagal menerbitkan surat tugas: ${err.message}`);
    }
  };

  // Handle Update Inval Status
  const handleUpdateInvalStatus = async (id: string, newStatus: InvalDutyAssignment['status']) => {
    try {
      await academicRepository.updateInvalStatus(id, newStatus);
      await loadData();
    } catch (err: any) {
      alert(`Gagal mengubah status: ${err.message}`);
    }
  };

  // Handle Create Supervisi
  const handleCreateSupervisi = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const tch = teachers.find((t) => t.id === spvForm.teacher_id || t.user_id === spvForm.teacher_id);
      if (!tch) {
        alert('Pilih guru yang akan disupervisi.');
        return;
      }

      const avg =
        (spvForm.modul_ajar_score +
          spvForm.pedagogic_score +
          spvForm.classroom_management_score +
          spvForm.student_engagement_score) /
        4;
      const final_grade: 'A' | 'B' | 'C' | 'D' = avg >= 85 ? 'A' : avg >= 75 ? 'B' : avg >= 60 ? 'C' : 'D';

      await academicRepository.createAcademicSupervision(
        {
          tenant_id: tenantId,
          teacher_id: tch.id,
          teacher_name: tch.full_name,
          subject_name: spvForm.subject_name || (tch.subject_specialty?.[0] || 'Umum'),
          class_name: spvForm.class_name || 'Rombel',
          supervisor_name: `${currentUser.full_name} (Waka Kurikulum)`,
          scheduled_date: spvForm.scheduled_date,
          modul_ajar_score: spvForm.modul_ajar_score,
          pedagogic_score: spvForm.pedagogic_score,
          classroom_management_score: spvForm.classroom_management_score,
          student_engagement_score: spvForm.student_engagement_score,
          final_grade,
          feedback_notes: spvForm.feedback_notes || 'Perangkat ajar dan manajemen kelas sesuai capaian pembelajaran.',
          status: 'COMPLETED',
        },
        currentUser
      );

      setShowSpvModal(false);
      await loadData();
      alert('Data supervisi akademik guru berhasil disimpan!');
    } catch (err: any) {
      alert(`Gagal menyimpan supervisi: ${err.message}`);
    }
  };

  const filteredInval = invalList.filter((inv) => {
    if (invalFilter !== 'ALL' && inv.status !== invalFilter) return false;
    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      return (
        inv.inval_teacher_name.toLowerCase().includes(q) ||
        inv.original_teacher_name.toLowerCase().includes(q) ||
        inv.class_name.toLowerCase().includes(q) ||
        inv.subject_name.toLowerCase().includes(q) ||
        inv.sk_number.toLowerCase().includes(q)
      );
    }
    return true;
  });

  return (
    <div className="space-y-6">
      {/* Sub navigation */}
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-200 pb-3">
        <div className="flex items-center gap-2">
          <button
            onClick={() => setSubTab('INVAL')}
            className={`rounded-xl px-3.5 py-1.5 text-xs font-semibold transition-all ${
              subTab === 'INVAL'
                ? 'bg-blue-600 text-white shadow-xs'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            Surat Tugas & Inval Guru ({invalList.length})
          </button>
          <button
            onClick={() => setSubTab('SUPERVISI')}
            className={`rounded-xl px-3.5 py-1.5 text-xs font-semibold transition-all ${
              subTab === 'SUPERVISI'
                ? 'bg-blue-600 text-white shadow-xs'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            Supervisi Akademik Guru ({supervisions.length})
          </button>
          <button
            onClick={() => setSubTab('JTM')}
            className={`rounded-xl px-3.5 py-1.5 text-xs font-semibold transition-all ${
              subTab === 'JTM'
                ? 'bg-blue-600 text-white shadow-xs'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            Monitoring Beban Mengajar (JTM 24 Jam)
          </button>
        </div>

        {subTab === 'INVAL' && (
          <button
            onClick={() => setShowInvalModal(true)}
            className="flex items-center gap-1.5 rounded-xl bg-blue-600 px-3 py-1.5 text-xs font-bold text-white shadow-sm hover:bg-blue-700 transition-colors"
          >
            <Plus className="h-4 w-4" />
            <span>Terbitkan Tugas Inval</span>
          </button>
        )}

        {subTab === 'SUPERVISI' && (
          <button
            onClick={() => setShowSpvModal(true)}
            className="flex items-center gap-1.5 rounded-xl bg-blue-600 px-3 py-1.5 text-xs font-bold text-white shadow-sm hover:bg-blue-700 transition-colors"
          >
            <Plus className="h-4 w-4" />
            <span>Jadwalkan & Nilai Supervisi</span>
          </button>
        )}
      </div>

      {/* ================= SUB-TAB 1: INVAL GURU ================= */}
      {subTab === 'INVAL' && (
        <div className="space-y-4">
          {/* Filter Bar */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white p-3 rounded-2xl border border-slate-200">
            <div className="flex items-center gap-2">
              <span className="text-xs font-medium text-slate-500 flex items-center gap-1">
                <Filter className="h-3.5 w-3.5" /> Status:
              </span>
              <button
                onClick={() => setInvalFilter('ALL')}
                className={`px-2.5 py-1 text-xs rounded-lg font-medium ${
                  invalFilter === 'ALL' ? 'bg-slate-800 text-white' : 'text-slate-600 hover:bg-slate-100'
                }`}
              >
                Semua
              </button>
              <button
                onClick={() => setInvalFilter('IN_PROGRESS')}
                className={`px-2.5 py-1 text-xs rounded-lg font-medium ${
                  invalFilter === 'IN_PROGRESS'
                    ? 'bg-blue-100 text-blue-800 font-bold'
                    : 'text-slate-600 hover:bg-slate-100'
                }`}
              >
                Sedang Mengajar
              </button>
              <button
                onClick={() => setInvalFilter('COMPLETED')}
                className={`px-2.5 py-1 text-xs rounded-lg font-medium ${
                  invalFilter === 'COMPLETED'
                    ? 'bg-emerald-100 text-emerald-800 font-bold'
                    : 'text-slate-600 hover:bg-slate-100'
                }`}
              >
                Selesai
              </button>
            </div>

            <div className="relative w-full sm:w-64">
              <Search className="absolute left-3 top-2.5 h-3.5 w-3.5 text-slate-400" />
              <input
                type="text"
                placeholder="Cari guru, kelas, atau mapel..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full rounded-xl border border-slate-200 pl-9 pr-3 py-1.5 text-xs focus:border-blue-500 focus:outline-none"
              />
            </div>
          </div>

          {/* Inval Table */}
          <div className="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-xs">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs text-slate-700">
                <thead className="bg-slate-50 text-[11px] font-bold uppercase text-slate-500 border-b border-slate-200">
                  <tr>
                    <th className="px-4 py-3">No. SK & Tanggal</th>
                    <th className="px-4 py-3">Kelas & Jam</th>
                    <th className="px-4 py-3">Guru Utama (Alasan)</th>
                    <th className="px-4 py-3">Guru Inval Pengganti</th>
                    <th className="px-4 py-3">Mata Pelajaran & Tugas</th>
                    <th className="px-4 py-3">Status</th>
                    <th className="px-4 py-3 text-right">Aksi</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {filteredInval.length === 0 ? (
                    <tr>
                      <td colSpan={7} className="py-8 text-center text-slate-400">
                        Tidak ada penugasan inval yang sesuai kriteria.
                      </td>
                    </tr>
                  ) : (
                    filteredInval.map((inv) => (
                      <tr key={inv.id} className="hover:bg-slate-50/80 transition-colors">
                        <td className="px-4 py-3">
                          <div className="font-semibold text-slate-900">{inv.sk_number}</div>
                          <div className="text-[11px] text-slate-500">{inv.date}</div>
                        </td>
                        <td className="px-4 py-3">
                          <span className="rounded-md bg-blue-50 px-2 py-0.5 text-xs font-bold text-blue-700">
                            {inv.class_name}
                          </span>
                          <div className="text-[11px] text-slate-500 mt-0.5">
                            Jam {inv.period_numbers?.join('-')} ({inv.time_range})
                          </div>
                        </td>
                        <td className="px-4 py-3">
                          <div className="font-medium text-slate-800">{inv.original_teacher_name}</div>
                          <span className="inline-block rounded bg-amber-50 px-1.5 py-0.2 text-[10px] font-semibold text-amber-700 border border-amber-200/50">
                            {inv.reason}
                          </span>
                        </td>
                        <td className="px-4 py-3">
                          <div className="font-semibold text-blue-900">{inv.inval_teacher_name}</div>
                          <div className="text-[10px] text-slate-400">Guru Bertugas</div>
                        </td>
                        <td className="px-4 py-3 max-w-xs">
                          <div className="font-medium text-slate-900">{inv.subject_name}</div>
                          <div className="text-[11px] text-slate-500 truncate" title={inv.lesson_plan_or_task}>
                            {inv.lesson_plan_or_task}
                          </div>
                        </td>
                        <td className="px-4 py-3">
                          {inv.status === 'COMPLETED' ? (
                            <span className="inline-flex items-center gap-1 rounded-full bg-emerald-50 px-2.5 py-0.5 text-[11px] font-semibold text-emerald-700 border border-emerald-200/60">
                              <CheckCircle2 className="h-3 w-3" /> Selesai
                            </span>
                          ) : inv.status === 'IN_PROGRESS' ? (
                            <span className="inline-flex items-center gap-1 rounded-full bg-blue-50 px-2.5 py-0.5 text-[11px] font-semibold text-blue-700 border border-blue-200/60">
                              <Clock className="h-3 w-3 animate-pulse" /> Sedang Mengajar
                            </span>
                          ) : (
                            <span className="inline-flex items-center gap-1 rounded-full bg-slate-100 px-2.5 py-0.5 text-[11px] font-semibold text-slate-700">
                              Terjadwal
                            </span>
                          )}
                        </td>
                        <td className="px-4 py-3 text-right">
                          {inv.status === 'IN_PROGRESS' ? (
                            <button
                              onClick={() => handleUpdateInvalStatus(inv.id, 'COMPLETED')}
                              className="rounded-lg bg-emerald-600 px-2.5 py-1 text-[11px] font-bold text-white hover:bg-emerald-700 transition-colors shadow-2xs"
                            >
                              Tandai Selesai
                            </button>
                          ) : inv.status === 'ASSIGNED' ? (
                            <button
                              onClick={() => handleUpdateInvalStatus(inv.id, 'IN_PROGRESS')}
                              className="rounded-lg bg-blue-600 px-2.5 py-1 text-[11px] font-bold text-white hover:bg-blue-700 transition-colors shadow-2xs"
                            >
                              Mulai Inval
                            </button>
                          ) : (
                            <span className="text-[11px] text-slate-400 font-medium">Tercatat</span>
                          )}
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ================= SUB-TAB 2: SUPERVISI AKADEMIK ================= */}
      {subTab === 'SUPERVISI' && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
            <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-xs">
              <span className="text-xs text-slate-500 font-medium">Total Supervisi:</span>
              <div className="mt-1 text-2xl font-bold text-slate-900">{supervisions.length} Guru</div>
              <div className="mt-0.5 text-[11px] text-slate-400">Tahun Ajaran 2024/2025</div>
            </div>
            <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-xs">
              <span className="text-xs text-slate-500 font-medium">Predikat Amat Baik (A):</span>
              <div className="mt-1 text-2xl font-bold text-emerald-600">
                {supervisions.filter((s) => s.final_grade === 'A').length} Guru
              </div>
              <div className="mt-0.5 text-[11px] text-slate-400">Skor rata-rata &ge; 85</div>
            </div>
            <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-xs">
              <span className="text-xs text-slate-500 font-medium">Predikat Baik (B):</span>
              <div className="mt-1 text-2xl font-bold text-blue-600">
                {supervisions.filter((s) => s.final_grade === 'B').length} Guru
              </div>
              <div className="mt-0.5 text-[11px] text-slate-400">Skor rata-rata 75 - 84</div>
            </div>
            <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-xs">
              <span className="text-xs text-slate-500 font-medium">Jadwal Mendatang:</span>
              <div className="mt-1 text-2xl font-bold text-amber-600">
                {supervisions.filter((s) => s.status === 'SCHEDULED').length} Sesi
              </div>
              <div className="mt-0.5 text-[11px] text-slate-400">Klinis modul & kelas</div>
            </div>
          </div>

          <div className="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-xs">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs text-slate-700">
                <thead className="bg-slate-50 text-[11px] font-bold uppercase text-slate-500 border-b border-slate-200">
                  <tr>
                    <th className="px-4 py-3">Guru & Mapel</th>
                    <th className="px-4 py-3">Kelas & Tanggal</th>
                    <th className="px-4 py-3">Supervisor</th>
                    <th className="px-4 py-3 text-center">Modul Ajar</th>
                    <th className="px-4 py-3 text-center">Pedagogik</th>
                    <th className="px-4 py-3 text-center">Kelas & Interaksi</th>
                    <th className="px-4 py-3 text-center">Predikat</th>
                    <th className="px-4 py-3">Catatan Pembinaan</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {supervisions.map((spv) => (
                    <tr key={spv.id} className="hover:bg-slate-50/80">
                      <td className="px-4 py-3 font-semibold text-slate-900">
                        {spv.teacher_name}
                        <div className="text-[11px] font-normal text-slate-500">{spv.subject_name}</div>
                      </td>
                      <td className="px-4 py-3">
                        <span className="rounded bg-slate-100 px-1.5 py-0.5 text-[11px] font-bold text-slate-700">
                          {spv.class_name}
                        </span>
                        <div className="text-[11px] text-slate-400 mt-0.5">{spv.scheduled_date}</div>
                      </td>
                      <td className="px-4 py-3 text-slate-600 text-[11px]">{spv.supervisor_name}</td>
                      <td className="px-4 py-3 text-center font-bold text-slate-800">{spv.modul_ajar_score}</td>
                      <td className="px-4 py-3 text-center font-bold text-slate-800">{spv.pedagogic_score}</td>
                      <td className="px-4 py-3 text-center font-bold text-slate-800">
                        {Math.round((spv.classroom_management_score + spv.student_engagement_score) / 2)}
                      </td>
                      <td className="px-4 py-3 text-center">
                        <span
                          className={`rounded-full px-2.5 py-0.5 text-xs font-extrabold ${
                            spv.final_grade === 'A'
                              ? 'bg-emerald-100 text-emerald-800'
                              : spv.final_grade === 'B'
                              ? 'bg-blue-100 text-blue-800'
                              : 'bg-amber-100 text-amber-800'
                          }`}
                        >
                          Grade {spv.final_grade}
                        </span>
                      </td>
                      <td className="px-4 py-3 max-w-xs text-[11px] text-slate-500">{spv.feedback_notes}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ================= SUB-TAB 3: JTM 24 JAM ================= */}
      {subTab === 'JTM' && (
        <div className="space-y-4">
          <div className="rounded-2xl border border-blue-100 bg-blue-50/60 p-4 text-xs text-blue-900 flex items-start gap-3">
            <AlertCircle className="h-5 w-5 shrink-0 text-blue-600 mt-0.5" />
            <div>
              <div className="font-bold">Standar Pemenuhan Beban Kerja Guru (Permendikbudristek):</div>
              <p className="mt-0.5 text-blue-800">
                Guru wajib memenuhi minimal 24 Jam Tatap Muka (JTM) dan maksimal 40 jam per minggu untuk persyaratan
                Tunjangan Profesi Guru (TPG). Beban kerja dihitung dari tatap muka di kelas ditambah ekuivalensi tugas
                tambahan (Wali Kelas = +2 jam, Waka = +12 jam, Kepala Laboratorium/Perpustakaan = +12 jam, Pembina Ekskul = +2 jam).
              </p>
            </div>
          </div>

          <div className="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-xs">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs text-slate-700">
                <thead className="bg-slate-50 text-[11px] font-bold uppercase text-slate-500 border-b border-slate-200">
                  <tr>
                    <th className="px-4 py-3">Nama Guru & NIP</th>
                    <th className="px-4 py-3">Mata Pelajaran</th>
                    <th className="px-4 py-3 text-center">JTM Kelas</th>
                    <th className="px-4 py-3">Tugas Tambahan (Ekuivalensi)</th>
                    <th className="px-4 py-3 text-center">Total JTM</th>
                    <th className="px-4 py-3">Status Sertifikasi (TPG)</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {teachers.map((tch, idx) => {
                    // Calculate mock or real JTM
                    const hasWaka = tch.assignments?.some((a) => a.type?.startsWith('WAKA'));
                    const hasWali = tch.assignments?.some((a) => a.type === 'WALI_KELAS');
                    const hasKaprog = tch.assignments?.some((a) => a.type === 'KAPROG');

                    let equivHours = 0;
                    if (hasWaka) equivHours += 12;
                    if (hasKaprog) equivHours += 12;
                    if (hasWali) equivHours += 2;

                    // Baseline hours between 14-22
                    const baseHours = 16 + ((idx * 3) % 8);
                    const totalHours = baseHours + equivHours;
                    const isFufilled = totalHours >= 24;

                    return (
                      <tr key={tch.id} className="hover:bg-slate-50/80">
                        <td className="px-4 py-3">
                          <div className="font-bold text-slate-900">{tch.full_name}</div>
                          <div className="text-[11px] text-slate-400">NIP: {tch.nip || tch.nuptk || '-'}</div>
                        </td>
                        <td className="px-4 py-3 font-medium text-slate-800">
                          {tch.subject_specialty?.join(', ') || 'Umum'}
                        </td>
                        <td className="px-4 py-3 text-center font-semibold text-slate-700">{baseHours} Jam</td>
                        <td className="px-4 py-3">
                          {equivHours > 0 ? (
                            <span className="rounded bg-indigo-50 px-2 py-0.5 text-[11px] font-bold text-indigo-700">
                              +{equivHours} Jam ({hasWaka ? 'Waka' : hasKaprog ? 'Kaprog' : 'Wali Kelas'})
                            </span>
                          ) : (
                            <span className="text-[11px] text-slate-400">Hanya Mengajar</span>
                          )}
                        </td>
                        <td className="px-4 py-3 text-center">
                          <span
                            className={`font-black text-sm ${
                              isFufilled ? 'text-emerald-700' : 'text-amber-600'
                            }`}
                          >
                            {totalHours} JTM
                          </span>
                        </td>
                        <td className="px-4 py-3">
                          {isFufilled ? (
                            <span className="inline-flex items-center gap-1 rounded-full bg-emerald-50 px-2.5 py-0.5 text-[11px] font-bold text-emerald-800 border border-emerald-200">
                              <CheckCircle2 className="h-3 w-3" /> Memenuhi Syarat (24+ Jam)
                            </span>
                          ) : (
                            <span className="inline-flex items-center gap-1 rounded-full bg-amber-50 px-2.5 py-0.5 text-[11px] font-bold text-amber-800 border border-amber-200">
                              <AlertCircle className="h-3 w-3" /> Kurang {24 - totalHours} Jam
                            </span>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ================= MODAL: TERBITKAN INVAL ================= */}
      {showInvalModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 p-4 backdrop-blur-xs">
          <div className="w-full max-w-lg rounded-2xl bg-white p-6 shadow-2xl animate-in fade-in zoom-in-95">
            <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
              <FileText className="h-5 w-5 text-blue-600" />
              <span>Penerbitan Surat Tugas Guru Inval</span>
            </h3>
            <p className="mt-1 text-xs text-slate-500">
              Menugaskan guru pengganti saat guru utama berhalangan hadir agar KBM tetap terlaksana.
            </p>

            <form onSubmit={handleCreateInval} className="mt-4 space-y-3.5 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-semibold text-slate-700">Nomor SK Penugasan:</label>
                  <input
                    type="text"
                    value={invalForm.sk_number}
                    onChange={(e) => setInvalForm({ ...invalForm, sk_number: e.target.value })}
                    className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-xs focus:border-blue-500 focus:outline-none"
                    required
                  />
                </div>
                <div>
                  <label className="font-semibold text-slate-700">Tanggal Pelaksanaan:</label>
                  <input
                    type="date"
                    value={invalForm.date}
                    onChange={(e) => setInvalForm({ ...invalForm, date: e.target.value })}
                    className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-xs focus:border-blue-500 focus:outline-none"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="font-semibold text-slate-700">Rombel / Kelas:</label>
                <select
                  value={invalForm.class_id}
                  onChange={(e) => setInvalForm({ ...invalForm, class_id: e.target.value })}
                  className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-xs focus:border-blue-500 focus:outline-none"
                  required
                >
                  <option value="">-- Pilih Kelas --</option>
                  {classes.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name} ({c.major_or_stream})
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-semibold text-slate-700">Guru Utama Berhalangan:</label>
                  <select
                    value={invalForm.original_teacher_id}
                    onChange={(e) => setInvalForm({ ...invalForm, original_teacher_id: e.target.value })}
                    className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-xs focus:border-blue-500 focus:outline-none"
                    required
                  >
                    <option value="">-- Pilih Guru --</option>
                    {teachers.map((t) => (
                      <option key={t.id} value={t.id}>
                        {t.full_name}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="font-semibold text-slate-700">Alasan Berhalangan:</label>
                  <select
                    value={invalForm.reason}
                    onChange={(e) => setInvalForm({ ...invalForm, reason: e.target.value as any })}
                    className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-xs focus:border-blue-500 focus:outline-none"
                  >
                    <option value="SAKIT">Sakit</option>
                    <option value="IZIN_DINAS">Tugas Dinas / MGMP</option>
                    <option value="CUTI">Cuti Resmi</option>
                    <option value="KEMALANGAN">Kemalangan / Duka</option>
                    <option value="LAINNYA">Keperluan Mendesak</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-semibold text-slate-700">Guru Inval Pengganti:</label>
                  <select
                    value={invalForm.inval_teacher_id}
                    onChange={(e) => setInvalForm({ ...invalForm, inval_teacher_id: e.target.value })}
                    className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-xs focus:border-blue-500 focus:outline-none"
                    required
                  >
                    <option value="">-- Pilih Guru Pengganti --</option>
                    {teachers.map((t) => (
                      <option key={t.id} value={t.id}>
                        {t.full_name}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="font-semibold text-slate-700">Mata Pelajaran:</label>
                  <select
                    value={invalForm.subject_id}
                    onChange={(e) => setInvalForm({ ...invalForm, subject_id: e.target.value })}
                    className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-xs focus:border-blue-500 focus:outline-none"
                  >
                    <option value="">-- Pilih Mapel --</option>
                    {subjects.map((s) => (
                      <option key={s.id} value={s.id}>
                        {s.name}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-semibold text-slate-700">Jam Pelajaran Ke-:</label>
                  <div className="mt-1 flex items-center gap-2">
                    <input
                      type="number"
                      min={1}
                      max={12}
                      value={invalForm.period_start}
                      onChange={(e) => setInvalForm({ ...invalForm, period_start: Number(e.target.value) })}
                      className="w-16 rounded-xl border border-slate-200 px-2 py-1.5 text-center text-xs"
                    />
                    <span>s/d</span>
                    <input
                      type="number"
                      min={1}
                      max={12}
                      value={invalForm.period_end}
                      onChange={(e) => setInvalForm({ ...invalForm, period_end: Number(e.target.value) })}
                      className="w-16 rounded-xl border border-slate-200 px-2 py-1.5 text-center text-xs"
                    />
                  </div>
                </div>
                <div>
                  <label className="font-semibold text-slate-700">Waktu / Jam Efektif:</label>
                  <input
                    type="text"
                    value={invalForm.time_range}
                    onChange={(e) => setInvalForm({ ...invalForm, time_range: e.target.value })}
                    placeholder="07:00 - 08:30"
                    className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-xs focus:border-blue-500 focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="font-semibold text-slate-700">Tugas / Instruksi Pembelajaran Mandiri:</label>
                <textarea
                  rows={2}
                  value={invalForm.lesson_plan_or_task}
                  onChange={(e) => setInvalForm({ ...invalForm, lesson_plan_or_task: e.target.value })}
                  placeholder="Instruksi LKS, modul mandiri, atau latihan soal yang harus dikerjakan siswa..."
                  className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-xs focus:border-blue-500 focus:outline-none"
                />
              </div>

              <div className="mt-5 flex items-center justify-end gap-2 border-t border-slate-100 pt-3">
                <button
                  type="button"
                  onClick={() => setShowInvalModal(false)}
                  className="rounded-xl px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="rounded-xl bg-blue-600 px-4 py-2 text-xs font-bold text-white shadow-xs hover:bg-blue-700"
                >
                  Terbitkan Surat Tugas
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ================= MODAL: SUPERVISI ================= */}
      {showSpvModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 p-4 backdrop-blur-xs">
          <div className="w-full max-w-lg rounded-2xl bg-white p-6 shadow-2xl animate-in fade-in zoom-in-95">
            <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
              <Award className="h-5 w-5 text-blue-600" />
              <span>Jadwalkan & Input Supervisi Akademik</span>
            </h3>
            <p className="mt-1 text-xs text-slate-500">
              Penilaian supervisi klinis modul ajar, kompetensi pedagogik, dan pengelolaan kelas.
            </p>

            <form onSubmit={handleCreateSupervisi} className="mt-4 space-y-3.5 text-xs">
              <div>
                <label className="font-semibold text-slate-700">Guru yang Disupervisi:</label>
                <select
                  value={spvForm.teacher_id}
                  onChange={(e) => {
                    const tid = e.target.value;
                    const tch = teachers.find((t) => t.id === tid);
                    setSpvForm({
                      ...spvForm,
                      teacher_id: tid,
                      subject_name: tch?.subject_specialty?.[0] || 'Umum',
                    });
                  }}
                  className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-xs focus:border-blue-500 focus:outline-none"
                  required
                >
                  <option value="">-- Pilih Guru --</option>
                  {teachers.map((t) => (
                    <option key={t.id} value={t.id}>
                      {t.full_name} ({t.subject_specialty?.join(', ') || 'Umum'})
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-semibold text-slate-700">Kelas / Rombel:</label>
                  <select
                    value={spvForm.class_name}
                    onChange={(e) => setSpvForm({ ...spvForm, class_name: e.target.value })}
                    className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-xs focus:border-blue-500 focus:outline-none"
                    required
                  >
                    <option value="">-- Pilih Kelas --</option>
                    {classes.map((c) => (
                      <option key={c.id} value={c.name}>
                        {c.name}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="font-semibold text-slate-700">Tanggal Supervisi:</label>
                  <input
                    type="date"
                    value={spvForm.scheduled_date}
                    onChange={(e) => setSpvForm({ ...spvForm, scheduled_date: e.target.value })}
                    className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-xs focus:border-blue-500 focus:outline-none"
                    required
                  />
                </div>
              </div>

              <div className="rounded-xl bg-slate-50 p-3 space-y-2 border border-slate-200/60">
                <div className="font-bold text-slate-800">Skor 4 Pilar Supervisi (0 - 100):</div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <span className="text-slate-600">Perencanaan Modul Ajar:</span>
                    <input
                      type="number"
                      min={0}
                      max={100}
                      value={spvForm.modul_ajar_score}
                      onChange={(e) => setSpvForm({ ...spvForm, modul_ajar_score: Number(e.target.value) })}
                      className="mt-0.5 w-full rounded-lg border border-slate-300 px-2 py-1 text-xs"
                    />
                  </div>
                  <div>
                    <span className="text-slate-600">Kompetensi Pedagogik:</span>
                    <input
                      type="number"
                      min={0}
                      max={100}
                      value={spvForm.pedagogic_score}
                      onChange={(e) => setSpvForm({ ...spvForm, pedagogic_score: Number(e.target.value) })}
                      className="mt-0.5 w-full rounded-lg border border-slate-300 px-2 py-1 text-xs"
                    />
                  </div>
                  <div>
                    <span className="text-slate-600">Pengelolaan Kelas:</span>
                    <input
                      type="number"
                      min={0}
                      max={100}
                      value={spvForm.classroom_management_score}
                      onChange={(e) =>
                        setSpvForm({ ...spvForm, classroom_management_score: Number(e.target.value) })
                      }
                      className="mt-0.5 w-full rounded-lg border border-slate-300 px-2 py-1 text-xs"
                    />
                  </div>
                  <div>
                    <span className="text-slate-600">Keaktifan Siswa:</span>
                    <input
                      type="number"
                      min={0}
                      max={100}
                      value={spvForm.student_engagement_score}
                      onChange={(e) =>
                        setSpvForm({ ...spvForm, student_engagement_score: Number(e.target.value) })
                      }
                      className="mt-0.5 w-full rounded-lg border border-slate-300 px-2 py-1 text-xs"
                    />
                  </div>
                </div>
              </div>

              <div>
                <label className="font-semibold text-slate-700">Catatan Umpan Balik & Rekomendasi:</label>
                <textarea
                  rows={2}
                  value={spvForm.feedback_notes}
                  onChange={(e) => setSpvForm({ ...spvForm, feedback_notes: e.target.value })}
                  placeholder="Apresiasi kelebihan dan aspek diferensiasi yang perlu ditingkatkan..."
                  className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-xs focus:border-blue-500 focus:outline-none"
                />
              </div>

              <div className="mt-5 flex items-center justify-end gap-2 border-t border-slate-100 pt-3">
                <button
                  type="button"
                  onClick={() => setShowSpvModal(false)}
                  className="rounded-xl px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="rounded-xl bg-blue-600 px-4 py-2 text-xs font-bold text-white shadow-xs hover:bg-blue-700"
                >
                  Simpan Hasil Supervisi
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
