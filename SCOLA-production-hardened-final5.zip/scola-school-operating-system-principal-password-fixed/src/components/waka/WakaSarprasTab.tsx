import React, { useState, useEffect } from 'react';
import {
  Wrench,
  Building2,
  Calendar,
  AlertCircle,
  Plus,
  CheckCircle2,
  Clock,
  Search,
  Filter,
  Layers,
  Sparkles,
} from 'lucide-react';
import {
  UserProfile,
  FacilityMaintenanceTicket,
  RoomReservationRecord,
  SchoolFacility,
} from '../../types';
import { academicRepository } from '../../repositories/academicRepository';

interface WakaSarprasTabProps {
  currentUser: UserProfile;
  tenantId: string;
}

export const WakaSarprasTab: React.FC<WakaSarprasTabProps> = ({ currentUser, tenantId }) => {
  const [subTab, setSubTab] = useState<'TIKET' | 'PEMINJAMAN' | 'FASILITAS'>('TIKET');

  // Data state
  const [tickets, setTickets] = useState<FacilityMaintenanceTicket[]>([]);
  const [reservations, setReservations] = useState<RoomReservationRecord[]>([]);
  const [facilities, setFacilities] = useState<SchoolFacility[]>([]);

  // Filter & Search
  const [ticketFilter, setTicketFilter] = useState<'ALL' | 'DALAM_PENGERJAAN' | 'SELESAI' | 'PENDING'>('ALL');
  const [searchQuery, setSearchQuery] = useState('');

  // Modals
  const [showTicketModal, setShowTicketModal] = useState(false);
  const [showReservationModal, setShowReservationModal] = useState(false);
  const [showFacilityModal, setShowFacilityModal] = useState(false);

  // Forms
  const [ticketForm, setTicketForm] = useState({
    facility_id: '',
    reported_by_name: currentUser.full_name,
    reported_by_role: 'Waka Sarpras',
    issue_description: '',
    urgency: 'SEDANG' as FacilityMaintenanceTicket['urgency'],
    estimated_cost: 450000,
    funding_source: 'BOS_REGULER' as FacilityMaintenanceTicket['funding_source'],
    assigned_technician: 'Tim Teknisi Sarpras Sekolah',
  });

  const [resForm, setResForm] = useState({
    facility_id: '',
    borrower_name: currentUser.full_name,
    borrower_role: 'GURU',
    purpose: 'Simulasi Ujian Berbasis Komputer & Asesmen Nasional',
    reservation_date: new Date().toISOString().split('T')[0],
    start_time: '08:00',
    end_time: '12:00',
  });

  const [facForm, setFacForm] = useState({
    name: '',
    code: '',
    category: 'Ruang Teori',
    capacity: 36,
    condition: 'BAIK' as 'BAIK' | 'RUSAK_RINGAN' | 'RUSAK_BERAT',
    location: 'Gedung A Lantai 2',
    pic_name: 'Staf Sarpras',
  });

  const loadData = async () => {
    try {
      const [tktData, resData, facData] = await Promise.all([
        academicRepository.getMaintenanceTickets(tenantId),
        academicRepository.getRoomReservations(tenantId),
        academicRepository.getFacilities(tenantId),
      ]);
      setTickets(tktData);
      setReservations(resData);
      setFacilities(facData);
    } catch (err) {
      console.error('Error loading Sarpras data:', err);
    }
  };

  useEffect(() => {
    loadData();
  }, [tenantId]);

  // Create Ticket
  const handleCreateTicket = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const fac = facilities.find((f) => f.id === ticketForm.facility_id);
      if (!ticketForm.facility_id || !ticketForm.issue_description) {
        alert('Mohon pilih fasilitas dan jelaskan kerusakan yang terjadi.');
        return;
      }

      await academicRepository.createMaintenanceTicket(
        {
          tenant_id: tenantId,
          ticket_number: `TKT-${Math.floor(1000 + Math.random() * 9000)}`,
          facility_id: ticketForm.facility_id,
          facility_name: fac ? fac.name : 'Sarana Sekolah',
          reported_by_name: ticketForm.reported_by_name,
          reported_by_role: ticketForm.reported_by_role,
          issue_description: ticketForm.issue_description,
          urgency: ticketForm.urgency,
          estimated_cost: ticketForm.estimated_cost,
          funding_source: ticketForm.funding_source,
          assigned_technician: ticketForm.assigned_technician,
          status: 'DALAM_PENGERJAAN',
          report_date: new Date().toISOString().split('T')[0],
        },
        currentUser
      );

      setShowTicketModal(false);
      await loadData();
      alert('Tiket kerusakan sarpras berhasil diterbitkan!');
    } catch (err: any) {
      alert(`Gagal membuat tiket: ${err.message}`);
    }
  };

  // Update Ticket Status
  const handleUpdateTicketStatus = async (id: string, newStatus: FacilityMaintenanceTicket['status']) => {
    try {
      await academicRepository.updateMaintenanceTicketStatus(id, newStatus);
      await loadData();
    } catch (err: any) {
      alert(`Gagal mengubah status: ${err.message}`);
    }
  };

  // Create Room Reservation
  const handleCreateReservation = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const fac = facilities.find((f) => f.id === resForm.facility_id);
      if (!resForm.facility_id || !resForm.purpose) {
        alert('Mohon pilih ruang/lab dan keperluan peminjaman.');
        return;
      }

      await academicRepository.createRoomReservation(
        {
          tenant_id: tenantId,
          facility_id: resForm.facility_id,
          facility_name: fac ? fac.name : 'Ruangan',
          borrower_name: resForm.borrower_name,
          borrower_role: resForm.borrower_role,
          purpose: resForm.purpose,
          reservation_date: resForm.reservation_date,
          start_time: resForm.start_time,
          end_time: resForm.end_time,
          status: 'APPROVED',
        },
        currentUser
      );

      setShowReservationModal(false);
      await loadData();
      alert('Peminjaman ruangan berhasil diajukan dan disetujui!');
    } catch (err: any) {
      alert(`Gagal mengajukan reservasi: ${err.message}`);
    }
  };

  // Create Facility
  const handleCreateFacility = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      if (!facForm.name.trim()) {
        alert('Nama fasilitas wajib diisi.');
        return;
      }

      await academicRepository.addFacility(
        {
          tenant_id: tenantId,
          name: facForm.name,
          code: facForm.code || `FAC-${Math.floor(100 + Math.random() * 900)}`,
          category: facForm.category,
          capacity: facForm.capacity,
          condition: facForm.condition,
          location: facForm.location,
          pic_name: facForm.pic_name,
          last_inspected: new Date().toISOString().split('T')[0],
        },
        currentUser
      );

      setShowFacilityModal(false);
      await loadData();
      alert('Fasilitas / Ruangan baru berhasil ditambahkan ke inventaris!');
    } catch (err: any) {
      alert(`Gagal menambah fasilitas: ${err.message}`);
    }
  };

  const filteredTickets = tickets.filter((t) => {
    if (ticketFilter !== 'ALL' && t.status !== ticketFilter) return false;
    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      return (
        t.facility_name.toLowerCase().includes(q) ||
        t.issue_description.toLowerCase().includes(q) ||
        t.reported_by_name.toLowerCase().includes(q) ||
        t.ticket_number.toLowerCase().includes(q)
      );
    }
    return true;
  });

  const totalCost = tickets.reduce((acc, t) => acc + (t.actual_cost || t.estimated_cost || 0), 0);

  return (
    <div className="space-y-6">
      {/* Sub navigation */}
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-200 pb-3">
        <div className="flex items-center gap-2">
          <button
            onClick={() => setSubTab('TIKET')}
            className={`rounded-xl px-3.5 py-1.5 text-xs font-semibold transition-all ${
              subTab === 'TIKET'
                ? 'bg-amber-600 text-white shadow-xs'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            Tiket Kerusakan & Work Order ({tickets.length})
          </button>
          <button
            onClick={() => setSubTab('PEMINJAMAN')}
            className={`rounded-xl px-3.5 py-1.5 text-xs font-semibold transition-all ${
              subTab === 'PEMINJAMAN'
                ? 'bg-amber-600 text-white shadow-xs'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            Peminjaman Ruang & Lab ({reservations.length})
          </button>
          <button
            onClick={() => setSubTab('FASILITAS')}
            className={`rounded-xl px-3.5 py-1.5 text-xs font-semibold transition-all ${
              subTab === 'FASILITAS'
                ? 'bg-amber-600 text-white shadow-xs'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            Inventaris Aset & Gedung ({facilities.length})
          </button>
        </div>

        {subTab === 'TIKET' && (
          <button
            onClick={() => setShowTicketModal(true)}
            className="flex items-center gap-1.5 rounded-xl bg-amber-600 px-3 py-1.5 text-xs font-bold text-white shadow-sm hover:bg-amber-700 transition-colors"
          >
            <Plus className="h-4 w-4" />
            <span>Buat Tiket Perbaikan</span>
          </button>
        )}

        {subTab === 'PEMINJAMAN' && (
          <button
            onClick={() => setShowReservationModal(true)}
            className="flex items-center gap-1.5 rounded-xl bg-amber-600 px-3 py-1.5 text-xs font-bold text-white shadow-sm hover:bg-amber-700 transition-colors"
          >
            <Plus className="h-4 w-4" />
            <span>Pinjam Ruangan / Lab</span>
          </button>
        )}

        {subTab === 'FASILITAS' && (
          <button
            onClick={() => setShowFacilityModal(true)}
            className="flex items-center gap-1.5 rounded-xl bg-amber-600 px-3 py-1.5 text-xs font-bold text-white shadow-sm hover:bg-amber-700 transition-colors"
          >
            <Plus className="h-4 w-4" />
            <span>Tambah Fasilitas Baru</span>
          </button>
        )}
      </div>

      {/* ================= SUB-TAB 1: TIKET KERUSAKAN ================= */}
      {subTab === 'TIKET' && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-4">
            <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-xs">
              <span className="text-xs text-slate-500 font-medium">Total Tiket Masuk:</span>
              <div className="mt-1 text-2xl font-bold text-slate-900">{tickets.length} Tiket</div>
              <div className="mt-0.5 text-[11px] text-slate-400">Tercatat di sistem</div>
            </div>
            <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-xs">
              <span className="text-xs text-slate-500 font-medium">Dalam Pengerjaan:</span>
              <div className="mt-1 text-2xl font-bold text-amber-600">
                {tickets.filter((t) => t.status === 'DALAM_PENGERJAAN').length}
              </div>
              <div className="mt-0.5 text-[11px] text-slate-400">Teknisi sedang bertugas</div>
            </div>
            <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-xs">
              <span className="text-xs text-slate-500 font-medium">Selesai Diperbaiki:</span>
              <div className="mt-1 text-2xl font-bold text-emerald-600">
                {tickets.filter((t) => t.status === 'SELESAI').length}
              </div>
              <div className="mt-0.5 text-[11px] text-slate-400">Bebas kendala</div>
            </div>
            <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-xs">
              <span className="text-xs text-slate-500 font-medium">Estimasi Realisasi Biaya:</span>
              <div className="mt-1 text-2xl font-black text-slate-900">
                Rp {totalCost.toLocaleString('id-ID')}
              </div>
              <div className="mt-0.5 text-[11px] text-slate-400">Sumber: BOS & Komite</div>
            </div>
          </div>

          {/* Filter Bar */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white p-3 rounded-2xl border border-slate-200">
            <div className="flex items-center gap-2">
              <span className="text-xs font-medium text-slate-500 flex items-center gap-1">
                <Filter className="h-3.5 w-3.5" /> Filter:
              </span>
              <button
                onClick={() => setTicketFilter('ALL')}
                className={`px-2.5 py-1 text-xs rounded-lg font-medium ${
                  ticketFilter === 'ALL' ? 'bg-slate-800 text-white' : 'text-slate-600 hover:bg-slate-100'
                }`}
              >
                Semua
              </button>
              <button
                onClick={() => setTicketFilter('DALAM_PENGERJAAN')}
                className={`px-2.5 py-1 text-xs rounded-lg font-medium ${
                  ticketFilter === 'DALAM_PENGERJAAN'
                    ? 'bg-amber-100 text-amber-800 font-bold'
                    : 'text-slate-600 hover:bg-slate-100'
                }`}
              >
                Dikerjakan
              </button>
              <button
                onClick={() => setTicketFilter('SELESAI')}
                className={`px-2.5 py-1 text-xs rounded-lg font-medium ${
                  ticketFilter === 'SELESAI'
                    ? 'bg-emerald-100 text-emerald-800 font-bold'
                    : 'text-slate-600 hover:bg-slate-100'
                }`}
              >
                Selesai
              </button>
            </div>

            <div className="relative w-full sm:w-64">
              <Search className="absolute left-3 top-2.5 h-3.5 w-3.5 text-slate-400" />
              <input
                type="text"
                placeholder="Cari no. tiket, fasilitas, masalah..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full rounded-xl border border-slate-200 pl-9 pr-3 py-1.5 text-xs focus:border-amber-500 focus:outline-none"
              />
            </div>
          </div>

          {/* Ticket Table */}
          <div className="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-xs">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs text-slate-700">
                <thead className="bg-slate-50 text-[11px] font-bold uppercase text-slate-500 border-b border-slate-200">
                  <tr>
                    <th className="px-4 py-3">No. Tiket & Tgl</th>
                    <th className="px-4 py-3">Fasilitas / Ruangan</th>
                    <th className="px-4 py-3">Urgensi</th>
                    <th className="px-4 py-3">Deskripsi Kerusakan</th>
                    <th className="px-4 py-3">Estimasi Biaya & Sumber</th>
                    <th className="px-4 py-3">Teknisi / Status</th>
                    <th className="px-4 py-3 text-right">Aksi</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {filteredTickets.length === 0 ? (
                    <tr>
                      <td colSpan={7} className="py-8 text-center text-slate-400">
                        Tidak ada tiket perbaikan yang sesuai.
                      </td>
                    </tr>
                  ) : (
                    filteredTickets.map((t) => (
                      <tr key={t.id} className="hover:bg-slate-50/80">
                        <td className="px-4 py-3">
                          <div className="font-bold text-slate-900">{t.ticket_number}</div>
                          <div className="text-[11px] text-slate-400">{t.report_date}</div>
                        </td>
                        <td className="px-4 py-3">
                          <div className="font-semibold text-slate-800">{t.facility_name}</div>
                          <div className="text-[11px] text-slate-400">Pelapor: {t.reported_by_name}</div>
                        </td>
                        <td className="px-4 py-3">
                          <span
                            className={`rounded-md px-2 py-0.5 text-[10px] font-extrabold ${
                              t.urgency === 'DARURAT'
                                ? 'bg-rose-100 text-rose-800'
                                : t.urgency === 'TINGGI'
                                ? 'bg-amber-100 text-amber-800'
                                : 'bg-slate-100 text-slate-700'
                            }`}
                          >
                            {t.urgency}
                          </span>
                        </td>
                        <td className="px-4 py-3 max-w-xs text-[11px] text-slate-600">{t.issue_description}</td>
                        <td className="px-4 py-3">
                          <div className="font-bold text-slate-900">
                            Rp {t.estimated_cost.toLocaleString('id-ID')}
                          </div>
                          <div className="text-[10px] text-slate-400 uppercase">{t.funding_source}</div>
                        </td>
                        <td className="px-4 py-3">
                          <div className="font-medium text-slate-800">{t.assigned_technician}</div>
                          <div className="mt-0.5">
                            {t.status === 'SELESAI' ? (
                              <span className="inline-flex items-center gap-1 rounded-full bg-emerald-50 px-2 py-0.5 text-[10px] font-bold text-emerald-800 border border-emerald-200">
                                <CheckCircle2 className="h-3 w-3" /> Selesai
                              </span>
                            ) : (
                              <span className="inline-flex items-center gap-1 rounded-full bg-amber-50 px-2 py-0.5 text-[10px] font-bold text-amber-800 border border-amber-200">
                                <Clock className="h-3 w-3 animate-pulse" /> Dikerjakan
                              </span>
                            )}
                          </div>
                        </td>
                        <td className="px-4 py-3 text-right">
                          {t.status !== 'SELESAI' ? (
                            <button
                              onClick={() => handleUpdateTicketStatus(t.id, 'SELESAI')}
                              className="rounded-lg bg-emerald-600 px-2.5 py-1 text-[11px] font-bold text-white hover:bg-emerald-700 transition-colors shadow-2xs"
                            >
                              Tandai Selesai
                            </button>
                          ) : (
                            <span className="text-[11px] text-slate-400 font-medium">Beres</span>
                          )}
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ================= SUB-TAB 2: PEMINJAMAN RUANG ================= */}
      {subTab === 'PEMINJAMAN' && (
        <div className="space-y-4">
          <div className="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-xs">
            <div className="p-4 border-b border-slate-100">
              <h4 className="font-bold text-slate-900 text-sm">Jadwal Reservasi Ruang Khusus & Laboratorium</h4>
              <p className="text-xs text-slate-500">
                Pencegahan bentrok jadwal pemakaian Lab Komputer, Aula, Ruang Multimedia, dan Bengkel.
              </p>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs text-slate-700">
                <thead className="bg-slate-50 text-[11px] font-bold uppercase text-slate-500 border-b border-slate-200">
                  <tr>
                    <th className="px-4 py-3">Nama Ruang / Lab</th>
                    <th className="px-4 py-3">Peminjam & Jabatan</th>
                    <th className="px-4 py-3">Tanggal & Jam</th>
                    <th className="px-4 py-3">Keperluan Kegiatan</th>
                    <th className="px-4 py-3">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {reservations.length === 0 ? (
                    <tr>
                      <td colSpan={5} className="py-8 text-center text-slate-400">
                        Belum ada jadwal reservasi ruang aktif.
                      </td>
                    </tr>
                  ) : (
                    reservations.map((r) => (
                      <tr key={r.id} className="hover:bg-slate-50/80">
                        <td className="px-4 py-3 font-bold text-slate-900">{r.facility_name}</td>
                        <td className="px-4 py-3">
                          <div className="font-semibold text-slate-800">{r.borrower_name}</div>
                          <div className="text-[11px] text-slate-400">{r.borrower_role}</div>
                        </td>
                        <td className="px-4 py-3">
                          <div className="font-medium text-slate-800">{r.reservation_date}</div>
                          <div className="text-[11px] text-slate-500">
                            {r.start_time} - {r.end_time} WIB
                          </div>
                        </td>
                        <td className="px-4 py-3 max-w-xs text-[11px] text-slate-600">{r.purpose}</td>
                        <td className="px-4 py-3">
                          <span className="inline-flex items-center gap-1 rounded-full bg-emerald-50 px-2.5 py-0.5 text-[11px] font-bold text-emerald-800 border border-emerald-200">
                            <CheckCircle2 className="h-3 w-3" /> Disetujui Waka
                          </span>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ================= SUB-TAB 3: FASILITAS ================= */}
      {subTab === 'FASILITAS' && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {facilities.map((fac) => {
              const isBaik = fac.condition === 'BAIK';
              const isRingan = fac.condition === 'RUSAK_RINGAN';
              return (
                <div
                  key={fac.id}
                  className="rounded-2xl border border-slate-200 bg-white p-5 shadow-xs flex flex-col justify-between"
                >
                  <div>
                    <div className="flex items-center justify-between">
                      <span className="rounded-md bg-slate-100 px-2 py-0.5 text-[10px] font-extrabold text-slate-700">
                        {fac.code || 'SARANA'}
                      </span>
                      <span
                        className={`rounded-full px-2 py-0.5 text-[10px] font-bold ${
                          isBaik
                            ? 'bg-emerald-100 text-emerald-800'
                            : isRingan
                            ? 'bg-amber-100 text-amber-800'
                            : 'bg-rose-100 text-rose-800'
                        }`}
                      >
                        {fac.condition}
                      </span>
                    </div>

                    <h4 className="mt-2 text-base font-bold text-slate-900">{fac.name}</h4>
                    <p className="mt-0.5 text-xs text-slate-500">{fac.location || 'Area Sekolah'}</p>

                    <div className="mt-3 space-y-1 text-xs text-slate-600 border-t border-slate-100 pt-2.5">
                      <div className="flex items-center justify-between">
                        <span className="text-slate-400">Kapasitas:</span>
                        <span className="font-semibold">{fac.capacity} Orang / Siswa</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-slate-400">Kategori:</span>
                        <span className="font-semibold">{fac.category || 'Ruang KBM'}</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-slate-400">Penanggung Jawab (PIC):</span>
                        <span className="font-semibold text-slate-800">{fac.pic_name || 'Staf Sarpras'}</span>
                      </div>
                    </div>
                  </div>

                  <div className="mt-4 flex items-center justify-between border-t border-slate-100 pt-3 text-[11px] text-slate-400">
                    <span>Inspeksi Terakhir:</span>
                    <span className="font-medium text-slate-600">{fac.last_inspected || 'Terverifikasi'}</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* ================= MODAL: BUAT TIKET ================= */}
      {showTicketModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 p-4 backdrop-blur-xs">
          <div className="w-full max-w-lg rounded-2xl bg-white p-6 shadow-2xl animate-in fade-in zoom-in-95">
            <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
              <Wrench className="h-5 w-5 text-amber-600" />
              <span>Buat Tiket Perbaikan Kerusakan Sarpras</span>
            </h3>

            <form onSubmit={handleCreateTicket} className="mt-4 space-y-3.5 text-xs">
              <div>
                <label className="font-semibold text-slate-700">Pilih Fasilitas / Ruangan:</label>
                <select
                  value={ticketForm.facility_id}
                  onChange={(e) => setTicketForm({ ...ticketForm, facility_id: e.target.value })}
                  className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-xs focus:border-amber-500 focus:outline-none"
                  required
                >
                  <option value="">-- Pilih Fasilitas --</option>
                  {facilities.map((f) => (
                    <option key={f.id} value={f.id}>
                      {f.name} ({f.location})
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-semibold text-slate-700">Nama Pelapor:</label>
                  <input
                    type="text"
                    value={ticketForm.reported_by_name}
                    onChange={(e) => setTicketForm({ ...ticketForm, reported_by_name: e.target.value })}
                    className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-xs focus:border-amber-500 focus:outline-none"
                    required
                  />
                </div>
                <div>
                  <label className="font-semibold text-slate-700">Tingkat Urgensi:</label>
                  <select
                    value={ticketForm.urgency}
                    onChange={(e) => setTicketForm({ ...ticketForm, urgency: e.target.value as any })}
                    className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-xs focus:border-amber-500 focus:outline-none"
                  >
                    <option value="RENDAH">Rendah (Dapat Ditunda)</option>
                    <option value="SEDANG">Sedang (Perlu Penanganan)</option>
                    <option value="TINGGI">Tinggi (Mengganggu KBM)</option>
                    <option value="DARURAT">Darurat (Bahaya Keamanan)</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="font-semibold text-slate-700">Rincian Masalah / Gejala Kerusakan:</label>
                <textarea
                  rows={2}
                  value={ticketForm.issue_description}
                  onChange={(e) => setTicketForm({ ...ticketForm, issue_description: e.target.value })}
                  placeholder="Contoh: AC tidak dingin dan bocor, proyektor mati total, keran wastafel patah..."
                  className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-xs focus:border-amber-500 focus:outline-none"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-semibold text-slate-700">Estimasi Biaya Perbaikan (Rp):</label>
                  <input
                    type="number"
                    value={ticketForm.estimated_cost}
                    onChange={(e) => setTicketForm({ ...ticketForm, estimated_cost: Number(e.target.value) })}
                    className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-xs focus:border-amber-500 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="font-semibold text-slate-700">Sumber Pembiayaan:</label>
                  <select
                    value={ticketForm.funding_source}
                    onChange={(e) => setTicketForm({ ...ticketForm, funding_source: e.target.value as any })}
                    className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-xs focus:border-amber-500 focus:outline-none"
                  >
                    <option value="BOS_REGULER">BOS Reguler Kemdikbud</option>
                    <option value="BOS_KINERJA">BOS Kinerja</option>
                    <option value="DANA_KOMITE">Dana Komite Sekolah</option>
                    <option value="YAYASAN">Kas Yayasan / Pemda</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="font-semibold text-slate-700">Teknisi Ditugaskan:</label>
                <input
                  type="text"
                  value={ticketForm.assigned_technician}
                  onChange={(e) => setTicketForm({ ...ticketForm, assigned_technician: e.target.value })}
                  className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-xs focus:border-amber-500 focus:outline-none"
                />
              </div>

              <div className="mt-5 flex items-center justify-end gap-2 border-t border-slate-100 pt-3">
                <button
                  type="button"
                  onClick={() => setShowTicketModal(false)}
                  className="rounded-xl px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="rounded-xl bg-amber-600 px-4 py-2 text-xs font-bold text-white shadow-xs hover:bg-amber-700"
                >
                  Terbitkan Tiket
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ================= MODAL: RESERVASI RUANG ================= */}
      {showReservationModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 p-4 backdrop-blur-xs">
          <div className="w-full max-w-lg rounded-2xl bg-white p-6 shadow-2xl animate-in fade-in zoom-in-95">
            <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
              <Building2 className="h-5 w-5 text-amber-600" />
              <span>Formulir Reservasi Ruangan / Laboratorium</span>
            </h3>

            <form onSubmit={handleCreateReservation} className="mt-4 space-y-3.5 text-xs">
              <div>
                <label className="font-semibold text-slate-700">Pilih Ruangan / Lab:</label>
                <select
                  value={resForm.facility_id}
                  onChange={(e) => setResForm({ ...resForm, facility_id: e.target.value })}
                  className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-xs focus:border-amber-500 focus:outline-none"
                  required
                >
                  <option value="">-- Pilih Ruang/Lab --</option>
                  {facilities.map((f) => (
                    <option key={f.id} value={f.id}>
                      {f.name} (Kapasitas: {f.capacity} orang)
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-semibold text-slate-700">Nama Peminjam:</label>
                  <input
                    type="text"
                    value={resForm.borrower_name}
                    onChange={(e) => setResForm({ ...resForm, borrower_name: e.target.value })}
                    className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-xs focus:border-amber-500 focus:outline-none"
                    required
                  />
                </div>
                <div>
                  <label className="font-semibold text-slate-700">Tanggal Pemakaian:</label>
                  <input
                    type="date"
                    value={resForm.reservation_date}
                    onChange={(e) => setResForm({ ...resForm, reservation_date: e.target.value })}
                    className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-xs focus:border-amber-500 focus:outline-none"
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-semibold text-slate-700">Jam Mulai:</label>
                  <input
                    type="time"
                    value={resForm.start_time}
                    onChange={(e) => setResForm({ ...resForm, start_time: e.target.value })}
                    className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-xs focus:border-amber-500 focus:outline-none"
                    required
                  />
                </div>
                <div>
                  <label className="font-semibold text-slate-700">Jam Selesai:</label>
                  <input
                    type="time"
                    value={resForm.end_time}
                    onChange={(e) => setResForm({ ...resForm, end_time: e.target.value })}
                    className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-xs focus:border-amber-500 focus:outline-none"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="font-semibold text-slate-700">Tujuan & Keperluan Pemakaian:</label>
                <textarea
                  rows={2}
                  value={resForm.purpose}
                  onChange={(e) => setResForm({ ...resForm, purpose: e.target.value })}
                  placeholder="Contoh: Tryout UTBK Bersama, Gladi Bersih ANBK, Pertemuan MPK..."
                  className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-xs focus:border-amber-500 focus:outline-none"
                  required
                />
              </div>

              <div className="mt-5 flex items-center justify-end gap-2 border-t border-slate-100 pt-3">
                <button
                  type="button"
                  onClick={() => setShowReservationModal(false)}
                  className="rounded-xl px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="rounded-xl bg-amber-600 px-4 py-2 text-xs font-bold text-white shadow-xs hover:bg-amber-700"
                >
                  Setujui & Jadwalkan
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ================= MODAL: FASILITAS ================= */}
      {showFacilityModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 p-4 backdrop-blur-xs">
          <div className="w-full max-w-lg rounded-2xl bg-white p-6 shadow-2xl animate-in fade-in zoom-in-95">
            <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
              <Building2 className="h-5 w-5 text-amber-600" />
              <span>Registrasi Fasilitas / Ruang Baru</span>
            </h3>

            <form onSubmit={handleCreateFacility} className="mt-4 space-y-3.5 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-semibold text-slate-700">Kode Ruang:</label>
                  <input
                    type="text"
                    value={facForm.code}
                    onChange={(e) => setFacForm({ ...facForm, code: e.target.value })}
                    placeholder="Contoh: LAB-KOMP-01"
                    className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-xs focus:border-amber-500 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="font-semibold text-slate-700">Kapasitas (Orang):</label>
                  <input
                    type="number"
                    value={facForm.capacity}
                    onChange={(e) => setFacForm({ ...facForm, capacity: Number(e.target.value) })}
                    className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-xs focus:border-amber-500 focus:outline-none"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="font-semibold text-slate-700">Nama Fasilitas / Ruang:</label>
                <input
                  type="text"
                  value={facForm.name}
                  onChange={(e) => setFacForm({ ...facForm, name: e.target.value })}
                  placeholder="Contoh: Laboratorium Rekayasa Perangkat Lunak 1"
                  className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-xs focus:border-amber-500 focus:outline-none"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-semibold text-slate-700">Kategori / Fungsi:</label>
                  <input
                    type="text"
                    value={facForm.category}
                    onChange={(e) => setFacForm({ ...facForm, category: e.target.value })}
                    placeholder="Laboratorium, Kelas Teori, Aula"
                    className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-xs focus:border-amber-500 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="font-semibold text-slate-700">Kondisi Fisik:</label>
                  <select
                    value={facForm.condition}
                    onChange={(e) => setFacForm({ ...facForm, condition: e.target.value as any })}
                    className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-xs focus:border-amber-500 focus:outline-none"
                  >
                    <option value="BAIK">Baik (Siap Pakai)</option>
                    <option value="RUSAK_RINGAN">Rusak Ringan</option>
                    <option value="RUSAK_BERAT">Rusak Berat</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-semibold text-slate-700">Lokasi Gedung:</label>
                  <input
                    type="text"
                    value={facForm.location}
                    onChange={(e) => setFacForm({ ...facForm, location: e.target.value })}
                    placeholder="Gedung B Lantai 2"
                    className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-xs focus:border-amber-500 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="font-semibold text-slate-700">PIC / Penanggung Jawab:</label>
                  <input
                    type="text"
                    value={facForm.pic_name}
                    onChange={(e) => setFacForm({ ...facForm, pic_name: e.target.value })}
                    className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-xs focus:border-amber-500 focus:outline-none"
                  />
                </div>
              </div>

              <div className="mt-5 flex items-center justify-end gap-2 border-t border-slate-100 pt-3">
                <button
                  type="button"
                  onClick={() => setShowFacilityModal(false)}
                  className="rounded-xl px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="rounded-xl bg-amber-600 px-4 py-2 text-xs font-bold text-white shadow-xs hover:bg-amber-700"
                >
                  Simpan Aset
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
