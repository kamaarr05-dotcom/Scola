import React, { useMemo } from 'react';
import {
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Legend,
  Line,
  LineChart,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';
import { DailyAttendance, GradeItem } from '../../types';

interface DashboardKpiChartsProps {
  attendance: DailyAttendance[];
  grades: GradeItem[];
  scopeLabel: string;
}

const ATTENDANCE_LABELS: Record<string, string> = {
  HADIR: 'Hadir',
  SAKIT: 'Sakit',
  IZIN: 'Izin',
  ALPA: 'Alpa',
  DISPENSASI: 'Dispensasi',
};

export const DashboardKpiCharts: React.FC<DashboardKpiChartsProps> = ({ attendance, grades, scopeLabel }) => {
  const attendanceDistribution = useMemo(() => {
    const counts = attendance.reduce<Record<string, number>>((acc, item) => {
      acc[item.status] = (acc[item.status] || 0) + 1;
      return acc;
    }, {});

    return Object.entries(ATTENDANCE_LABELS)
      .map(([key, label]) => ({ name: label, value: counts[key] || 0 }))
      .filter((item) => item.value > 0);
  }, [attendance]);

  const attendanceTrend = useMemo(() => {
    const byDate = new Map<string, { hadir: number; total: number }>();
    attendance.forEach((item) => {
      const entry = byDate.get(item.date) || { hadir: 0, total: 0 };
      entry.total += 1;
      if (item.status === 'HADIR') entry.hadir += 1;
      byDate.set(item.date, entry);
    });

    return Array.from(byDate.entries())
      .sort(([a], [b]) => a.localeCompare(b))
      .slice(-14)
      .map(([date, value]) => ({
        date: date.slice(5),
        hadir: value.total ? Number(((value.hadir / value.total) * 100).toFixed(1)) : 0,
      }));
  }, [attendance]);

  const gradeDistribution = useMemo(() => {
    const buckets = [
      { range: '90–100', min: 90, max: 100, students: 0 },
      { range: '80–89', min: 80, max: 89.999, students: 0 },
      { range: '70–79', min: 70, max: 79.999, students: 0 },
      { range: '<70', min: 0, max: 69.999, students: 0 },
    ];

    grades.forEach((item) => {
      const score = Number(item.score ?? item.final_score ?? 0);
      const bucket = buckets.find((entry) => score >= entry.min && score <= entry.max);
      if (bucket) bucket.students += 1;
    });

    return buckets;
  }, [grades]);

  const averageScore = useMemo(() => {
    if (!grades.length) return 0;
    return grades.reduce((sum, item) => sum + Number(item.score ?? item.final_score ?? 0), 0) / grades.length;
  }, [grades]);

  const attendanceRate = useMemo(() => {
    if (!attendance.length) return 0;
    return (attendance.filter((item) => item.status === 'HADIR').length / attendance.length) * 100;
  }, [attendance]);

  const pieColors = ['#2563eb', '#f59e0b', '#ef4444', '#64748b', '#10b981'];

  return (
    <section className="space-y-4">
      <div className="flex flex-col gap-1 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <h3 className="text-sm font-extrabold text-slate-900">KPI Akademik</h3>
          <p className="text-xs text-slate-500">Grafik kehadiran dan distribusi nilai untuk {scopeLabel}.</p>
        </div>
        <div className="flex gap-2 text-[11px] font-bold">
          <span className="rounded-lg bg-blue-50 px-2.5 py-1.5 text-blue-700">Kehadiran {attendanceRate.toFixed(1)}%</span>
          <span className="rounded-lg bg-indigo-50 px-2.5 py-1.5 text-indigo-700">Rata-rata nilai {averageScore.toFixed(1)}</span>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-4 xl:grid-cols-3">
        <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-xs">
          <div className="mb-2 flex items-center justify-between">
            <div>
              <h4 className="text-xs font-bold text-slate-900">Status Kehadiran</h4>
              <p className="text-[11px] text-slate-400">Akumulasi data presensi</p>
            </div>
          </div>
          <div className="h-56">
            {attendanceDistribution.length ? (
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie data={attendanceDistribution} dataKey="value" nameKey="name" innerRadius={48} outerRadius={78} paddingAngle={3}>
                    {attendanceDistribution.map((entry, index) => (
                      <Cell key={entry.name} fill={pieColors[index % pieColors.length]} />
                    ))}
                  </Pie>
                  <Tooltip />
                  <Legend verticalAlign="bottom" height={28} wrapperStyle={{ fontSize: 10 }} />
                </PieChart>
              </ResponsiveContainer>
            ) : (
              <div className="flex h-full items-center justify-center text-xs text-slate-400">Belum ada data presensi.</div>
            )}
          </div>
        </div>

        <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-xs">
          <div className="mb-2">
            <h4 className="text-xs font-bold text-slate-900">Tren Kehadiran</h4>
            <p className="text-[11px] text-slate-400">Persentase hadir per tanggal terakhir</p>
          </div>
          <div className="h-56">
            {attendanceTrend.length ? (
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={attendanceTrend} margin={{ top: 10, right: 12, left: -18, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} />
                  <XAxis dataKey="date" tick={{ fontSize: 10 }} />
                  <YAxis domain={[0, 100]} tick={{ fontSize: 10 }} tickFormatter={(value) => `${value}%`} />
                  <Tooltip formatter={(value) => [`${Number(value)}%`, 'Hadir']} />
                  <Line type="monotone" dataKey="hadir" stroke="#2563eb" strokeWidth={3} dot={{ r: 3 }} />
                </LineChart>
              </ResponsiveContainer>
            ) : (
              <div className="flex h-full items-center justify-center text-xs text-slate-400">Belum ada histori presensi.</div>
            )}
          </div>
        </div>

        <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-xs">
          <div className="mb-2">
            <h4 className="text-xs font-bold text-slate-900">Distribusi Nilai</h4>
            <p className="text-[11px] text-slate-400">Jumlah hasil penilaian berdasarkan rentang skor</p>
          </div>
          <div className="h-56">
            {grades.length ? (
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={gradeDistribution} margin={{ top: 10, right: 12, left: -18, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} />
                  <XAxis dataKey="range" tick={{ fontSize: 10 }} />
                  <YAxis allowDecimals={false} tick={{ fontSize: 10 }} />
                  <Tooltip />
                  <Bar dataKey="students" name="Siswa" fill="#4f46e5" radius={[6, 6, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            ) : (
              <div className="flex h-full items-center justify-center text-xs text-slate-400">Belum ada data nilai.</div>
            )}
          </div>
        </div>
      </div>
    </section>
  );
};
