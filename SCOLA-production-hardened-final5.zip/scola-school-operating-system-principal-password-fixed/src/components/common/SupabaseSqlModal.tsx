import React, { useState } from 'react';
import { X, Copy, Check, Database, ShieldAlert, Terminal } from 'lucide-react';

interface SupabaseSqlModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const SupabaseSqlModal: React.FC<SupabaseSqlModalProps> = ({ isOpen, onClose }) => {
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const sqlScript = `-- ==============================================================================
-- SCOLA - Multi-Tenant School Operating System (PostgreSQL + RLS Schema)
-- Run this in Supabase SQL Editor: Dashboard > SQL Editor > New Query
-- ==============================================================================

-- 1. Enable UUID Extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- 2. TENANTS TABLE (Sekolah)
CREATE TABLE IF NOT EXISTS public.tenants (
  id TEXT PRIMARY KEY,
  npsn VARCHAR(10) UNIQUE NOT NULL,
  name VARCHAR(255) NOT NULL,
  slug VARCHAR(100) UNIQUE NOT NULL,
  subdomain VARCHAR(100),
  type VARCHAR(10) NOT NULL CHECK (type IN ('SMA', 'SMK')),
  accreditation VARCHAR(20) DEFAULT 'A',
  province VARCHAR(100) NOT NULL,
  city VARCHAR(100) NOT NULL,
  address TEXT NOT NULL,
  phone VARCHAR(50),
  email VARCHAR(150),
  logo_url TEXT,
  brand_color VARCHAR(20) DEFAULT '#1e40af',
  teacher_quota INT NOT NULL DEFAULT 20 CHECK (teacher_quota >= 1),
  active_teacher_count INT NOT NULL DEFAULT 0,
  is_active BOOLEAN NOT NULL DEFAULT true,
  status VARCHAR(20) NOT NULL DEFAULT 'ACTIVE',
  subscription_tier VARCHAR(20) DEFAULT 'STANDARD',
  valid_until DATE,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 3. USER PROFILES (Universal Auth Mirror)
CREATE TABLE IF NOT EXISTS public.user_profiles (
  id TEXT PRIMARY KEY, -- Maps to auth.users.id
  tenant_id TEXT REFERENCES public.tenants(id) ON DELETE CASCADE,
  email VARCHAR(255) UNIQUE NOT NULL,
  full_name VARCHAR(255) NOT NULL,
  phone VARCHAR(50),
  role VARCHAR(30) NOT NULL CHECK (role IN ('MASTER', 'KEPALA_SEKOLAH', 'GURU', 'SISWA', 'ORANG_TUA', 'TENAGA_KEPENDIDIKAN')),
  status VARCHAR(30) NOT NULL DEFAULT 'ACTIVE' CHECK (status IN ('ACTIVE', 'INACTIVE', 'PENDING_VERIFICATION')),
  assignments JSONB DEFAULT '[]'::jsonb,
  linked_students JSONB DEFAULT '[]'::jsonb,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 4. TEACHERS TABLE (Guru Pengajar)
CREATE TABLE IF NOT EXISTS public.teachers (
  id TEXT PRIMARY KEY,
  tenant_id TEXT NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  user_id TEXT REFERENCES public.user_profiles(id) ON DELETE SET NULL,
  nip VARCHAR(50),
  nuptk VARCHAR(50),
  full_name VARCHAR(255) NOT NULL,
  title_prefix VARCHAR(50),
  title_suffix VARCHAR(50),
  gender VARCHAR(5) NOT NULL CHECK (gender IN ('L', 'P')),
  email VARCHAR(150),
  phone VARCHAR(50),
  status VARCHAR(20) NOT NULL DEFAULT 'ACTIVE' CHECK (status IN ('ACTIVE', 'INACTIVE')),
  created_by TEXT,
  subject_specialty JSONB DEFAULT '[\"Umum\"]'::jsonb,
  employment_type VARCHAR(20) DEFAULT 'GTY',
  assignments JSONB DEFAULT '[]'::jsonb,
  role VARCHAR(30) DEFAULT 'GURU',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Migration-safe columns for existing SCOLA installations
ALTER TABLE public.teachers ADD COLUMN IF NOT EXISTS subject_specialty JSONB DEFAULT '[\"Umum\"]'::jsonb;
ALTER TABLE public.teachers ADD COLUMN IF NOT EXISTS employment_type VARCHAR(20) DEFAULT 'GTY';
ALTER TABLE public.teachers ADD COLUMN IF NOT EXISTS assignments JSONB DEFAULT '[]'::jsonb;
ALTER TABLE public.teachers ADD COLUMN IF NOT EXISTS role VARCHAR(30) DEFAULT 'GURU';

-- 5. CLASSES TABLE (Rombongan Belajar)
CREATE TABLE IF NOT EXISTS public.classes (
  id TEXT PRIMARY KEY,
  tenant_id TEXT NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  name VARCHAR(100) NOT NULL,
  grade_level INT NOT NULL CHECK (grade_level IN (10, 11, 12)),
  school_type VARCHAR(10) NOT NULL CHECK (school_type IN ('SMA', 'SMK')),
  major_or_stream VARCHAR(100) NOT NULL,
  academic_year_id VARCHAR(50) NOT NULL,
  wali_kelas_teacher_id TEXT,
  wali_kelas_name VARCHAR(255),
  capacity INT DEFAULT 36,
  total_students INT DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 6. STUDENTS TABLE (Peserta Didik)
CREATE TABLE IF NOT EXISTS public.students (
  id TEXT PRIMARY KEY,
  tenant_id TEXT NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  user_id TEXT REFERENCES public.user_profiles(id) ON DELETE SET NULL,
  nisn VARCHAR(10) UNIQUE NOT NULL,
  nis VARCHAR(50) NOT NULL,
  full_name VARCHAR(255) NOT NULL,
  gender VARCHAR(5) CHECK (gender IN ('L', 'P')),
  class_id TEXT REFERENCES public.classes(id) ON DELETE SET NULL,
  class_name VARCHAR(100),
  generation_year INT DEFAULT 2024,
  status VARCHAR(30) NOT NULL DEFAULT 'ACTIVE' CHECK (status IN ('ACTIVE', 'INACTIVE', 'PENDING', 'GRADUATED', 'TRANSFERRED')),
  self_registered BOOLEAN DEFAULT false,
  registration_date DATE DEFAULT CURRENT_DATE,
  sma_peminatan VARCHAR(100),
  smk_program_id VARCHAR(100),
  smk_program_name VARCHAR(150),
  kompetensi_keahlian VARCHAR(150),
  address TEXT,
  phone VARCHAR(50),
  email VARCHAR(150),
  parent_name VARCHAR(255),
  parent_relation VARCHAR(20),
  parent_whatsapp VARCHAR(50),
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);
ALTER TABLE public.students ADD COLUMN IF NOT EXISTS updated_at TIMESTAMPTZ DEFAULT NOW();


-- 6A. ACADEMIC YEARS
CREATE TABLE IF NOT EXISTS public.academic_years (
  id TEXT PRIMARY KEY, tenant_id TEXT NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  name VARCHAR(100) NOT NULL, semester VARCHAR(20) NOT NULL, start_date DATE NOT NULL, end_date DATE NOT NULL,
  is_active BOOLEAN NOT NULL DEFAULT false, created_at TIMESTAMPTZ DEFAULT NOW(), updated_at TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_academic_years_tenant ON public.academic_years(tenant_id, start_date DESC);
CREATE UNIQUE INDEX IF NOT EXISTS uq_academic_year_active_tenant ON public.academic_years(tenant_id) WHERE is_active;
ALTER TABLE public.academic_years ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "SCOLA academic years read" ON public.academic_years;
DROP POLICY IF EXISTS "SCOLA academic years write" ON public.academic_years;
CREATE POLICY "SCOLA academic years read" ON public.academic_years FOR SELECT TO authenticated USING ((SELECT role FROM public.scola_current_profile() LIMIT 1)='MASTER' OR tenant_id=(SELECT tenant_id FROM public.scola_current_profile() LIMIT 1));
CREATE POLICY "SCOLA academic years write" ON public.academic_years FOR ALL TO authenticated USING ((SELECT role FROM public.scola_current_profile() LIMIT 1)='MASTER' OR ((SELECT role FROM public.scola_current_profile() LIMIT 1)='KEPALA_SEKOLAH' AND tenant_id=(SELECT tenant_id FROM public.scola_current_profile() LIMIT 1))) WITH CHECK ((SELECT role FROM public.scola_current_profile() LIMIT 1)='MASTER' OR ((SELECT role FROM public.scola_current_profile() LIMIT 1)='KEPALA_SEKOLAH' AND tenant_id=(SELECT tenant_id FROM public.scola_current_profile() LIMIT 1)));

-- 6B. TEACHER ASSIGNMENTS
CREATE TABLE IF NOT EXISTS public.teacher_assignments (
  id TEXT PRIMARY KEY, tenant_id TEXT NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  teacher_id TEXT NOT NULL REFERENCES public.user_profiles(id) ON DELETE CASCADE, teacher_user_id TEXT NOT NULL REFERENCES public.user_profiles(id) ON DELETE CASCADE,
  type VARCHAR(50) NOT NULL, assignment_type VARCHAR(50), class_id TEXT REFERENCES public.classes(id) ON DELETE SET NULL, program_id TEXT,
  academic_year_id TEXT NOT NULL REFERENCES public.academic_years(id) ON DELETE RESTRICT, active BOOLEAN NOT NULL DEFAULT true, notes TEXT, assigned_at TIMESTAMPTZ DEFAULT NOW()
);
ALTER TABLE public.teacher_assignments ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "SCOLA assignments read" ON public.teacher_assignments;
DROP POLICY IF EXISTS "SCOLA assignments write" ON public.teacher_assignments;
CREATE POLICY "SCOLA assignments read" ON public.teacher_assignments FOR SELECT TO authenticated USING ((SELECT role FROM public.scola_current_profile() LIMIT 1)='MASTER' OR tenant_id=(SELECT tenant_id FROM public.scola_current_profile() LIMIT 1));
CREATE POLICY "SCOLA assignments write" ON public.teacher_assignments FOR ALL TO authenticated USING ((SELECT role FROM public.scola_current_profile() LIMIT 1)='MASTER' OR ((SELECT role FROM public.scola_current_profile() LIMIT 1)='KEPALA_SEKOLAH' AND tenant_id=(SELECT tenant_id FROM public.scola_current_profile() LIMIT 1))) WITH CHECK ((SELECT role FROM public.scola_current_profile() LIMIT 1)='MASTER' OR ((SELECT role FROM public.scola_current_profile() LIMIT 1)='KEPALA_SEKOLAH' AND tenant_id=(SELECT tenant_id FROM public.scola_current_profile() LIMIT 1)));

-- 7. DAILY ATTENDANCE (Presensi Harian)
CREATE TABLE IF NOT EXISTS public.daily_attendance (
  id TEXT PRIMARY KEY,
  tenant_id TEXT NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  student_id TEXT NOT NULL REFERENCES public.students(id) ON DELETE CASCADE,
  student_name VARCHAR(255),
  class_id TEXT REFERENCES public.classes(id) ON DELETE SET NULL,
  date DATE NOT NULL,
  status VARCHAR(20) NOT NULL CHECK (status IN ('HADIR', 'SAKIT', 'IZIN', 'ALPA', 'DISPENSASI')),
  period_number INT DEFAULT 1,
  source VARCHAR(50) DEFAULT 'FIRST_PERIOD_ANCHOR',
  recorded_by_user_id TEXT,
  recorded_by_name VARCHAR(255),
  notes TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  CONSTRAINT unique_student_date_period UNIQUE (student_id, date, period_number)
);

-- 8. GRADES TABLE (Penilaian Akademik)
CREATE TABLE IF NOT EXISTS public.grades (
  id TEXT PRIMARY KEY,
  tenant_id TEXT NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  student_id TEXT NOT NULL REFERENCES public.students(id) ON DELETE CASCADE,
  student_name VARCHAR(255),
  class_id TEXT REFERENCES public.classes(id) ON DELETE SET NULL,
  subject_id VARCHAR(50) NOT NULL,
  subject_name VARCHAR(150) NOT NULL,
  academic_year_id VARCHAR(50) NOT NULL,
  semester VARCHAR(10) NOT NULL CHECK (semester IN ('GANJIL', 'GENAP')),
  assessment_type VARCHAR(30) NOT NULL,
  score NUMERIC(5,2) NOT NULL,
  max_score NUMERIC(5,2) DEFAULT 100,
  competency_achievement TEXT,
  created_at DATE DEFAULT CURRENT_DATE
);

-- 9. AUDIT LOGS TABLE (Keamanan & Lisensi)
CREATE TABLE IF NOT EXISTS public.audit_logs (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  timestamp TIMESTAMPTZ DEFAULT NOW(),
  event VARCHAR(50) NOT NULL,
  email VARCHAR(255) NOT NULL,
  user_id TEXT,
  role VARCHAR(30),
  tenant_id TEXT,
  ip_address VARCHAR(50),
  user_agent TEXT,
  status VARCHAR(20) NOT NULL,
  details TEXT
);

-- ==============================================================================
-- PRODUCTION ROW LEVEL SECURITY (RLS)
-- This setup never grants public read/write access and never seeds demo data.
-- ==============================================================================
CREATE OR REPLACE FUNCTION public.scola_current_profile()
RETURNS TABLE (id TEXT, tenant_id TEXT, role TEXT, status TEXT)
LANGUAGE SQL SECURITY DEFINER STABLE SET search_path = public
AS $$ SELECT id, tenant_id, role, status FROM public.user_profiles WHERE id = auth.uid()::text LIMIT 1; $$;
REVOKE ALL ON FUNCTION public.scola_current_profile() FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.scola_current_profile() TO authenticated;

ALTER TABLE public.tenants ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.teachers ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.classes ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.students ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.daily_attendance ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.grades ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.audit_logs ENABLE ROW LEVEL SECURITY;

DO $$ DECLARE p record; BEGIN
  FOR p IN SELECT policyname,tablename FROM pg_policies WHERE schemaname='public' AND (policyname ILIKE '%Public Read%' OR policyname ILIKE '%Insert %' OR policyname ILIKE '%Update %') LOOP
    EXECUTE format('DROP POLICY IF EXISTS %I ON public.%I',p.policyname,p.tablename);
  END LOOP;
END $$;

DROP POLICY IF EXISTS "SCOLA tenants read" ON public.tenants;
DROP POLICY IF EXISTS "SCOLA profiles read" ON public.user_profiles;
DROP POLICY IF EXISTS "SCOLA profiles self update" ON public.user_profiles;
DROP POLICY IF EXISTS "SCOLA teachers read" ON public.teachers;
DROP POLICY IF EXISTS "SCOLA teachers admin write" ON public.teachers;
DROP POLICY IF EXISTS "SCOLA classes read" ON public.classes;
DROP POLICY IF EXISTS "SCOLA classes admin write" ON public.classes;
DROP POLICY IF EXISTS "SCOLA students read" ON public.students;
DROP POLICY IF EXISTS "SCOLA students self update" ON public.students;
DROP POLICY IF EXISTS "SCOLA attendance read" ON public.daily_attendance;
DROP POLICY IF EXISTS "SCOLA attendance write" ON public.daily_attendance;
DROP POLICY IF EXISTS "SCOLA grades read" ON public.grades;
DROP POLICY IF EXISTS "SCOLA grades write" ON public.grades;
DROP POLICY IF EXISTS "SCOLA audit read" ON public.audit_logs;

DROP POLICY IF EXISTS "SCOLA tenants read" ON public.tenants;
CREATE POLICY "SCOLA tenants read" ON public.tenants FOR SELECT TO authenticated USING (id=(SELECT tenant_id FROM public.scola_current_profile() LIMIT 1) OR (SELECT role FROM public.scola_current_profile() LIMIT 1)='MASTER');
DROP POLICY IF EXISTS "SCOLA profiles read" ON public.user_profiles;
CREATE POLICY "SCOLA profiles read" ON public.user_profiles FOR SELECT TO authenticated USING (id=auth.uid()::text OR (SELECT role FROM public.scola_current_profile() LIMIT 1)='MASTER' OR tenant_id=(SELECT tenant_id FROM public.scola_current_profile() LIMIT 1));
DROP POLICY IF EXISTS "SCOLA profiles self update" ON public.user_profiles;
CREATE POLICY "SCOLA profiles self update" ON public.user_profiles FOR UPDATE TO authenticated USING (id=auth.uid()::text) WITH CHECK (id=auth.uid()::text);

-- Prevent a normal user from changing authorization/tenant fields in their own profile.
CREATE OR REPLACE FUNCTION public.scola_protect_profile_self_update() RETURNS trigger
LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
BEGIN
  IF auth.uid() IS NOT NULL AND auth.uid()::text = OLD.id THEN
    NEW.id := OLD.id; NEW.tenant_id := OLD.tenant_id; NEW.role := OLD.role; NEW.status := OLD.status; NEW.email := OLD.email;
    NEW.assignments := OLD.assignments; NEW.linked_students := OLD.linked_students;
  END IF;
  RETURN NEW;
END; $$;
DROP TRIGGER IF EXISTS trg_scola_protect_profile_self_update ON public.user_profiles;
CREATE TRIGGER trg_scola_protect_profile_self_update BEFORE UPDATE ON public.user_profiles FOR EACH ROW EXECUTE FUNCTION public.scola_protect_profile_self_update();
DROP POLICY IF EXISTS "SCOLA teachers read" ON public.teachers;
CREATE POLICY "SCOLA teachers read" ON public.teachers FOR SELECT TO authenticated USING (user_id=auth.uid()::text OR tenant_id=(SELECT tenant_id FROM public.scola_current_profile() LIMIT 1) OR (SELECT role FROM public.scola_current_profile() LIMIT 1)='MASTER');
CREATE POLICY "SCOLA teachers admin write" ON public.teachers FOR ALL TO authenticated USING ((SELECT role FROM public.scola_current_profile() LIMIT 1)='MASTER' OR (tenant_id=(SELECT tenant_id FROM public.scola_current_profile() LIMIT 1) AND (SELECT role FROM public.scola_current_profile() LIMIT 1)='KEPALA_SEKOLAH')) WITH CHECK (tenant_id=(SELECT tenant_id FROM public.scola_current_profile() LIMIT 1) OR (SELECT role FROM public.scola_current_profile() LIMIT 1)='MASTER');
DROP POLICY IF EXISTS "SCOLA classes read" ON public.classes;
CREATE POLICY "SCOLA classes read" ON public.classes FOR SELECT TO authenticated USING (tenant_id=(SELECT tenant_id FROM public.scola_current_profile() LIMIT 1) OR (SELECT role FROM public.scola_current_profile() LIMIT 1)='MASTER');
CREATE POLICY "SCOLA classes admin write" ON public.classes FOR ALL TO authenticated USING ((SELECT role FROM public.scola_current_profile() LIMIT 1)='MASTER' OR (tenant_id=(SELECT tenant_id FROM public.scola_current_profile() LIMIT 1) AND (SELECT role FROM public.scola_current_profile() LIMIT 1)='KEPALA_SEKOLAH')) WITH CHECK (tenant_id=(SELECT tenant_id FROM public.scola_current_profile() LIMIT 1) OR (SELECT role FROM public.scola_current_profile() LIMIT 1)='MASTER');
DROP POLICY IF EXISTS "SCOLA students read" ON public.students;
CREATE POLICY "SCOLA students read" ON public.students FOR SELECT TO authenticated USING (user_id=auth.uid()::text OR tenant_id=(SELECT tenant_id FROM public.scola_current_profile() LIMIT 1) OR (SELECT role FROM public.scola_current_profile() LIMIT 1)='MASTER');
CREATE POLICY "SCOLA students self update" ON public.students FOR UPDATE TO authenticated USING (user_id=auth.uid()::text) WITH CHECK (user_id=auth.uid()::text);
CREATE POLICY "SCOLA students staff write" ON public.students FOR UPDATE TO authenticated USING (
  (SELECT role FROM public.scola_current_profile() LIMIT 1)='MASTER'
  OR ((SELECT role FROM public.scola_current_profile() LIMIT 1) IN ('KEPALA_SEKOLAH','TENAGA_KEPENDIDIKAN') AND tenant_id=(SELECT tenant_id FROM public.scola_current_profile() LIMIT 1))
  OR ((SELECT role FROM public.scola_current_profile() LIMIT 1)='GURU' AND tenant_id=(SELECT tenant_id FROM public.scola_current_profile() LIMIT 1) AND EXISTS (SELECT 1 FROM public.teacher_assignments ta WHERE ta.teacher_user_id=auth.uid()::text AND ta.class_id=students.class_id AND ta.type='WALI_KELAS' AND ta.active=true))
) WITH CHECK (tenant_id=(SELECT tenant_id FROM public.scola_current_profile() LIMIT 1));

CREATE OR REPLACE FUNCTION public.scola_protect_student_self_update() RETURNS trigger
LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
BEGIN
  IF auth.uid() IS NOT NULL AND OLD.user_id = auth.uid()::text AND (SELECT role FROM public.scola_current_profile() LIMIT 1) = 'SISWA' THEN
    NEW.id := OLD.id; NEW.user_id := OLD.user_id; NEW.tenant_id := OLD.tenant_id; NEW.nisn := OLD.nisn; NEW.nis := OLD.nis; NEW.full_name := OLD.full_name; NEW.gender := OLD.gender; NEW.class_id := OLD.class_id; NEW.class_name := OLD.class_name; NEW.status := OLD.status;
  END IF;
  RETURN NEW;
END; $$;
DROP TRIGGER IF EXISTS trg_scola_protect_student_self_update ON public.students;
CREATE TRIGGER trg_scola_protect_student_self_update BEFORE UPDATE ON public.students FOR EACH ROW EXECUTE FUNCTION public.scola_protect_student_self_update();
DROP POLICY IF EXISTS "SCOLA attendance read" ON public.daily_attendance;
CREATE POLICY "SCOLA attendance read" ON public.daily_attendance FOR SELECT TO authenticated USING (tenant_id=(SELECT tenant_id FROM public.scola_current_profile() LIMIT 1) OR (SELECT role FROM public.scola_current_profile() LIMIT 1)='MASTER');
CREATE POLICY "SCOLA attendance write" ON public.daily_attendance FOR ALL TO authenticated USING (tenant_id=(SELECT tenant_id FROM public.scola_current_profile() LIMIT 1) AND (SELECT role FROM public.scola_current_profile() LIMIT 1) IN ('MASTER','KEPALA_SEKOLAH','GURU','TENAGA_KEPENDIDIKAN')) WITH CHECK (tenant_id=(SELECT tenant_id FROM public.scola_current_profile() LIMIT 1) AND (SELECT role FROM public.scola_current_profile() LIMIT 1) IN ('MASTER','KEPALA_SEKOLAH','GURU','TENAGA_KEPENDIDIKAN'));
DROP POLICY IF EXISTS "SCOLA grades read" ON public.grades;
CREATE POLICY "SCOLA grades read" ON public.grades FOR SELECT TO authenticated USING (tenant_id=(SELECT tenant_id FROM public.scola_current_profile() LIMIT 1) OR (SELECT role FROM public.scola_current_profile() LIMIT 1)='MASTER');
CREATE POLICY "SCOLA grades write" ON public.grades FOR ALL TO authenticated USING (tenant_id=(SELECT tenant_id FROM public.scola_current_profile() LIMIT 1) AND (SELECT role FROM public.scola_current_profile() LIMIT 1) IN ('MASTER','KEPALA_SEKOLAH','GURU')) WITH CHECK (tenant_id=(SELECT tenant_id FROM public.scola_current_profile() LIMIT 1) AND (SELECT role FROM public.scola_current_profile() LIMIT 1) IN ('MASTER','KEPALA_SEKOLAH','GURU'));
-- Audit log writes are allowed only for authenticated users, and a trigger overwrites identity fields from the JWT/profile.
CREATE POLICY "SCOLA audit insert" ON public.audit_logs FOR INSERT TO authenticated WITH CHECK (user_id = auth.uid()::text);
CREATE OR REPLACE FUNCTION public.scola_normalize_audit_log() RETURNS trigger
LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
DECLARE me record; BEGIN
  SELECT * INTO me FROM public.scola_current_profile() LIMIT 1;
  IF me.id IS NULL OR me.status <> 'ACTIVE' THEN RAISE EXCEPTION 'Akun audit tidak aktif'; END IF;
  NEW.user_id := me.id; NEW.tenant_id := me.tenant_id; NEW.role := me.role; NEW.email := (SELECT email FROM public.user_profiles WHERE id=me.id);
  NEW.ip_address := COALESCE(NULLIF(NEW.ip_address,''),'CLIENT');
  NEW.timestamp := COALESCE(NEW.timestamp,NOW());
  RETURN NEW;
END; $$;
DROP TRIGGER IF EXISTS trg_scola_normalize_audit_log ON public.audit_logs;
CREATE TRIGGER trg_scola_normalize_audit_log BEFORE INSERT ON public.audit_logs FOR EACH ROW EXECUTE FUNCTION public.scola_normalize_audit_log();

CREATE OR REPLACE FUNCTION public.scola_record_audit(p_event TEXT,p_status TEXT,p_details TEXT DEFAULT NULL,p_email TEXT DEFAULT NULL,p_tenant_id TEXT DEFAULT NULL,p_role TEXT DEFAULT NULL) RETURNS UUID
LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
DECLARE me public.user_profiles%ROWTYPE; audit_id UUID;
BEGIN
 SELECT * INTO me FROM public.user_profiles WHERE id=auth.uid()::text LIMIT 1;
 IF me.id IS NULL OR me.status <> 'ACTIVE' THEN RAISE EXCEPTION 'Akun audit tidak aktif'; END IF;
 INSERT INTO public.audit_logs(event,email,user_id,role,tenant_id,status,details) VALUES(p_event,COALESCE(me.email,p_email,''),me.id,me.role,me.tenant_id,p_status,p_details) RETURNING id INTO audit_id;
 RETURN audit_id; END; $$;
REVOKE ALL ON FUNCTION public.scola_record_audit(TEXT,TEXT,TEXT,TEXT,TEXT,TEXT) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.scola_record_audit(TEXT,TEXT,TEXT,TEXT,TEXT,TEXT) TO authenticated;

CREATE OR REPLACE FUNCTION public.scola_reserve_teacher_slot(p_tenant_id TEXT) RETURNS BOOLEAN
LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
DECLARE ok BOOLEAN; me public.user_profiles%ROWTYPE;
BEGIN
  SELECT * INTO me FROM public.user_profiles WHERE id=auth.uid()::text LIMIT 1;
  IF auth.role() <> 'service_role' AND (me.id IS NULL OR (me.role <> 'MASTER' AND NOT (me.role='KEPALA_SEKOLAH' AND me.tenant_id=p_tenant_id))) THEN
    RAISE EXCEPTION 'Akses Ditolak';
  END IF;
  UPDATE public.tenants SET active_teacher_count=active_teacher_count+1, updated_at=now()
  WHERE id=p_tenant_id AND is_active=true AND active_teacher_count < teacher_quota
  RETURNING true INTO ok;
  RETURN COALESCE(ok,false);
END; $$;
REVOKE ALL ON FUNCTION public.scola_reserve_teacher_slot(TEXT) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.scola_reserve_teacher_slot(TEXT) TO authenticated, service_role;
CREATE OR REPLACE FUNCTION public.scola_release_teacher_slot(p_tenant_id TEXT) RETURNS VOID
LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
DECLARE me public.user_profiles%ROWTYPE;
BEGIN
  SELECT * INTO me FROM public.user_profiles WHERE id=auth.uid()::text LIMIT 1;
  IF auth.role() <> 'service_role' AND (me.id IS NULL OR (me.role <> 'MASTER' AND NOT (me.role='KEPALA_SEKOLAH' AND me.tenant_id=p_tenant_id))) THEN
    RAISE EXCEPTION 'Akses Ditolak';
  END IF;
  UPDATE public.tenants SET active_teacher_count=GREATEST(active_teacher_count-1,0),updated_at=now() WHERE id=p_tenant_id;
END; $$;
REVOKE ALL ON FUNCTION public.scola_release_teacher_slot(TEXT) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.scola_release_teacher_slot(TEXT) TO authenticated, service_role;

-- FINAL TRANSACTIONAL TEACHER STATUS OPERATION
CREATE OR REPLACE FUNCTION public.scola_set_teacher_status(p_teacher_id TEXT,p_new_status TEXT) RETURNS public.teachers
LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
DECLARE me public.user_profiles%ROWTYPE; t public.teachers%ROWTYPE; out_t public.teachers%ROWTYPE;
BEGIN
  IF p_new_status NOT IN ('ACTIVE','INACTIVE') THEN RAISE EXCEPTION 'Status guru tidak valid'; END IF;
  SELECT * INTO me FROM public.user_profiles WHERE id=auth.uid()::text LIMIT 1;
  SELECT * INTO t FROM public.teachers WHERE id=p_teacher_id FOR UPDATE;
  IF t.id IS NULL THEN RAISE EXCEPTION 'Data guru tidak ditemukan'; END IF;
  IF auth.role()<>'service_role' AND (me.id IS NULL OR me.status<>'ACTIVE' OR (me.role<>'MASTER' AND NOT(me.role='KEPALA_SEKOLAH' AND me.tenant_id=t.tenant_id))) THEN RAISE EXCEPTION 'Akses Ditolak'; END IF;
  IF t.status=p_new_status THEN RETURN t; END IF;
  IF p_new_status='ACTIVE' THEN
    UPDATE public.tenants SET active_teacher_count=active_teacher_count+1,updated_at=now() WHERE id=t.tenant_id AND is_active=true AND active_teacher_count<teacher_quota;
    IF NOT FOUND THEN RAISE EXCEPTION 'Kuota guru telah habis'; END IF;
  ELSE
    UPDATE public.tenants SET active_teacher_count=GREATEST(active_teacher_count-1,0),updated_at=now() WHERE id=t.tenant_id;
  END IF;
  UPDATE public.teachers SET status=p_new_status,exit_date=CASE WHEN p_new_status='INACTIVE' THEN COALESCE(exit_date,CURRENT_DATE) ELSE NULL END,updated_at=now() WHERE id=t.id RETURNING * INTO out_t;
  UPDATE public.user_profiles SET status=CASE WHEN p_new_status='ACTIVE' THEN 'ACTIVE' ELSE 'INACTIVE' END,updated_at=now() WHERE id=t.user_id;
  IF NOT FOUND THEN RAISE EXCEPTION 'Profil pengguna guru tidak ditemukan'; END IF;
  INSERT INTO public.audit_logs(event,email,user_id,role,tenant_id,status,details,teacher_id,teacher_name) VALUES(CASE WHEN p_new_status='ACTIVE' THEN 'TEACHER_ACTIVATED' ELSE 'TEACHER_DEACTIVATED' END,COALESCE(me.email,''),me.id,me.role,t.tenant_id,'SUCCESS',format('Status guru %s diubah menjadi %s.',t.full_name,p_new_status),t.id,t.full_name);
  RETURN out_t;
END; $$;
REVOKE ALL ON FUNCTION public.scola_set_teacher_status(TEXT,TEXT) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.scola_set_teacher_status(TEXT,TEXT) TO authenticated, service_role;

-- Parent/guardian persistence
CREATE TABLE IF NOT EXISTS public.student_guardians (
  id TEXT PRIMARY KEY, tenant_id TEXT NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  guardian_user_id TEXT NOT NULL REFERENCES public.user_profiles(id) ON DELETE CASCADE, guardian_name TEXT NOT NULL,
  guardian_whatsapp TEXT, guardian_email TEXT, student_id TEXT NOT NULL REFERENCES public.students(id) ON DELETE CASCADE,
  student_name TEXT, student_nisn TEXT, class_id TEXT REFERENCES public.classes(id) ON DELETE SET NULL, class_name TEXT,
  relation_type TEXT NOT NULL CHECK (relation_type IN ('AYAH','IBU','WALI')), status TEXT NOT NULL DEFAULT 'ACTIVE' CHECK (status IN ('ACTIVE','INACTIVE')),
  is_primary BOOLEAN NOT NULL DEFAULT false, activated_by_wali_kelas_id TEXT, activated_by_name TEXT,
  activation_mode TEXT NOT NULL DEFAULT 'SUPABASE_AUTH_INTERNAL_PROVISION', created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_student_guardians_guardian ON public.student_guardians(guardian_user_id,status);
CREATE INDEX IF NOT EXISTS idx_student_guardians_student ON public.student_guardians(student_id,status);
ALTER TABLE public.student_guardians ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "SCOLA guardians read" ON public.student_guardians;
CREATE POLICY "SCOLA guardians read" ON public.student_guardians FOR SELECT TO authenticated USING (
  (SELECT role FROM public.scola_current_profile() LIMIT 1)='MASTER' OR
  (guardian_user_id=auth.uid()::text) OR
  EXISTS (SELECT 1 FROM public.students s WHERE s.id=student_guardians.student_id AND s.user_id=auth.uid()::text) OR
  (tenant_id=(SELECT tenant_id FROM public.scola_current_profile() LIMIT 1) AND (SELECT role FROM public.scola_current_profile() LIMIT 1) IN ('KEPALA_SEKOLAH','GURU','TENAGA_KEPENDIDIKAN'))
);
DROP POLICY IF EXISTS "SCOLA guardians write" ON public.student_guardians;

-- Atomic student class transfer
CREATE OR REPLACE FUNCTION public.scola_move_student_class(p_student_id TEXT,p_new_class_id TEXT) RETURNS public.students
LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
DECLARE me public.user_profiles%ROWTYPE; st public.students%ROWTYPE; old_c public.classes%ROWTYPE; new_c public.classes%ROWTYPE; out_st public.students%ROWTYPE;
BEGIN
 SELECT * INTO me FROM public.user_profiles WHERE id=auth.uid()::text LIMIT 1;
 SELECT * INTO st FROM public.students WHERE id=p_student_id FOR UPDATE;
 IF st.id IS NULL THEN RAISE EXCEPTION 'Data siswa tidak ditemukan'; END IF;
 IF me.id IS NULL OR me.status<>'ACTIVE' OR (me.role<>'MASTER' AND NOT(me.role='KEPALA_SEKOLAH' AND me.tenant_id=st.tenant_id)) THEN RAISE EXCEPTION 'Akses Ditolak'; END IF;
 SELECT * INTO new_c FROM public.classes WHERE id=p_new_class_id AND tenant_id=st.tenant_id FOR UPDATE;
 IF new_c.id IS NULL THEN RAISE EXCEPTION 'Kelas tujuan tidak valid'; END IF;
 IF st.class_id=p_new_class_id THEN RETURN st; END IF;
 IF st.class_id IS NOT NULL THEN SELECT * INTO old_c FROM public.classes WHERE id=st.class_id AND tenant_id=st.tenant_id FOR UPDATE; IF old_c.id IS NOT NULL THEN UPDATE public.classes SET total_students=GREATEST(total_students-1,0),updated_at=now() WHERE id=old_c.id; END IF; END IF;
 IF new_c.total_students >= new_c.capacity THEN RAISE EXCEPTION 'Kapasitas kelas tujuan sudah penuh'; END IF;
 UPDATE public.classes SET total_students=total_students+1,updated_at=now() WHERE id=new_c.id;
 UPDATE public.students SET class_id=new_c.id,class_name=new_c.name,updated_at=now() WHERE id=st.id RETURNING * INTO out_st;
 INSERT INTO public.audit_logs(event,email,user_id,role,tenant_id,status,details,student_id,student_name,nisn,old_value,new_value) VALUES('STUDENT_CLASS_CHANGED',COALESCE(me.email,''),me.id,me.role,st.tenant_id,'SUCCESS',format('Siswa %s dipindahkan ke %s.',st.full_name,new_c.name),st.id,st.full_name,st.nisn,st.class_name,new_c.name);
 RETURN out_st;
END; $$;
REVOKE ALL ON FUNCTION public.scola_move_student_class(TEXT,TEXT) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.scola_move_student_class(TEXT,TEXT) TO authenticated, service_role;

-- Assignment source-of-truth synchronization + uniqueness
CREATE OR REPLACE FUNCTION public.scola_sync_teacher_assignments_json() RETURNS trigger
LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
DECLARE payload jsonb; target_teacher TEXT;
BEGIN
  target_teacher := COALESCE(NEW.teacher_user_id,OLD.teacher_user_id);
  SELECT COALESCE(jsonb_agg(to_jsonb(x) ORDER BY x.assigned_at DESC),'[]'::jsonb) INTO payload
  FROM public.teacher_assignments x WHERE x.teacher_user_id=target_teacher AND x.active=true;
  UPDATE public.teachers SET assignments=payload,updated_at=now() WHERE user_id=target_teacher;
  RETURN COALESCE(NEW,OLD);
END; $$;
DROP TRIGGER IF EXISTS trg_scola_sync_teacher_assignments ON public.teacher_assignments;
CREATE TRIGGER trg_scola_sync_teacher_assignments AFTER INSERT OR UPDATE OR DELETE ON public.teacher_assignments FOR EACH ROW EXECUTE FUNCTION public.scola_sync_teacher_assignments_json();
CREATE UNIQUE INDEX IF NOT EXISTS uq_teacher_active_wali_class ON public.teacher_assignments(tenant_id,class_id,academic_year_id) WHERE active=true AND type='WALI_KELAS' AND class_id IS NOT NULL;
CREATE UNIQUE INDEX IF NOT EXISTS uq_teacher_active_assignment ON public.teacher_assignments(tenant_id,teacher_user_id,type,class_id,program_id,academic_year_id) WHERE active=true;

`;

  const handleCopy = () => {
    navigator.clipboard.writeText(sqlScript);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 p-4 backdrop-blur-xs">
      <div className="flex max-h-[90vh] w-full max-w-4xl flex-col rounded-2xl bg-white shadow-2xl overflow-hidden border border-slate-200">
        {/* Modal Header */}
        <div className="flex items-center justify-between border-b border-slate-200 px-6 py-4 bg-slate-50">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-blue-100 text-blue-700">
              <Database className="h-5 w-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900">
                Skrip SQL & Setup Database Supabase
              </h3>
              <p className="text-xs text-slate-500">
                Skema PostgreSQL multi-tenant, Row Level Security (RLS), dan akun Master
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="rounded-lg p-2 text-slate-400 hover:bg-slate-200/60 hover:text-slate-600 transition-colors"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Notice & Environment Info */}
        <div className="border-b border-amber-200/80 bg-amber-50/70 px-6 py-3 text-xs text-amber-900 flex items-start gap-3">
          <ShieldAlert className="h-5 w-5 shrink-0 text-amber-600 mt-0.5" />
          <div>
            <span className="font-bold">Panduan Konfigurasi Supabase:</span>
            <p className="mt-0.5 text-amber-800">
              1. Buka <strong>Supabase Dashboard</strong> &gt; <strong>SQL Editor</strong> &gt; Buat New Query &gt; Tempel (Paste) skrip di bawah &gt; Klik <strong>Run</strong>.
              <br />
              2. Masukkan <code>VITE_SUPABASE_URL</code> dan <code>VITE_SUPABASE_ANON_KEY</code> di pengaturan environment.
              <br />
              3. <strong className="underline">ATURAN KEAMANAN KRUSIAL:</strong> JANGAN PERNAH menyalin atau meminta <code>SUPABASE_SERVICE_ROLE_KEY</code> pada aplikasi klien web!
            </p>
          </div>
        </div>

        {/* Code View */}
        <div className="relative flex-1 overflow-auto bg-slate-950 p-4 font-mono text-xs text-emerald-400">
          <button
            onClick={handleCopy}
            className="absolute top-4 right-4 flex items-center gap-1.5 rounded-lg bg-slate-800/80 hover:bg-slate-700 px-3 py-1.5 text-xs text-slate-200 border border-slate-700 shadow-sm transition-colors"
          >
            {copied ? (
              <>
                <Check className="h-3.5 w-3.5 text-emerald-400" />
                <span className="text-emerald-400 font-semibold">Tersalin!</span>
              </>
            ) : (
              <>
                <Copy className="h-3.5 w-3.5" />
                <span>Salin Skrip SQL</span>
              </>
            )}
          </button>
          <pre className="pr-24 whitespace-pre-wrap">{sqlScript}</pre>
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between border-t border-slate-200 bg-slate-50 px-6 py-3.5">
          <div className="flex items-center gap-2 text-xs text-slate-500">
            <Terminal className="h-4 w-4 text-slate-400" />
            <span>Mendukung PostgreSQL 14+, Supabase Auth JWT, dan Realtime Channels</span>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={handleCopy}
              className="flex items-center gap-1.5 rounded-xl bg-blue-700 hover:bg-blue-800 px-4 py-2 text-xs font-semibold text-white shadow-xs transition-colors"
            >
              {copied ? <Check className="h-3.5 w-3.5" /> : <Copy className="h-3.5 w-3.5" />}
              <span>{copied ? 'Tersalin ke Clipboard' : 'Salin Semua SQL'}</span>
            </button>
            <button
              onClick={onClose}
              className="rounded-xl border border-slate-300 bg-white px-4 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-100 transition-colors"
            >
              Tutup
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};