import React from 'react';
import { ViewportMode } from '../../types';
import { Wifi, BatteryMedium, Signal } from 'lucide-react';

interface DeviceFrameProps {
  viewportMode: ViewportMode;
  children: React.ReactNode;
}

export const DeviceFrame: React.FC<DeviceFrameProps> = ({ viewportMode, children }) => {
  if (viewportMode === 'desktop') {
    return <div className="w-full flex-1 flex flex-col">{children}</div>;
  }

  const isMobile = viewportMode === 'mobile';
  const isTablet = viewportMode === 'tablet';

  return (
    <div className="flex-1 overflow-auto bg-slate-900/90 py-6 px-3 flex items-center justify-center min-h-[calc(100vh-4rem)]">
      <div
        className={`relative flex flex-col bg-white overflow-hidden shadow-2xl transition-all duration-300 ${
          isMobile
            ? 'w-[390px] h-[820px] rounded-[48px] border-[10px] border-slate-800 ring-1 ring-slate-700'
            : 'w-[780px] h-[920px] rounded-[36px] border-[12px] border-slate-800 ring-1 ring-slate-700'
        }`}
      >
        {/* Device Simulated Status Bar */}
        <div className="shrink-0 flex items-center justify-between px-6 pt-3 pb-2 bg-white text-slate-900 select-none z-20">
          <span className="text-xs font-semibold tracking-tight">09:41</span>

          {/* Dynamic Island / Notch */}
          {isMobile && (
            <div className="h-4 w-24 bg-slate-900 rounded-full flex items-center justify-end px-2">
              <div className="h-2 w-2 rounded-full bg-slate-700" />
            </div>
          )}

          <div className="flex items-center gap-1.5 text-slate-700">
            <Signal className="h-3.5 w-3.5" />
            <Wifi className="h-3.5 w-3.5" />
            <BatteryMedium className="h-4 w-4" />
          </div>
        </div>

        {/* Device Content Container */}
        <div className="flex-1 overflow-y-auto flex flex-col">{children}</div>

        {/* Home Indicator Bar (Mobile) */}
        {isMobile && (
          <div className="h-5 shrink-0 flex items-center justify-center bg-white">
            <div className="h-1 w-32 rounded-full bg-slate-300" />
          </div>
        )}
      </div>
    </div>
  );
};
