import React, { useState } from 'react';
import {
  LogOut,
  User,
  ShieldCheck,
  Monitor,
  Tablet,
  Smartphone,
  ChevronDown,
  Database,
  Building2,
  FileCode,
  History,
  Menu,
} from 'lucide-react';
import { UserProfile, ViewportMode, ScolaRole } from '../../types';
import { ROLE_LABELS } from '../../lib/permissions';
import { isSupabaseConfigured } from '../../config/supabase';

interface NavbarProps {
  currentUser: UserProfile | null;
  currentTenantName?: string;
  viewportMode: ViewportMode;
  onViewportChange: (mode: ViewportMode) => void;
  onSwitchRole?: (role: ScolaRole, schoolType?: 'SMA' | 'SMK') => void;
  onLogout: () => void;
  onOpenSqlModal: () => void;
  onNavigate: (route: string) => void;
  onToggleMobileSidebar: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentUser,
  currentTenantName,
  viewportMode,
  onViewportChange,
  onSwitchRole,
  onLogout,
  onOpenSqlModal,
  onNavigate,
  onToggleMobileSidebar,
}) => {
  const [roleDropdownOpen, setRoleDropdownOpen] = useState(false);
  const [userMenuOpen, setUserMenuOpen] = useState(false);
  const isCloudActive = isSupabaseConfigured();

  return (
    <header className="sticky top-0 z-30 flex h-16 items-center justify-between border-b border-slate-200 bg-white/95 px-4 backdrop-blur-md transition-colors sm:px-6">
      {/* Left: Mobile Menu Toggle & Brand / School Info */}
      <div className="flex items-center gap-3">
        <button
          onClick={onToggleMobileSidebar}
          className="rounded-lg p-1.5 text-slate-600 hover:bg-slate-100 lg:hidden"
          title="Buka Menu Navigasi"
          aria-label="Buka Menu Navigasi"
        >
          <Menu className="h-5 w-5" />
        </button>

        <div className="flex items-center gap-3">
          <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-blue-700 to-indigo-800 text-white font-bold text-base shadow-sm">
            SC
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-extrabold tracking-tight text-slate-900 text-lg leading-tight">
                SCOLA
              </span>
              <span className="hidden sm:inline-block rounded-full bg-blue-50 px-2 py-0.5 text-[11px] font-semibold text-blue-700">
                School OS
              </span>
            </div>
            {currentTenantName && (
              <div className="flex items-center gap-1 text-xs text-slate-500 font-medium">
                <Building2 className="h-3 w-3 text-slate-400" />
                <span className="truncate max-w-[140px] sm:max-w-[220px]">{currentTenantName}</span>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Center: Responsive Device Preview Switcher */}
      <div className="hidden md:flex items-center rounded-xl bg-slate-100 p-1 text-slate-600">
        <button
          onClick={() => onViewportChange('desktop')}
          className={`flex items-center gap-1.5 rounded-lg px-2.5 py-1 text-xs font-medium transition-all ${
            viewportMode === 'desktop'
              ? 'bg-white text-blue-700 shadow-xs font-semibold'
              : 'hover:text-slate-900'
          }`}
          title="Tampilan Desktop (Responsive Penuh)"
        >
          <Monitor className="h-3.5 w-3.5" />
          <span>Desktop</span>
        </button>
        <button
          onClick={() => onViewportChange('tablet')}
          className={`flex items-center gap-1.5 rounded-lg px-2.5 py-1 text-xs font-medium transition-all ${
            viewportMode === 'tablet'
              ? 'bg-white text-blue-700 shadow-xs font-semibold'
              : 'hover:text-slate-900'
          }`}
          title="Simulasi Tablet (iPad/Android Tab)"
        >
          <Tablet className="h-3.5 w-3.5" />
          <span>Tablet</span>
        </button>
        <button
          onClick={() => onViewportChange('mobile')}
          className={`flex items-center gap-1.5 rounded-lg px-2.5 py-1 text-xs font-medium transition-all ${
            viewportMode === 'mobile'
              ? 'bg-white text-blue-700 shadow-xs font-semibold'
              : 'hover:text-slate-900'
          }`}
          title="Simulasi Smartphone (Capacitor iOS/Android)"
        >
          <Smartphone className="h-3.5 w-3.5" />
          <span>Mobile</span>
        </button>
      </div>

      {/* Right: Cloud status, Quick Switcher, SQL helper, Audit logs, User Profile */}
      <div className="flex items-center gap-2 sm:gap-3">
        {/* Supabase Realtime/Cloud Indicator */}
        <div
          className={`hidden sm:flex items-center gap-1.5 rounded-full px-2.5 py-1 text-xs font-medium ${
            isCloudActive
              ? 'bg-emerald-50 text-emerald-700 border border-emerald-200/60'
              : 'bg-amber-50 text-amber-700 border border-amber-200/60'
          }`}
          title={
            isCloudActive
              ? 'Terhubung ke Supabase Cloud (PostgreSQL + RLS)'
              : 'Mode In-Memory Standalone (Siap Hubungkan ke Supabase)'
          }
        >
          <span
            className={`h-2 w-2 rounded-full ${
              isCloudActive ? 'bg-emerald-500 animate-pulse' : 'bg-amber-500'
            }`}
          />
          <Database className="h-3 w-3" />
          <span className="hidden md:inline">
            {isCloudActive ? 'Supabase Live' : 'Local State'}
          </span>
        </div>

        {/* Supabase SQL DDL Modal Trigger */}
        <button
          onClick={onOpenSqlModal}
          className="hidden lg:flex items-center gap-1.5 rounded-lg border border-slate-200 bg-white px-2.5 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50 transition-colors shadow-2xs"
          title="Lihat Skrip SQL Supabase & RLS Setup"
        >
          <FileCode className="h-3.5 w-3.5 text-blue-600" />
          <span>SQL Setup</span>
        </button>

        {/* Audit Log Quick Trigger */}
        <button
          onClick={() => onNavigate('/audit')}
          className="rounded-lg p-2 text-slate-600 hover:bg-slate-100 transition-colors"
          title="Lihat Audit Log Keamanan & Perubahan Kuota"
          aria-label="Audit Log"
        >
          <History className="h-4 w-4" />
        </button>

        {/* Quick Role Switcher Dropdown (offline/demo only) */}
        {!isCloudActive && <div className="relative">
          <button
            onClick={() => setRoleDropdownOpen(!roleDropdownOpen)}
            className="flex items-center gap-1.5 rounded-lg border border-blue-200 bg-blue-50/70 px-2.5 py-1.5 text-xs font-semibold text-blue-800 hover:bg-blue-100 transition-colors"
            title="Ganti Peran Pengguna untuk Pengujian"
          >
            <ShieldCheck className="h-3.5 w-3.5 text-blue-700" />
            <span className="hidden sm:inline">Ganti Role</span>
            <ChevronDown className="h-3 w-3" />
          </button>

          {roleDropdownOpen && (
            <div
              className="absolute right-0 mt-2 w-64 rounded-xl border border-slate-200 bg-white py-2 shadow-xl z-50 animate-in fade-in zoom-in-95 duration-100"
              onMouseLeave={() => setRoleDropdownOpen(false)}
            >
              <div className="px-3 py-1.5 text-[11px] font-bold uppercase tracking-wider text-slate-400">
                Mode Simulasi Pengguna
              </div>

              <button
                onClick={() => {
                  onSwitchRole?.('MASTER');
                  setRoleDropdownOpen(false);
                }}
                className="w-full text-left px-3 py-2 text-xs hover:bg-slate-50 flex items-center justify-between"
              >
                <div>
                  <div className="font-semibold text-slate-800">Super Master Platform</div>
                  <div className="text-[11px] text-slate-500">mdqputra@gmail.com</div>
                </div>
                {currentUser?.role === 'MASTER' && (
                  <span className="h-2 w-2 rounded-full bg-blue-600" />
                )}
              </button>

              <button
                onClick={() => {
                  onSwitchRole?.('KEPALA_SEKOLAH', 'SMA');
                  setRoleDropdownOpen(false);
                }}
                className="w-full text-left px-3 py-2 text-xs hover:bg-slate-50 flex items-center justify-between"
              >
                <div>
                  <div className="font-semibold text-slate-800">Kepala Sekolah (SMA)</div>
                  <div className="text-[11px] text-slate-500">SMAN 1 Nusantara</div>
                </div>
                {currentUser?.role === 'KEPALA_SEKOLAH' && currentUser.tenant_id === 'tenant-sma-01' && (
                  <span className="h-2 w-2 rounded-full bg-blue-600" />
                )}
              </button>

              <button
                onClick={() => {
                  onSwitchRole?.('GURU', 'SMA');
                  setRoleDropdownOpen(false);
                }}
                className="w-full text-left px-3 py-2 text-xs hover:bg-slate-50 flex items-center justify-between"
              >
                <div>
                  <div className="font-semibold text-slate-800">Guru / Wali Kelas & Waka</div>
                  <div className="text-[11px] text-slate-500">Budi Santoso, S.Pd. (SMA)</div>
                </div>
                {currentUser?.role === 'GURU' && currentUser.tenant_id === 'tenant-sma-01' && (
                  <span className="h-2 w-2 rounded-full bg-blue-600" />
                )}
              </button>

              <button
                onClick={() => {
                  onSwitchRole?.('GURU', 'SMK');
                  setRoleDropdownOpen(false);
                }}
                className="w-full text-left px-3 py-2 text-xs hover:bg-slate-50 flex items-center justify-between"
              >
                <div>
                  <div className="font-semibold text-slate-800">Guru Kaprog PPLG / PKL</div>
                  <div className="text-[11px] text-slate-500">Hendra Kusuma, M.Kom (SMK)</div>
                </div>
                {currentUser?.role === 'GURU' && currentUser.tenant_id === 'tenant-smk-02' && (
                  <span className="h-2 w-2 rounded-full bg-blue-600" />
                )}
              </button>

              <button
                onClick={() => {
                  onSwitchRole?.('SISWA', 'SMA');
                  setRoleDropdownOpen(false);
                }}
                className="w-full text-left px-3 py-2 text-xs hover:bg-slate-50 flex items-center justify-between"
              >
                <div>
                  <div className="font-semibold text-slate-800">Siswa / Siswi (SMA)</div>
                  <div className="text-[11px] text-slate-500">Ahmad Fauzan (X MIPA 1)</div>
                </div>
                {currentUser?.role === 'SISWA' && (
                  <span className="h-2 w-2 rounded-full bg-blue-600" />
                )}
              </button>

              <button
                onClick={() => {
                  onSwitchRole?.('ORANG_TUA');
                  setRoleDropdownOpen(false);
                }}
                className="w-full text-left px-3 py-2 text-xs hover:bg-slate-50 flex items-center justify-between"
              >
                <div>
                  <div className="font-semibold text-slate-800">Orang Tua / Wali Murid</div>
                  <div className="text-[11px] text-slate-500">Santoso Wijaya (Wali Siswa)</div>
                </div>
                {currentUser?.role === 'ORANG_TUA' && (
                  <span className="h-2 w-2 rounded-full bg-blue-600" />
                )}
              </button>

              <button
                onClick={() => {
                  onSwitchRole?.('TENAGA_KEPENDIDIKAN');
                  setRoleDropdownOpen(false);
                }}
                className="w-full text-left px-3 py-2 text-xs hover:bg-slate-50 flex items-center justify-between"
              >
                <div>
                  <div className="font-semibold text-slate-800">Tenaga Kependidikan / TU</div>
                  <div className="text-[11px] text-slate-500">Siti Rahmawati, S.AP</div>
                </div>
                {currentUser?.role === 'TENAGA_KEPENDIDIKAN' && (
                  <span className="h-2 w-2 rounded-full bg-blue-600" />
                )}
              </button>
            </div>
          )}
        </div>}

        {/* User Account Menu */}
        <div className="relative">
          <button
            onClick={() => setUserMenuOpen(!userMenuOpen)}
            className="flex items-center gap-2 rounded-lg p-1.5 hover:bg-slate-100 transition-colors"
          >
            <div className="flex h-8 w-8 items-center justify-center rounded-full bg-slate-200 text-slate-700 font-semibold text-xs border border-slate-300">
              {currentUser?.full_name ? currentUser.full_name.charAt(0) : <User className="h-4 w-4" />}
            </div>
            <div className="hidden text-left xl:block">
              <div className="text-xs font-semibold text-slate-800 leading-none">
                {currentUser?.full_name || 'Tamu'}
              </div>
              <div className="text-[10px] text-slate-500 mt-0.5">
                {currentUser?.role ? ROLE_LABELS[currentUser.role] : 'Guest'}
              </div>
            </div>
            <ChevronDown className="hidden xl:block h-3 w-3 text-slate-400" />
          </button>

          {userMenuOpen && (
            <div
              className="absolute right-0 mt-2 w-56 rounded-xl border border-slate-200 bg-white py-1.5 shadow-xl z-50 animate-in fade-in zoom-in-95 duration-100"
              onMouseLeave={() => setUserMenuOpen(false)}
            >
              <div className="border-b border-slate-100 px-3.5 py-2">
                <div className="font-semibold text-xs text-slate-900 truncate">
                  {currentUser?.full_name}
                </div>
                <div className="text-[11px] text-slate-500 truncate">{currentUser?.email}</div>
                <div className="mt-1">
                  <span className="inline-block rounded bg-blue-50 px-1.5 py-0.5 text-[10px] font-semibold text-blue-700">
                    {currentUser?.role ? ROLE_LABELS[currentUser.role] : 'Guest'}
                  </span>
                </div>
              </div>

              <button
                onClick={() => {
                  setUserMenuOpen(false);
                  onNavigate('/audit');
                }}
                className="flex w-full items-center gap-2 px-3.5 py-2 text-xs text-slate-700 hover:bg-slate-50"
              >
                <History className="h-3.5 w-3.5 text-slate-400" />
                <span>Log Aktivitas & Audit</span>
              </button>

              <button
                onClick={() => {
                  setUserMenuOpen(false);
                  onLogout();
                }}
                className="flex w-full items-center gap-2 border-t border-slate-100 px-3.5 py-2 text-xs text-red-600 hover:bg-red-50"
              >
                <LogOut className="h-3.5 w-3.5" />
                <span>Keluar (Sign Out)</span>
              </button>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};
