import React from 'react';
import {
  LayoutDashboard,
  Building2,
  Users,
  GraduationCap,
  BookOpen,
  Calendar,
  ClipboardList,
  Award,
  Briefcase,
  Layers,
  HeartHandshake,
  ShieldCheck,
  History,
  X,
  UserCheck,
  Building,
  Mail,
  FileCheck,
} from 'lucide-react';
import { UserProfile, Tenant } from '../../types';
import { ROLE_LABELS, hasAssignment } from '../../lib/permissions';

interface SidebarProps {
  currentUser: UserProfile | null;
  currentTenant: Tenant | null;
  currentRoute: string;
  onNavigate: (route: string) => void;
  isOpenMobile: boolean;
  onCloseMobile: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentUser,
  currentTenant,
  currentRoute,
  onNavigate,
  isOpenMobile,
  onCloseMobile,
}) => {
  const role = currentUser?.role || 'SISWA';
  const isSmk = currentTenant?.type === 'SMK';

  const isWaliKelas = hasAssignment(currentUser, 'WALI_KELAS');
  const isWakaKurikulum = hasAssignment(currentUser, 'WAKA_KURIKULUM');
  const isWakaKesiswaan = hasAssignment(currentUser, 'WAKA_KESISWAAN');
  const isWakaSarpras = hasAssignment(currentUser, 'WAKA_SARPRAS');
  const isWakaHumas = hasAssignment(currentUser, 'WAKA_HUMAS');
  const isKaprog = hasAssignment(currentUser, 'KAPROG');
  const isBk = hasAssignment(currentUser, 'BK') || hasAssignment(currentUser, 'GURU_BK');
  const hasAnyWaka = isWakaKurikulum || isWakaKesiswaan || isWakaSarpras || isWakaHumas;

  const handleNav = (route: string) => {
    onNavigate(route);
    onCloseMobile();
  };

  return (
    <>
      {/* Mobile Backdrop */}
      {isOpenMobile && (
        <div
          className="fixed inset-0 z-40 bg-slate-900/40 backdrop-blur-xs lg:hidden"
          onClick={onCloseMobile}
        />
      )}

      {/* Sidebar Panel */}
      <aside
        className={`fixed inset-y-0 left-0 z-50 flex w-72 flex-col border-r border-slate-200 bg-white transition-transform duration-200 ease-in-out lg:static lg:translate-x-0 ${
          isOpenMobile ? 'translate-x-0 shadow-2xl' : '-translate-x-0 hidden lg:flex'
        }`}
      >
        {/* Top: School Tenant Badge / Master Brand */}
        <div className="flex h-16 items-center justify-between border-b border-slate-100 px-5">
          <div className="flex items-center gap-3 overflow-hidden">
            <div
              className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl font-bold text-white shadow-xs"
              style={{ backgroundColor: currentTenant?.brand_color || '#1e40af' }}
            >
              {currentTenant?.type === 'SMK' ? 'SMK' : currentTenant?.type === 'SMA' ? 'SMA' : 'SC'}
            </div>
            <div className="truncate">
              <div className="text-sm font-bold text-slate-900 truncate leading-tight">
                {currentTenant?.name || 'SCOLA System'}
              </div>
              <div className="text-[11px] font-medium text-slate-500 flex items-center gap-1.5 mt-0.5">
                <span className="truncate">{ROLE_LABELS[role]}</span>
                {currentTenant && (
                  <span className="rounded bg-slate-100 px-1 text-[10px] text-slate-600 font-semibold uppercase">
                    {currentTenant.type}
                  </span>
                )}
              </div>
            </div>
          </div>

          <button
            onClick={onCloseMobile}
            className="rounded-lg p-1.5 text-slate-400 hover:bg-slate-100 lg:hidden"
            aria-label="Tutup Menu"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Scrollable Navigation Items */}
        <nav className="flex-1 space-y-6 overflow-y-auto px-4 py-4 text-xs">
          {/* ================= MASTER ROLE MENU ================= */}
          {role === 'MASTER' && (
            <div>
              <div className="px-2 pb-2 text-[10px] font-bold uppercase tracking-wider text-slate-400">
                Super Master Platform
              </div>
              <div className="space-y-1">
                <button
                  onClick={() => handleNav('/master')}
                  className={`flex w-full items-center gap-3 rounded-xl px-3 py-2.5 font-medium transition-all ${
                    currentRoute === '/master'
                      ? 'bg-blue-50 text-blue-700 font-semibold shadow-2xs'
                      : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
                  }`}
                >
                  <LayoutDashboard className="h-4 w-4" />
                  <span>Dashboard Platform</span>
                </button>
                <button
                  onClick={() => handleNav('/master')}
                  className={`flex w-full items-center gap-3 rounded-xl px-3 py-2.5 font-medium transition-all ${
                    currentRoute === '/master'
                      ? 'bg-blue-50 text-blue-700 font-semibold shadow-2xs'
                      : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
                  }`}
                >
                  <Building2 className="h-4 w-4" />
                  <span>Kelola Tenant & Kuota</span>
                </button>
                <button
                  onClick={() => handleNav('/audit')}
                  className={`flex w-full items-center gap-3 rounded-xl px-3 py-2.5 font-medium transition-all ${
                    currentRoute === '/audit'
                      ? 'bg-blue-50 text-blue-700 font-semibold shadow-2xs'
                      : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
                  }`}
                >
                  <History className="h-4 w-4" />
                  <span>Log Audit Multi-Tenant</span>
                </button>
              </div>
            </div>
          )}

          {/* ================= KEPALA SEKOLAH MENU ================= */}
          {role === 'KEPALA_SEKOLAH' && (
            <div>
              <div className="px-2 pb-2 text-[10px] font-bold uppercase tracking-wider text-slate-400">
                Manajemen Sekolah
              </div>
              <div className="space-y-1">
                <button
                  onClick={() => handleNav('/kepsek')}
                  className={`flex w-full items-center gap-3 rounded-xl px-3 py-2.5 font-medium transition-all ${
                    currentRoute === '/kepsek'
                      ? 'bg-blue-50 text-blue-700 font-semibold shadow-2xs'
                      : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
                  }`}
                >
                  <LayoutDashboard className="h-4 w-4" />
                  <span>Overview & Kuota Guru</span>
                </button>
                <button
                  onClick={() => handleNav('/kepsek')}
                  className={`flex w-full items-center gap-3 rounded-xl px-3 py-2.5 font-medium transition-all ${
                    currentRoute === '/kepsek'
                      ? 'bg-blue-50 text-blue-700 font-semibold shadow-2xs'
                      : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
                  }`}
                >
                  <Users className="h-4 w-4" />
                  <span>Manajemen Akun Guru</span>
                </button>
                <button
                  onClick={() => handleNav('/kepsek')}
                  className={`flex w-full items-center gap-3 rounded-xl px-3 py-2.5 font-medium transition-all ${
                    currentRoute === '/kepsek'
                      ? 'bg-blue-50 text-blue-700 font-semibold shadow-2xs'
                      : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
                  }`}
                >
                  <Layers className="h-4 w-4" />
                  <span>Rombel & Kelas Siswa</span>
                </button>
                <button
                  onClick={() => handleNav('/waka')}
                  className={`flex w-full items-center gap-3 rounded-xl px-3 py-2.5 font-medium transition-all ${
                    currentRoute === '/waka'
                      ? 'bg-blue-50 text-blue-700 font-semibold shadow-2xs'
                      : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
                  }`}
                >
                  <ShieldCheck className="h-4 w-4" />
                  <span>Bidang Waka & Tugas</span>
                </button>
                {isSmk ? (
                  <button
                    onClick={() => handleNav('/smk')}
                    className={`flex w-full items-center gap-3 rounded-xl px-3 py-2.5 font-medium transition-all ${
                      currentRoute === '/smk'
                        ? 'bg-blue-50 text-blue-700 font-semibold shadow-2xs'
                        : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
                    }`}
                  >
                    <Briefcase className="h-4 w-4 text-emerald-600" />
                    <span>Program SMK & PKL</span>
                  </button>
                ) : (
                  <button
                    onClick={() => handleNav('/sma')}
                    className={`flex w-full items-center gap-3 rounded-xl px-3 py-2.5 font-medium transition-all ${
                      currentRoute === '/sma'
                        ? 'bg-blue-50 text-blue-700 font-semibold shadow-2xs'
                        : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
                    }`}
                  >
                    <BookOpen className="h-4 w-4 text-blue-600" />
                    <span>Peminatan SMA & SNBP</span>
                  </button>
                )}
                <button
                  onClick={() => handleNav('/bk')}
                  className={`flex w-full items-center gap-3 rounded-xl px-3 py-2.5 font-medium transition-all ${
                    currentRoute === '/bk'
                      ? 'bg-blue-50 text-blue-700 font-semibold shadow-2xs'
                      : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
                  }`}
                >
                  <HeartHandshake className="h-4 w-4" />
                  <span>Bimbingan Konseling (BK)</span>
                </button>
                <button
                  onClick={() => handleNav('/audit')}
                  className={`flex w-full items-center gap-3 rounded-xl px-3 py-2.5 font-medium transition-all ${
                    currentRoute === '/audit'
                      ? 'bg-blue-50 text-blue-700 font-semibold shadow-2xs'
                      : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
                  }`}
                >
                  <History className="h-4 w-4" />
                  <span>Log Audit Sekolah</span>
                </button>
              </div>
            </div>
          )}

          {/* ================= GURU ROLE MENU ================= */}
          {role === 'GURU' && (
            <div>
              <div className="px-2 pb-2 text-[10px] font-bold uppercase tracking-wider text-slate-400">
                Aktivitas Akademik Guru
              </div>
              <div className="space-y-1">
                <button
                  onClick={() => handleNav('/guru')}
                  className={`flex w-full items-center gap-3 rounded-xl px-3 py-2.5 font-medium transition-all ${
                    currentRoute === '/guru'
                      ? 'bg-blue-50 text-blue-700 font-semibold shadow-2xs'
                      : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
                  }`}
                >
                  <LayoutDashboard className="h-4 w-4" />
                  <span>Beranda Pengajar</span>
                </button>
                <button
                  onClick={() => handleNav('/guru')}
                  className={`flex w-full items-center gap-3 rounded-xl px-3 py-2.5 font-medium transition-all ${
                    currentRoute === '/guru'
                      ? 'bg-blue-50 text-blue-700 font-semibold shadow-2xs'
                      : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
                  }`}
                >
                  <Calendar className="h-4 w-4" />
                  <span>Jadwal & Mengajar</span>
                </button>
                <button
                  onClick={() => handleNav('/guru')}
                  className={`flex w-full items-center gap-3 rounded-xl px-3 py-2.5 font-medium transition-all ${
                    currentRoute === '/guru'
                      ? 'bg-blue-50 text-blue-700 font-semibold shadow-2xs'
                      : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
                  }`}
                >
                  <UserCheck className="h-4 w-4" />
                  <span>Presensi & Absensi</span>
                </button>
                <button
                  onClick={() => handleNav('/guru')}
                  className={`flex w-full items-center gap-3 rounded-xl px-3 py-2.5 font-medium transition-all ${
                    currentRoute === '/guru'
                      ? 'bg-blue-50 text-blue-700 font-semibold shadow-2xs'
                      : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
                  }`}
                >
                  <ClipboardList className="h-4 w-4" />
                  <span>Tugas & Penilaian</span>
                </button>
                <button
                  onClick={() => handleNav('/guru')}
                  className={`flex w-full items-center gap-3 rounded-xl px-3 py-2.5 font-medium transition-all ${
                    currentRoute === '/guru'
                      ? 'bg-blue-50 text-blue-700 font-semibold shadow-2xs'
                      : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
                  }`}
                >
                  <Award className="h-4 w-4" />
                  <span>e-Rapor & Nilai Akhir</span>
                </button>
              </div>

              {/* Assignments Section */}
              <div className="mt-5">
                <div className="px-2 pb-2 text-[10px] font-bold uppercase tracking-wider text-slate-400">
                  Tugas Tambahan Terdaftar
                </div>
                <div className="space-y-1">
                  {isWaliKelas && (
                    <button
                      onClick={() => handleNav('/guru')}
                      className="flex w-full items-center justify-between rounded-xl px-3 py-2 text-slate-700 hover:bg-slate-50 font-medium"
                    >
                      <div className="flex items-center gap-2.5">
                        <GraduationCap className="h-4 w-4 text-emerald-600" />
                        <span>Wali Kelas & Orang Tua</span>
                      </div>
                      <span className="rounded-full bg-emerald-100 px-1.5 py-0.5 text-[10px] font-bold text-emerald-800">
                        Aktif
                      </span>
                    </button>
                  )}
                  {hasAnyWaka && (
                    <button
                      onClick={() => handleNav('/waka')}
                      className={`flex w-full items-center justify-between rounded-xl px-3 py-2 font-medium transition-all ${
                        currentRoute === '/waka'
                          ? 'bg-blue-50 text-blue-700 font-semibold shadow-2xs'
                          : 'text-slate-700 hover:bg-slate-50'
                      }`}
                    >
                      <div className="flex items-center gap-2.5">
                        <ShieldCheck className="h-4 w-4 text-blue-600" />
                        <span>Portal Manajemen Waka</span>
                      </div>
                      <span className="rounded-full bg-blue-100 px-1.5 py-0.5 text-[10px] font-bold text-blue-800">
                        {isWakaKurikulum ? 'Kurikulum' : isWakaKesiswaan ? 'Kesiswaan' : isWakaSarpras ? 'Sarpras' : isWakaHumas ? 'Humas' : 'Waka'}
                      </span>
                    </button>
                  )}
                  {isKaprog && (
                    <button
                      onClick={() => handleNav('/smk')}
                      className="flex w-full items-center justify-between rounded-xl px-3 py-2 text-slate-700 hover:bg-slate-50 font-medium"
                    >
                      <div className="flex items-center gap-2.5">
                        <Briefcase className="h-4 w-4 text-amber-600" />
                        <span>Kaprog SMK & PKL</span>
                      </div>
                      <span className="rounded-full bg-amber-100 px-1.5 py-0.5 text-[10px] font-bold text-amber-800">
                        Kaprog
                      </span>
                    </button>
                  )}
                  {isBk && (
                    <button
                      onClick={() => handleNav('/bk')}
                      className="flex w-full items-center justify-between rounded-xl px-3 py-2 text-slate-700 hover:bg-slate-50 font-medium"
                    >
                      <div className="flex items-center gap-2.5">
                        <HeartHandshake className="h-4 w-4 text-purple-600" />
                        <span>Bimbingan Konseling</span>
                      </div>
                      <span className="rounded-full bg-purple-100 px-1.5 py-0.5 text-[10px] font-bold text-purple-800">
                        BK
                      </span>
                    </button>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* ================= SISWA ROLE MENU ================= */}
          {role === 'SISWA' && (
            <div>
              <div className="px-2 pb-2 text-[10px] font-bold uppercase tracking-wider text-slate-400">
                Portal Mandiri Siswa
              </div>
              <div className="space-y-1">
                <button
                  onClick={() => handleNav('/siswa')}
                  className={`flex w-full items-center gap-3 rounded-xl px-3 py-2.5 font-medium transition-all ${
                    currentRoute === '/siswa'
                      ? 'bg-blue-50 text-blue-700 font-semibold shadow-2xs'
                      : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
                  }`}
                >
                  <LayoutDashboard className="h-4 w-4" />
                  <span>Beranda Siswa</span>
                </button>
                <button
                  onClick={() => handleNav('/siswa')}
                  className={`flex w-full items-center gap-3 rounded-xl px-3 py-2.5 font-medium transition-all ${
                    currentRoute === '/siswa'
                      ? 'bg-blue-50 text-blue-700 font-semibold shadow-2xs'
                      : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
                  }`}
                >
                  <Calendar className="h-4 w-4" />
                  <span>Jadwal Pelajaran</span>
                </button>
                <button
                  onClick={() => handleNav('/siswa')}
                  className={`flex w-full items-center gap-3 rounded-xl px-3 py-2.5 font-medium transition-all ${
                    currentRoute === '/siswa'
                      ? 'bg-blue-50 text-blue-700 font-semibold shadow-2xs'
                      : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
                  }`}
                >
                  <ClipboardList className="h-4 w-4" />
                  <span>Tugas Mandiri</span>
                </button>
                <button
                  onClick={() => handleNav('/siswa')}
                  className={`flex w-full items-center gap-3 rounded-xl px-3 py-2.5 font-medium transition-all ${
                    currentRoute === '/siswa'
                      ? 'bg-blue-50 text-blue-700 font-semibold shadow-2xs'
                      : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
                  }`}
                >
                  <UserCheck className="h-4 w-4" />
                  <span>Kehadiran Saya</span>
                </button>
                <button
                  onClick={() => handleNav('/siswa')}
                  className={`flex w-full items-center gap-3 rounded-xl px-3 py-2.5 font-medium transition-all ${
                    currentRoute === '/siswa'
                      ? 'bg-blue-50 text-blue-700 font-semibold shadow-2xs'
                      : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
                  }`}
                >
                  <Award className="h-4 w-4" />
                  <span>e-Rapor & Capaian</span>
                </button>
                {isSmk && (
                  <button
                    onClick={() => handleNav('/smk')}
                    className={`flex w-full items-center gap-3 rounded-xl px-3 py-2.5 font-medium transition-all ${
                      currentRoute === '/smk'
                        ? 'bg-emerald-50 text-emerald-700 font-semibold shadow-2xs'
                        : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
                    }`}
                  >
                    <Briefcase className="h-4 w-4 text-emerald-600" />
                    <span>Jurnal PKL & UKK SMK</span>
                  </button>
                )}
              </div>
            </div>
          )}

          {/* ================= ORANG TUA ROLE MENU ================= */}
          {role === 'ORANG_TUA' && (
            <div>
              <div className="px-2 pb-2 text-[10px] font-bold uppercase tracking-wider text-slate-400">
                Portal Orang Tua & Wali
              </div>
              <div className="space-y-1">
                <button
                  onClick={() => handleNav('/parent')}
                  className={`flex w-full items-center gap-3 rounded-xl px-3 py-2.5 font-medium transition-all ${
                    currentRoute === '/parent'
                      ? 'bg-blue-50 text-blue-700 font-semibold shadow-2xs'
                      : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
                  }`}
                >
                  <LayoutDashboard className="h-4 w-4" />
                  <span>Ringkasan Perkembangan</span>
                </button>
                <button
                  onClick={() => handleNav('/parent')}
                  className={`flex w-full items-center gap-3 rounded-xl px-3 py-2.5 font-medium transition-all ${
                    currentRoute === '/parent'
                      ? 'bg-blue-50 text-blue-700 font-semibold shadow-2xs'
                      : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
                  }`}
                >
                  <UserCheck className="h-4 w-4" />
                  <span>Presensi & Absensi Anak</span>
                </button>
                <button
                  onClick={() => handleNav('/parent')}
                  className={`flex w-full items-center gap-3 rounded-xl px-3 py-2.5 font-medium transition-all ${
                    currentRoute === '/parent'
                      ? 'bg-blue-50 text-blue-700 font-semibold shadow-2xs'
                      : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
                  }`}
                >
                  <Award className="h-4 w-4" />
                  <span>Nilai Tugas & e-Rapor</span>
                </button>
                <button
                  onClick={() => handleNav('/parent')}
                  className={`flex w-full items-center gap-3 rounded-xl px-3 py-2.5 font-medium transition-all ${
                    currentRoute === '/parent'
                      ? 'bg-blue-50 text-blue-700 font-semibold shadow-2xs'
                      : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
                  }`}
                >
                  <Calendar className="h-4 w-4" />
                  <span>Jadwal Pelajaran</span>
                </button>
                <button
                  onClick={() => handleNav('/parent')}
                  className={`flex w-full items-center gap-3 rounded-xl px-3 py-2.5 font-medium transition-all ${
                    currentRoute === '/parent'
                      ? 'bg-blue-50 text-blue-700 font-semibold shadow-2xs'
                      : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
                  }`}
                >
                  <HeartHandshake className="h-4 w-4" />
                  <span>Komunikasi Wali Kelas</span>
                </button>
              </div>
            </div>
          )}

          {/* ================= TENAGA KEPENDIDIKAN (TU) MENU ================= */}
          {role === 'TENAGA_KEPENDIDIKAN' && (
            <div>
              <div className="px-2 pb-2 text-[10px] font-bold uppercase tracking-wider text-slate-400">
                Tata Usaha & Administrasi
              </div>
              <div className="space-y-1">
                <button
                  onClick={() => handleNav('/tu')}
                  className={`flex w-full items-center gap-3 rounded-xl px-3 py-2.5 font-medium transition-all ${
                    currentRoute === '/tu'
                      ? 'bg-blue-50 text-blue-700 font-semibold shadow-2xs'
                      : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
                  }`}
                >
                  <LayoutDashboard className="h-4 w-4" />
                  <span>Overview Tata Usaha</span>
                </button>
                <button
                  onClick={() => handleNav('/tu')}
                  className={`flex w-full items-center gap-3 rounded-xl px-3 py-2.5 font-medium transition-all ${
                    currentRoute === '/tu'
                      ? 'bg-blue-50 text-blue-700 font-semibold shadow-2xs'
                      : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
                  }`}
                >
                  <Mail className="h-4 w-4" />
                  <span>Persuratan & SK Resmi</span>
                </button>
                <button
                  onClick={() => handleNav('/tu')}
                  className={`flex w-full items-center gap-3 rounded-xl px-3 py-2.5 font-medium transition-all ${
                    currentRoute === '/tu'
                      ? 'bg-blue-50 text-blue-700 font-semibold shadow-2xs'
                      : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
                  }`}
                >
                  <Building className="h-4 w-4" />
                  <span>Inventaris & Sarpras</span>
                </button>
                <button
                  onClick={() => handleNav('/tu')}
                  className={`flex w-full items-center gap-3 rounded-xl px-3 py-2.5 font-medium transition-all ${
                    currentRoute === '/tu'
                      ? 'bg-blue-50 text-blue-700 font-semibold shadow-2xs'
                      : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
                  }`}
                >
                  <FileCheck className="h-4 w-4" />
                  <span>Legalisir Ijazah</span>
                </button>
              </div>
            </div>
          )}
        </nav>

        {/* Footer: User info summary */}
        <div className="border-t border-slate-100 p-4">
          <div className="rounded-xl bg-slate-50 p-3 text-slate-700">
            <div className="flex items-center gap-2">
              <div className="h-2 w-2 rounded-full bg-emerald-500 animate-pulse" />
              <div className="text-[11px] font-semibold truncate">
                {currentUser?.full_name}
              </div>
            </div>
            <div className="text-[10px] text-slate-500 truncate mt-0.5">
              {currentUser?.email}
            </div>
          </div>
        </div>
      </aside>
    </>
  );
};
