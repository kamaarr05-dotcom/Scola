import React, { useState, useEffect } from 'react';
import { Navbar } from './Navbar';
import { Sidebar } from './Sidebar';
import { DeviceFrame } from '../common/DeviceFrame';
import { SupabaseSqlModal } from '../common/SupabaseSqlModal';
import { UserProfile, Tenant, ViewportMode, ScolaRole } from '../../types';
import { tenantRepository } from '../../repositories/tenantRepository';
import { authService } from '../../services/authService';
import { isSupabaseConfigured } from '../../config/supabase';

interface DashboardLayoutProps {
  currentUser: UserProfile | null;
  currentRoute: string;
  viewportMode: ViewportMode;
  onViewportChange: (mode: ViewportMode) => void;
  onNavigate: (route: string) => void;
  onLogout: () => void;
  children: React.ReactNode;
}

export const DashboardLayout: React.FC<DashboardLayoutProps> = ({
  currentUser,
  currentRoute,
  viewportMode,
  onViewportChange,
  onNavigate,
  onLogout,
  children,
}) => {
  const [currentTenant, setCurrentTenant] = useState<Tenant | null>(null);
  const [mobileSidebarOpen, setMobileSidebarOpen] = useState(false);
  const [sqlModalOpen, setSqlModalOpen] = useState(false);

  useEffect(() => {
    async function loadTenant() {
      if (currentUser?.tenant_id) {
        const t = await tenantRepository.getById(currentUser.tenant_id);
        setCurrentTenant(t);
      } else {
        setCurrentTenant(null);
      }
    }
    loadTenant();
  }, [currentUser]);

  const handleSwitchRole = async (role: ScolaRole, schoolType: 'SMA' | 'SMK' = 'SMA') => {
    try {
      await authService.switchRole(role, schoolType);
    } catch (err: any) {
      alert(`Gagal berganti role: ${err.message}`);
    }
  };

  return (
    <div className="flex h-screen w-screen overflow-hidden bg-slate-50 font-sans antialiased text-slate-900">
      {/* Sidebar Navigation */}
      <Sidebar
        currentUser={currentUser}
        currentTenant={currentTenant}
        currentRoute={currentRoute}
        onNavigate={onNavigate}
        isOpenMobile={mobileSidebarOpen}
        onCloseMobile={() => setMobileSidebarOpen(false)}
      />

      {/* Main Content Area */}
      <div className="flex flex-1 flex-col overflow-hidden">
        {/* Top Navbar */}
        <Navbar
          currentUser={currentUser}
          currentTenantName={currentTenant?.name}
          viewportMode={viewportMode}
          onViewportChange={onViewportChange}
          onSwitchRole={isSupabaseConfigured() ? undefined : handleSwitchRole}
          onLogout={onLogout}
          onOpenSqlModal={() => setSqlModalOpen(true)}
          onNavigate={onNavigate}
          onToggleMobileSidebar={() => setMobileSidebarOpen(!mobileSidebarOpen)}
        />

        {/* Dynamic Viewport Container (Desktop / Tablet / Mobile) */}
        <DeviceFrame viewportMode={viewportMode}>
          <main className="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8">
            <div className="mx-auto max-w-7xl">{children}</div>
          </main>
        </DeviceFrame>
      </div>

      {/* Supabase SQL DDL Modal */}
      <SupabaseSqlModal isOpen={sqlModalOpen} onClose={() => setSqlModalOpen(false)} />
    </div>
  );
};
