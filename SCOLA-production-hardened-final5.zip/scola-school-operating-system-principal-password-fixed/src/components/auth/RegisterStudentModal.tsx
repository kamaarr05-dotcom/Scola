import React, { useState, useEffect } from 'react';
import { UserPlus, X, Building2, CheckCircle2, ShieldAlert } from 'lucide-react';
import { Tenant, SchoolClass } from '../../types';
import { tenantRepository } from '../../repositories/tenantRepository';
import { academicRepository } from '../../repositories/academicRepository';
import { userRepository } from '../../repositories/userRepository';

interface RegisterStudentModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: (email: string) => void;
}

export const RegisterStudentModal: React.FC<RegisterStudentModalProps> = ({
  isOpen,
  onClose,
  onSuccess,
}) => {
  const [tenants, setTenants] = useState<Tenant[]>([]);
  const [selectedTenantId, setSelectedTenantId] = useState('');
  const [classes, setClasses] = useState<SchoolClass[]>([]);

  const [fullName, setFullName] = useState('');
  const [nisn, setNisn] = useState('');
  const [nis, setNis] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [phone, setPhone] = useState('');
  const [gender, setGender] = useState<'L' | 'P'>('L');
  const [selectedClassId, setSelectedClassId] = useState('');
  const [parentName, setParentName] = useState('');
  const [parentRelation, setParentRelation] = useState<'AYAH' | 'IBU' | 'WALI'>('AYAH');
  const [parentWhatsapp, setParentWhatsapp] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  useEffect(() => {
    async function loadTenants() {
      const list = await tenantRepository.getAll();
      const activeOnly = list.filter((t) => t.is_active);
      setTenants(activeOnly);
      if (activeOnly.length > 0) {
        setSelectedTenantId(activeOnly[0].id);
      }
    }
    if (isOpen) {
      loadTenants();
    }
  }, [isOpen]);

  useEffect(() => {
    async function loadTenantClasses() {
      if (selectedTenantId) {
        const clsList = await academicRepository.getClassesByTenant(selectedTenantId);
        setClasses(clsList);
        if (clsList.length > 0) {
          setSelectedClassId(clsList[0].id);
        } else {
          setSelectedClassId('');
        }
      }
    }
    loadTenantClasses();
  }, [selectedTenantId]);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedTenantId) {
      setErrorMsg('Silakan pilih sekolah tujuan.');
      return;
    }
    if (!selectedClassId) {
      setErrorMsg('Silakan pilih kelas/rombel yang dituju.');
      return;
    }
    if (!/^[0-9]{10}$/.test(nisn.trim())) {
      setErrorMsg('NISN wajib tepat 10 digit angka.');
      return;
    }
    if (!nis.trim()) {
      setErrorMsg('NIS sekolah wajib diisi.');
      return;
    }
    if (password.length < 8) {
      setErrorMsg('Password minimal 8 karakter.');
      return;
    }
    if (password !== confirmPassword) {
      setErrorMsg('Konfirmasi password tidak sama.');
      return;
    }
    setSubmitting(true);
    setErrorMsg(null);

    try {
      const cleanEmail = email.toLowerCase().trim();
      const selectedClass = classes.find((c) => c.id === selectedClassId);
      if (!selectedClass) {
        throw new Error('Kelas/rombel yang dipilih tidak ditemukan.');
      }

      const result = await academicRepository.selfRegisterStudent({
        tenant_id: selectedTenantId,
        full_name: fullName,
        nisn: nis.trim(),
        nis: nis.trim(),
        gender,
        class_id: selectedClassId,
        class_name: selectedClass.name,
        email: cleanEmail,
        password,
        phone: phone || undefined,
        parent_name: parentName.trim(),
        parent_relation: parentRelation,
        parent_whatsapp: parentWhatsapp.trim(),
        generation_year: new Date().getFullYear(),
      });

      onSuccess(result.user.email);
    } catch (err: any) {
      setErrorMsg(err.message || 'Gagal mendaftar akun siswa.');
    } finally {
      setSubmitting(false);
    }
  };

  const selectedTenant = tenants.find((t) => t.id === selectedTenantId);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 p-4 backdrop-blur-xs">
      <div className="flex max-h-[90vh] w-full max-w-lg flex-col rounded-2xl bg-white shadow-2xl overflow-hidden border border-slate-200">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-100 px-6 py-4 bg-slate-50">
          <div className="flex items-center gap-2.5">
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-blue-100 text-blue-700">
              <UserPlus className="h-5 w-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900">Registrasi Mandiri Siswa Baru</h3>
              <p className="text-[11px] text-slate-500">Pendaftaran akun peserta didik terhubung ke sekolah</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="rounded-lg p-1.5 text-slate-400 hover:bg-slate-200/60 hover:text-slate-600"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Error Alert */}
        {errorMsg && (
          <div className="mx-6 mt-4 rounded-xl bg-red-50 p-3 text-xs font-semibold text-red-800 border border-red-200 flex items-center gap-2">
            <ShieldAlert className="h-4 w-4 shrink-0 text-red-600" />
            <span>{errorMsg}</span>
          </div>
        )}

        {/* Form */}
        <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto px-6 py-4 space-y-3.5">
          {/* Tenant Selector */}
          <div>
            <label className="text-xs font-bold text-slate-700">Pilih Sekolah Tujuan</label>
            <select
              value={selectedTenantId}
              onChange={(e) => setSelectedTenantId(e.target.value)}
              className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-xs font-medium text-slate-900 focus:border-blue-500 focus:outline-hidden"
              required
            >
              {tenants.map((t) => (
                <option key={t.id} value={t.id}>
                  {t.name} ({t.type} - NPSN: {t.npsn})
                </option>
              ))}
            </select>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="text-xs font-bold text-slate-700">Nama Lengkap Siswa</label>
              <input
                type="text"
                required
                placeholder="Muhammad Dimas"
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-xs focus:border-blue-500 focus:outline-hidden"
              />
            </div>
            <div>
              <label className="text-xs font-bold text-slate-700">NIS Sekolah</label>
              <input
                type="text"
                required
                placeholder="NIS00123"
                value={nis}
                onChange={(e) => setNis(e.target.value)}
                className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-xs focus:border-blue-500 focus:outline-hidden font-mono"
              />
            </div>
            <div>
              <label className="text-xs font-bold text-slate-700">NISN (10 Digit Angka)</label>
              <input
                type="text"
                required
                maxLength={10}
                placeholder="0081234567"
                value={nisn}
                onChange={(e) => setNisn(e.target.value)}
                className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-xs focus:border-blue-500 focus:outline-hidden font-mono"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="text-xs font-bold text-slate-700">Email Akun</label>
              <input
                type="email"
                required
                placeholder="dimas@student.sch.id"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-xs focus:border-blue-500 focus:outline-hidden"
              />
            </div>
            <div>
              <label className="text-xs font-bold text-slate-700">No. Handphone Siswa</label>
              <input
                type="tel"
                placeholder="08123456789"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-xs focus:border-blue-500 focus:outline-hidden"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="text-xs font-bold text-slate-700">Password Akun</label>
              <input
                type="password"
                required
                minLength={8}
                placeholder="Minimal 8 karakter"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-xs focus:border-blue-500 focus:outline-hidden"
              />
            </div>
            <div>
              <label className="text-xs font-bold text-slate-700">Konfirmasi Password</label>
              <input
                type="password"
                required
                minLength={8}
                placeholder="Ulangi password"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-xs focus:border-blue-500 focus:outline-hidden"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="text-xs font-bold text-slate-700">Jenis Kelamin</label>
              <select
                value={gender}
                onChange={(e) => setGender(e.target.value as 'L' | 'P')}
                className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-xs focus:border-blue-500 focus:outline-hidden"
              >
                <option value="L">Laki-laki</option>
                <option value="P">Perempuan</option>
              </select>
            </div>
            <div>
              <label className="text-xs font-bold text-slate-700">Rombel / Kelas Masuk</label>
              <select
                value={selectedClassId}
                onChange={(e) => setSelectedClassId(e.target.value)}
                className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-xs focus:border-blue-500 focus:outline-hidden"
              >
                {classes.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name} ({c.grade_level} - {c.major_or_stream})
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Parent Information */}
          <div className="border-t border-slate-100 pt-3">
            <span className="text-xs font-bold text-slate-900 block mb-2">
              Data Orang Tua / Wali Murid (Wajib untuk Verifikasi Rapor)
            </span>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="text-xs font-medium text-slate-600">Nama Orang Tua / Wali</label>
                <input
                  type="text"
                  required
                  placeholder="Bambang Wijaya"
                  value={parentName}
                  onChange={(e) => setParentName(e.target.value)}
                  className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-xs focus:border-blue-500 focus:outline-hidden"
                />
              </div>
              <div>
                <label className="text-xs font-medium text-slate-600">Hubungan</label>
                <select
                  value={parentRelation}
                  onChange={(e) => setParentRelation(e.target.value as 'AYAH' | 'IBU' | 'WALI')}
                  className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-xs focus:border-blue-500 focus:outline-hidden"
                >
                  <option value="AYAH">Ayah</option>
                  <option value="IBU">Ibu</option>
                  <option value="WALI">Wali</option>
                </select>
              </div>
              <div>
                <label className="text-xs font-medium text-slate-600">No. WhatsApp Orang Tua</label>
                <input
                  type="tel"
                  required
                  placeholder="081298765432"
                  value={parentWhatsapp}
                  onChange={(e) => setParentWhatsapp(e.target.value)}
                  className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-xs focus:border-blue-500 focus:outline-hidden"
                />
              </div>
            </div>
          </div>

          <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
            <button
              type="button"
              onClick={onClose}
              className="rounded-xl border border-slate-200 bg-white px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-50"
            >
              Batal
            </button>
            <button
              type="submit"
              disabled={submitting}
              className="rounded-xl bg-blue-700 hover:bg-blue-800 px-5 py-2 text-xs font-bold text-white shadow-xs"
            >
              {submitting ? 'Mendaftarkan...' : 'Selesaikan Pendaftaran'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
