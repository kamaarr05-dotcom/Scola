import React, { useState } from 'react';
import {
  GraduationCap,
  ShieldCheck,
  Lock,
  Mail,
  ArrowRight,
  UserPlus,
  CheckCircle2,
  Database,
  Sparkles,
} from 'lucide-react';
import { authService } from '../../services/authService';
import { UserRole } from '../../types';
import { RegisterStudentModal } from './RegisterStudentModal';
import { SupabaseSqlModal } from '../common/SupabaseSqlModal';
import { isSupabaseConfigured } from '../../config/supabase';

interface LoginViewProps {
  onLoginSuccess: () => void;
}

export const LoginView: React.FC<LoginViewProps> = ({ onLoginSuccess }) => {
  const [email, setEmail] = useState(() => isSupabaseConfigured() ? '' : 'kepsek@sman1nusantara.sch.id');
  const [password, setPassword] = useState(() => isSupabaseConfigured() ? '' : 'password123');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [registerModalOpen, setRegisterModalOpen] = useState(false);
  const [sqlModalOpen, setSqlModalOpen] = useState(false);
  const [registeredNotice, setRegisteredNotice] = useState<string | null>(null);
  const [activeCategory, setActiveCategory] = useState<'ALL' | 'PIMPINAN' | 'GURU' | 'KOMUNITAS'>('ALL');

  const demoAccounts = authService.getMockCredentials();

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);
    try {
      await authService.login(email, password);
      onLoginSuccess();
    } catch (err: any) {
      setError(err.message || 'Gagal masuk. Periksa kembali email dan kata sandi.');
    } finally {
      setLoading(false);
    }
  };

  const handleDirectDemoLogin = async (targetEmail: string) => {
    setEmail(targetEmail);
    setLoading(true);
    setError(null);
    try {
      await authService.login(targetEmail, 'password123');
      onLoginSuccess();
    } catch (err: any) {
      setError(err.message || 'Gagal login demo persona.');
    } finally {
      setLoading(false);
    }
  };

  const filteredDemos = activeCategory === 'ALL'
    ? demoAccounts
    : demoAccounts.filter((d) => d.category === activeCategory);

  return (
    <div className="min-h-screen bg-slate-950 flex flex-col justify-center py-12 sm:px-6 lg:px-8 text-slate-100">
      <div className="sm:mx-auto sm:w-full sm:max-w-xl text-center">
        {/* Logo and Brand */}
        <div className="inline-flex items-center justify-center p-3.5 rounded-2xl bg-gradient-to-tr from-blue-700 to-indigo-600 shadow-xl shadow-blue-500/20 mb-3 border border-blue-400/30">
          <GraduationCap className="h-8 w-8 text-white" />
        </div>
        <h2 className="text-3xl font-extrabold tracking-tight text-white">SCOLA OS</h2>
        <p className="mt-1 text-xs text-slate-400 font-medium max-w-md mx-auto">
          Next-Generation School Operating System • Manajemen Terpadu SMA & SMK Indonesia
        </p>
      </div>

      <div className="mt-7 sm:mx-auto sm:w-full sm:max-w-xl px-4 sm:px-0">
        <div className="bg-slate-900/90 backdrop-blur-md border border-slate-800 p-6 sm:p-8 shadow-2xl rounded-3xl space-y-6">
          {registeredNotice && (
            <div className="rounded-xl bg-emerald-500/10 border border-emerald-500/30 p-3 text-xs text-emerald-300 flex items-center gap-2">
              <CheckCircle2 className="h-4 w-4 shrink-0 text-emerald-400" />
              <span>{registeredNotice}</span>
            </div>
          )}

          {error && (
            <div className="rounded-xl bg-red-500/10 border border-red-500/30 p-3 text-xs text-red-300">
              {error}
            </div>
          )}

          <form onSubmit={handleLogin} className="space-y-3.5">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Alamat Email Akun
              </label>
              <div className="relative">
                <Mail className="absolute left-3 top-2.5 h-4 w-4 text-slate-500" />
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="nama@sekolah.sch.id"
                  className="w-full rounded-xl bg-slate-800 border border-slate-700 pl-9 pr-3 py-2.5 text-xs text-white placeholder:text-slate-500 focus:border-blue-500 focus:outline-hidden"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Kata Sandi
              </label>
              <div className="relative">
                <Lock className="absolute left-3 top-2.5 h-4 w-4 text-slate-500" />
                <input
                  type="password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full rounded-xl bg-slate-800 border border-slate-700 pl-9 pr-3 py-2.5 text-xs text-white placeholder:text-slate-500 focus:border-blue-500 focus:outline-hidden"
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full flex items-center justify-center gap-2 rounded-xl bg-blue-600 hover:bg-blue-500 py-2.5 text-xs font-bold text-white shadow-lg shadow-blue-600/30 transition-all disabled:opacity-50"
            >
              <span>{loading ? 'Memverifikasi...' : 'Masuk ke Sistem'}</span>
              <ArrowRight className="h-4 w-4" />
            </button>
          </form>

          {/* Categorized Demo Switcher without Master */}
          <div className="pt-4 border-t border-slate-800 space-y-3">
            <div className="flex items-center justify-between">
              <div>
                <span className="text-xs font-bold text-slate-200">
                  Uji Coba Demo Akun Berdasarkan Hak Akses (Permission):
                </span>
                <p className="text-[10px] text-slate-400 mt-0.5">
                  Klik persona untuk langsung masuk dan mengecek dashboard spesifik
                </p>
              </div>
              <span className="rounded-full bg-blue-500/10 border border-blue-500/30 px-2 py-0.5 text-[10px] font-semibold text-blue-400 shrink-0">
                1-Click Login
              </span>
            </div>

            {/* Category Filter Pills */}
            <div className="flex gap-1.5 overflow-x-auto pb-1 text-[11px]">
              {(['ALL', 'PIMPINAN', 'GURU', 'KOMUNITAS'] as const).map((cat) => (
                <button
                  key={cat}
                  type="button"
                  onClick={() => setActiveCategory(cat)}
                  className={`px-2.5 py-1 rounded-lg font-medium transition-colors shrink-0 ${
                    activeCategory === cat
                      ? 'bg-blue-600 text-white shadow-sm'
                      : 'bg-slate-800 text-slate-400 hover:text-slate-200 hover:bg-slate-700'
                  }`}
                >
                  {cat === 'ALL' ? 'Semua Role' : cat === 'PIMPINAN' ? 'Pimpinan & Wakasek' : cat === 'GURU' ? 'Guru & Wali Kelas' : 'Staf, Siswa & Ortu'}
                </button>
              ))}
            </div>

            {/* Demo Accounts Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 max-h-56 overflow-y-auto pr-1">
              {filteredDemos.map((demo) => (
                <button
                  key={demo.email}
                  type="button"
                  disabled={loading}
                  onClick={() => handleDirectDemoLogin(demo.email)}
                  className="rounded-xl border border-slate-800/80 bg-slate-800/40 hover:bg-slate-800/90 hover:border-blue-500/40 p-2.5 text-left transition-all group"
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-slate-200 group-hover:text-blue-400 transition-colors">
                      {demo.label}
                    </span>
                    <span className="text-[9px] px-1.5 py-0.2 rounded bg-slate-700/60 text-slate-300 font-mono">
                      {demo.category}
                    </span>
                  </div>
                  <div className="text-[10px] text-blue-400/90 truncate font-mono mt-0.5">
                    {demo.email}
                  </div>
                  <div className="text-[10px] text-slate-400 line-clamp-1 mt-1 leading-tight">
                    {demo.description}
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Self Register & Supabase Modal Trigger */}
          <div className="flex flex-col sm:flex-row items-center justify-between gap-2 pt-3 border-t border-slate-800 text-center">
            <button
              type="button"
              onClick={() => setRegisterModalOpen(true)}
              className="flex items-center justify-center gap-1.5 text-xs text-blue-400 hover:text-blue-300 font-semibold"
            >
              <UserPlus className="h-4 w-4" />
              <span>Pendaftaran Mandiri Siswa Baru</span>
            </button>

            <button
              type="button"
              onClick={() => setSqlModalOpen(true)}
              className="flex items-center justify-center gap-1.5 text-xs text-slate-400 hover:text-slate-300"
            >
              <Database className="h-3.5 w-3.5" />
              <span>Skema DDL & RLS Supabase</span>
            </button>
          </div>
        </div>
      </div>

      {/* Modals */}
      <RegisterStudentModal
        isOpen={registerModalOpen}
        onClose={() => setRegisterModalOpen(false)}
        onSuccess={(registeredEmail) => {
          setRegisterModalOpen(false);
          setEmail(registeredEmail);
          setRegisteredNotice(
            `Pendaftaran ${registeredEmail} berhasil diterima dan sedang menunggu persetujuan Wali Kelas. Akun belum dapat digunakan untuk login.`
          );
        }}
      />

      <SupabaseSqlModal
        isOpen={sqlModalOpen}
        onClose={() => setSqlModalOpen(false)}
      />
    </div>
  );
};
