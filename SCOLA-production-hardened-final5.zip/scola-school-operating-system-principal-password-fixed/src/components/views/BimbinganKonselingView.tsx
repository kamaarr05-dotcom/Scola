import React, { useState } from 'react';
import {
  HeartHandshake,
  ShieldCheck,
  AlertTriangle,
  UserCheck,
  Plus,
  Calendar,
  Lock,
} from 'lucide-react';
import { UserProfile } from '../../types';

interface BimbinganKonselingViewProps {
  currentUser: UserProfile;
}

export const BimbinganKonselingView: React.FC<BimbinganKonselingViewProps> = ({ currentUser }) => {
  const [activeTab, setActiveTab] = useState<'KONSELING' | 'KERAWANAN' | 'KARIR'>('KONSELING');

  return (
    <div className="space-y-6">
      {/* Banner */}
      <div className="rounded-2xl bg-gradient-to-r from-purple-950 via-indigo-950 to-slate-900 p-6 text-white shadow-xl">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-2 rounded-full bg-purple-500/20 px-3 py-1 text-xs font-semibold text-purple-300 border border-purple-400/30">
              <HeartHandshake className="h-3.5 w-3.5" />
              <span>Unit Bimbingan & Konseling (BK)</span>
            </div>
            <h1 className="mt-2 text-2xl font-extrabold tracking-tight sm:text-3xl">
              Layanan Konseling Siswa & Pengembangan Karir
            </h1>
            <p className="mt-1 text-xs sm:text-sm text-slate-300">
              Pendampingan psikososial, pencegahan perundungan (anti-bullying), dan penelusuran potensi diri peserta didik.
            </p>
          </div>

          <div className="flex items-center gap-2 text-xs bg-white/10 px-3 py-2 rounded-xl border border-white/20">
            <Lock className="h-4 w-4 text-emerald-400" />
            <span>Kerahasiaan Data Konseling Terlindungi</span>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-200 pb-2">
        <button
          onClick={() => setActiveTab('KONSELING')}
          className={`flex items-center gap-2 rounded-xl px-4 py-2 text-xs font-semibold transition-all ${
            activeTab === 'KONSELING'
              ? 'bg-purple-50 text-purple-800 shadow-2xs'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <HeartHandshake className="h-4 w-4" />
          <span>Sesi Konseling Aktif</span>
        </button>
        <button
          onClick={() => setActiveTab('KERAWANAN')}
          className={`flex items-center gap-2 rounded-xl px-4 py-2 text-xs font-semibold transition-all ${
            activeTab === 'KERAWANAN'
              ? 'bg-purple-50 text-purple-800 shadow-2xs'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <AlertTriangle className="h-4 w-4" />
          <span>Peta Kerawanan Siswa</span>
        </button>
        <button
          onClick={() => setActiveTab('KARIR')}
          className={`flex items-center gap-2 rounded-xl px-4 py-2 text-xs font-semibold transition-all ${
            activeTab === 'KARIR'
              ? 'bg-purple-50 text-purple-800 shadow-2xs'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <UserCheck className="h-4 w-4" />
          <span>Bimbingan Karir & Minat</span>
        </button>
      </div>

      {/* ================= TAB 1: KONSELING ================= */}
      {activeTab === 'KONSELING' && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-xs">
              <div className="flex items-center justify-between">
                <span className="rounded-md bg-purple-100 px-2 py-0.5 text-xs font-bold text-purple-800">
                  Konseling Belajar
                </span>
                <span className="text-xs text-slate-400">14 September 2024</span>
              </div>
              <h4 className="mt-2 text-base font-bold text-slate-900">Konseling Manajemen Waktu Belajar</h4>
              <p className="mt-1 text-xs text-slate-500">
                Siswa kelas X mengalami kelelahan akibat kegiatan ekskul padat. Diberikan panduan time-blocking dan jadwal istirahat seimbang.
              </p>
              <div className="mt-4 text-xs font-semibold text-purple-700">
                Konselor: Guru Bimbingan Konseling
              </div>
            </div>

            <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-xs">
              <div className="flex items-center justify-between">
                <span className="rounded-md bg-emerald-100 px-2 py-0.5 text-xs font-bold text-emerald-800">
                  Konseling Karir
                </span>
                <span className="text-xs text-slate-400">11 September 2024</span>
              </div>
              <h4 className="mt-2 text-base font-bold text-slate-900">Pemilihan Program Studi SNMPTN/SNBP</h4>
              <p className="mt-1 text-xs text-slate-500">
                Analisis transkrip nilai semester 1-4 dan minat vokasi teknik informatika vs ilmu komputer murni.
              </p>
              <div className="mt-4 text-xs font-semibold text-purple-700">
                Konselor: Guru Bimbingan Konseling
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ================= TAB 2: KERAWANAN ================= */}
      {activeTab === 'KERAWANAN' && (
        <div className="space-y-4">
          <h3 className="text-sm font-bold text-slate-900">Peta Deteksi Dini Kerawanan Belajar Siswa</h3>
          <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-xs text-xs text-slate-600 space-y-3">
            <div className="flex items-center gap-2 text-amber-700 font-bold">
              <AlertTriangle className="h-4 w-4" />
              <span>Indikator Otomatis Sistem:</span>
            </div>
            <p>
              Sistem SCOLA secara cerdas memantau ketidakhadiran beruntun (3x tanpa keterangan) atau penurunan nilai drastis untuk memicu notifikasi awal ke Guru BK dan Wali Kelas sebelum masalah membesar.
            </p>
          </div>
        </div>
      )}

      {/* ================= TAB 3: KARIR ================= */}
      {activeTab === 'KARIR' && (
        <div className="space-y-4">
          <h3 className="text-sm font-bold text-slate-900">Bimbingan Karir & Asesmen Psikotes Bakat</h3>
          <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-xs text-xs text-slate-600">
            Jadwal Tes Minat Bakat (MBTI & Holland RIASEC) untuk seluruh siswa kelas X direncanakan pada awal semester genap.
          </div>
        </div>
      )}
    </div>
  );
};
