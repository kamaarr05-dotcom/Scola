import React, { useEffect, useMemo, useState } from 'react';
import {
  Award,
  BookOpen,
  Calendar,
  Clock,
  HeartHandshake,
  MessageCircle,
  ShieldCheck,
  UserCheck,
} from 'lucide-react';
import { UserProfile, StudentProfile, GradeRecord, DailyAttendance, AcademicTask, TaskSubmission, StudentGuardian } from '../../types';
import { academicRepository } from '../../repositories/academicRepository';

interface Props { currentUser: UserProfile; }
type Tab = 'OVERVIEW' | 'GRADES' | 'ATTENDANCE' | 'TASKS';

export const OrangTuaDashboardView: React.FC<Props> = ({ currentUser }) => {
  const tenantId = currentUser.tenant_id;
  const [children, setChildren] = useState<StudentProfile[]>([]);
  const [guardians, setGuardians] = useState<StudentGuardian[]>([]);
  const [selectedId, setSelectedId] = useState('');
  const [grades, setGrades] = useState<GradeRecord[]>([]);
  const [attendances, setAttendances] = useState<DailyAttendance[]>([]);
  const [tasks, setTasks] = useState<AcademicTask[]>([]);
  const [submissions, setSubmissions] = useState<TaskSubmission[]>([]);
  const [activeTab, setActiveTab] = useState<Tab>('OVERVIEW');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;
    async function load() {
      if (!tenantId) return;
      setLoading(true);
      try {
        const [relations, allChildren] = await Promise.all([
          academicRepository.getStudentGuardians(tenantId, currentUser),
          academicRepository.getStudentsByTenant(tenantId, currentUser),
        ]);
        if (cancelled) return;
        setGuardians(relations);
        const relationIds = [...new Set(relations.map((r) => r.student_id))];
        const merged = relationIds.map((id) => allChildren.find((s) => s.id === id)).filter(Boolean) as StudentProfile[];
        // Demo accounts may contain linked_students even when a student row is not present locally.
        const summaries = currentUser.linked_students || [];
        const fallbackChildren = summaries.map((s) => ({
          id: s.id, tenant_id: tenantId, user_id: s.id, nisn: s.nisn, nis: s.nis || '-', full_name: s.full_name,
          gender: 'L' as const, class_id: s.class_id || '', class_name: s.class_name, school_type: s.school_type,
          generation_year: new Date().getFullYear(), status: 'ACTIVE' as const, self_registered: false,
          registration_date: '', tenant_name: s.tenant_name,
        }));
        const byId = new Map([...merged, ...fallbackChildren].map((s) => [s.id, s]));
        const result = [...byId.values()];
        setChildren(result);
        setSelectedId((prev) => prev && byId.has(prev) ? prev : result[0]?.id || '');
      } finally {
        if (!cancelled) setLoading(false);
      }
    }
    load();
    return () => { cancelled = true; };
  }, [tenantId, currentUser]);

  useEffect(() => {
    let cancelled = false;
    async function loadChildData() {
      if (!tenantId || !selectedId) return;
      const [g, a, t] = await Promise.all([
        academicRepository.getGrades(tenantId, currentUser, { student_id: selectedId }),
        academicRepository.getAttendance(tenantId, currentUser, { student_id: selectedId }),
        academicRepository.getTasks(tenantId, currentUser, { student_id: selectedId }),
      ]);
      const taskSubmissions = await Promise.all(t.map((task) => academicRepository.getSubmissions(task.id, currentUser)));
      if (!cancelled) {
        setGrades(g);
        setAttendances(a);
        setTasks(t);
        setSubmissions(taskSubmissions.flat());
      }
    }
    loadChildData();
    return () => { cancelled = true; };
  }, [tenantId, selectedId, currentUser]);

  const child = children.find((c) => c.id === selectedId) || children[0];
  const relation = guardians.find((g) => g.student_id === child?.id);
  const totalAttendance = attendances.length;
  const present = attendances.filter((a) => a.status === 'HADIR').length;
  const sick = attendances.filter((a) => a.status === 'SAKIT').length;
  const permit = attendances.filter((a) => a.status === 'IZIN').length;
  const absent = attendances.filter((a) => a.status === 'ALPA').length;
  const attendanceRate = totalAttendance ? Math.round((present / totalAttendance) * 100) : 0;
  const average = grades.length ? (grades.reduce((sum, g) => sum + Number(g.score || 0), 0) / grades.length).toFixed(1) : '—';
  const submittedIds = useMemo(() => new Set(submissions.map((s) => s.task_id)), [submissions]);
  const pendingTasks = tasks.filter((t) => !submittedIds.has(t.id));
  const waliPhone = relation?.guardian_whatsapp || child?.parent_whatsapp || '';
  const contactPhone = child?.id ? (child.parent_whatsapp || waliPhone) : waliPhone;

  const tabs: Array<[Tab, React.ReactNode, React.ReactNode]> = [
    ['OVERVIEW', <BookOpen className="h-4 w-4" />, 'Ringkasan'],
    ['GRADES', <Award className="h-4 w-4" />, 'Nilai & e-Rapor'],
    ['ATTENDANCE', <UserCheck className="h-4 w-4" />, 'Presensi'],
    ['TASKS', <Calendar className="h-4 w-4" />, 'Tugas'],
  ];

  return (
    <div className="space-y-6">
      <div className="rounded-2xl bg-gradient-to-r from-blue-900 via-indigo-900 to-slate-900 p-6 text-white shadow-xl">
        <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
          <div>
            <div className="inline-flex items-center gap-2 rounded-full border border-blue-400/30 bg-blue-500/20 px-3 py-1 text-xs font-semibold text-blue-300">
              <HeartHandshake className="h-3.5 w-3.5" /> Portal Orang Tua / Wali Murid
            </div>
            <h1 className="mt-2 text-2xl font-extrabold sm:text-3xl">Pantauan Akademik {child?.full_name || currentUser.full_name}</h1>
            <p className="mt-1 text-xs text-slate-300 sm:text-sm">{child?.nisn || '-'} • {child?.class_name || '-'} • {child?.tenant_name || 'Sekolah'}</p>
          </div>
          {children.length > 1 && (
            <select value={selectedId} onChange={(e) => setSelectedId(e.target.value)} className="rounded-xl border border-white/20 bg-white/10 px-3 py-2 text-xs font-semibold text-white outline-none">
              {children.map((c) => <option className="text-slate-900" key={c.id} value={c.id}>{c.full_name} — {c.class_name}</option>)}
            </select>
          )}
        </div>
      </div>

      {loading ? <div className="rounded-2xl border border-slate-200 bg-white p-8 text-center text-sm text-slate-500">Memuat data anak...</div> : children.length === 0 ? (
        <div className="rounded-2xl border border-amber-200 bg-amber-50 p-6 text-sm text-amber-800">Belum ada siswa yang terhubung ke akun orang tua ini.</div>
      ) : <>
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
          <Kpi icon={<UserCheck className="h-4 w-4" />} label="Kehadiran Semester" value={`${attendanceRate}%`} detail={`${present} hadir • ${sick} sakit • ${permit} izin • ${absent} alpa`} />
          <Kpi icon={<Award className="h-4 w-4" />} label="Rata-Rata Nilai" value={average} detail={`${grades.length} catatan penilaian tersedia`} />
          <Kpi icon={<Clock className="h-4 w-4" />} label="Tugas Belum Dikumpulkan" value={String(pendingTasks.length)} detail={pendingTasks[0]?.title || 'Semua tugas sudah terkumpul'} />
        </div>

        <div className="flex gap-2 overflow-x-auto border-b border-slate-200 pb-2">
          {tabs.map(([id, icon, label]) => <button key={id} onClick={() => setActiveTab(id)} className={`flex shrink-0 items-center gap-2 rounded-xl px-4 py-2 text-xs font-semibold ${activeTab === id ? 'bg-blue-50 text-blue-700' : 'text-slate-600 hover:bg-slate-50'}`}>{icon}{label}</button>)}
        </div>

        {activeTab === 'OVERVIEW' && <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
          <section className="rounded-2xl border border-slate-200 bg-white p-5 shadow-xs"><h3 className="font-bold text-slate-900">Profil Anak</h3><div className="mt-4 space-y-2 text-xs text-slate-600"><p><b>Nama:</b> {child.full_name}</p><p><b>NISN:</b> {child.nisn}</p><p><b>Kelas:</b> {child.class_name || '-'}</p><p><b>Status:</b> {child.status}</p><p><b>Hubungan wali:</b> {relation?.relation_type || child.parent_relation || '-'}</p></div></section>
          <section className="rounded-2xl border border-slate-200 bg-white p-5 shadow-xs"><h3 className="font-bold text-slate-900">Wali Kelas & Komunikasi</h3><div className="mt-4 flex items-center justify-between gap-3"><div><p className="text-sm font-bold text-slate-900">Wali Kelas</p><p className="text-xs text-slate-500">{relation?.activated_by_name || 'Wali Kelas aktif'}</p></div>{contactPhone && <a href={`https://wa.me/62${contactPhone.replace(/^0/, '')}`} target="_blank" rel="noreferrer" className="inline-flex items-center gap-2 rounded-xl bg-emerald-600 px-3 py-2 text-xs font-bold text-white"><MessageCircle className="h-4 w-4" /> WhatsApp</a>}</div><div className="mt-5 rounded-xl bg-slate-50 p-3 text-xs text-slate-600"><ShieldCheck className="mr-2 inline h-4 w-4 text-emerald-600" />Data yang ditampilkan dibatasi pada anak yang terhubung dengan akun ini.</div></section>
        </div>}

        {activeTab === 'GRADES' && <DataTable title="Nilai Akademik" headers={['Mata Pelajaran','Asesmen','Nilai','Capaian']} rows={grades.map((g) => [g.subject_name, g.assessment_type, String(g.score), g.competency_achievement || '-'])} empty="Belum ada nilai." />}
        {activeTab === 'ATTENDANCE' && <DataTable title="Riwayat Presensi" headers={['Tanggal','Jam','Status','Pencatat','Keterangan']} rows={attendances.map((a) => [a.date, `Jam ${a.period_number}`, a.status, a.recorded_by_name || '-', a.notes || '-'])} empty="Belum ada riwayat presensi." />}
        {activeTab === 'TASKS' && <div className="space-y-3">{tasks.length ? tasks.map((task) => { const sub = submissions.find((s) => s.task_id === task.id); return <div key={task.id} className="rounded-2xl border border-slate-200 bg-white p-4 shadow-xs"><div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between"><div><h3 className="text-sm font-bold text-slate-900">{task.title}</h3><p className="mt-1 text-xs text-slate-500">{task.subject_name} • Batas {new Date(task.due_date).toLocaleString('id-ID')}</p></div><span className={`rounded-full px-3 py-1 text-[10px] font-bold ${sub ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'}`}>{sub ? (sub.status === 'GRADED' ? `DINILAI ${sub.score ?? ''}` : 'TERKUMPUL') : 'BELUM DIKUMPULKAN'}</span></div></div>}) : <div className="rounded-2xl border border-slate-200 bg-white p-6 text-center text-xs text-slate-500">Belum ada tugas.</div>}</div>}
      </>}
    </div>
  );
};

const Kpi: React.FC<{icon: React.ReactNode; label:string; value:string; detail:string}> = ({icon,label,value,detail}) => <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-xs"><div className="flex items-center justify-between text-slate-500"><span className="text-xs font-semibold uppercase">{label}</span>{icon}</div><div className="mt-3 text-3xl font-extrabold text-slate-900">{value}</div><p className="mt-2 text-[11px] text-slate-500">{detail}</p></div>;

const DataTable: React.FC<{title:string; headers:string[]; rows:string[][]; empty:string}> = ({title,headers,rows,empty}) => <section className="space-y-3"><h3 className="text-sm font-bold text-slate-900">{title}</h3><div className="overflow-x-auto rounded-2xl border border-slate-200 bg-white shadow-xs">{rows.length ? <table className="w-full text-left text-xs text-slate-600"><thead className="border-b border-slate-200 bg-slate-50 text-[10px] font-bold uppercase text-slate-500"><tr>{headers.map((h) => <th key={h} className="px-4 py-3">{h}</th>)}</tr></thead><tbody className="divide-y divide-slate-100">{rows.map((row,i) => <tr key={i}>{row.map((cell,j) => <td key={j} className={`px-4 py-3 ${j===0?'font-semibold text-slate-900':''}`}>{cell}</td>)}</tr>)}</tbody></table> : <div className="p-6 text-center text-xs text-slate-500">{empty}</div>}</div></section>;
