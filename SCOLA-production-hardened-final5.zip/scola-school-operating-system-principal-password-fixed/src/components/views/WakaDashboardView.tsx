import React, { useState, useEffect } from 'react';
import {
  ShieldCheck,
  BookOpen,
  Users,
  Building,
  HeartHandshake,
  CheckCircle2,
  Clock,
  Calendar,
  AlertCircle,
  Award,
  Wrench,
  Briefcase,
  Layers,
  Sparkles,
  School,
} from 'lucide-react';
import { UserProfile } from '../../types';
import { academicRepository } from '../../repositories/academicRepository';
import { WakaKurikulumTab } from '../waka/WakaKurikulumTab';
import { WakaKesiswaanTab } from '../waka/WakaKesiswaanTab';
import { WakaSarprasTab } from '../waka/WakaSarprasTab';
import { WakaHumasTab } from '../waka/WakaHumasTab';

interface WakaDashboardViewProps {
  currentUser: UserProfile;
}

export const WakaDashboardView: React.FC<WakaDashboardViewProps> = ({ currentUser }) => {
  const tenantId = currentUser?.tenant_id || 'tenant-sma-01';

  // Check user assignments
  const isWakaKurikulum = currentUser?.assignments?.some((a) => a.type === 'WAKA_KURIKULUM' && a.active);
  const isWakaKesiswaan = currentUser?.assignments?.some((a) => a.type === 'WAKA_KESISWAAN' && a.active);
  const isWakaSarpras = currentUser?.assignments?.some((a) => a.type === 'WAKA_SARPRAS' && a.active);
  const isWakaHumas = currentUser?.assignments?.some((a) => a.type === 'WAKA_HUMAS' && a.active);
  const isKepsekOrMaster = currentUser?.role === 'KEPALA_SEKOLAH' || currentUser?.role === 'MASTER';

  // Default active tab based on user's assignment
  const initialTab = isWakaKurikulum
    ? 'KURIKULUM'
    : isWakaKesiswaan
    ? 'KESISWAAN'
    : isWakaSarpras
    ? 'SARPRAS'
    : isWakaHumas
    ? 'HUMAS'
    : 'KURIKULUM';

  const [activeTab, setActiveTab] = useState<'KURIKULUM' | 'KESISWAAN' | 'SARPRAS' | 'HUMAS'>(initialTab);

  // Global KPI stats for top summary
  const [stats, setStats] = useState({
    invalActive: 0,
    invalTotal: 0,
    disciplineCases: 0,
    attendanceRate: 0,
    activeTickets: 0,
    mouActive: 0,
    internshipQuota: 0,
  });

  useEffect(() => {
    const loadOverview = async () => {
      try {
        const [invals, disciplines, attendances, tickets, mous] = await Promise.all([
          academicRepository.getInvalAssignments(tenantId),
          academicRepository.getDisciplineRecords(tenantId),
          academicRepository.getAttendanceByTenant(tenantId, currentUser),
          academicRepository.getMaintenanceTickets(tenantId),
          academicRepository.getIndustryMoUs(tenantId),
        ]);

        const invalActive = invals.filter((i) => i.status === 'IN_PROGRESS').length;
        const activeTickets = tickets.filter((t) => t.status === 'DALAM_PENGERJAAN').length;
        const mouActive = mous.filter((m) => m.status === 'AKTIF').length;
        const internshipQuota = mous.reduce((acc, m) => acc + (m.pkl_quota || 0), 0);

        const totalAtt = attendances.length;
        const hadirCount = attendances.filter((a) => a.status === 'HADIR').length;
        const attRate = totalAtt > 0 ? Math.round((hadirCount / totalAtt) * 100) : 0;

        setStats({
          invalActive,
          invalTotal: invals.length,
          disciplineCases: disciplines.length,
          attendanceRate: attRate,
          activeTickets,
          mouActive,
          internshipQuota,
        });
      } catch (err) {
        console.error('Error loading waka overview:', err);
      }
    };
    loadOverview();
  }, [tenantId]);

  return (
    <div className="space-y-6">
      {/* Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-slate-900 via-indigo-950 to-blue-950 p-6 sm:p-8 text-white shadow-xl">
        <div className="relative z-10 flex flex-col md:flex-row md:items-center md:justify-between gap-6">
          <div>
            <div className="inline-flex items-center gap-2 rounded-full bg-blue-500/20 px-3 py-1 text-xs font-semibold text-blue-300 border border-blue-400/30">
              <ShieldCheck className="h-4 w-4" />
              <span>Portal Manajemen Wakil Kepala Sekolah (Waka)</span>
            </div>
            <h1 className="mt-3 text-2xl font-black tracking-tight sm:text-3xl lg:text-4xl text-white">
              Pusat Kendali Operasional Sekolah
            </h1>
            <p className="mt-1.5 max-w-2xl text-xs sm:text-sm text-slate-300">
              Sistem terintegrasi untuk Waka Kurikulum (Inval & KBM), Kesiswaan (Buku Saku Disiplin & Prestasi), Sarpras
              (Tiket Kerusakan & Aset), dan Humas (MoU Kemitraan Industri & Komite).
            </p>

            <div className="mt-4 flex flex-wrap items-center gap-2 text-xs">
              <span className="rounded-xl bg-white/10 px-3 py-1.5 font-semibold text-blue-200 border border-white/10 flex items-center gap-1.5">
                <School className="h-3.5 w-3.5" />
                {tenantId === 'tenant-smk-02' ? 'SMK Teknologi Unggul' : 'SMA Negeri 1 Nusantara'}
              </span>
              <span className="rounded-xl bg-white/10 px-3 py-1.5 font-medium text-slate-300 border border-white/10">
                Pengguna: <strong>{currentUser.full_name}</strong>
              </span>
              <span className="rounded-xl bg-emerald-500/20 px-3 py-1.5 font-bold text-emerald-300 border border-emerald-400/30">
                {isKepsekOrMaster
                  ? 'Otoritas Penuh Seluruh Bidang'
                  : isWakaKurikulum
                  ? 'Waka Kurikulum'
                  : isWakaKesiswaan
                  ? 'Waka Kesiswaan'
                  : isWakaSarpras
                  ? 'Waka Sarpras'
                  : isWakaHumas
                  ? 'Waka Humas'
                  : 'Wakil Kepala Sekolah'}
              </span>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row gap-3">
            <div className="rounded-2xl bg-white/10 p-4 backdrop-blur-xs border border-white/15 min-w-[150px]">
              <div className="text-[11px] font-semibold text-blue-200 uppercase tracking-wider">Inval Hari Ini</div>
              <div className="mt-1 text-2xl font-black text-white">{stats.invalActive} Aktif</div>
              <div className="text-[10px] text-slate-400">Dari {stats.invalTotal} total penugasan</div>
            </div>
            <div className="rounded-2xl bg-white/10 p-4 backdrop-blur-xs border border-white/15 min-w-[150px]">
              <div className="text-[11px] font-semibold text-blue-200 uppercase tracking-wider">Kemitraan DUDI</div>
              <div className="mt-1 text-2xl font-black text-emerald-400">{stats.mouActive} MoU Aktif</div>
              <div className="text-[10px] text-slate-400">{stats.internshipQuota} kuota magang PKL</div>
            </div>
          </div>
        </div>
      </div>

      {/* Main Tabs Navigation */}
      <div className="flex flex-wrap items-center gap-2 border-b border-slate-200 pb-3">
        <button
          onClick={() => setActiveTab('KURIKULUM')}
          className={`flex items-center gap-2 rounded-2xl px-5 py-2.5 text-xs font-bold transition-all ${
            activeTab === 'KURIKULUM'
              ? 'bg-blue-600 text-white shadow-md shadow-blue-500/20'
              : 'bg-white text-slate-700 hover:bg-slate-50 border border-slate-200/80'
          }`}
        >
          <BookOpen className="h-4 w-4" />
          <span>Waka Kurikulum & Pembelajaran</span>
          {stats.invalActive > 0 && (
            <span
              className={`ml-1 rounded-full px-1.5 py-0.2 text-[10px] font-black ${
                activeTab === 'KURIKULUM' ? 'bg-blue-800 text-white' : 'bg-blue-100 text-blue-800'
              }`}
            >
              {stats.invalActive} Inval
            </span>
          )}
        </button>

        <button
          onClick={() => setActiveTab('KESISWAAN')}
          className={`flex items-center gap-2 rounded-2xl px-5 py-2.5 text-xs font-bold transition-all ${
            activeTab === 'KESISWAAN'
              ? 'bg-rose-600 text-white shadow-md shadow-rose-500/20'
              : 'bg-white text-slate-700 hover:bg-slate-50 border border-slate-200/80'
          }`}
        >
          <Users className="h-4 w-4" />
          <span>Waka Kesiswaan & Karakter</span>
          <span
            className={`ml-1 rounded-full px-1.5 py-0.2 text-[10px] font-black ${
              activeTab === 'KESISWAAN' ? 'bg-rose-800 text-white' : 'bg-rose-100 text-rose-800'
            }`}
          >
            {stats.attendanceRate}% Hadir
          </span>
        </button>

        <button
          onClick={() => setActiveTab('SARPRAS')}
          className={`flex items-center gap-2 rounded-2xl px-5 py-2.5 text-xs font-bold transition-all ${
            activeTab === 'SARPRAS'
              ? 'bg-amber-600 text-white shadow-md shadow-amber-500/20'
              : 'bg-white text-slate-700 hover:bg-slate-50 border border-slate-200/80'
          }`}
        >
          <Wrench className="h-4 w-4" />
          <span>Waka Sarpras & Fasilitas</span>
          {stats.activeTickets > 0 && (
            <span
              className={`ml-1 rounded-full px-1.5 py-0.2 text-[10px] font-black ${
                activeTab === 'SARPRAS' ? 'bg-amber-800 text-white' : 'bg-amber-100 text-amber-800'
              }`}
            >
              {stats.activeTickets} Tiket
            </span>
          )}
        </button>

        <button
          onClick={() => setActiveTab('HUMAS')}
          className={`flex items-center gap-2 rounded-2xl px-5 py-2.5 text-xs font-bold transition-all ${
            activeTab === 'HUMAS'
              ? 'bg-emerald-600 text-white shadow-md shadow-emerald-500/20'
              : 'bg-white text-slate-700 hover:bg-slate-50 border border-slate-200/80'
          }`}
        >
          <Briefcase className="h-4 w-4" />
          <span>Waka Humas & Kemitraan Industri</span>
          <span
            className={`ml-1 rounded-full px-1.5 py-0.2 text-[10px] font-black ${
              activeTab === 'HUMAS' ? 'bg-emerald-800 text-white' : 'bg-emerald-100 text-emerald-800'
            }`}
          >
            {stats.mouActive} MoU
          </span>
        </button>
      </div>

      {/* Main Tab Content */}
      <div className="mt-4">
        {activeTab === 'KURIKULUM' && <WakaKurikulumTab currentUser={currentUser} tenantId={tenantId} />}
        {activeTab === 'KESISWAAN' && <WakaKesiswaanTab currentUser={currentUser} tenantId={tenantId} />}
        {activeTab === 'SARPRAS' && <WakaSarprasTab currentUser={currentUser} tenantId={tenantId} />}
        {activeTab === 'HUMAS' && <WakaHumasTab currentUser={currentUser} tenantId={tenantId} />}
      </div>
    </div>
  );
};
