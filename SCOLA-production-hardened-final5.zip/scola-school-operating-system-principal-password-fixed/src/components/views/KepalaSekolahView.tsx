import React, { useState, useEffect } from 'react';
import {
  Users,
  Layers,
  GraduationCap,
  Plus,
  ShieldCheck,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  Building2,
  Calendar,
  Briefcase,
  Sliders,
  Settings,
  UserPlus,
  Radio,
  Activity,
} from 'lucide-react';
import {
  UserProfile,
  Tenant,
  TeacherProfile,
  SchoolClass,
  AcademicYear,
  TeacherAssignmentType,
  LicenseUsage,
  DailyAttendance,
  GradeItem,
} from '../../types';
import { tenantRepository } from '../../repositories/tenantRepository';
import { teacherRepository } from '../../repositories/teacherRepository';
import { academicRepository } from '../../repositories/academicRepository';
import { teacherLicenseService } from '../../services/teacherLicenseService';
import { teacherAccountService } from '../../services/teacherAccountService';
import { ASSIGNMENT_LABELS } from '../../lib/permissions';
import { KepsekCommandCenterTab } from './KepsekCommandCenterTab';
import { DashboardKpiCharts } from '../common/DashboardKpiCharts';

interface KepalaSekolahViewProps {
  currentUser: UserProfile;
}

export const KepalaSekolahView: React.FC<KepalaSekolahViewProps> = ({ currentUser }) => {
  const [tenant, setTenant] = useState<Tenant | null>(null);
  const [licenseUsage, setLicenseUsage] = useState<LicenseUsage | null>(null);
  const [teachers, setTeachers] = useState<TeacherProfile[]>([]);
  const [classes, setClasses] = useState<SchoolClass[]>([]);
  const [academicYears, setAcademicYears] = useState<AcademicYear[]>([]);
  const [attendanceHistory, setAttendanceHistory] = useState<DailyAttendance[]>([]);
  const [gradeHistory, setGradeHistory] = useState<GradeItem[]>([]);
  const [activeTab, setActiveTab] = useState<
    'COMMAND_CENTER' | 'TEACHERS' | 'CLASSES' | 'ACADEMIC_YEAR' | 'PROFILE'
  >('COMMAND_CENTER');
  const [loading, setLoading] = useState(true);

  // Modals State (All-in-One Teacher & Staff Onboarding)
  const [addTeacherModalOpen, setAddTeacherModalOpen] = useState(false);
  const [newTeacherName, setNewTeacherName] = useState('');
  const [newTeacherNip, setNewTeacherNip] = useState('');
  const [newTeacherNuptk, setNewTeacherNuptk] = useState('');
  const [newTeacherEmail, setNewTeacherEmail] = useState('');
  const [newTeacherPassword, setNewTeacherPassword] = useState('');
  const [newTeacherPasswordConfirm, setNewTeacherPasswordConfirm] = useState('');
  const [showNewTeacherPassword, setShowNewTeacherPassword] = useState(false);
  const [newTeacherPhone, setNewTeacherPhone] = useState('');
  const [newTeacherGender, setNewTeacherGender] = useState<'L' | 'P'>('L');
  const [newTeacherEmploymentType, setNewTeacherEmploymentType] = useState<'PNS' | 'PPPK' | 'GTY' | 'GTT'>('GTY');
  const [newTeacherRoleType, setNewTeacherRoleType] = useState<'GURU' | 'TENAGA_KEPENDIDIKAN'>('GURU');
  const [newTeacherSpecialty, setNewTeacherSpecialty] = useState('Matematika');
  const [newTeacherInitialAssignment, setNewTeacherInitialAssignment] = useState<
    'NONE' | 'WALI_KELAS' | 'WAKA_KURIKULUM' | 'WAKA_KESISWAAN' | 'WAKA_SARPRAS' | 'WAKA_HUMAS' | 'BK' | 'KAPROG'
  >('NONE');
  const [newTeacherClassId, setNewTeacherClassId] = useState('');

  // Assignment Modal State
  const [assignModalOpen, setAssignModalOpen] = useState(false);
  const [selectedTeacherForAssign, setSelectedTeacherForAssign] = useState<TeacherProfile | null>(null);
  const [assignmentType, setAssignmentType] = useState<TeacherAssignmentType>('WALI_KELAS');
  const [assignmentClassId, setAssignmentClassId] = useState<string>('');
  const [assignmentNotes, setAssignmentNotes] = useState<string>('');

  // Class Modal State
  const [addClassModalOpen, setAddClassModalOpen] = useState(false);
  const [newClassName, setNewClassName] = useState('');
  const [newClassGrade, setNewClassGrade] = useState<10 | 11 | 12>(10);
  const [newClassMajor, setNewClassMajor] = useState('');
  const [newClassCapacity, setNewClassCapacity] = useState(36);
  const [newClassWaliId, setNewClassWaliId] = useState('');

  // Notifications
  const [notification, setNotification] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  const tenantId = currentUser.tenant_id;

  const loadData = async () => {
    if (!tenantId) return;
    setLoading(true);
    try {
      const [t, usage, teacherList, classList, ayList, attendanceList, gradeList] = await Promise.all([
        tenantRepository.getById(tenantId),
        teacherLicenseService.getLicenseUsage(tenantId),
        teacherRepository.getByTenant(tenantId, currentUser),
        academicRepository.getClassesByTenant(tenantId, currentUser),
        academicRepository.getAcademicYears(tenantId, currentUser),
        academicRepository.getAttendanceByTenant(tenantId, currentUser),
        academicRepository.getGradesByTenant(tenantId, currentUser),
      ]);
      setTenant(t);
      setLicenseUsage(usage);
      setTeachers(teacherList);
      setClasses(classList);
      setAcademicYears(ayList);
      setAttendanceHistory(attendanceList);
      setGradeHistory(gradeList);
    } catch (err: any) {
      setNotification({ type: 'error', message: err.message || 'Gagal memuat data sekolah' });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, [tenantId]);

  // Handle Teacher Activation / Deactivation
  const handleToggleTeacherStatus = async (teacher: TeacherProfile) => {
    if (!tenantId) return;
    try {
      if (teacher.status === 'ACTIVE') {
        const confirmDeactivate = window.confirm(
          `Apakah Anda yakin ingin menonaktifkan akun guru "${teacher.full_name}"? Slot lisensi aktif akan dibebaskan, tetapi semua data historis (nilai, presensi, kelas) tetap tersimpan utuh.`
        );
        if (!confirmDeactivate) return;
        await teacherLicenseService.deactivateTeacher({
          tenantId,
          teacherId: teacher.id,
          actor: currentUser,
          reason: 'Penonaktifan oleh Kepala Sekolah',
        });
        setNotification({
          type: 'success',
          message: `Guru ${teacher.full_name} dinonaktifkan. 1 slot lisensi guru telah dibebaskan.`,
        });
      } else {
        await teacherLicenseService.activateTeacher({
          tenantId,
          teacherId: teacher.id,
          actor: currentUser,
        });
        setNotification({
          type: 'success',
          message: `Guru ${teacher.full_name} berhasil diaktifkan kembali!`,
        });
      }
      await loadData();
    } catch (err: any) {
      setNotification({
        type: 'error',
        message: err.message || 'Gagal mengubah status guru.',
      });
    }
  };

  // Handle Add Teacher & Staff (All-in-One Onboarding)
  const handleAddTeacher = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!tenantId) return;

    try {
      const initialAssignments = [];
      if (newTeacherInitialAssignment !== 'NONE') {
        initialAssignments.push({
          id: `asg-${Date.now()}`,
          type: newTeacherInitialAssignment as TeacherAssignmentType,
          active: true,
          class_id: newTeacherInitialAssignment === 'WALI_KELAS' ? newTeacherClassId : undefined,
          start_date: new Date().toISOString().split('T')[0],
        });
      }

      if (newTeacherPassword.length < 8) {
        throw new Error('Password minimal 8 karakter.');
      }
      if (newTeacherPassword !== newTeacherPasswordConfirm) {
        throw new Error('Konfirmasi password tidak sama.');
      }
      if (newTeacherRoleType !== 'GURU') {
        throw new Error('Registrasi akun Tenaga Kependidikan melalui modul khusus staf belum tersedia. Pilih Guru Pendidik.');
      }

      const created = await teacherAccountService.createTeacherAccount(
        {
          tenant_id: tenantId,
          full_name: newTeacherName,
          nip: newTeacherNip || undefined,
          nuptk: newTeacherNuptk || undefined,
          email: newTeacherEmail,
          password: newTeacherPassword,
          phone: newTeacherPhone || undefined,
          gender: newTeacherGender,
          employment_type: newTeacherEmploymentType,
          subject_specialty: newTeacherSpecialty ? [newTeacherSpecialty] : ['Umum'],
          assignments: initialAssignments,
        },
        currentUser
      );

      // If assigned as homeroom teacher (WALI_KELAS), link class
      if (newTeacherInitialAssignment === 'WALI_KELAS' && newTeacherClassId) {
        await academicRepository.updateClass(
          newTeacherClassId,
          {
            wali_kelas_teacher_id: created.id,
            wali_kelas_name: created.full_name,
          },
          currentUser
        );
      }

      const assignmentLabel =
        newTeacherInitialAssignment !== 'NONE'
          ? ASSIGNMENT_LABELS[newTeacherInitialAssignment as TeacherAssignmentType]
          : newTeacherRoleType === 'TENAGA_KEPENDIDIKAN'
          ? 'Tenaga Kependidikan'
          : 'Guru Pengajar';

      setNotification({
        type: 'success',
        message: `Akun "${newTeacherName}" berhasil didaftarkan dan diaktifkan langsung dengan peran ${assignmentLabel}. Pengguna siap login!`,
      });
      setAddTeacherModalOpen(false);
      setNewTeacherName('');
      setNewTeacherNip('');
      setNewTeacherNuptk('');
      setNewTeacherEmail('');
      setNewTeacherPassword('');
      setNewTeacherPasswordConfirm('');
      setShowNewTeacherPassword(false);
      setNewTeacherPhone('');
      setNewTeacherSpecialty('Matematika');
      setNewTeacherInitialAssignment('NONE');
      setNewTeacherClassId('');
      await loadData();
    } catch (err: any) {
      setNotification({
        type: 'error',
        message: err.message || 'Gagal menambahkan akun guru.',
      });
    }
  };

  // Handle Assign Teacher
  const handleSaveAssignment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!tenantId || !selectedTeacherForAssign) return;

    try {
      await academicRepository.assignTeacher(
        {
          tenant_id: tenantId,
          teacher_user_id: selectedTeacherForAssign.user_id || selectedTeacherForAssign.id,
          assignment_type: assignmentType,
          class_id: assignmentType === 'WALI_KELAS' ? assignmentClassId : undefined,
          notes: assignmentNotes,
        },
        currentUser
      );

      setNotification({
        type: 'success',
        message: `Tugas tambahan "${ASSIGNMENT_LABELS[assignmentType]}" berhasil diberikan kepada ${selectedTeacherForAssign.full_name}.`,
      });
      setAssignModalOpen(false);
      await loadData();
    } catch (err: any) {
      setNotification({ type: 'error', message: err.message || 'Gagal menugaskan guru.' });
    }
  };

  // Handle Add Class
  const handleAddClass = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!tenantId) return;

    try {
      const selectedWali = teachers.find((t) => t.id === newClassWaliId);
      await academicRepository.createClass(
        {
          tenant_id: tenantId,
          name: newClassName,
          grade_level: newClassGrade,
          school_type: tenant?.type || 'SMA',
          major_or_stream: newClassMajor || (tenant?.type === 'SMA' ? 'MIPA' : 'Teknik Komputer'),
          academic_year_id: academicYears.find((y) => y.is_active)?.id || 'ay-2024-ganjil',
          wali_kelas_teacher_id: newClassWaliId || undefined,
          wali_kelas_name: selectedWali?.full_name,
          capacity: newClassCapacity,
        },
        currentUser
      );

      setNotification({
        type: 'success',
        message: `Kelas baru "${newClassName}" berhasil dibuat.`,
      });
      setAddClassModalOpen(false);
      setNewClassName('');
      setNewClassMajor('');
      await loadData();
    } catch (err: any) {
      setNotification({ type: 'error', message: err.message || 'Gagal membuat kelas.' });
    }
  };

  // Handle Switch Academic Year
  const handleSelectAcademicYear = async (yearId: string) => {
    if (!tenantId) return;
    try {
      await academicRepository.setActiveAcademicYear(tenantId, yearId, currentUser);
      setNotification({
        type: 'success',
        message: 'Tahun ajaran aktif berhasil diperbarui.',
      });
      await loadData();
    } catch (err: any) {
      setNotification({ type: 'error', message: err.message || 'Gagal mengubah tahun ajaran.' });
    }
  };

  return (
    <div className="space-y-6">
      {/* School Header Banner */}
      <div className="rounded-2xl bg-gradient-to-r from-blue-900 via-indigo-900 to-slate-900 p-6 text-white shadow-xl">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-2 rounded-full bg-blue-500/20 px-3 py-1 text-xs font-semibold text-blue-300 border border-blue-400/30">
              <ShieldCheck className="h-3.5 w-3.5" />
              <span>Portal Eksekutif Kepala Sekolah</span>
            </div>
            <h1 className="mt-2 text-2xl font-extrabold tracking-tight sm:text-3xl">
              {tenant?.name || 'Dashboard Kepala Sekolah'}
            </h1>
            <p className="mt-1 text-xs sm:text-sm text-slate-300 max-w-2xl">
              NPSN: {tenant?.npsn} • Akreditasi {tenant?.accreditation} • Jenjang {tenant?.type} ({tenant?.city}, {tenant?.province})
            </p>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => setAddTeacherModalOpen(true)}
              disabled={licenseUsage?.is_full}
              className={`flex items-center gap-2 rounded-xl px-4 py-2.5 text-xs font-bold text-white shadow-lg transition-all ${
                licenseUsage?.is_full
                  ? 'bg-slate-700 opacity-60 cursor-not-allowed'
                  : 'bg-blue-600 hover:bg-blue-500'
              }`}
              title={
                licenseUsage?.is_full
                  ? 'Kuota guru telah habis. Hubungi Super Master untuk menambah kuota.'
                  : 'Tambah Akun Guru Baru'
              }
            >
              <UserPlus className="h-4 w-4" />
              <span>Tambah Guru</span>
            </button>
          </div>
        </div>
      </div>

      {/* Notification */}
      {notification && (
        <div
          className={`flex items-center justify-between rounded-xl p-4 text-xs font-medium ${
            notification.type === 'success'
              ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
              : 'bg-red-50 text-red-800 border border-red-200'
          }`}
        >
          <span>{notification.message}</span>
          <button onClick={() => setNotification(null)} className="font-bold underline">
            Tutup
          </button>
        </div>
      )}

      {/* Quota Exhausted Warning Banner (Exact Business Rule) */}
      {licenseUsage?.is_full && (
        <div className="rounded-2xl border border-red-200 bg-red-50 p-4 text-red-900 shadow-xs flex items-start gap-3">
          <AlertTriangle className="h-5 w-5 text-red-600 shrink-0 mt-0.5" />
          <div className="text-xs">
            <span className="font-bold text-sm">Pemberitahuan Kuota Lisensi Penuh:</span>
            <p className="mt-0.5 font-medium">
              Kuota guru telah habis. Silakan hubungi administrator SCOLA untuk menambah lisensi.
            </p>
            <p className="mt-1 text-slate-600">
              Sekolah Anda telah menggunakan seluruh <strong>{licenseUsage.total_quota} slot lisensi guru</strong> yang dialokasikan. Untuk menambah guru pengajar baru atau mengaktifkan kembali guru nonaktif, mintalah administrator Super Master untuk menaikkan kuota sekolah.
            </p>
          </div>
        </div>
      )}

      {/* License Quota Summary Card */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
        <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-xs">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-xs font-semibold uppercase">Kapasitas Lisensi Guru</span>
            <Users className="h-4 w-4 text-blue-600" />
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-3xl font-extrabold text-blue-700">
              {licenseUsage?.used_licenses || 0}
            </span>
            <span className="text-sm font-semibold text-slate-500">
              / {licenseUsage?.total_quota || 0} Guru Aktif
            </span>
          </div>
          <div className="mt-3 h-2 w-full rounded-full bg-slate-100 overflow-hidden">
            <div
              className={`h-full rounded-full ${
                licenseUsage?.is_full ? 'bg-red-600' : 'bg-blue-600'
              }`}
              style={{ width: `${Math.min(100, licenseUsage?.usage_percentage || 0)}%` }}
            />
          </div>
          <div className="mt-2 text-[11px] text-slate-400">
            Tersedia: <strong className="text-slate-700">{licenseUsage?.available_licenses || 0} slot</strong>
          </div>
        </div>

        <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-xs">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-xs font-semibold uppercase">Total Rombel / Kelas</span>
            <Layers className="h-4 w-4 text-indigo-600" />
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-3xl font-extrabold text-indigo-700">{classes.length}</span>
            <span className="text-xs text-slate-500 font-medium">Kelas Terdaftar</span>
          </div>
          <div className="mt-4 text-[11px] text-slate-400">
            Total siswa terdaftar: {classes.reduce((acc, c) => acc + (c.total_students || 0), 0)} siswa
          </div>
        </div>

        <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-xs">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-xs font-semibold uppercase">Tahun Ajaran Aktif</span>
            <Calendar className="h-4 w-4 text-emerald-600" />
          </div>
          <div className="mt-3">
            <div className="text-xl font-bold text-slate-900">
              {academicYears.find((y) => y.is_active)?.name || '2024/2025'}
            </div>
            <span className="inline-block mt-1 rounded-md bg-emerald-100 px-2 py-0.5 text-xs font-bold text-emerald-800">
              Semester {academicYears.find((y) => y.is_active)?.semester || 'GANJIL'}
            </span>
          </div>
          <div className="mt-3 text-[11px] text-slate-400">Kurikulum Merdeka Satuan Pendidikan</div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-200 pb-2 overflow-x-auto">
        <button
          onClick={() => setActiveTab('COMMAND_CENTER')}
          className={`flex items-center gap-2 rounded-xl px-4 py-2 text-xs font-bold transition-all shrink-0 ${
            activeTab === 'COMMAND_CENTER'
              ? 'bg-blue-700 text-white shadow-xs'
              : 'text-slate-600 hover:text-slate-900 bg-slate-50'
          }`}
        >
          <Radio className="h-4 w-4" />
          <span>Command Center & Live Monitor</span>
        </button>
        <button
          onClick={() => setActiveTab('TEACHERS')}
          className={`flex items-center gap-2 rounded-xl px-4 py-2 text-xs font-semibold transition-all shrink-0 ${
            activeTab === 'TEACHERS'
              ? 'bg-blue-50 text-blue-700 shadow-2xs font-bold'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <Users className="h-4 w-4" />
          <span>Dewan Guru ({teachers.length})</span>
        </button>
        <button
          onClick={() => setActiveTab('CLASSES')}
          className={`flex items-center gap-2 rounded-xl px-4 py-2 text-xs font-semibold transition-all shrink-0 ${
            activeTab === 'CLASSES'
              ? 'bg-blue-50 text-blue-700 shadow-2xs font-bold'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <Layers className="h-4 w-4" />
          <span>Rombel & Kelas ({classes.length})</span>
        </button>
        <button
          onClick={() => setActiveTab('ACADEMIC_YEAR')}
          className={`flex items-center gap-2 rounded-xl px-4 py-2 text-xs font-semibold transition-all shrink-0 ${
            activeTab === 'ACADEMIC_YEAR'
              ? 'bg-blue-50 text-blue-700 shadow-2xs font-bold'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <Calendar className="h-4 w-4" />
          <span>Tahun Ajaran & Semester</span>
        </button>
        <button
          onClick={() => setActiveTab('PROFILE')}
          className={`flex items-center gap-2 rounded-xl px-4 py-2 text-xs font-semibold transition-all shrink-0 ${
            activeTab === 'PROFILE'
              ? 'bg-blue-50 text-blue-700 shadow-2xs font-bold'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <Building2 className="h-4 w-4" />
          <span>Profil & Branding</span>
        </button>
      </div>

      {/* ================= TAB 0: COMMAND CENTER ================= */}
      {activeTab === 'COMMAND_CENTER' && (
        <>
        <KepsekCommandCenterTab
          tenant={tenant}
          licenseUsage={licenseUsage}
          teachers={teachers}
          classes={classes}
          academicYears={academicYears}
          currentUser={currentUser}
          onOpenAddTeacher={() => setAddTeacherModalOpen(true)}
          onSwitchTab={(tab) => setActiveTab(tab)}
        />
        <DashboardKpiCharts attendance={attendanceHistory} grades={gradeHistory} scopeLabel={tenant?.name || 'sekolah'} />
        </>
      )}

      {/* ================= TAB 1: TEACHERS ================= */}
      {activeTab === 'TEACHERS' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-slate-900">Daftar Akun Guru & Penugasan Tugas Tambahan</h3>
            <button
              onClick={() => setAddTeacherModalOpen(true)}
              disabled={licenseUsage?.is_full}
              className="flex items-center gap-1.5 rounded-xl bg-blue-700 hover:bg-blue-800 disabled:bg-slate-400 px-3 py-2 text-xs font-semibold text-white transition-colors"
            >
              <Plus className="h-3.5 w-3.5" />
              <span>Tambah Guru</span>
            </button>
          </div>

          <div className="overflow-x-auto rounded-2xl border border-slate-200 bg-white shadow-xs">
            <table className="w-full text-left text-xs text-slate-600">
              <thead className="border-b border-slate-200 bg-slate-50 text-[11px] font-bold uppercase text-slate-500">
                <tr>
                  <th className="px-4 py-3">Nama Lengkap Guru</th>
                  <th className="px-4 py-3">NIP / NUPTK</th>
                  <th className="px-4 py-3">Kontak</th>
                  <th className="px-4 py-3">Tugas Tambahan (SK)</th>
                  <th className="px-4 py-3">Status Lisensi</th>
                  <th className="px-4 py-3 text-right">Tindakan</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {teachers.map((teacher) => {
                  const teacherAssignments = teacher.assignments || [];

                  return (
                    <tr key={teacher.id} className="hover:bg-slate-50/80 transition-colors">
                      <td className="px-4 py-3.5">
                        <div className="font-bold text-slate-900">{teacher.full_name}</div>
                        <div className="text-[11px] text-slate-400">Gender: {teacher.gender === 'L' ? 'Laki-laki' : 'Perempuan'}</div>
                      </td>
                      <td className="px-4 py-3.5 font-mono text-[11px]">
                        <div>NIP: {teacher.nip || '-'}</div>
                        <div className="text-slate-400">NUPTK: {teacher.nuptk || '-'}</div>
                      </td>
                      <td className="px-4 py-3.5">
                        <div>{teacher.email || '-'}</div>
                        <div className="text-slate-400">{teacher.phone || '-'}</div>
                      </td>
                      <td className="px-4 py-3.5">
                        <div className="flex flex-wrap gap-1">
                          {teacherAssignments.length > 0 ? (
                            teacherAssignments.map((asg, idx) => (
                              <span
                                key={idx}
                                className="rounded-md bg-blue-50 px-2 py-0.5 text-[10px] font-semibold text-blue-700 border border-blue-200/60"
                              >
                                {ASSIGNMENT_LABELS[asg.type] || asg.type}
                              </span>
                            ))
                          ) : (
                            <span className="text-[11px] text-slate-400">Guru Mapel</span>
                          )}
                        </div>
                      </td>
                      <td className="px-4 py-3.5">
                        <span
                          className={`inline-flex items-center gap-1 rounded-full px-2.5 py-0.5 text-[10px] font-bold ${
                            teacher.status === 'ACTIVE'
                              ? 'bg-emerald-100 text-emerald-800'
                              : 'bg-slate-100 text-slate-600'
                          }`}
                        >
                          {teacher.status === 'ACTIVE' ? (
                            <>
                              <CheckCircle2 className="h-3 w-3" />
                              <span>AKTIF (1 Lisensi)</span>
                            </>
                          ) : (
                            <>
                              <XCircle className="h-3 w-3" />
                              <span>NONAKTIF</span>
                            </>
                          )}
                        </span>
                      </td>
                      <td className="px-4 py-3.5 text-right space-x-1">
                        <button
                          onClick={() => {
                            setSelectedTeacherForAssign(teacher);
                            setAssignModalOpen(true);
                          }}
                          className="rounded-lg border border-slate-200 bg-white hover:bg-slate-100 px-2.5 py-1 text-xs font-medium text-slate-700"
                          title="Beri Tugas Tambahan (Wali Kelas, Waka, Kaprog, dsb)"
                        >
                          + SK Tugas
                        </button>

                        <button
                          onClick={() => handleToggleTeacherStatus(teacher)}
                          className={`rounded-lg px-2.5 py-1 text-xs font-semibold ${
                            teacher.status === 'ACTIVE'
                              ? 'border border-red-200 bg-red-50 text-red-700 hover:bg-red-100'
                              : 'border border-emerald-200 bg-emerald-50 text-emerald-700 hover:bg-emerald-100'
                          }`}
                        >
                          {teacher.status === 'ACTIVE' ? 'Nonaktifkan' : 'Aktifkan'}
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ================= TAB 2: CLASSES ================= */}
      {activeTab === 'CLASSES' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-slate-900">Rombongan Belajar (Rombel) Terdaftar</h3>
            <button
              onClick={() => setAddClassModalOpen(true)}
              className="flex items-center gap-1.5 rounded-xl bg-blue-700 hover:bg-blue-800 px-3 py-2 text-xs font-semibold text-white transition-colors"
            >
              <Plus className="h-3.5 w-3.5" />
              <span>Buat Rombel Baru</span>
            </button>
          </div>

          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {classes.map((cls) => (
              <div key={cls.id} className="rounded-2xl border border-slate-200 bg-white p-5 shadow-xs">
                <div className="flex items-center justify-between">
                  <span className="rounded-md bg-blue-50 px-2 py-0.5 text-xs font-bold text-blue-700">
                    Tingkat {cls.grade_level}
                  </span>
                  <span className="text-xs text-slate-500">{cls.school_type}</span>
                </div>
                <h4 className="mt-2 text-lg font-bold text-slate-900">{cls.name}</h4>
                <div className="text-xs text-slate-500 font-medium">Jurusan / Peminatan: {cls.major_or_stream}</div>

                <div className="mt-4 border-t border-slate-100 pt-3 text-xs space-y-1">
                  <div className="flex justify-between">
                    <span className="text-slate-500">Wali Kelas:</span>
                    <span className="font-semibold text-slate-800">{cls.wali_kelas_name || 'Belum ditugaskan'}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Jumlah Siswa:</span>
                    <span className="font-bold text-blue-700">
                      {cls.total_students || 0} / {cls.capacity || 36}
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ================= TAB 3: ACADEMIC YEAR ================= */}
      {activeTab === 'ACADEMIC_YEAR' && (
        <div className="space-y-4">
          <h3 className="text-sm font-bold text-slate-900">Konfigurasi Tahun Ajaran & Semester</h3>
          <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-xs space-y-3">
            {academicYears.map((ay) => (
              <div
                key={ay.id}
                className={`flex items-center justify-between rounded-xl p-4 border transition-all ${
                  ay.is_active ? 'border-emerald-300 bg-emerald-50/40 shadow-xs' : 'border-slate-200 bg-slate-50/50'
                }`}
              >
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-base font-bold text-slate-900">Tahun Ajaran {ay.name}</span>
                    <span className="rounded-md bg-blue-100 px-2 py-0.5 text-xs font-bold text-blue-800">
                      Semester {ay.semester}
                    </span>
                    {ay.is_active && (
                      <span className="rounded-full bg-emerald-100 px-2.5 py-0.5 text-[10px] font-bold text-emerald-800">
                        AKTIF SAAT INI
                      </span>
                    )}
                  </div>
                  <div className="text-xs text-slate-500 mt-1">
                    Periode: {ay.start_date} s.d. {ay.end_date}
                  </div>
                </div>

                {!ay.is_active && (
                  <button
                    onClick={() => handleSelectAcademicYear(ay.id)}
                    className="rounded-xl bg-white border border-slate-300 hover:bg-slate-100 px-3.5 py-1.5 text-xs font-semibold text-slate-700 shadow-2xs"
                  >
                    Jadikan Aktif
                  </button>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ================= TAB 4: PROFILE ================= */}
      {activeTab === 'PROFILE' && tenant && (
        <div className="space-y-4">
          <h3 className="text-sm font-bold text-slate-900">Profil Satuan Pendidikan</h3>
          <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-xs space-y-4 max-w-2xl">
            <div className="grid grid-cols-2 gap-4 text-xs">
              <div>
                <span className="text-slate-400">Nama Sekolah:</span>
                <div className="font-bold text-slate-800 text-sm">{tenant.name}</div>
              </div>
              <div>
                <span className="text-slate-400">NPSN:</span>
                <div className="font-bold text-slate-800 text-sm">{tenant.npsn}</div>
              </div>
              <div>
                <span className="text-slate-400">Jenjang:</span>
                <div className="font-bold text-slate-800">{tenant.type}</div>
              </div>
              <div>
                <span className="text-slate-400">Akreditasi:</span>
                <div className="font-bold text-slate-800">{tenant.accreditation}</div>
              </div>
              <div className="col-span-2">
                <span className="text-slate-400">Alamat:</span>
                <div className="font-medium text-slate-800">
                  {tenant.address}, {tenant.city}, {tenant.province}
                </div>
              </div>
              <div>
                <span className="text-slate-400">Email Resmi:</span>
                <div className="font-medium text-slate-800">{tenant.email}</div>
              </div>
              <div>
                <span className="text-slate-400">Telepon:</span>
                <div className="font-medium text-slate-800">{tenant.phone}</div>
              </div>
            </div>

            <div className="rounded-xl bg-amber-50 p-3 text-xs text-amber-800 border border-amber-200/70">
              <strong>Catatan Wewenang:</strong> Perubahan kuota lisensi guru dan status aktivasi tenant sekolah hanya dapat dilakukan oleh administrator <strong>Super Master SCOLA</strong>.
            </div>
          </div>
        </div>
      )}

      {/* ================= MODAL: ALL-IN-ONE TAMBAH GURU & PENUGASAN ================= */}
      {addTeacherModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 p-4 backdrop-blur-xs overflow-y-auto">
          <div className="w-full max-w-xl rounded-2xl bg-white p-6 shadow-2xl border border-slate-200 my-8">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2">
                <div className="rounded-xl bg-blue-100 p-2 text-blue-700">
                  <UserPlus className="h-5 w-5" />
                </div>
                <div>
                  <h3 className="text-base font-extrabold text-slate-900">Registrasi Terpadu Akun Guru & Penugasan</h3>
                  <p className="text-[11px] text-slate-500">Pendaftaran akun, status kepegawaian, mapel ampuan, dan tugas struktural/wali kelas sekaligus.</p>
                </div>
              </div>
              <button
                onClick={() => setAddTeacherModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 text-xl font-bold"
              >
                &times;
              </button>
            </div>

            <form onSubmit={handleAddTeacher} className="mt-4 space-y-4">
              {/* Jenis Akun & Status Kepegawaian */}
              <div className="grid grid-cols-2 gap-3 bg-slate-50 p-3 rounded-xl border border-slate-200">
                <div>
                  <label className="text-xs font-bold text-slate-700 block">Kategori Akun</label>
                  <select
                    value={newTeacherRoleType}
                    onChange={(e) => setNewTeacherRoleType(e.target.value as 'GURU' | 'TENAGA_KEPENDIDIKAN')}
                    className="mt-1 w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs font-semibold text-slate-800 focus:border-blue-500 focus:outline-hidden"
                  >
                    <option value="GURU">Guru Pendidik (Pengajar)</option>
                    <option value="TENAGA_KEPENDIDIKAN">Tenaga Kependidikan (TU/Staf)</option>
                  </select>
                </div>
                <div>
                  <label className="text-xs font-bold text-slate-700 block">Status Kepegawaian</label>
                  <select
                    value={newTeacherEmploymentType}
                    onChange={(e) => setNewTeacherEmploymentType(e.target.value as 'PNS' | 'PPPK' | 'GTY' | 'GTT')}
                    className="mt-1 w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs font-semibold text-slate-800 focus:border-blue-500 focus:outline-hidden"
                  >
                    <option value="PNS">PNS (Pegawai Negeri Sipil)</option>
                    <option value="PPPK">PPPK (Pegawai Pemerintah dg Perjanjian Kerja)</option>
                    <option value="GTY">GTY (Guru Tetap Yayasan)</option>
                    <option value="GTT">GTT / Guru Honorer</option>
                  </select>
                </div>
              </div>

              {/* Nama Lengkap & NIP */}
              <div>
                <label className="text-xs font-bold text-slate-700">Nama Lengkap & Gelar</label>
                <input
                  type="text"
                  required
                  placeholder="Drs. H. Ahmad Dahlan, M.Pd."
                  value={newTeacherName}
                  onChange={(e) => setNewTeacherName(e.target.value)}
                  className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-xs focus:border-blue-500 focus:outline-hidden"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-bold text-slate-700">NIP (Opsional)</label>
                  <input
                    type="text"
                    placeholder="19780101..."
                    value={newTeacherNip}
                    onChange={(e) => setNewTeacherNip(e.target.value)}
                    className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-xs focus:border-blue-500 focus:outline-hidden"
                  />
                </div>
                <div>
                  <label className="text-xs font-bold text-slate-700">NUPTK (Opsional)</label>
                  <input
                    type="text"
                    placeholder="12345678..."
                    value={newTeacherNuptk}
                    onChange={(e) => setNewTeacherNuptk(e.target.value)}
                    className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-xs focus:border-blue-500 focus:outline-hidden"
                  />
                </div>
              </div>

              {/* Kontak & Login */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-bold text-slate-700">Email Login Resmi</label>
                  <input
                    type="email"
                    required
                    placeholder="ahmad.dahlan@sekolah.sch.id"
                    value={newTeacherEmail}
                    onChange={(e) => setNewTeacherEmail(e.target.value)}
                    className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-xs focus:border-blue-500 focus:outline-hidden"
                  />
                </div>
                <div>
                  <label className="text-xs font-bold text-slate-700">No. WhatsApp</label>
                  <input
                    type="tel"
                    placeholder="08123456789"
                    value={newTeacherPhone}
                    onChange={(e) => setNewTeacherPhone(e.target.value)}
                    className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-xs focus:border-blue-500 focus:outline-hidden"
                  />
                </div>
              </div>

              {/* Kredensial Login */}
              <div className="rounded-xl border border-blue-200 bg-blue-50/60 p-3">
                <div className="flex items-center justify-between gap-2">
                  <div>
                    <label className="text-xs font-bold text-blue-900">Password Login Guru</label>
                    <p className="mt-0.5 text-[10px] text-blue-700">Akun langsung ACTIVE dan password ini dipakai guru untuk login.</p>
                  </div>
                  <button
                    type="button"
                    onClick={() => setShowNewTeacherPassword((v) => !v)}
                    className="text-[10px] font-bold text-blue-700 hover:text-blue-900"
                  >
                    {showNewTeacherPassword ? 'Sembunyikan' : 'Tampilkan'}
                  </button>
                </div>
                <div className="mt-2 grid grid-cols-2 gap-3">
                  <input
                    type={showNewTeacherPassword ? 'text' : 'password'}
                    required
                    minLength={8}
                    autoComplete="new-password"
                    placeholder="Minimal 8 karakter"
                    value={newTeacherPassword}
                    onChange={(e) => setNewTeacherPassword(e.target.value)}
                    className="w-full rounded-xl border border-blue-200 bg-white px-3 py-2 text-xs focus:border-blue-500 focus:outline-hidden"
                  />
                  <input
                    type={showNewTeacherPassword ? 'text' : 'password'}
                    required
                    minLength={8}
                    autoComplete="new-password"
                    placeholder="Ulangi password"
                    value={newTeacherPasswordConfirm}
                    onChange={(e) => setNewTeacherPasswordConfirm(e.target.value)}
                    className="w-full rounded-xl border border-blue-200 bg-white px-3 py-2 text-xs focus:border-blue-500 focus:outline-hidden"
                  />
                </div>
              </div>

              {/* Jenis Kelamin & Bidang Studi */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-bold text-slate-700">Jenis Kelamin</label>
                  <select
                    value={newTeacherGender}
                    onChange={(e) => setNewTeacherGender(e.target.value as 'L' | 'P')}
                    className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-xs focus:border-blue-500 focus:outline-hidden"
                  >
                    <option value="L">Laki-laki</option>
                    <option value="P">Perempuan</option>
                  </select>
                </div>
                <div>
                  <label className="text-xs font-bold text-slate-700">Mata Pelajaran Utama</label>
                  <select
                    value={newTeacherSpecialty}
                    onChange={(e) => setNewTeacherSpecialty(e.target.value)}
                    className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-xs focus:border-blue-500 focus:outline-hidden"
                  >
                    <option value="Matematika">Matematika</option>
                    <option value="Fisika">Fisika</option>
                    <option value="Biologi">Biologi</option>
                    <option value="Kimia">Kimia</option>
                    <option value="Bahasa Indonesia">Bahasa Indonesia</option>
                    <option value="Bahasa Inggris">Bahasa Inggris</option>
                    <option value="Informatika">Informatika / Komputer</option>
                    <option value="Sejarah">Sejarah</option>
                    <option value="Geografi">Geografi</option>
                    <option value="Ekonomi">Ekonomi</option>
                    <option value="Sosiologi">Sosiologi</option>
                    <option value="PJOK">PJOK / Olahraga</option>
                    <option value="Pendidikan Agama">Pendidikan Agama</option>
                    <option value="Seni Budaya">Seni Budaya</option>
                    <option value="Bimbingan Konseling">Bimbingan Konseling (BK)</option>
                    <option value="Administrasi TU">Administrasi Tata Usaha</option>
                  </select>
                </div>
              </div>

              {/* Penugasan Tugas Tambahan (SK Langsung) */}
              <div className="rounded-xl border border-blue-200 bg-blue-50/50 p-3.5 space-y-3">
                <div className="flex items-center justify-between">
                  <div>
                    <span className="text-xs font-extrabold text-blue-900 block">Penugasan Struktural Sekaligus</span>
                    <span className="text-[11px] text-blue-700">Atur wewenang khusus atau kepemimpinan rombel pada saat pendaftaran.</span>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="text-xs font-bold text-slate-700 block">Tugas Tambahan</label>
                    <select
                      value={newTeacherInitialAssignment}
                      onChange={(e) => setNewTeacherInitialAssignment(e.target.value as any)}
                      className="mt-1 w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs font-semibold text-slate-900 focus:border-blue-500 focus:outline-hidden"
                    >
                      <option value="NONE">Tanpa Tugas Tambahan (Guru Reguler)</option>
                      <option value="WALI_KELAS">Wali Kelas Rombel</option>
                      <option value="WAKA_KURIKULUM">Waka Kurikulum</option>
                      <option value="WAKA_KESISWAAN">Waka Kesiswaan</option>
                      <option value="WAKA_SARPRAS">Waka Sarpras</option>
                      <option value="WAKA_HUMAS">Waka Humas & Kemitraan</option>
                      <option value="BK">Guru Bimbingan Konseling (BK)</option>
                      <option value="KAPROG">Kepala Program Keahlian (Kaprog SMK)</option>
                    </select>
                  </div>

                  {newTeacherInitialAssignment === 'WALI_KELAS' && (
                    <div>
                      <label className="text-xs font-bold text-slate-700 block">Pilih Rombel / Kelas yang Dibina</label>
                      <select
                        value={newTeacherClassId}
                        onChange={(e) => setNewTeacherClassId(e.target.value)}
                        required
                        className="mt-1 w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs font-bold text-blue-800 focus:border-blue-500 focus:outline-hidden"
                      >
                        <option value="">-- Pilih Kelas --</option>
                        {classes.map((cls) => (
                          <option key={cls.id} value={cls.id}>
                            {cls.name} ({cls.grade_level} - {cls.major_or_stream})
                          </option>
                        ))}
                      </select>
                    </div>
                  )}
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setAddTeacherModalOpen(false)}
                  className="rounded-xl border border-slate-200 bg-white px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-50"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="rounded-xl bg-blue-700 hover:bg-blue-800 px-5 py-2.5 text-xs font-bold text-white shadow-xs transition-colors"
                >
                  Simpan & Terbitkan Akun
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ================= MODAL: BERI TUGAS TAMBAHAN (SK) ================= */}
      {assignModalOpen && selectedTeacherForAssign && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 p-4 backdrop-blur-xs">
          <div className="w-full max-w-md rounded-2xl bg-white p-6 shadow-2xl border border-slate-200">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2">
                <GraduationCap className="h-5 w-5 text-indigo-600" />
                <h3 className="text-base font-bold text-slate-900">Beri Tugas Tambahan Guru</h3>
              </div>
              <button
                onClick={() => setAssignModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 text-lg font-bold"
              >
                &times;
              </button>
            </div>

            <form onSubmit={handleSaveAssignment} className="mt-4 space-y-3">
              <div>
                <label className="text-xs font-semibold text-slate-600">Guru</label>
                <div className="mt-1 rounded-xl bg-slate-50 p-2.5 text-xs font-bold text-slate-800 border border-slate-200">
                  {selectedTeacherForAssign.full_name}
                </div>
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-700">Jenis Tugas Tambahan</label>
                <select
                  value={assignmentType}
                  onChange={(e) => setAssignmentType(e.target.value as TeacherAssignmentType)}
                  className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-xs focus:border-indigo-500 focus:outline-hidden"
                >
                  <option value="WALI_KELAS">Wali Kelas</option>
                  <option value="WAKA_KURIKULUM">Waka Kurikulum</option>
                  <option value="WAKA_KESISWAAN">Waka Kesiswaan</option>
                  <option value="WAKA_SARPRAS">Waka Sarpras</option>
                  <option value="WAKA_HUMAS">Waka Humas / Hubin</option>
                  <option value="KAPROG">Kepala Program (SMK)</option>
                  <option value="BK">Bimbingan Konseling (BK)</option>
                </select>
              </div>

              {assignmentType === 'WALI_KELAS' && (
                <div>
                  <label className="text-xs font-semibold text-slate-700">Pilih Rombel / Kelas</label>
                  <select
                    required
                    value={assignmentClassId}
                    onChange={(e) => setAssignmentClassId(e.target.value)}
                    className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-xs focus:border-indigo-500 focus:outline-hidden"
                  >
                    <option value="">-- Pilih Rombel --</option>
                    {classes.map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.name} ({c.grade_level} - {c.major_or_stream})
                      </option>
                    ))}
                  </select>
                </div>
              )}

              <div>
                <label className="text-xs font-semibold text-slate-700">Nomor SK / Catatan Tugas</label>
                <input
                  type="text"
                  placeholder="SK Kepala Sekolah No. 421.3/08/2024"
                  value={assignmentNotes}
                  onChange={(e) => setAssignmentNotes(e.target.value)}
                  className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-xs focus:border-indigo-500 focus:outline-hidden"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setAssignModalOpen(false)}
                  className="rounded-xl border border-slate-200 bg-white px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-50"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="rounded-xl bg-indigo-700 hover:bg-indigo-800 px-4 py-2 text-xs font-semibold text-white shadow-xs"
                >
                  Tetapkan Tugas
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ================= MODAL: BUAT KELAS BARU ================= */}
      {addClassModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 p-4 backdrop-blur-xs">
          <div className="w-full max-w-md rounded-2xl bg-white p-6 shadow-2xl border border-slate-200">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2">
                <Layers className="h-5 w-5 text-blue-600" />
                <h3 className="text-base font-bold text-slate-900">Buat Rombel Baru</h3>
              </div>
              <button
                onClick={() => setAddClassModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 text-lg font-bold"
              >
                &times;
              </button>
            </div>

            <form onSubmit={handleAddClass} className="mt-4 space-y-3">
              <div>
                <label className="text-xs font-semibold text-slate-700">Nama Rombel / Kelas</label>
                <input
                  type="text"
                  required
                  placeholder="X MIPA 3 atau X PPLG 2"
                  value={newClassName}
                  onChange={(e) => setNewClassName(e.target.value)}
                  className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-xs focus:border-blue-500 focus:outline-hidden"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-semibold text-slate-700">Tingkat</label>
                  <select
                    value={newClassGrade}
                    onChange={(e) => setNewClassGrade(parseInt(e.target.value) as 10 | 11 | 12)}
                    className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-xs focus:border-blue-500 focus:outline-hidden"
                  >
                    <option value={10}>Kelas 10</option>
                    <option value={11}>Kelas 11</option>
                    <option value={12}>Kelas 12</option>
                  </select>
                </div>
                <div>
                  <label className="text-xs font-semibold text-slate-700">Kapasitas Kursi</label>
                  <input
                    type="number"
                    min={10}
                    max={50}
                    value={newClassCapacity}
                    onChange={(e) => setNewClassCapacity(parseInt(e.target.value) || 36)}
                    className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-xs focus:border-blue-500 focus:outline-hidden"
                  />
                </div>
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-700">Jurusan / Konsentrasi</label>
                <input
                  type="text"
                  placeholder="MIPA, IPS, PPLG, dsb"
                  value={newClassMajor}
                  onChange={(e) => setNewClassMajor(e.target.value)}
                  className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-xs focus:border-blue-500 focus:outline-hidden"
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-700">Wali Kelas (Opsional)</label>
                <select
                  value={newClassWaliId}
                  onChange={(e) => setNewClassWaliId(e.target.value)}
                  className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-xs focus:border-blue-500 focus:outline-hidden"
                >
                  <option value="">-- Tentukan Nanti --</option>
                  {teachers.map((t) => (
                    <option key={t.id} value={t.id}>
                      {t.full_name}
                    </option>
                  ))}
                </select>
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setAddClassModalOpen(false)}
                  className="rounded-xl border border-slate-200 bg-white px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-50"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="rounded-xl bg-blue-700 hover:bg-blue-800 px-4 py-2 text-xs font-semibold text-white shadow-xs"
                >
                  Buat Rombel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
