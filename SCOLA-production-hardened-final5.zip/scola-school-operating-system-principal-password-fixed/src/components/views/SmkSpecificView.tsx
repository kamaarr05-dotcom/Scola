import React, { useState } from 'react';
import {
  Briefcase,
  Building2,
  Calendar,
  CheckCircle2,
  Clock,
  Plus,
  Award,
  BookOpen,
  MapPin,
  ExternalLink,
} from 'lucide-react';
import { UserProfile } from '../../types';

interface SmkSpecificViewProps {
  currentUser: UserProfile;
}

export const SmkSpecificView: React.FC<SmkSpecificViewProps> = ({ currentUser }) => {
  const [activeTab, setActiveTab] = useState<'PKL' | 'JURNAL' | 'UKK' | 'INDUSTRI'>('PKL');
  const [addJurnalModalOpen, setAddJurnalModalOpen] = useState(false);

  const [jurnalActivity, setJurnalActivity] = useState('');
  const [jurnalCompetency, setJurnalCompetency] = useState('');
  const [jurnalHours, setJurnalHours] = useState(8);

  const [jurnalList, setJurnalList] = useState([
    {
      id: 'jrn-1',
      date: '15 September 2024',
      student: 'Rizky Firmansyah',
      company: 'PT Telkom Akses Bandung',
      activity: 'Konfigurasi Mikrotik Router & Penyambungan Fiber Optic FTTH',
      competency: 'Teknik Jaringan Komputer & Telekomunikasi',
      hours: 8,
      status: 'DISETUJUI_PEMBIMBING',
    },
    {
      id: 'jrn-2',
      date: '14 September 2024',
      student: 'Rizky Firmansyah',
      company: 'PT Telkom Akses Bandung',
      activity: 'Troubleshooting Optical Power Meter (OPM) dan Fusion Splicing',
      competency: 'K3 & Pengukuran Redaman Kabel Optik',
      hours: 8,
      status: 'MENUNGGU_VERIFIKASI',
    },
  ]);

  const handleAddJurnal = (e: React.FormEvent) => {
    e.preventDefault();
    const newEntry = {
      id: `jrn-${Date.now()}`,
      date: new Date().toLocaleDateString('id-ID', {
        day: 'numeric',
        month: 'long',
        year: 'numeric',
      }),
      student: currentUser.full_name || 'Rizky Firmansyah',
      company: 'PT Telkom Akses Bandung',
      activity: jurnalActivity,
      competency: jurnalCompetency,
      hours: Number(jurnalHours),
      status: 'MENUNGGU_VERIFIKASI',
    };
    setJurnalList([newEntry, ...jurnalList]);
    setAddJurnalModalOpen(false);
    setJurnalActivity('');
    setJurnalCompetency('');
  };

  return (
    <div className="space-y-6">
      {/* Banner */}
      <div className="rounded-2xl bg-gradient-to-r from-emerald-900 via-teal-900 to-slate-900 p-6 text-white shadow-xl">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-2 rounded-full bg-emerald-500/20 px-3 py-1 text-xs font-semibold text-emerald-300 border border-emerald-400/30">
              <Briefcase className="h-3.5 w-3.5" />
              <span>Pusat Kejuruan Vokasi & Link and Match SMK</span>
            </div>
            <h1 className="mt-2 text-2xl font-extrabold tracking-tight sm:text-3xl">
              Praktik Kerja Lapangan (PKL) & Sertifikasi UKK
            </h1>
            <p className="mt-1 text-xs sm:text-sm text-slate-300">
              Integrasi kurikulum merdeka vokasi: pembimbingan industri, jurnal harian digital, dan asesmen kompetensi kerja.
            </p>
          </div>

          <button
            onClick={() => setAddJurnalModalOpen(true)}
            className="flex items-center gap-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 px-4 py-2.5 text-xs font-bold text-slate-950 shadow-md transition-colors"
          >
            <Plus className="h-4 w-4" />
            <span>Isi Jurnal Harian PKL</span>
          </button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
        <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-xs">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-xs font-semibold uppercase">Mitra Industri (DUDI)</span>
            <Building2 className="h-4 w-4 text-emerald-600" />
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-3xl font-extrabold text-emerald-700">18</span>
            <span className="text-xs text-slate-500 font-medium">Perusahaan MoU Aktif</span>
          </div>
          <div className="mt-3 text-xs text-slate-500">
            Bidang IT, Otomotif, Mekatronika, & Multimedia
          </div>
        </div>

        <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-xs">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-xs font-semibold uppercase">Peserta PKL Berjalan</span>
            <Briefcase className="h-4 w-4 text-blue-600" />
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-3xl font-extrabold text-blue-700">124</span>
            <span className="text-xs text-slate-500 font-medium">Siswa di Industri</span>
          </div>
          <div className="mt-3 text-xs text-slate-500">
            Periode Semester Ganjil (6 Bulan Kerja)
          </div>
        </div>

        <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-xs">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-xs font-semibold uppercase">Kesiapan Sertifikasi UKK</span>
            <Award className="h-4 w-4 text-amber-600" />
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-3xl font-extrabold text-amber-600">92%</span>
            <span className="text-xs text-slate-500 font-medium">Standar LSP-P1</span>
          </div>
          <div className="mt-3 text-xs text-slate-500">
            Terakreditasi Badan Nasional Sertifikasi Profesi (BNSP)
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-200 pb-2">
        <button
          onClick={() => setActiveTab('PKL')}
          className={`flex items-center gap-2 rounded-xl px-4 py-2 text-xs font-semibold transition-all ${
            activeTab === 'PKL'
              ? 'bg-emerald-50 text-emerald-800 shadow-2xs'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <Briefcase className="h-4 w-4" />
          <span>Penempatan PKL Siswa</span>
        </button>
        <button
          onClick={() => setActiveTab('JURNAL')}
          className={`flex items-center gap-2 rounded-xl px-4 py-2 text-xs font-semibold transition-all ${
            activeTab === 'JURNAL'
              ? 'bg-emerald-50 text-emerald-800 shadow-2xs'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <BookOpen className="h-4 w-4" />
          <span>Jurnal Harian PKL ({jurnalList.length})</span>
        </button>
        <button
          onClick={() => setActiveTab('UKK')}
          className={`flex items-center gap-2 rounded-xl px-4 py-2 text-xs font-semibold transition-all ${
            activeTab === 'UKK'
              ? 'bg-emerald-50 text-emerald-800 shadow-2xs'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <Award className="h-4 w-4" />
          <span>Uji Kompetensi Keahlian (UKK)</span>
        </button>
        <button
          onClick={() => setActiveTab('INDUSTRI')}
          className={`flex items-center gap-2 rounded-xl px-4 py-2 text-xs font-semibold transition-all ${
            activeTab === 'INDUSTRI'
              ? 'bg-emerald-50 text-emerald-800 shadow-2xs'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <Building2 className="h-4 w-4" />
          <span>Daftar Mitra DUDI</span>
        </button>
      </div>

      {/* ================= TAB 1: PKL ================= */}
      {activeTab === 'PKL' && (
        <div className="space-y-4">
          <h3 className="text-sm font-bold text-slate-900">Daftar Siswa & Industri Tempat Magang / PKL</h3>
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
            <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-xs">
              <div className="flex items-center justify-between">
                <span className="rounded-md bg-emerald-100 px-2 py-0.5 text-xs font-bold text-emerald-800">
                  Sedang Berlangsung
                </span>
                <span className="text-xs text-slate-400">Juli - Des 2024</span>
              </div>
              <h4 className="mt-3 text-base font-bold text-slate-900">Rizky Firmansyah</h4>
              <div className="text-xs text-slate-500">Kelas: XII PPLG 1 (Pengembangan Perangkat Lunak)</div>

              <div className="mt-4 border-t border-slate-100 pt-3 text-xs space-y-1.5">
                <div className="flex items-center gap-1.5 text-slate-700 font-semibold">
                  <Building2 className="h-3.5 w-3.5 text-emerald-600" />
                  <span>PT Telkom Akses Bandung</span>
                </div>
                <div className="flex items-center gap-1.5 text-slate-500">
                  <MapPin className="h-3.5 w-3.5 text-slate-400" />
                  <span>Jl. Gegerkalong Hilir No. 47</span>
                </div>
                <div className="text-slate-500">
                  Pembimbing Sekolah: <strong>Hendra Kusuma, M.Kom</strong>
                </div>
              </div>
            </div>

            <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-xs">
              <div className="flex items-center justify-between">
                <span className="rounded-md bg-emerald-100 px-2 py-0.5 text-xs font-bold text-emerald-800">
                  Sedang Berlangsung
                </span>
                <span className="text-xs text-slate-400">Juli - Des 2024</span>
              </div>
              <h4 className="mt-3 text-base font-bold text-slate-900">Ananda Putri Wijaya</h4>
              <div className="text-xs text-slate-500">Kelas: XII PPLG 1</div>

              <div className="mt-4 border-t border-slate-100 pt-3 text-xs space-y-1.5">
                <div className="flex items-center gap-1.5 text-slate-700 font-semibold">
                  <Building2 className="h-3.5 w-3.5 text-emerald-600" />
                  <span>Software House Agate Studio</span>
                </div>
                <div className="flex items-center gap-1.5 text-slate-500">
                  <MapPin className="h-3.5 w-3.5 text-slate-400" />
                  <span>Summarecon Bandung</span>
                </div>
                <div className="text-slate-500">
                  Pembimbing Sekolah: <strong>Hendra Kusuma, M.Kom</strong>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ================= TAB 2: JURNAL ================= */}
      {activeTab === 'JURNAL' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-slate-900">Log Aktivitas Harian Siswa di Industri</h3>
            <button
              onClick={() => setAddJurnalModalOpen(true)}
              className="flex items-center gap-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 px-3 py-2 text-xs font-semibold text-white transition-colors"
            >
              <Plus className="h-3.5 w-3.5" />
              <span>Tambah Jurnal Harian</span>
            </button>
          </div>

          <div className="overflow-x-auto rounded-2xl border border-slate-200 bg-white shadow-xs">
            <table className="w-full text-left text-xs text-slate-600">
              <thead className="border-b border-slate-200 bg-slate-50 text-[11px] font-bold uppercase text-slate-500">
                <tr>
                  <th className="px-4 py-3">Tanggal & Jam</th>
                  <th className="px-4 py-3">Siswa</th>
                  <th className="px-4 py-3">Tempat PKL</th>
                  <th className="px-4 py-3">Aktivitas & Kompetensi Diterapkan</th>
                  <th className="px-4 py-3">Status Verifikasi</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {jurnalList.map((j) => (
                  <tr key={j.id} className="hover:bg-slate-50/80">
                    <td className="px-4 py-3.5">
                      <div className="font-bold text-slate-900">{j.date}</div>
                      <div className="text-slate-400">{j.hours} Jam Kerja</div>
                    </td>
                    <td className="px-4 py-3.5 font-semibold text-slate-800">{j.student}</td>
                    <td className="px-4 py-3.5 text-slate-700">{j.company}</td>
                    <td className="px-4 py-3.5">
                      <div className="font-medium text-slate-900">{j.activity}</div>
                      <div className="text-[11px] text-emerald-700 font-semibold mt-0.5">
                        Kompetensi: {j.competency}
                      </div>
                    </td>
                    <td className="px-4 py-3.5">
                      <span
                        className={`rounded-full px-2.5 py-0.5 text-[10px] font-bold ${
                          j.status === 'DISETUJUI_PEMBIMBING'
                            ? 'bg-emerald-100 text-emerald-800'
                            : 'bg-amber-100 text-amber-800'
                        }`}
                      >
                        {j.status === 'DISETUJUI_PEMBIMBING' ? 'Disetujui Pembimbing' : 'Menunggu Review'}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ================= TAB 3: UKK ================= */}
      {activeTab === 'UKK' && (
        <div className="space-y-4">
          <h3 className="text-sm font-bold text-slate-900">Skema Uji Kompetensi Keahlian (UKK) Mandiri & Industri</h3>
          <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-xs space-y-3">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div>
                <h4 className="text-base font-bold text-slate-900">
                  Paket 4: Perancangan Aplikasi Web & Mobile Full-Stack
                </h4>
                <p className="text-xs text-slate-500">
                  Standar Asesor: LSP-Telematika & Asosiasi Industri Perangkat Lunak Indonesia.
                </p>
              </div>
              <span className="rounded-md bg-blue-100 px-3 py-1 text-xs font-bold text-blue-800">
                LSP-P1 SMK
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2 text-xs">
              <div className="rounded-xl bg-slate-50 p-3">
                <span className="text-slate-400 block">Peserta Terdaftar:</span>
                <span className="text-lg font-bold text-slate-900">36 Siswa</span>
              </div>
              <div className="rounded-xl bg-slate-50 p-3">
                <span className="text-slate-400 block">Jadwal Uji Teori & Praktik:</span>
                <span className="text-sm font-bold text-slate-900">20 - 24 November 2024</span>
              </div>
              <div className="rounded-xl bg-slate-50 p-3">
                <span className="text-slate-400 block">Penguji Eksternal:</span>
                <span className="text-sm font-bold text-slate-900">Lead Engineer PT Telkom</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ================= TAB 4: INDUSTRI ================= */}
      {activeTab === 'INDUSTRI' && (
        <div className="space-y-4">
          <h3 className="text-sm font-bold text-slate-900">Daftar Dunia Usaha & Dunia Industri (DUDI) Mitra</h3>
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
            <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-xs">
              <h4 className="text-base font-bold text-slate-900">PT Telkom Akses</h4>
              <p className="text-xs text-slate-500 mt-1">Bidang: Jaringan Telekomunikasi & Fiber Optic</p>
              <div className="mt-3 text-xs text-emerald-700 font-semibold">MoU No: 082/MOU/SMK/2023</div>
            </div>
            <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-xs">
              <h4 className="text-base font-bold text-slate-900">Agate Game Studio</h4>
              <p className="text-xs text-slate-500 mt-1">Bidang: Game Development & Mobile Application</p>
              <div className="mt-3 text-xs text-emerald-700 font-semibold">MoU No: 091/MOU/SMK/2023</div>
            </div>
            <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-xs">
              <h4 className="text-base font-bold text-slate-900">Astra Honda Motor Service</h4>
              <p className="text-xs text-slate-500 mt-1">Bidang: Teknik & Bisnis Sepeda Motor (TBSM)</p>
              <div className="mt-3 text-xs text-emerald-700 font-semibold">MoU No: 104/MOU/SMK/2024</div>
            </div>
          </div>
        </div>
      )}

      {/* Modal Tambah Jurnal */}
      {addJurnalModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 p-4 backdrop-blur-xs">
          <div className="w-full max-w-md rounded-2xl bg-white p-6 shadow-2xl border border-slate-200">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2">
                <BookOpen className="h-5 w-5 text-emerald-600" />
                <h3 className="text-base font-bold text-slate-900">Catat Jurnal Harian PKL</h3>
              </div>
              <button
                onClick={() => setAddJurnalModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 text-lg font-bold"
              >
                &times;
              </button>
            </div>

            <form onSubmit={handleAddJurnal} className="mt-4 space-y-3">
              <div>
                <label className="text-xs font-semibold text-slate-700">Uraian Pekerjaan / Tugas Industri</label>
                <textarea
                  rows={3}
                  required
                  placeholder="Contoh: Menguji dan merakit kabel UTP Cat 6 serta konfigurasi DHCP Server..."
                  value={jurnalActivity}
                  onChange={(e) => setJurnalActivity(e.target.value)}
                  className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-xs focus:border-emerald-500 focus:outline-hidden"
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-700">Kompetensi yang Dipraktikkan</label>
                <input
                  type="text"
                  required
                  placeholder="Contoh: Administrasi Sistem Jaringan"
                  value={jurnalCompetency}
                  onChange={(e) => setJurnalCompetency(e.target.value)}
                  className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-xs focus:border-emerald-500 focus:outline-hidden"
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-700">Durasi Jam Kerja</label>
                <input
                  type="number"
                  min={1}
                  max={12}
                  required
                  value={jurnalHours}
                  onChange={(e) => setJurnalHours(parseInt(e.target.value) || 8)}
                  className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-xs focus:border-emerald-500 focus:outline-hidden"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setAddJurnalModalOpen(false)}
                  className="rounded-xl border border-slate-200 bg-white px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-50"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="rounded-xl bg-emerald-600 hover:bg-emerald-700 px-4 py-2 text-xs font-semibold text-white shadow-xs"
                >
                  Kirim ke Pembimbing
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
