import React, { useState, useEffect } from 'react';
import {
  History,
  Search,
  Filter,
  ShieldCheck,
  AlertTriangle,
  CheckCircle2,
  XCircle,
  RefreshCw,
} from 'lucide-react';
import { AuditLogEntry, UserProfile } from '../../types';
import { auditService } from '../../services/auditService';

interface AuditLogsViewProps {
  currentUser: UserProfile;
}

export const AuditLogsView: React.FC<AuditLogsViewProps> = ({ currentUser }) => {
  const [logs, setLogs] = useState<AuditLogEntry[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<'ALL' | 'SUCCESS' | 'FAILED'>('ALL');
  const [loading, setLoading] = useState(true);

  const isMaster = currentUser.role === 'MASTER';
  const tenantId = currentUser.tenant_id;

  const loadLogs = async () => {
    setLoading(true);
    try {
      const allLogs = await auditService.getLogs({
        tenant_id: isMaster ? undefined : tenantId || undefined,
        limit: 100,
      });
      setLogs(allLogs);
    } catch {
      // Fallback
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadLogs();
  }, [tenantId, isMaster]);

  const filteredLogs = logs.filter((log) => {
    const matchesSearch =
      log.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
      log.event.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (log.details || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
      (log.tenant_id || '').toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'ALL' || log.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  return (
    <div className="space-y-6">
      {/* Banner */}
      <div className="rounded-2xl bg-gradient-to-r from-slate-900 via-blue-950 to-slate-900 p-6 text-white shadow-xl">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-2 rounded-full bg-blue-500/20 px-3 py-1 text-xs font-semibold text-blue-300 border border-blue-400/30">
              <History className="h-3.5 w-3.5" />
              <span>Audit Trail & Keamanan Sistem</span>
            </div>
            <h1 className="mt-2 text-2xl font-extrabold tracking-tight sm:text-3xl">
              {isMaster ? 'Log Audit Global Multi-Tenant' : 'Log Audit Satuan Pendidikan'}
            </h1>
            <p className="mt-1 text-xs sm:text-sm text-slate-300">
              Pencatatan rekam jejak otomatis perubahan kuota lisensi guru, aktivasi akun, login, dan modifikasi data penting.
            </p>
          </div>

          <button
            onClick={loadLogs}
            className="flex items-center gap-2 rounded-xl bg-white/10 hover:bg-white/20 px-4 py-2.5 text-xs font-bold text-white transition-colors"
          >
            <RefreshCw className={`h-4 w-4 ${loading ? 'animate-spin' : ''}`} />
            <span>Segarkan Log</span>
          </button>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3 rounded-2xl border border-slate-200 bg-white p-4 shadow-xs">
        <div className="relative w-full sm:w-80">
          <Search className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
          <input
            type="text"
            placeholder="Cari event, email, atau detail..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full rounded-xl border border-slate-200 pl-9 pr-3 py-2 text-xs text-slate-800 placeholder:text-slate-400 focus:border-blue-500 focus:outline-hidden"
          />
        </div>

        <div className="flex rounded-xl bg-slate-100 p-1 text-xs">
          <button
            onClick={() => setStatusFilter('ALL')}
            className={`rounded-lg px-3 py-1 font-medium transition-all ${
              statusFilter === 'ALL' ? 'bg-white text-blue-700 shadow-xs font-bold' : 'text-slate-600'
            }`}
          >
            Semua Status
          </button>
          <button
            onClick={() => setStatusFilter('SUCCESS')}
            className={`rounded-lg px-3 py-1 font-medium transition-all ${
              statusFilter === 'SUCCESS' ? 'bg-white text-blue-700 shadow-xs font-bold' : 'text-slate-600'
            }`}
          >
            Berhasil (Success)
          </button>
          <button
            onClick={() => setStatusFilter('FAILED')}
            className={`rounded-lg px-3 py-1 font-medium transition-all ${
              statusFilter === 'FAILED' ? 'bg-white text-blue-700 shadow-xs font-bold' : 'text-slate-600'
            }`}
          >
            Gagal / Diblokir
          </button>
        </div>
      </div>

      {/* Table */}
      <div className="overflow-x-auto rounded-2xl border border-slate-200 bg-white shadow-xs">
        <table className="w-full text-left text-xs text-slate-600">
          <thead className="border-b border-slate-200 bg-slate-50 text-[11px] font-bold uppercase text-slate-500">
            <tr>
              <th className="px-4 py-3">Waktu (WIB)</th>
              <th className="px-4 py-3">Nama Event</th>
              <th className="px-4 py-3">Pengguna / Aktor</th>
              <th className="px-4 py-3">Tenant ID</th>
              <th className="px-4 py-3">Status</th>
              <th className="px-4 py-3">Rincian Perubahan</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {filteredLogs.map((log) => (
              <tr key={log.id} className="hover:bg-slate-50/80">
                <td className="px-4 py-3.5 font-mono text-[11px] whitespace-nowrap text-slate-500">
                  {new Date(log.timestamp).toLocaleString('id-ID')}
                </td>
                <td className="px-4 py-3.5">
                  <span className="rounded-md bg-slate-100 px-2 py-0.5 font-mono text-[10px] font-bold text-slate-800">
                    {log.event}
                  </span>
                </td>
                <td className="px-4 py-3.5">
                  <div className="font-semibold text-slate-900">{log.email}</div>
                  <div className="text-[11px] text-slate-400">{log.role || 'GUEST'}</div>
                </td>
                <td className="px-4 py-3.5 font-mono text-[11px] text-slate-500">
                  {log.tenant_id || 'GLOBAL (MASTER)'}
                </td>
                <td className="px-4 py-3.5">
                  <span
                    className={`inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[10px] font-bold ${
                      log.status === 'SUCCESS'
                        ? 'bg-emerald-100 text-emerald-800'
                        : 'bg-red-100 text-red-800'
                    }`}
                  >
                    {log.status === 'SUCCESS' ? (
                      <CheckCircle2 className="h-3 w-3" />
                    ) : (
                      <XCircle className="h-3 w-3" />
                    )}
                    <span>{log.status}</span>
                  </span>
                </td>
                <td className="px-4 py-3.5 text-slate-700 max-w-xs truncate" title={log.details}>
                  {log.details || '-'}
                </td>
              </tr>
            ))}

            {filteredLogs.length === 0 && (
              <tr>
                <td colSpan={6} className="px-4 py-8 text-center text-slate-400">
                  Tidak ada catatan log yang sesuai dengan kriteria filter.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};
