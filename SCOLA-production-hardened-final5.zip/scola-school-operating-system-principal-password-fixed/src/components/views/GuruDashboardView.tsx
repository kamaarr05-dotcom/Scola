import React, { useState, useEffect } from 'react';
import {
  Calendar,
  UserCheck,
  ClipboardList,
  Award,
  GraduationCap,
  Users,
  CheckCircle2,
  Clock,
  BookOpen,
  Phone,
  MessageCircle,
  Save,
  CheckCheck,
  UserPlus,
  ShieldCheck,
  AlertCircle,
  UserX,
} from 'lucide-react';
import {
  UserProfile,
  SchoolClass,
  StudentProfile,
  GradeRecord,
  GradeItem,
  DailyAttendance,
  AttendanceStatus,
  AssessmentType,
} from '../../types';
import { academicRepository } from '../../repositories/academicRepository';
import { hasAssignment } from '../../lib/permissions';
import { DashboardKpiCharts } from '../common/DashboardKpiCharts';

interface GuruDashboardViewProps {
  currentUser: UserProfile;
  onNavigate: (route: string) => void;
}

export const GuruDashboardView: React.FC<GuruDashboardViewProps> = ({ currentUser, onNavigate }) => {
  const [classes, setClasses] = useState<SchoolClass[]>([]);
  const [selectedClassId, setSelectedClassId] = useState<string>('');
  const [students, setStudents] = useState<StudentProfile[]>([]);
  const [attendanceHistory, setAttendanceHistory] = useState<DailyAttendance[]>([]);
  const [gradeHistory, setGradeHistory] = useState<GradeItem[]>([]);
  const [pendingStudents, setPendingStudents] = useState<StudentProfile[]>([]);
  const [approvalLoading, setApprovalLoading] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'SCHEDULE' | 'ATTENDANCE' | 'GRADES' | 'HOMEROOM'>('SCHEDULE');
  const [loading, setLoading] = useState(true);

  // Attendance Form State
  const [attendanceDate, setAttendanceDate] = useState<string>(
    new Date().toISOString().split('T')[0]
  );
  const [attendancePeriod, setAttendancePeriod] = useState<number>(1);
  const [attendanceRecords, setAttendanceRecords] = useState<Record<string, AttendanceStatus>>({});
  const [attendanceNotes, setAttendanceNotes] = useState<Record<string, string>>({});
  const [attendanceSubmitting, setAttendanceSubmitting] = useState(false);

  // Grades Form State
  const [selectedSubject, setSelectedSubject] = useState('Matematika');
  const [assessmentType, setAssessmentType] = useState<AssessmentType>('FORMATIF');
  const [studentGrades, setStudentGrades] = useState<Record<string, number>>({});
  const [studentNotes, setStudentNotes] = useState<Record<string, string>>({});
  const [gradeSubmitting, setGradeSubmitting] = useState(false);

  // Notification Toast
  const [notification, setNotification] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  const tenantId = currentUser.tenant_id;
  const isWaliKelas = hasAssignment(currentUser, 'WALI_KELAS');
  const isWaka = hasAssignment(currentUser, 'WAKA_KURIKULUM') || hasAssignment(currentUser, 'WAKA_KESISWAAN') || hasAssignment(currentUser, 'WAKA_SARPRAS');
  const isKaprog = hasAssignment(currentUser, 'KAPROG');

  const loadClassesAndStudents = async () => {
    if (!tenantId) return;
    setLoading(true);
    try {
      const clsList = await academicRepository.getClassesByTenant(tenantId, currentUser);
      setClasses(clsList);

      const defaultClass = clsList[0]?.id || '';
      setSelectedClassId(defaultClass);

      if (defaultClass) {
        const [stdList, pendingList, attendanceList, gradeList] = await Promise.all([
          academicRepository.getStudentsByClass(tenantId, defaultClass, currentUser),
          academicRepository.getPendingStudents(tenantId, defaultClass, currentUser),
          academicRepository.getAttendance(tenantId, currentUser, { class_id: defaultClass }),
          academicRepository.getGrades(tenantId, currentUser, { class_id: defaultClass }),
        ]);
        setStudents(stdList);
        setPendingStudents(pendingList);
        setAttendanceHistory(attendanceList);
        setGradeHistory(gradeList);

        // Init default attendance records as HADIR
        const initialAtt: Record<string, AttendanceStatus> = {};
        stdList.forEach((s) => {
          initialAtt[s.id] = 'HADIR';
        });
        setAttendanceRecords(initialAtt);
      }
    } catch (err: any) {
      setNotification({ type: 'error', message: err.message || 'Gagal memuat data kelas guru' });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadClassesAndStudents();
  }, [tenantId]);

  // Handle Class Switch
  const handleClassChange = async (newClassId: string) => {
    setSelectedClassId(newClassId);
    if (!tenantId) return;
    try {
      const [stdList, pendingList, attendanceList, gradeList] = await Promise.all([
        academicRepository.getStudentsByClass(tenantId, newClassId, currentUser),
        academicRepository.getPendingStudents(tenantId, newClassId, currentUser),
        academicRepository.getAttendance(tenantId, currentUser, { class_id: newClassId }),
        academicRepository.getGrades(tenantId, currentUser, { class_id: newClassId }),
      ]);
      setStudents(stdList);
      setPendingStudents(pendingList);
      setAttendanceHistory(attendanceList);
      setGradeHistory(gradeList);

      const initialAtt: Record<string, AttendanceStatus> = {};
      const initialGrades: Record<string, number> = {};
      stdList.forEach((s) => {
        initialAtt[s.id] = 'HADIR';
      });
      setAttendanceRecords(initialAtt);
      setStudentGrades(initialGrades);
    } catch (err: any) {
      setNotification({ type: 'error', message: err.message });
    }
  };

  // Handle Approve Student (Wali Kelas Gatekeeper)
  const handleApproveStudent = async (studentId: string, studentName: string) => {
    try {
      setApprovalLoading(studentId);
      await academicRepository.updateStudentStatus(studentId, 'ACTIVE', currentUser);
      setNotification({
        type: 'success',
        message: `Akun siswa "${studentName}" berhasil disetujui oleh Wali Kelas dan kini aktif!`,
      });

      if (selectedClassId && tenantId) {
        const [stdList, pendingList] = await Promise.all([
          academicRepository.getStudentsByClass(tenantId, selectedClassId, currentUser),
          academicRepository.getPendingStudents(tenantId, selectedClassId, currentUser),
        ]);
        setStudents(stdList);
        setPendingStudents(pendingList);
      }
    } catch (err: any) {
      setNotification({
        type: 'error',
        message: err.message || 'Gagal menyetujui akun siswa.',
      });
    } finally {
      setApprovalLoading(null);
    }
  };

  // Handle Reject Student
  const handleRejectStudent = async (studentId: string, studentName: string) => {
    const confirmReject = window.confirm(
      `Apakah Anda yakin ingin menolak / mengembalikan pendaftaran siswa "${studentName}"?`
    );
    if (!confirmReject) return;

    try {
      setApprovalLoading(studentId);
      await academicRepository.updateStudentStatus(studentId, 'INACTIVE', currentUser);
      setNotification({
        type: 'success',
        message: `Pendaftaran siswa "${studentName}" telah ditolak/dibatalkan.`,
      });

      if (selectedClassId && tenantId) {
        const [stdList, pendingList] = await Promise.all([
          academicRepository.getStudentsByClass(tenantId, selectedClassId, currentUser),
          academicRepository.getPendingStudents(tenantId, selectedClassId, currentUser),
        ]);
        setStudents(stdList);
        setPendingStudents(pendingList);
      }
    } catch (err: any) {
      setNotification({
        type: 'error',
        message: err.message || 'Gagal memproses penolakan siswa.',
      });
    } finally {
      setApprovalLoading(null);
    }
  };

  // Mark all students as HADIR
  const handleMarkAllHadir = () => {
    const updated: Record<string, AttendanceStatus> = {};
    students.forEach((s) => {
      updated[s.id] = 'HADIR';
    });
    setAttendanceRecords(updated);
    setNotification({ type: 'success', message: 'Semua siswa ditandai HADIR.' });
  };

  // Save Daily Attendance
  const handleSaveAttendance = async () => {
    if (!tenantId || !selectedClassId) return;
    setAttendanceSubmitting(true);
    try {
      const attendanceBatch = students.map((s) => ({
        student_id: s.id,
        student_name: s.full_name,
        class_id: selectedClassId,
        date: attendanceDate,
        status: attendanceRecords[s.id] || 'HADIR',
        period_number: attendancePeriod,
        notes: attendanceNotes[s.id] || '',
      }));

      await academicRepository.recordAttendanceBatch(tenantId, attendanceBatch, currentUser);
      const refreshedAttendance = await academicRepository.getAttendance(tenantId, currentUser, { class_id: selectedClassId });
      setAttendanceHistory(refreshedAttendance);
      setNotification({
        type: 'success',
        message: `Presensi tanggal ${attendanceDate} untuk kelas berhasil disimpan!`,
      });
    } catch (err: any) {
      setNotification({ type: 'error', message: err.message || 'Gagal menyimpan presensi.' });
    } finally {
      setAttendanceSubmitting(false);
    }
  };

  // Save Grades
  const handleSaveGrades = async () => {
    if (!tenantId || !selectedClassId) return;
    setGradeSubmitting(true);
    try {
      for (const s of students) {
        const score = studentGrades[s.id] !== undefined ? studentGrades[s.id] : null;
        await academicRepository.recordGrade(
          {
            tenant_id: tenantId,
            student_id: s.id,
            student_name: s.full_name,
            class_id: selectedClassId,
            subject_id: `sub-${selectedSubject.toLowerCase()}`,
            subject_name: selectedSubject,
            academic_year_id: 'ay-2024-ganjil',
            semester: 'GANJIL',
            assessment_type: assessmentType,
            score,
            competency_achievement: studentNotes[s.id] || 'Menunjukkan penguasaan materi yang baik.',
          },
          currentUser
        );
      }
      const refreshedGrades = await academicRepository.getGrades(tenantId, currentUser, { class_id: selectedClassId });
      setGradeHistory(refreshedGrades);
      setNotification({
        type: 'success',
        message: `Penilaian ${assessmentType} (${selectedSubject}) berhasil disimpan untuk seluruh siswa!`,
      });
    } catch (err: any) {
      setNotification({ type: 'error', message: err.message || 'Gagal menyimpan nilai.' });
    } finally {
      setGradeSubmitting(false);
    }
  };

  const currentSelectedClass = classes.find((c) => c.id === selectedClassId);

  return (
    <div className="space-y-6">
      {/* Teacher Banner */}
      <div className="rounded-2xl bg-gradient-to-r from-blue-900 via-indigo-900 to-slate-900 p-6 text-white shadow-xl">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-2 rounded-full bg-blue-500/20 px-3 py-1 text-xs font-semibold text-blue-300 border border-blue-400/30">
              <GraduationCap className="h-3.5 w-3.5" />
              <span>Portal Guru & Pengajar</span>
            </div>
            <h1 className="mt-2 text-2xl font-extrabold tracking-tight sm:text-3xl">
              Selamat Bertugas, {currentUser.full_name}
            </h1>
            <p className="mt-1 text-xs sm:text-sm text-slate-300">
              Pengelolaan KBM harian, presensi jam pertama, e-Rapor, dan pembinaan wali kelas.
            </p>
          </div>

          <div className="flex items-center gap-2 flex-wrap">
            {isWaka && (
              <button
                onClick={() => onNavigate('/waka')}
                className="rounded-xl bg-white/10 hover:bg-white/20 px-3 py-2 text-xs font-semibold text-white border border-white/20 transition-colors"
              >
                Buka Modul Waka
              </button>
            )}
            {isKaprog && (
              <button
                onClick={() => onNavigate('/smk')}
                className="rounded-xl bg-amber-500 hover:bg-amber-600 px-3 py-2 text-xs font-bold text-slate-950 transition-colors"
              >
                Buka Modul SMK / PKL
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Notification Toast */}
      {notification && (
        <div
          className={`flex items-center justify-between rounded-xl p-4 text-xs font-medium ${
            notification.type === 'success'
              ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
              : 'bg-red-50 text-red-800 border border-red-200'
          }`}
        >
          <span>{notification.message}</span>
          <button onClick={() => setNotification(null)} className="font-bold underline">
            Tutup
          </button>
        </div>
      )}

      {/* Class Selector Bar */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-4 rounded-2xl border border-slate-200 bg-white p-4 shadow-xs">
        <div className="flex items-center gap-3 w-full sm:w-auto">
          <div className="rounded-xl bg-blue-50 p-2 text-blue-700">
            <Users className="h-5 w-5" />
          </div>
          <div>
            <label className="text-xs font-semibold text-slate-500 block">Pilih Kelas / Rombel Aktif:</label>
            <select
              value={selectedClassId}
              onChange={(e) => handleClassChange(e.target.value)}
              className="mt-0.5 rounded-lg border border-slate-200 px-3 py-1.5 text-xs font-bold text-slate-900 focus:border-blue-500 focus:outline-hidden"
            >
              {classes.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name} ({c.grade_level} - {c.major_or_stream})
                </option>
              ))}
            </select>
          </div>
        </div>

        <div className="flex items-center gap-3 text-xs text-slate-600 w-full sm:w-auto justify-end">
          <div className="rounded-xl bg-slate-50 px-3 py-2 border border-slate-100">
            <span>Jumlah Siswa: </span>
            <strong className="text-slate-900 font-bold">{students.length} Orang</strong>
          </div>
          <div className="rounded-xl bg-slate-50 px-3 py-2 border border-slate-100">
            <span>Wali Kelas: </span>
            <strong className="text-slate-900 font-bold">{currentSelectedClass?.wali_kelas_name || '-'}</strong>
          </div>
        </div>
      </div>

      <DashboardKpiCharts
        attendance={attendanceHistory}
        grades={gradeHistory}
        scopeLabel={currentSelectedClass?.name || 'kelas aktif'}
      />

      {/* Navigation Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-200 pb-2">
        <button
          onClick={() => setActiveTab('SCHEDULE')}
          className={`flex items-center gap-2 rounded-xl px-4 py-2 text-xs font-semibold transition-all ${
            activeTab === 'SCHEDULE'
              ? 'bg-blue-50 text-blue-700 shadow-2xs'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <Calendar className="h-4 w-4" />
          <span>Jadwal Mengajar</span>
        </button>
        <button
          onClick={() => setActiveTab('ATTENDANCE')}
          className={`flex items-center gap-2 rounded-xl px-4 py-2 text-xs font-semibold transition-all ${
            activeTab === 'ATTENDANCE'
              ? 'bg-blue-50 text-blue-700 shadow-2xs'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <UserCheck className="h-4 w-4" />
          <span>Presensi & Absensi</span>
        </button>
        <button
          onClick={() => setActiveTab('GRADES')}
          className={`flex items-center gap-2 rounded-xl px-4 py-2 text-xs font-semibold transition-all ${
            activeTab === 'GRADES'
              ? 'bg-blue-50 text-blue-700 shadow-2xs'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <Award className="h-4 w-4" />
          <span>Input Nilai e-Rapor</span>
        </button>
        {isWaliKelas && (
          <button
            onClick={() => setActiveTab('HOMEROOM')}
            className={`flex items-center gap-2 rounded-xl px-4 py-2 text-xs font-semibold transition-all ${
              activeTab === 'HOMEROOM'
                ? 'bg-emerald-50 text-emerald-800 shadow-2xs font-bold'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <GraduationCap className="h-4 w-4 text-emerald-600" />
            <span>Rombel Wali Kelas & Ortu</span>
            {pendingStudents.length > 0 && (
              <span className="rounded-full bg-amber-500 px-2 py-0.5 text-[10px] font-black text-white shadow-2xs animate-pulse">
                {pendingStudents.length} Menunggu Persetujuan
              </span>
            )}
          </button>
        )}
      </div>

      {/* ================= TAB 1: SCHEDULE ================= */}
      {activeTab === 'SCHEDULE' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-slate-900">Jadwal Tatap Muka Pengajar Hari Ini</h3>
            <span className="rounded-md bg-blue-100 px-2 py-0.5 text-xs font-bold text-blue-800">
              Senin, Semester Ganjil 2024/2025
            </span>
          </div>

          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
            <div className="rounded-2xl border border-blue-200 bg-white p-5 shadow-xs">
              <div className="flex items-center justify-between">
                <span className="rounded-md bg-blue-50 px-2 py-0.5 text-[11px] font-bold text-blue-700">
                  Jam Ke-1 & 2
                </span>
                <span className="text-xs text-slate-400 flex items-center gap-1">
                  <Clock className="h-3 w-3" /> 07:15 - 08:45
                </span>
              </div>
              <h4 className="mt-3 text-base font-bold text-slate-900">Matematika Wajib</h4>
              <div className="text-xs text-slate-500 font-medium">Kelas: X MIPA 1 (Ruang A-101)</div>

              <div className="mt-4 flex items-center gap-2">
                <button
                  onClick={() => setActiveTab('ATTENDANCE')}
                  className="flex-1 rounded-xl bg-blue-700 hover:bg-blue-800 py-1.5 text-xs font-semibold text-white transition-colors text-center"
                >
                  Buka Presensi
                </button>
                <button
                  onClick={() => setActiveTab('GRADES')}
                  className="rounded-xl border border-slate-200 bg-white hover:bg-slate-50 px-3 py-1.5 text-xs font-semibold text-slate-700"
                >
                  Nilai
                </button>
              </div>
            </div>

            <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-xs">
              <div className="flex items-center justify-between">
                <span className="rounded-md bg-slate-100 px-2 py-0.5 text-[11px] font-bold text-slate-700">
                  Jam Ke-3 & 4
                </span>
                <span className="text-xs text-slate-400 flex items-center gap-1">
                  <Clock className="h-3 w-3" /> 09:00 - 10:30
                </span>
              </div>
              <h4 className="mt-3 text-base font-bold text-slate-900">Matematika Wajib</h4>
              <div className="text-xs text-slate-500 font-medium">Kelas: X MIPA 2 (Ruang A-102)</div>

              <div className="mt-4 flex items-center gap-2">
                <button
                  onClick={() => setActiveTab('ATTENDANCE')}
                  className="flex-1 rounded-xl bg-slate-800 hover:bg-slate-900 py-1.5 text-xs font-semibold text-white transition-colors text-center"
                >
                  Buka Presensi
                </button>
              </div>
            </div>

            <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-xs">
              <div className="flex items-center justify-between">
                <span className="rounded-md bg-slate-100 px-2 py-0.5 text-[11px] font-bold text-slate-700">
                  Jam Ke-5 & 6
                </span>
                <span className="text-xs text-slate-400 flex items-center gap-1">
                  <Clock className="h-3 w-3" /> 11:00 - 12:30
                </span>
              </div>
              <h4 className="mt-3 text-base font-bold text-slate-900">Matematika Tingkat Lanjut</h4>
              <div className="text-xs text-slate-500 font-medium">Kelas: XI MIPA 1 (Ruang B-201)</div>

              <div className="mt-4 flex items-center gap-2">
                <button
                  onClick={() => setActiveTab('ATTENDANCE')}
                  className="flex-1 rounded-xl bg-slate-800 hover:bg-slate-900 py-1.5 text-xs font-semibold text-white transition-colors text-center"
                >
                  Buka Presensi
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ================= TAB 2: ATTENDANCE ================= */}
      {activeTab === 'ATTENDANCE' && (
        <div className="space-y-4">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <div>
                <label className="text-xs font-semibold text-slate-500 block">Tanggal Presensi:</label>
                <input
                  type="date"
                  value={attendanceDate}
                  onChange={(e) => setAttendanceDate(e.target.value)}
                  className="rounded-xl border border-slate-200 px-3 py-1.5 text-xs font-bold text-slate-900 focus:border-blue-500 focus:outline-hidden"
                />
              </div>
              <div>
                <label className="text-xs font-semibold text-slate-500 block">Jam Pelajaran:</label>
                <select
                  value={attendancePeriod}
                  onChange={(e) => setAttendancePeriod(parseInt(e.target.value) || 1)}
                  className="rounded-xl border border-slate-200 px-3 py-1.5 text-xs font-bold text-slate-900 focus:border-blue-500 focus:outline-hidden"
                >
                  <option value={1}>Jam Ke-1 (Anchor Harian)</option>
                  <option value={2}>Jam Ke-2</option>
                  <option value={3}>Jam Ke-3</option>
                  <option value={4}>Jam Ke-4</option>
                  <option value={5}>Jam Ke-5</option>
                </select>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={handleMarkAllHadir}
                className="flex items-center gap-1.5 rounded-xl border border-emerald-300 bg-emerald-50 hover:bg-emerald-100 px-3 py-2 text-xs font-semibold text-emerald-800 transition-colors"
              >
                <CheckCheck className="h-3.5 w-3.5" />
                <span>Tandai Semua Hadir</span>
              </button>
              <button
                onClick={handleSaveAttendance}
                disabled={attendanceSubmitting}
                className="flex items-center gap-1.5 rounded-xl bg-blue-700 hover:bg-blue-800 px-4 py-2 text-xs font-semibold text-white shadow-xs transition-colors"
              >
                <Save className="h-3.5 w-3.5" />
                <span>{attendanceSubmitting ? 'Menyimpan...' : 'Simpan Presensi'}</span>
              </button>
            </div>
          </div>

          <div className="overflow-x-auto rounded-2xl border border-slate-200 bg-white shadow-xs">
            <table className="w-full text-left text-xs text-slate-600">
              <thead className="border-b border-slate-200 bg-slate-50 text-[11px] font-bold uppercase text-slate-500">
                <tr>
                  <th className="px-4 py-3">No</th>
                  <th className="px-4 py-3">Nama Lengkap Siswa</th>
                  <th className="px-4 py-3">NISN / NIS</th>
                  <th className="px-4 py-3 text-center">Status Kehadiran</th>
                  <th className="px-4 py-3">Catatan Khusus</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {students.map((student, idx) => {
                  const currentStatus = attendanceRecords[student.id] || 'HADIR';

                  return (
                    <tr key={student.id} className="hover:bg-slate-50/80 transition-colors">
                      <td className="px-4 py-3 font-semibold">{idx + 1}</td>
                      <td className="px-4 py-3 font-bold text-slate-900">{student.full_name}</td>
                      <td className="px-4 py-3 font-mono text-[11px] text-slate-500">
                        {student.nisn} / {student.nis}
                      </td>
                      <td className="px-4 py-3">
                        <div className="flex items-center justify-center gap-1">
                          {(['HADIR', 'SAKIT', 'IZIN', 'ALPA', 'DISPENSASI'] as AttendanceStatus[]).map(
                            (statusOpt) => {
                              const isSelected = currentStatus === statusOpt;
                              return (
                                <button
                                  key={statusOpt}
                                  type="button"
                                  onClick={() =>
                                    setAttendanceRecords((prev) => ({
                                      ...prev,
                                      [student.id]: statusOpt,
                                    }))
                                  }
                                  className={`rounded-lg px-2 py-1 text-[10px] font-bold transition-all ${
                                    isSelected
                                      ? statusOpt === 'HADIR'
                                        ? 'bg-emerald-600 text-white shadow-xs'
                                        : statusOpt === 'SAKIT'
                                        ? 'bg-amber-500 text-white shadow-xs'
                                        : statusOpt === 'IZIN'
                                        ? 'bg-blue-600 text-white shadow-xs'
                                        : statusOpt === 'ALPA'
                                        ? 'bg-red-600 text-white shadow-xs'
                                        : 'bg-purple-600 text-white shadow-xs'
                                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                                  }`}
                                >
                                  {statusOpt}
                                </button>
                              );
                            }
                          )}
                        </div>
                      </td>
                      <td className="px-4 py-3">
                        <input
                          type="text"
                          placeholder="Keterangan..."
                          value={attendanceNotes[student.id] || ''}
                          onChange={(e) =>
                            setAttendanceNotes((prev) => ({
                              ...prev,
                              [student.id]: e.target.value,
                            }))
                          }
                          className="w-full rounded-lg border border-slate-200 px-2 py-1 text-xs focus:border-blue-500 focus:outline-hidden"
                        />
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ================= TAB 3: GRADES ================= */}
      {activeTab === 'GRADES' && (
        <div className="space-y-4">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <div>
                <label className="text-xs font-semibold text-slate-500 block">Mata Pelajaran:</label>
                <select
                  value={selectedSubject}
                  onChange={(e) => setSelectedSubject(e.target.value)}
                  className="rounded-xl border border-slate-200 px-3 py-1.5 text-xs font-bold text-slate-900 focus:border-blue-500 focus:outline-hidden"
                >
                  <option value="Matematika">Matematika Wajib</option>
                  <option value="Bahasa Indonesia">Bahasa Indonesia</option>
                  <option value="Bahasa Inggris">Bahasa Inggris</option>
                  <option value="Fisika">Fisika</option>
                  <option value="Informatika">Informatika</option>
                </select>
              </div>
              <div>
                <label className="text-xs font-semibold text-slate-500 block">Jenis Penilaian:</label>
                <select
                  value={assessmentType}
                  onChange={(e) => setAssessmentType(e.target.value as AssessmentType)}
                  className="rounded-xl border border-slate-200 px-3 py-1.5 text-xs font-bold text-slate-900 focus:border-blue-500 focus:outline-hidden"
                >
                  <option value="FORMATIF">Formatif / Tugas Harian</option>
                  <option value="SUMATIF_LINGKUP_MATERI">Sumatif Lingkup Materi (UH)</option>
                  <option value="SUMATIF_AKHIR_SEMESTER">Sumatif Akhir Semester (PAS)</option>
                  <option value="PRAKTIK">Ujian Praktik / Kinerja</option>
                  <option value="PROYEK_P5">Proyek P5 (Profil Pelajar Pancasila)</option>
                </select>
              </div>
            </div>

            <button
              onClick={handleSaveGrades}
              disabled={gradeSubmitting}
              className="flex items-center gap-1.5 rounded-xl bg-blue-700 hover:bg-blue-800 px-4 py-2 text-xs font-semibold text-white shadow-xs transition-colors"
            >
              <Save className="h-3.5 w-3.5" />
              <span>{gradeSubmitting ? 'Menyimpan...' : 'Simpan Nilai Siswa'}</span>
            </button>
          </div>

          <div className="overflow-x-auto rounded-2xl border border-slate-200 bg-white shadow-xs">
            <table className="w-full text-left text-xs text-slate-600">
              <thead className="border-b border-slate-200 bg-slate-50 text-[11px] font-bold uppercase text-slate-500">
                <tr>
                  <th className="px-4 py-3">No</th>
                  <th className="px-4 py-3">Nama Siswa</th>
                  <th className="px-4 py-3">NISN</th>
                  <th className="px-4 py-3 w-32">Nilai (0 - 100)</th>
                  <th className="px-4 py-3">Capaian Kompetensi / Deskripsi Rapor</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {students.map((student, idx) => (
                  <tr key={student.id} className="hover:bg-slate-50/80 transition-colors">
                    <td className="px-4 py-3 font-semibold">{idx + 1}</td>
                    <td className="px-4 py-3 font-bold text-slate-900">{student.full_name}</td>
                    <td className="px-4 py-3 font-mono text-[11px] text-slate-400">{student.nisn}</td>
                    <td className="px-4 py-3">
                      <input
                        type="number"
                        min={0}
                        max={100}
                        value={studentGrades[student.id] !== undefined ? studentGrades[student.id] : undefined}
                        onChange={(e) =>
                          setStudentGrades((prev) => ({
                            ...prev,
                            [student.id]: parseFloat(e.target.value) || 0,
                          }))
                        }
                        className="w-24 rounded-lg border border-slate-200 px-2 py-1 text-xs font-bold text-blue-700 focus:border-blue-500 focus:outline-hidden"
                      />
                    </td>
                    <td className="px-4 py-3">
                      <input
                        type="text"
                        placeholder="Deskripsi pencapaian kompetensi..."
                        value={studentNotes[student.id] || ''}
                        onChange={(e) =>
                          setStudentNotes((prev) => ({
                            ...prev,
                            [student.id]: e.target.value,
                          }))
                        }
                        className="w-full rounded-lg border border-slate-200 px-2 py-1 text-xs focus:border-blue-500 focus:outline-hidden"
                      />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ================= TAB 4: HOMEROOM (WALI KELAS) ================= */}
      {activeTab === 'HOMEROOM' && isWaliKelas && (
        <div className="space-y-6">
          {/* Section 1: Gatekeeper Persetujuan Akun Siswa Baru (PENDING -> ACTIVE) */}
          <div className="rounded-2xl border border-amber-300 bg-gradient-to-br from-amber-50/70 via-white to-orange-50/40 p-5 shadow-xs">
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 border-b border-amber-200/80 pb-3">
              <div className="flex items-center gap-3">
                <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-amber-500 text-white shadow-xs">
                  <ShieldCheck className="h-5 w-5" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="text-sm font-black text-slate-900">
                      Persetujuan Akun Siswa Baru (Wali Kelas Gatekeeper)
                    </h3>
                    <span
                      className={`rounded-full px-2.5 py-0.5 text-[10px] font-extrabold ${
                        pendingStudents.length > 0
                          ? 'bg-amber-100 text-amber-900 border border-amber-300'
                          : 'bg-emerald-100 text-emerald-800'
                      }`}
                    >
                      {pendingStudents.length} Menunggu Persetujuan
                    </span>
                  </div>
                  <p className="text-xs text-slate-600 mt-0.5">
                    Akun siswa yang mendaftar mandiri berada dalam status <strong>PENDING</strong>. Akun baru aktif setelah disetujui oleh Anda sebagai Wali Kelas.
                  </p>
                </div>
              </div>
            </div>

            {pendingStudents.length === 0 ? (
              <div className="mt-4 flex items-center gap-3 rounded-xl bg-white p-4 text-xs font-medium text-slate-600 border border-slate-200">
                <CheckCircle2 className="h-4 w-4 text-emerald-600 shrink-0" />
                <span>Semua pendaftaran siswa untuk rombel ini telah diverifikasi dan aktif. Tidak ada akun tertunda.</span>
              </div>
            ) : (
              <div className="mt-4 grid grid-cols-1 gap-3 md:grid-cols-2">
                {pendingStudents.map((pStd) => (
                  <div
                    key={pStd.id}
                    className="rounded-xl border border-amber-200 bg-white p-4 shadow-2xs hover:shadow-xs transition-shadow"
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-xs text-slate-900">{pStd.full_name}</span>
                          <span className="rounded-md bg-amber-100 px-1.5 py-0.5 text-[10px] font-bold text-amber-800">
                            PENDING
                          </span>
                        </div>
                        <div className="mt-1 text-[11px] font-mono text-slate-500">
                          NISN: {pStd.nisn} • NIS: {pStd.nis}
                        </div>
                        <div className="mt-1 text-[11px] text-slate-600">
                          Jalur: <strong>{pStd.sma_peminatan || pStd.kompetensi_keahlian || 'Reguler'}</strong>
                        </div>
                        <div className="mt-1 text-[11px] text-slate-600">
                          Orang Tua: <strong>{pStd.parent_name || '-'}</strong> ({pStd.parent_relation || 'Wali'}) • WA: {pStd.parent_whatsapp || '-'}
                        </div>
                        <div className="mt-1 text-[10px] text-slate-400">
                          Tgl Daftar: {pStd.registration_date}
                        </div>
                      </div>
                    </div>

                    <div className="mt-3 flex items-center justify-end gap-2 border-t border-slate-100 pt-2.5">
                      <button
                        onClick={() => handleRejectStudent(pStd.id, pStd.full_name)}
                        disabled={approvalLoading === pStd.id}
                        className="flex items-center gap-1 rounded-lg border border-red-200 bg-white hover:bg-red-50 px-2.5 py-1.5 text-[11px] font-bold text-red-600 transition-colors"
                      >
                        <UserX className="h-3.5 w-3.5" />
                        <span>Tolak</span>
                      </button>
                      <button
                        onClick={() => handleApproveStudent(pStd.id, pStd.full_name)}
                        disabled={approvalLoading === pStd.id}
                        className="flex items-center gap-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 px-3 py-1.5 text-[11px] font-bold text-white shadow-2xs transition-colors"
                      >
                        <CheckCircle2 className="h-3.5 w-3.5" />
                        <span>{approvalLoading === pStd.id ? 'Memproses...' : 'Setujui & Aktifkan'}</span>
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Section 2: Buku Induk Siswa Aktif Rombel */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-sm font-bold text-slate-900">Buku Induk & Komunikasi Rombel Wali Kelas</h3>
                <p className="text-xs text-slate-500">
                  Daftar siswa aktif terverifikasi, kontak orang tua murid, dan kanal komunikasi langsung.
                </p>
              </div>
              <span className="rounded-lg bg-slate-100 px-2.5 py-1 text-xs font-bold text-slate-700">
                {students.length} Siswa Aktif
              </span>
            </div>

            <div className="overflow-x-auto rounded-2xl border border-slate-200 bg-white shadow-xs">
              <table className="w-full text-left text-xs text-slate-600">
                <thead className="border-b border-slate-200 bg-slate-50 text-[11px] font-bold uppercase text-slate-500">
                  <tr>
                    <th className="px-4 py-3">Nama Siswa</th>
                    <th className="px-4 py-3">NISN / NIS</th>
                    <th className="px-4 py-3">Nama Orang Tua / Wali</th>
                    <th className="px-4 py-3">WhatsApp Ortu</th>
                    <th className="px-4 py-3">Status Akun</th>
                    <th className="px-4 py-3 text-right">Kontak</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {students.map((student) => (
                    <tr key={student.id} className="hover:bg-slate-50/80 transition-colors">
                      <td className="px-4 py-3.5">
                        <div className="font-bold text-slate-900">{student.full_name}</div>
                        <div className="text-[11px] text-slate-400">{student.address || 'Alamat belum diisi'}</div>
                      </td>
                      <td className="px-4 py-3.5 font-mono text-[11px]">
                        <div>{student.nisn}</div>
                        <div className="text-slate-400">{student.nis}</div>
                      </td>
                      <td className="px-4 py-3.5">
                        <div className="font-semibold text-slate-800">{student.parent_name || 'Santoso Wijaya'}</div>
                        <div className="text-[11px] text-slate-400">Ayah Kandung</div>
                      </td>
                      <td className="px-4 py-3.5 font-mono text-[11px]">
                        {student.parent_whatsapp || '081298765432'}
                      </td>
                      <td className="px-4 py-3.5">
                        <span className="inline-flex items-center gap-1 rounded-full bg-emerald-100 px-2 py-0.5 text-[10px] font-bold text-emerald-800">
                          <CheckCircle2 className="h-3 w-3" />
                          <span>Aktif & Terverifikasi</span>
                        </span>
                      </td>
                      <td className="px-4 py-3.5 text-right">
                        <a
                          href={`https://wa.me/62${(student.parent_whatsapp || '081298765432').replace(/^0/, '')}?text=Halo%20Bapak%2FIbu%20wali%20murid%20${encodeURIComponent(student.full_name)}`}
                          target="_blank"
                          rel="noreferrer"
                          className="inline-flex items-center gap-1 rounded-lg bg-emerald-600 hover:bg-emerald-700 px-2.5 py-1 text-xs font-semibold text-white shadow-2xs transition-colors"
                        >
                          <MessageCircle className="h-3.5 w-3.5" />
                          <span>WhatsApp</span>
                        </a>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
