import React, { useEffect, useState } from 'react';
import { Mail, Building, FileCheck, Plus, Printer, Users, RefreshCw } from 'lucide-react';
import { UserProfile, SchoolFacility, SchoolLetter, StudentProfile } from '../../types';
import { academicRepository } from '../../repositories/academicRepository';

interface Props { currentUser: UserProfile; }

type Tab = 'SURAT' | 'SARPRAS' | 'LEGALISIR';

export const TenagaKependidikanView: React.FC<Props> = ({ currentUser }) => {
  const tenantId = currentUser.tenant_id;
  const [activeTab, setActiveTab] = useState<Tab>('SURAT');
  const [letters, setLetters] = useState<SchoolLetter[]>([]);
  const [facilities, setFacilities] = useState<SchoolFacility[]>([]);
  const [students, setStudents] = useState<StudentProfile[]>([]);
  const [search, setSearch] = useState('');
  const [modal, setModal] = useState(false);
  const [type, setType] = useState('SURAT_KETERANGAN_AKTIF');
  const [studentId, setStudentId] = useState('');
  const [purpose, setPurpose] = useState('');
  const [notice, setNotice] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  const load = async () => {
    if (!tenantId) return;
    setLoading(true);
    try {
      const [letterData, facilityData, studentData] = await Promise.all([
        academicRepository.getOfficialLetters(tenantId),
        academicRepository.getSchoolFacilities(tenantId),
        academicRepository.getStudentsByTenant(tenantId, currentUser),
      ]);
      setLetters(letterData);
      setFacilities(facilityData);
      setStudents(studentData);
      if (!studentId) setStudentId(studentData[0]?.id || '');
    } finally { setLoading(false); }
  };

  useEffect(() => { load(); }, [tenantId, currentUser.id]);

  const handleCreateLetter = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!tenantId) return;
    const student = students.find((s) => s.id === studentId);
    try {
      const letter = await academicRepository.createLetter({
        tenant_id: tenantId,
        letter_number: `421.3/${String(letters.length + 86).padStart(3, '0')}/SCOLA/${new Date().getFullYear()}`,
        letter_type: type,
        type,
        subject: purpose,
        sender_or_recipient: student?.full_name || 'Umum',
        recipient: student?.full_name || 'Umum',
        date: new Date().toISOString().slice(0, 10),
        created_date: new Date().toISOString(),
        created_by_name: currentUser.full_name,
        status: 'SELESAI',
      }, currentUser);
      setLetters((prev) => [letter, ...prev]);
      setModal(false); setPurpose('');
      setNotice(`Surat ${letter.letter_number} berhasil diterbitkan.`);
      setTimeout(() => setNotice(null), 3500);
    } catch (err: any) { setNotice(err.message || 'Gagal menerbitkan surat.'); }
  };

  const filteredLetters = letters.filter((l) => `${l.letter_number} ${l.letter_type || l.type || ''} ${l.subject} ${l.recipient || ''}`.toLowerCase().includes(search.toLowerCase()));
  const good = facilities.filter((f) => f.condition === 'BAIK').length;
  const needsRepair = facilities.filter((f) => f.condition !== 'BAIK').length;

  return <div className="space-y-6">
    <div className="rounded-2xl bg-gradient-to-r from-blue-900 via-indigo-900 to-slate-900 p-6 text-white shadow-xl">
      <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <div><div className="inline-flex items-center gap-2 rounded-full border border-blue-400/30 bg-blue-500/20 px-3 py-1 text-xs font-semibold text-blue-300"><Building className="h-3.5 w-3.5"/> Portal Tata Usaha & Kependidikan</div><h1 className="mt-2 text-2xl font-extrabold sm:text-3xl">Layanan Administrasi Sekolah</h1><p className="mt-1 text-xs text-slate-300 sm:text-sm">Persuratan, sarana-prasarana, dan layanan legalisir alumni.</p></div>
        <button onClick={() => setModal(true)} className="inline-flex items-center gap-2 rounded-xl bg-blue-600 px-4 py-2.5 text-xs font-bold text-white"><Plus className="h-4 w-4"/> Terbitkan Surat Baru</button>
      </div>
    </div>
    {notice && <div className={`rounded-xl p-4 text-xs font-semibold ${notice.startsWith('Surat') ? 'border border-emerald-200 bg-emerald-50 text-emerald-800' : 'border border-red-200 bg-red-50 text-red-800'}`}>{notice}</div>}

    <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
      <Mini label="Surat Tersimpan" value={String(letters.length)} />
      <Mini label="Inventaris Baik" value={String(good)} />
      <Mini label="Perlu Perhatian" value={String(needsRepair)} />
    </div>

    <div className="flex gap-2 overflow-x-auto border-b border-slate-200 pb-2">
      {([['SURAT', Mail, 'Persuratan'], ['SARPRAS', Building, 'Sarana & Inventaris'], ['LEGALISIR', FileCheck, 'Legalisir Ijazah']] as const).map(([id, Icon, label]) => <button key={id} onClick={() => setActiveTab(id)} className={`flex shrink-0 items-center gap-2 rounded-xl px-4 py-2 text-xs font-semibold ${activeTab === id ? 'bg-blue-50 text-blue-700' : 'text-slate-600 hover:bg-slate-50'}`}><Icon className="h-4 w-4"/>{label}</button>)}
    </div>

    {loading ? <div className="rounded-2xl border border-slate-200 bg-white p-8 text-center text-xs text-slate-500">Memuat administrasi...</div> : activeTab === 'SURAT' ? <section className="space-y-3">
      <div className="flex items-center gap-2"><input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Cari nomor, penerima, atau jenis surat..." className="w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs outline-none focus:border-blue-500"/><button onClick={load} className="rounded-xl border border-slate-200 bg-white p-2 text-slate-600" title="Muat ulang"><RefreshCw className="h-4 w-4"/></button></div>
      <div className="overflow-x-auto rounded-2xl border border-slate-200 bg-white shadow-xs"><table className="w-full text-left text-xs text-slate-600"><thead className="border-b border-slate-200 bg-slate-50 text-[10px] font-bold uppercase"><tr><th className="px-4 py-3">Nomor/Tanggal</th><th className="px-4 py-3">Jenis</th><th className="px-4 py-3">Penerima</th><th className="px-4 py-3">Keperluan</th><th className="px-4 py-3">Status</th><th className="px-4 py-3"/></tr></thead><tbody className="divide-y divide-slate-100">{filteredLetters.map((l) => <tr key={l.id}><td className="px-4 py-3"><b className="font-mono text-slate-900">{l.letter_number}</b><div className="text-[10px] text-slate-400">{l.date || l.created_date || '-'}</div></td><td className="px-4 py-3">{l.letter_type || l.type || '-'}</td><td className="px-4 py-3 font-semibold text-slate-800">{l.recipient || l.sender_or_recipient || '-'}</td><td className="px-4 py-3">{l.subject || '-'}</td><td className="px-4 py-3"><span className="rounded-full bg-emerald-100 px-2 py-1 text-[10px] font-bold text-emerald-800">{l.status}</span></td><td className="px-4 py-3 text-right"><button onClick={() => window.print()} className="rounded-lg border border-slate-200 p-1.5"><Printer className="h-4 w-4"/></button></td></tr>)}{!filteredLetters.length && <tr><td colSpan={6} className="p-8 text-center text-slate-400">Belum ada surat.</td></tr>}</tbody></table></div>
    </section> : activeTab === 'SARPRAS' ? <section className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">{facilities.map((f) => <div key={f.id} className="rounded-2xl border border-slate-200 bg-white p-5 shadow-xs"><div className="flex items-center justify-between"><span className={`rounded-full px-2 py-1 text-[10px] font-bold ${f.condition === 'BAIK' ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'}`}>{f.condition}</span><span className="text-[10px] text-slate-400">{f.code || f.id}</span></div><h3 className="mt-3 font-bold text-slate-900">{f.name}</h3><p className="mt-1 text-xs text-slate-500">{f.location || 'Lokasi belum dicatat'} • Kapasitas {f.capacity}</p><p className="mt-2 text-xs text-slate-600">{f.notes || f.category || 'Inventaris sekolah'}</p></div>)}{!facilities.length && <div className="rounded-2xl border border-slate-200 bg-white p-6 text-xs text-slate-500">Belum ada inventaris.</div>}</section> : <section className="rounded-2xl border border-slate-200 bg-white p-6 shadow-xs"><h3 className="font-bold text-slate-900">Legalisir Ijazah Alumni</h3><p className="mt-2 text-xs text-slate-500">Pencatatan layanan legalisir dilakukan sebagai layanan administrasi dokumen, tanpa data keuangan.</p><div className="mt-5 grid gap-3 sm:grid-cols-3"><Mini label="Permohonan Masuk" value="14"/><Mini label="Selesai" value="11"/><Mini label="Dalam Proses" value="3"/></div><div className="mt-5 rounded-xl bg-slate-50 p-4 text-xs text-slate-600"><Users className="mr-2 inline h-4 w-4 text-blue-600"/> Verifikasi identitas alumni dan dokumen dapat ditindaklanjuti oleh petugas TU.</div></section>}

    {modal && <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 p-4"><form onSubmit={handleCreateLetter} className="w-full max-w-md rounded-2xl bg-white p-6 shadow-2xl"><div className="flex items-center justify-between"><h3 className="font-bold text-slate-900">Terbitkan Surat Resmi</h3><button type="button" onClick={() => setModal(false)} className="text-xl text-slate-400">×</button></div><div className="mt-4 space-y-3"><select value={type} onChange={(e) => setType(e.target.value)} className="w-full rounded-xl border border-slate-200 px-3 py-2 text-xs"><option value="SURAT_KETERANGAN_AKTIF">Surat Keterangan Siswa Aktif</option><option value="SURAT_PINDAH">Surat Keterangan Pindah</option><option value="SURAT_DISPENSASI">Surat Dispensasi</option><option value="SURAT_TUGAS">Surat Tugas</option></select><select value={studentId} onChange={(e) => setStudentId(e.target.value)} className="w-full rounded-xl border border-slate-200 px-3 py-2 text-xs"><option value="">Umum / Tanpa siswa</option>{students.map((s) => <option key={s.id} value={s.id}>{s.full_name} — {s.nisn}</option>)}</select><textarea required value={purpose} onChange={(e) => setPurpose(e.target.value)} rows={3} placeholder="Keperluan / perihal surat" className="w-full rounded-xl border border-slate-200 px-3 py-2 text-xs"/><div className="flex justify-end gap-2"><button type="button" onClick={() => setModal(false)} className="rounded-xl border border-slate-200 px-4 py-2 text-xs font-semibold">Batal</button><button className="rounded-xl bg-blue-700 px-4 py-2 text-xs font-bold text-white">Terbitkan</button></div></div></form></div>}
  </div>;
};

const Mini = ({label,value}:{label:string;value:string}) => <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-xs"><p className="text-[10px] font-bold uppercase text-slate-500">{label}</p><p className="mt-2 text-2xl font-extrabold text-slate-900">{value}</p></div>;
