import React, { useState, useEffect } from 'react';
import {
  Calendar,
  Award,
  CheckCircle2,
  Clock,
  BookOpen,
  UserCheck,
  AlertCircle,
  FileText,
  Briefcase,
  ChevronRight,
} from 'lucide-react';
import { UserProfile, GradeRecord, DailyAttendance, StudentProfile, Tenant, AcademicTask, TaskSubmission } from '../../types';
import { academicRepository } from '../../repositories/academicRepository';
import { tenantRepository } from '../../repositories/tenantRepository';

interface SiswaDashboardViewProps {
  currentUser: UserProfile;
  onNavigate: (route: string) => void;
}

export const SiswaDashboardView: React.FC<SiswaDashboardViewProps> = ({ currentUser, onNavigate }) => {
  const [tenant, setTenant] = useState<Tenant | null>(null);
  const [student, setStudent] = useState<StudentProfile | null>(null);
  const [grades, setGrades] = useState<GradeRecord[]>([]);
  const [attendances, setAttendances] = useState<DailyAttendance[]>([]);
  const [activeTab, setActiveTab] = useState<'OVERVIEW' | 'SCHEDULE' | 'GRADES' | 'ATTENDANCE' | 'TASKS'>('OVERVIEW');
  const [tasks, setTasks] = useState<AcademicTask[]>([]);
  const [submissions, setSubmissions] = useState<TaskSubmission[]>([]);
  const [loading, setLoading] = useState(true);

  const tenantId = currentUser.tenant_id;

  useEffect(() => {
    async function loadStudentData() {
      if (!tenantId) return;
      setLoading(true);
      try {
        const [t, sList] = await Promise.all([
          tenantRepository.getById(tenantId),
          academicRepository.getStudentsByTenant(tenantId, currentUser),
        ]);
        setTenant(t);

        // Find current student profile by user_id or email
        const found = sList.find(
          (s) => s.user_id === currentUser.id || s.email?.toLowerCase() === currentUser.email.toLowerCase()
        );
        setStudent(found);

        if (found) {
          const [gList, aList, tList] = await Promise.all([
            academicRepository.getGradesByStudent(tenantId, found.id, currentUser),
            academicRepository.getAttendanceByStudent(tenantId, found.id, currentUser),
            academicRepository.getTasks(tenantId, currentUser, { student_id: found.id }),
          ]);
          const submissionLists = await Promise.all(tList.map((task) => academicRepository.getSubmissions(task.id, currentUser)));
          setGrades(gList);
          setAttendances(aList);
          setTasks(tList);
          setSubmissions(submissionLists.flat());
        }
      } catch {
        // Fallback gracefully
      } finally {
        setLoading(false);
      }
    }
    loadStudentData();
  }, [tenantId, currentUser]);

  const totalAttendanceDays = attendances.length;
  const hadirCount = attendances.filter((a) => a.status === 'HADIR').length;
  const sakitCount = attendances.filter((a) => a.status === 'SAKIT').length;
  const izinCount = attendances.filter((a) => a.status === 'IZIN').length || 0;
  const alpaCount = attendances.filter((a) => a.status === 'ALPA').length || 0;
  const attendanceRate = totalAttendanceDays > 0 ? Math.round((hadirCount / totalAttendanceDays) * 100) : null;

  const averageGrade = grades.length > 0
    ? Math.round(grades.reduce((acc, g) => acc + g.score, 0) / grades.length)
    : null;

  const isSmk = tenant?.type === 'SMK';
  const submittedTaskIds = new Set(submissions.map((s) => s.task_id));
  const pendingTasks = tasks.filter((task) => !submittedTaskIds.has(task.id));

  return (
    <div className="space-y-6">
      {/* Student Banner */}
      <div className="rounded-2xl bg-gradient-to-r from-blue-900 via-indigo-900 to-slate-900 p-6 text-white shadow-xl">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-2 rounded-full bg-blue-500/20 px-3 py-1 text-xs font-semibold text-blue-300 border border-blue-400/30">
              <BookOpen className="h-3.5 w-3.5" />
              <span>Portal Mandiri Siswa</span>
            </div>
            <h1 className="mt-2 text-2xl font-extrabold tracking-tight sm:text-3xl">
              Halo, {student?.full_name || currentUser.full_name}
            </h1>
            <p className="mt-1 text-xs sm:text-sm text-slate-300">
              NISN: {student?.nisn || '—'} • Kelas: {student?.class_name || '—'} • {tenant?.name || '—'}
            </p>
          </div>

          {isSmk && (
            <button
              onClick={() => onNavigate('/smk')}
              className="flex items-center gap-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 px-4 py-2.5 text-xs font-bold text-white shadow-md transition-colors"
            >
              <Briefcase className="h-4 w-4" />
              <span>Jurnal Harian PKL & UKK</span>
              <ChevronRight className="h-4 w-4" />
            </button>
          )}
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
        <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-xs">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-xs font-semibold uppercase">Persentase Kehadiran</span>
            <UserCheck className="h-4 w-4 text-emerald-600" />
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-3xl font-extrabold text-emerald-600">{attendanceRate === null ? '—' : `${attendanceRate}%`}</span>
            <span className="text-xs text-slate-500 font-medium">Semester Ganjil</span>
          </div>
          <div className="mt-3 text-[11px] text-slate-500">
            Hadir: {hadirCount} hari • Sakit: {sakitCount} • Izin: {izinCount} • Alpa: {alpaCount}
          </div>
        </div>

        <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-xs">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-xs font-semibold uppercase">Rata-Rata Nilai</span>
            <Award className="h-4 w-4 text-blue-600" />
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-3xl font-extrabold text-blue-700">{averageGrade === null ? '—' : averageGrade}</span>
            <span className="text-xs text-slate-500 font-medium">Skala 100</span>
          </div>
          <div className="mt-3 text-[11px] text-slate-500">
            Predikat Capaian: <strong className="text-blue-700">Amat Baik (A)</strong>
          </div>
        </div>

        <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-xs">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-xs font-semibold uppercase">Tugas Mendatang</span>
            <Clock className="h-4 w-4 text-amber-600" />
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-3xl font-extrabold text-amber-600">{pendingTasks.length}</span>
            <span className="text-xs text-slate-500 font-medium">Tugas Belum Selesai</span>
          </div>
          <div className="mt-3 text-[11px] text-slate-500">
            {pendingTasks[0]?.title || 'Tidak ada tugas yang tertunda.'}
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-200 pb-2">
        <button
          onClick={() => setActiveTab('OVERVIEW')}
          className={`flex items-center gap-2 rounded-xl px-4 py-2 text-xs font-semibold transition-all ${
            activeTab === 'OVERVIEW'
              ? 'bg-blue-50 text-blue-700 shadow-2xs'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <BookOpen className="h-4 w-4" />
          <span>Jadwal & Agenda</span>
        </button>
        <button
          onClick={() => setActiveTab('GRADES')}
          className={`flex items-center gap-2 rounded-xl px-4 py-2 text-xs font-semibold transition-all ${
            activeTab === 'GRADES'
              ? 'bg-blue-50 text-blue-700 shadow-2xs'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <Award className="h-4 w-4" />
          <span>Nilai & e-Rapor</span>
        </button>
        <button
          onClick={() => setActiveTab('ATTENDANCE')}
          className={`flex items-center gap-2 rounded-xl px-4 py-2 text-xs font-semibold transition-all ${
            activeTab === 'ATTENDANCE'
              ? 'bg-blue-50 text-blue-700 shadow-2xs'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <UserCheck className="h-4 w-4" />
          <span>Rekap Kehadiran</span>
        </button>
        <button
          onClick={() => setActiveTab('TASKS')}
          className={`flex items-center gap-2 rounded-xl px-4 py-2 text-xs font-semibold transition-all ${
            activeTab === 'TASKS'
              ? 'bg-blue-50 text-blue-700 shadow-2xs'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <FileText className="h-4 w-4" />
          <span>Tugas</span>
        </button>
      </div>

      {/* ================= TAB: OVERVIEW & JADWAL ================= */}
      {activeTab === 'OVERVIEW' && (
        <div className="space-y-4">
          <h3 className="text-sm font-bold text-slate-900">Jadwal Pelajaran Kelas Hari Ini</h3>
          <div className="space-y-3">
            <div className="flex items-center justify-between rounded-2xl border border-blue-200 bg-blue-50/50 p-4">
              <div className="flex items-center gap-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-blue-600 text-white font-bold text-xs">
                  01
                </div>
                <div>
                  <div className="text-sm font-bold text-slate-900">Matematika Wajib</div>
                  <div className="text-xs text-slate-500">Guru: Budi Santoso, S.Pd. • 07:15 - 08:45</div>
                </div>
              </div>
              <span className="rounded-full bg-blue-100 px-3 py-1 text-xs font-bold text-blue-800">
                Sedang Berlangsung
              </span>
            </div>

            <div className="flex items-center justify-between rounded-2xl border border-slate-200 bg-white p-4">
              <div className="flex items-center gap-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-slate-100 text-slate-700 font-bold text-xs">
                  02
                </div>
                <div>
                  <div className="text-sm font-bold text-slate-900">Bahasa Indonesia</div>
                  <div className="text-xs text-slate-500">Guru: Dra. Hj. Ratna Sari • 09:00 - 10:30</div>
                </div>
              </div>
              <span className="rounded-full bg-slate-100 px-3 py-1 text-xs font-semibold text-slate-600">
                Jam Ke-2
              </span>
            </div>

            <div className="flex items-center justify-between rounded-2xl border border-slate-200 bg-white p-4">
              <div className="flex items-center gap-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-slate-100 text-slate-700 font-bold text-xs">
                  03
                </div>
                <div>
                  <div className="text-sm font-bold text-slate-900">Fisika / Kejuruan</div>
                  <div className="text-xs text-slate-500">Laboratorium Sains • 11:00 - 12:30</div>
                </div>
              </div>
              <span className="rounded-full bg-slate-100 px-3 py-1 text-xs font-semibold text-slate-600">
                Jam Ke-3
              </span>
            </div>
          </div>
        </div>
      )}

      {/* ================= TAB: GRADES ================= */}
      {activeTab === 'GRADES' && (
        <div className="space-y-4">
          <h3 className="text-sm font-bold text-slate-900">Transkrip Nilai Akademik & Capaian Rapor</h3>
          <div className="overflow-x-auto rounded-2xl border border-slate-200 bg-white shadow-xs">
            <table className="w-full text-left text-xs text-slate-600">
              <thead className="border-b border-slate-200 bg-slate-50 text-[11px] font-bold uppercase text-slate-500">
                <tr>
                  <th className="px-4 py-3">Mata Pelajaran</th>
                  <th className="px-4 py-3">Jenis Asesmen</th>
                  <th className="px-4 py-3">Nilai</th>
                  <th className="px-4 py-3">Capaian Kompetensi</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {grades.length > 0 ? (
                  grades.map((grade) => (
                    <tr key={grade.id} className="hover:bg-slate-50/80">
                      <td className="px-4 py-3 font-bold text-slate-900">{grade.subject_name}</td>
                      <td className="px-4 py-3 font-medium text-slate-600">{grade.assessment_type}</td>
                      <td className="px-4 py-3">
                        <span
                          className={`inline-block rounded-lg px-2.5 py-1 font-extrabold ${
                            grade.score >= 85
                              ? 'bg-emerald-100 text-emerald-800'
                              : grade.score >= 75
                              ? 'bg-blue-100 text-blue-800'
                              : 'bg-amber-100 text-amber-800'
                          }`}
                        >
                          {grade.score}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-slate-600">
                        {grade.competency_achievement || 'Mencapai target kompetensi kurikulum dengan sangat baik.'}
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td className="px-4 py-3 font-bold text-slate-900">Matematika Wajib</td>
                    <td className="px-4 py-3">Formatif 1</td>
                    <td className="px-4 py-3 font-bold text-emerald-700">88</td>
                    <td className="px-4 py-3">Sangat terampil dalam aljabar linear</td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ================= TAB: ATTENDANCE ================= */}
      {activeTab === 'ATTENDANCE' && (
        <div className="space-y-4">
          <h3 className="text-sm font-bold text-slate-900">Riwayat Presensi Harian Siswa</h3>
          <div className="overflow-x-auto rounded-2xl border border-slate-200 bg-white shadow-xs">
            <table className="w-full text-left text-xs text-slate-600">
              <thead className="border-b border-slate-200 bg-slate-50 text-[11px] font-bold uppercase text-slate-500">
                <tr>
                  <th className="px-4 py-3">Tanggal</th>
                  <th className="px-4 py-3">Jam Ke-</th>
                  <th className="px-4 py-3">Status</th>
                  <th className="px-4 py-3">Pencatat Presensi</th>
                  <th className="px-4 py-3">Keterangan</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {attendances.length > 0 ? (
                  attendances.map((att) => (
                    <tr key={att.id} className="hover:bg-slate-50/80">
                      <td className="px-4 py-3 font-bold text-slate-900">{att.date}</td>
                      <td className="px-4 py-3">Jam Ke-{att.period_number}</td>
                      <td className="px-4 py-3">
                        <span
                          className={`rounded-full px-2 py-0.5 text-[10px] font-bold ${
                            att.status === 'HADIR'
                              ? 'bg-emerald-100 text-emerald-800'
                              : att.status === 'SAKIT'
                              ? 'bg-amber-100 text-amber-800'
                              : att.status === 'IZIN'
                              ? 'bg-blue-100 text-blue-800'
                              : 'bg-red-100 text-red-800'
                          }`}
                        >
                          {att.status}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-slate-500">{att.recorded_by_name || 'Guru Piket / KBM'}</td>
                      <td className="px-4 py-3 text-slate-500">{att.notes || '-'}</td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td className="px-4 py-3 font-bold">Hari Ini</td>
                    <td className="px-4 py-3">Jam Ke-1</td>
                    <td className="px-4 py-3 font-bold text-emerald-700">HADIR</td>
                    <td className="px-4 py-3">Budi Santoso, S.Pd.</td>
                    <td className="px-4 py-3">-</td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ================= TAB: TASKS ================= */}
      {activeTab === 'TASKS' && (
        <div className="space-y-4">
          <h3 className="text-sm font-bold text-slate-900">Tugas & Pengumpulan</h3>
          <div className="space-y-3">
            {tasks.length ? tasks.map((task) => {
              const submission = submissions.find((item) => item.task_id === task.id);
              return (
                <div key={task.id} className="rounded-2xl border border-slate-200 bg-white p-4 shadow-xs">
                  <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                    <div>
                      <h4 className="text-sm font-bold text-slate-900">{task.title}</h4>
                      <p className="mt-1 text-xs text-slate-500">{task.subject_name} • Batas {new Date(task.due_date).toLocaleString('id-ID')}</p>
                    </div>
                    <span className={`rounded-full px-3 py-1 text-[10px] font-bold ${submission ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'}`}>
                      {submission ? (submission.status === 'GRADED' ? `DINILAI ${submission.score ?? ''}` : 'TERKUMPUL') : 'BELUM DIKUMPULKAN'}
                    </span>
                  </div>
                  <p className="mt-3 text-xs text-slate-600">{task.description}</p>
                  {submission?.feedback && <p className="mt-2 rounded-lg bg-slate-50 p-2 text-[11px] text-slate-600">Feedback: {submission.feedback}</p>}
                </div>
              );
            }) : <div className="rounded-2xl border border-slate-200 bg-white p-6 text-center text-xs text-slate-500">Belum ada tugas.</div>}
          </div>
        </div>
      )}
    </div>
  );
};
