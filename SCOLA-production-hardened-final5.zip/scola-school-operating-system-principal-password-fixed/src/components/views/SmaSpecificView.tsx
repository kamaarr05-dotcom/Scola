import React, { useState } from 'react';
import {
  BookOpen,
  Award,
  GraduationCap,
  Compass,
  CheckCircle2,
  TrendingUp,
  Target,
  ExternalLink,
} from 'lucide-react';
import { UserProfile } from '../../types';

interface SmaSpecificViewProps {
  currentUser: UserProfile;
}

export const SmaSpecificView: React.FC<SmaSpecificViewProps> = ({ currentUser }) => {
  const [activeTab, setActiveTab] = useState<'PEMINATAN' | 'SNBP' | 'KARIR'>('PEMINATAN');

  return (
    <div className="space-y-6">
      {/* Banner */}
      <div className="rounded-2xl bg-gradient-to-r from-blue-900 via-indigo-900 to-slate-900 p-6 text-white shadow-xl">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-2 rounded-full bg-blue-500/20 px-3 py-1 text-xs font-semibold text-blue-300 border border-blue-400/30">
              <BookOpen className="h-3.5 w-3.5" />
              <span>Kurikulum Merdeka Fase F & Persiapan PTN</span>
            </div>
            <h1 className="mt-2 text-2xl font-extrabold tracking-tight sm:text-3xl">
              Peminatan Mata Pelajaran & Jalur SNBP
            </h1>
            <p className="mt-1 text-xs sm:text-sm text-slate-300">
              Pemilihan mata pelajaran pilihan kelas XI & XII, kalkulator eligible SNBP (Akreditasi A: Kuota 40%), dan portofolio prestasi siswa.
            </p>
          </div>

          <div className="rounded-xl bg-white/10 px-4 py-2 border border-white/20 text-xs">
            <span className="text-slate-300 block">Kuota Siswa Eligible SNBP:</span>
            <strong className="text-emerald-400 text-sm font-extrabold">Top 40% (144 Siswa)</strong>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-200 pb-2">
        <button
          onClick={() => setActiveTab('PEMINATAN')}
          className={`flex items-center gap-2 rounded-xl px-4 py-2 text-xs font-semibold transition-all ${
            activeTab === 'PEMINATAN'
              ? 'bg-blue-50 text-blue-700 shadow-2xs'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <Compass className="h-4 w-4" />
          <span>Paket Mapel Pilihan Fase F</span>
        </button>
        <button
          onClick={() => setActiveTab('SNBP')}
          className={`flex items-center gap-2 rounded-xl px-4 py-2 text-xs font-semibold transition-all ${
            activeTab === 'SNBP'
              ? 'bg-blue-50 text-blue-700 shadow-2xs'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <Award className="h-4 w-4" />
          <span>Simulasi Kuota Eligible SNBP</span>
        </button>
        <button
          onClick={() => setActiveTab('KARIR')}
          className={`flex items-center gap-2 rounded-xl px-4 py-2 text-xs font-semibold transition-all ${
            activeTab === 'KARIR'
              ? 'bg-blue-50 text-blue-700 shadow-2xs'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <GraduationCap className="h-4 w-4" />
          <span>Pilihan Jurusan & Kampus Impian</span>
        </button>
      </div>

      {/* ================= TAB 1: PEMINATAN ================= */}
      {activeTab === 'PEMINATAN' && (
        <div className="space-y-4">
          <h3 className="text-sm font-bold text-slate-900">Struktur Mata Pelajaran Pilihan Fase F (Kelas XI & XII)</h3>
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
            <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-xs">
              <span className="rounded-md bg-blue-100 px-2 py-0.5 text-xs font-bold text-blue-800">
                Klaster Saintek Kedokteran & Teknik
              </span>
              <h4 className="mt-3 text-base font-bold text-slate-900">Paket Eksakta Unggulan</h4>
              <ul className="mt-3 text-xs text-slate-600 space-y-2">
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="h-3.5 w-3.5 text-emerald-600" />
                  <span>Matematika Tingkat Lanjut (5 Jam/Mgg)</span>
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="h-3.5 w-3.5 text-emerald-600" />
                  <span>Fisika Tingkat Lanjut (5 Jam/Mgg)</span>
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="h-3.5 w-3.5 text-emerald-600" />
                  <span>Kimia & Biologi Pilihan (5 Jam/Mgg)</span>
                </li>
              </ul>
            </div>

            <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-xs">
              <span className="rounded-md bg-purple-100 px-2 py-0.5 text-xs font-bold text-purple-800">
                Klaster Soshum Manajemen & Hukum
              </span>
              <h4 className="mt-3 text-base font-bold text-slate-900">Paket Sosial Humaniora</h4>
              <ul className="mt-3 text-xs text-slate-600 space-y-2">
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="h-3.5 w-3.5 text-emerald-600" />
                  <span>Ekonomi & Bisnis (5 Jam/Mgg)</span>
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="h-3.5 w-3.5 text-emerald-600" />
                  <span>Sosiologi (5 Jam/Mgg)</span>
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="h-3.5 w-3.5 text-emerald-600" />
                  <span>Geografi & Bahasa Asing (5 Jam/Mgg)</span>
                </li>
              </ul>
            </div>

            <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-xs">
              <span className="rounded-md bg-amber-100 px-2 py-0.5 text-xs font-bold text-amber-800">
                Klaster Campuran / Lintas Minat
              </span>
              <h4 className="mt-3 text-base font-bold text-slate-900">Informatika & Bisnis Digital</h4>
              <ul className="mt-3 text-xs text-slate-600 space-y-2">
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="h-3.5 w-3.5 text-emerald-600" />
                  <span>Informatika Lanjutan (5 Jam/Mgg)</span>
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="h-3.5 w-3.5 text-emerald-600" />
                  <span>Matematika Tingkat Lanjut (5 Jam/Mgg)</span>
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="h-3.5 w-3.5 text-emerald-600" />
                  <span>Ekonomi Digital (5 Jam/Mgg)</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      )}

      {/* ================= TAB 2: SNBP ================= */}
      {activeTab === 'SNBP' && (
        <div className="space-y-4">
          <h3 className="text-sm font-bold text-slate-900">Perhitungan Pemeringkatan Eligible SNBP Satuan Pendidikan</h3>
          <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-xs space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div>
                <span className="text-xs text-slate-500 font-medium">Dasar Kuota Seleksi:</span>
                <div className="text-base font-bold text-slate-900">Akreditasi A &gt; Kuota 40% Siswa Terbaik</div>
              </div>
              <span className="rounded-full bg-emerald-100 px-3 py-1 text-xs font-bold text-emerald-800">
                144 Kuota Tersedia
              </span>
            </div>

            <div className="text-xs text-slate-600 space-y-2">
              <p>Komponen pemeringkatan sesuai Permendikbudristek:</p>
              <ul className="list-disc pl-5 space-y-1">
                <li>Rata-rata seluruh nilai rapor semester 1 s.d. 5 (Bobot 50%)</li>
                <li>Dua mata pelajaran pendukung program studi yang dituju (Bobot 30%)</li>
                <li>Prestasi kejuaraan tingkat nasional/internasional atau portofolio (Bobot 20%)</li>
              </ul>
            </div>
          </div>
        </div>
      )}

      {/* ================= TAB 3: KARIR ================= */}
      {activeTab === 'KARIR' && (
        <div className="space-y-4">
          <h3 className="text-sm font-bold text-slate-900">Penelusuran Minat Bakat & Kampus PTN Favorit</h3>
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
            <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-xs">
              <h4 className="font-bold text-slate-900">Institut Teknologi Bandung (ITB)</h4>
              <p className="text-xs text-slate-500 mt-1">STEI - Rekayasa Perangkat Lunak</p>
              <div className="mt-3 text-xs text-blue-700 font-semibold">Passing Grade Prediksi: 89.8</div>
            </div>
            <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-xs">
              <h4 className="font-bold text-slate-900">Universitas Indonesia (UI)</h4>
              <p className="text-xs text-slate-500 mt-1">Fakultas Kedokteran (FK)</p>
              <div className="mt-3 text-xs text-blue-700 font-semibold">Passing Grade Prediksi: 92.4</div>
            </div>
            <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-xs">
              <h4 className="font-bold text-slate-900">Universitas Gadjah Mada (UGM)</h4>
              <p className="text-xs text-slate-500 mt-1">Fakultas Ekonomika dan Bisnis</p>
              <div className="mt-3 text-xs text-blue-700 font-semibold">Passing Grade Prediksi: 88.6</div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
