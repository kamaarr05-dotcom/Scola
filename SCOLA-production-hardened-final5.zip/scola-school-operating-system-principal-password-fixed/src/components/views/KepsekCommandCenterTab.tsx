import React, { useState } from 'react';
import { isSupabaseConfigured } from '../../config/supabase';
import {
  Activity,
  AlertTriangle,
  Award,
  BookOpen,
  Building2,
  Calendar,
  CheckCircle2,
  ChevronRight,
  Clock,
  GraduationCap,
  HeartHandshake,
  Layers,
  MessageCircle,
  Radio,
  ShieldAlert,
  ShieldCheck,
  Sparkles,
  Stethoscope,
  TrendingUp,
  UserCheck,
  UserPlus,
  Users,
  Wrench,
  XCircle,
  Zap,
} from 'lucide-react';
import {
  Tenant,
  TeacherProfile,
  SchoolClass,
  AcademicYear,
  LicenseUsage,
  UserProfile,
} from '../../types';

interface KepsekCommandCenterTabProps {
  tenant: Tenant | null;
  licenseUsage: LicenseUsage | null;
  teachers: TeacherProfile[];
  classes: SchoolClass[];
  academicYears: AcademicYear[];
  currentUser: UserProfile;
  onOpenAddTeacher: () => void;
  onSwitchTab: (tab: 'TEACHERS' | 'CLASSES' | 'ACADEMIC_YEAR' | 'PROFILE') => void;
}

export const KepsekCommandCenterTab: React.FC<KepsekCommandCenterTabProps> = ({
  tenant,
  licenseUsage,
  teachers,
  classes,
  academicYears,
  currentUser,
  onOpenAddTeacher,
  onSwitchTab,
}) => {
  const [activeSessionFilter, setActiveSessionFilter] = useState<'ALL' | 'ANOMALY' | 'NORMAL'>('ALL');
  const [notifSent, setNotifSent] = useState<string | null>(null);

  const activeAcademicYear = academicYears.find((y) => y.is_active) || academicYears[0];

  // Calculated Real-Time Metrics
  const totalRombel = classes.length;
  const totalStudents = classes.reduce((sum, c) => sum + (c.total_students || 0), 0);
  const activeTeachersCount = teachers.filter((t) => t.status === 'ACTIVE').length;

  // Real-Time Multi-Period Cross-Check Alerts are shown only from recorded data.
  const attendanceAnomalies: Array<{ id: string; studentName: string; nisn: string; className: string; waliKelas: string; waliPhone: string; parentPhone: string; type: string; title: string; description: string; time: string }> = [];

  // Live Class Rooms Status
  const classroomStatus = isSupabaseConfigured() ? [] : [
    {
      id: 'cls-sma-10-1',
      name: 'X MIPA 1',
      currentSubject: 'Kimia Dasar',
      currentTeacher: 'Dra. Hj. Siti Aminah, M.Pd.',
      session: 'Sesi 2 (Jam 3 - 4)',
      room: 'R. 101 - Lab Sains',
      totalPresent: 34,
      totalCapacity: 36,
      attendanceRate: 94,
      hasAnomaly: true,
      anomalyNote: '1 Siswa Alpa (Jam 3), 1 di UKS',
    },
    {
      id: 'cls-sma-10-2',
      name: 'X MIPA 2',
      currentSubject: 'Matematika Wajib',
      currentTeacher: 'Budi Santoso, S.Pd., M.Si.',
      session: 'Sesi 2 (Jam 3 - 4)',
      room: 'R. 102 - Gedung A',
      totalPresent: 36,
      totalCapacity: 36,
      attendanceRate: 100,
      hasAnomaly: false,
    },
    {
      id: 'cls-sma-11-1',
      name: 'XI MIPA 1',
      currentSubject: 'Bahasa Inggris Lanjutan',
      currentTeacher: 'Ahmad Hidayat, S.Pd. (Guru Inval)',
      session: 'Sesi 2 (Jam 3 - 4)',
      room: 'R. 201 - Gedung B',
      totalPresent: 34,
      totalCapacity: 35,
      attendanceRate: 97,
      hasAnomaly: false,
      isInval: true,
    },
    {
      id: 'cls-sma-11-2',
      name: 'XI IPS 1',
      currentSubject: 'Sosiologi & Antropologi',
      currentTeacher: 'Fatimah Az-Zahra, S.Pd.',
      session: 'Sesi 2 (Jam 3 - 4)',
      room: 'R. 202 - Gedung B',
      totalPresent: 33,
      totalCapacity: 34,
      attendanceRate: 97,
      hasAnomaly: false,
    },
  ];

  const filteredClassrooms = classroomStatus.filter((c) => {
    if (activeSessionFilter === 'ANOMALY') return c.hasAnomaly;
    if (activeSessionFilter === 'NORMAL') return !c.hasAnomaly;
    return true;
  });

  const handleSendWA = (phone: string, studentName: string, reason: string) => {
    const cleanPhone = phone.replace(/^0/, '62');
    const msg = encodeURIComponent(
      `Yth. Bapak/Ibu Wali Murid ${studentName},\n\nKami menginformasikan dari Presensi Digital Sekolah: ${reason}.\nMohon konfirmasi jika ananda sedang ada keperluan darurat atau memerlukan penjemputan.\n\nTerima kasih,\nKepala Sekolah & Tim Ketertiban`
    );
    window.open(`https://wa.me/${cleanPhone}?text=${msg}`, '_blank');
    setNotifSent(`WhatsApp notifikasi dikirim ke wali murid ananda ${studentName}`);
    setTimeout(() => setNotifSent(null), 4000);
  };

  return (
    <div className="space-y-6">
      {/* Toast Notification */}
      {notifSent && (
        <div className="flex items-center justify-between rounded-2xl bg-emerald-50 border border-emerald-200 p-4 text-xs font-semibold text-emerald-900 shadow-xs">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="h-4 w-4 text-emerald-600" />
            <span>{notifSent}</span>
          </div>
          <button onClick={() => setNotifSent(null)} className="font-bold underline text-emerald-700">
            Tutup
          </button>
        </div>
      )}

      {/* Live Operational Status Strip */}
      <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-blue-600 text-white shadow-xs">
              <Radio className="h-5 w-5 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="inline-block h-2.5 w-2.5 rounded-full bg-emerald-500 ring-4 ring-emerald-100" />
                <span className="text-xs font-bold uppercase tracking-wider text-slate-500">
                  Live School Monitor • KBM Hari Ini Sedang Berjalan
                </span>
              </div>
              <div className="text-sm font-extrabold text-slate-900">
                Sesi KBM 2: Jam Pelajaran 3 - 4 (08.45 - 10.15 WIB)
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <span className="rounded-xl bg-blue-50 px-3 py-1.5 text-xs font-bold text-blue-700 border border-blue-200">
              {activeAcademicYear?.name || '2024/2025'} • Semester {activeAcademicYear?.semester || 'GANJIL'}
            </span>
            <button
              onClick={onOpenAddTeacher}
              disabled={licenseUsage?.is_full}
              className="flex items-center gap-1.5 rounded-xl bg-blue-700 hover:bg-blue-800 disabled:bg-slate-400 px-3.5 py-2 text-xs font-bold text-white shadow-xs transition-colors"
            >
              <UserPlus className="h-4 w-4" />
              <span>Tambah Guru & Penugasan</span>
            </button>
          </div>
        </div>
      </div>

      {/* Executive Command Cards Grid */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {/* Metric 1: Kehadiran Siswa Multi-Jam */}
        <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-xs transition-all hover:border-slate-300">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-xs font-bold uppercase tracking-wider">Presensi Siswa Hari Ini</span>
            <div className="rounded-lg bg-emerald-50 p-2 text-emerald-600">
              <UserCheck className="h-4 w-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-3xl font-black text-slate-900">97.2%</span>
            <span className="text-xs font-semibold text-emerald-600 flex items-center gap-0.5">
              <TrendingUp className="h-3 w-3" /> Sangat Baik
            </span>
          </div>
          <div className="mt-3 flex items-center justify-between text-[11px] text-slate-500">
            <span>Hadir: <strong className="text-slate-800">{totalStudents - 3}</strong></span>
            <span>Sakit UKS: <strong className="text-amber-600">1</strong></span>
            <span>Alpa: <strong className="text-red-600">1</strong></span>
          </div>
          <div className="mt-2 h-1.5 w-full rounded-full bg-slate-100 overflow-hidden">
            <div className="h-full rounded-full bg-emerald-500" style={{ width: '97.2%' }} />
          </div>
        </div>

        {/* Metric 2: Dewan Guru & Inval Aktif */}
        <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-xs transition-all hover:border-slate-300">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-xs font-bold uppercase tracking-wider">Dewan Guru Mengajar</span>
            <div className="rounded-lg bg-blue-50 p-2 text-blue-600">
              <GraduationCap className="h-4 w-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-3xl font-black text-slate-900">{activeTeachersCount}</span>
            <span className="text-xs font-semibold text-slate-500">Guru Bertugas</span>
          </div>
          <div className="mt-3 flex items-center justify-between text-[11px] text-slate-500">
            <span>Inval Pengganti: <strong className="text-indigo-600">1 Aktif</strong></span>
            <span>Izin Dinas: <strong className="text-slate-700">1 Guru</strong></span>
          </div>
          <div className="mt-2 text-[11px] text-blue-600 font-semibold cursor-pointer hover:underline" onClick={() => onSwitchTab('TEACHERS')}>
            Kelola SDM & Penugasan &rarr;
          </div>
        </div>

        {/* Metric 3: Rombel & Kesiapan KBM */}
        <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-xs transition-all hover:border-slate-300">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-xs font-bold uppercase tracking-wider">Kesiapan Rombel & KBM</span>
            <div className="rounded-lg bg-indigo-50 p-2 text-indigo-600">
              <Layers className="h-4 w-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-3xl font-black text-slate-900">{totalRombel}</span>
            <span className="text-xs font-semibold text-slate-500">Kelas Aktif</span>
          </div>
          <div className="mt-3 flex items-center justify-between text-[11px] text-slate-500">
            <span>Total Siswa: <strong className="text-slate-800">{totalStudents}</strong></span>
            <span>Kurikulum: <strong className="text-emerald-700">Merdeka</strong></span>
          </div>
          <div className="mt-2 text-[11px] text-indigo-600 font-semibold cursor-pointer hover:underline" onClick={() => onSwitchTab('CLASSES')}>
            Lihat Struktur Rombel &rarr;
          </div>
        </div>

        {/* Metric 4: Kuota Lisensi Satuan Pendidikan */}
        <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-xs transition-all hover:border-slate-300">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-xs font-bold uppercase tracking-wider">Kapasitas Lisensi Guru</span>
            <div className="rounded-lg bg-purple-50 p-2 text-purple-600">
              <ShieldCheck className="h-4 w-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-3xl font-black text-purple-700">
              {licenseUsage?.used_licenses || activeTeachersCount}
            </span>
            <span className="text-xs font-semibold text-slate-500">
              / {licenseUsage?.total_quota || 10} Lisensi
            </span>
          </div>
          <div className="mt-3 flex items-center justify-between text-[11px] text-slate-500">
            <span>Sisa Tersedia: <strong className="text-slate-800">{licenseUsage?.available_licenses || 5} Slot</strong></span>
            <span>Status: <strong className="text-emerald-600">Aman</strong></span>
          </div>
          <div className="mt-2 h-1.5 w-full rounded-full bg-slate-100 overflow-hidden">
            <div
              className={`h-full rounded-full ${licenseUsage?.is_full ? 'bg-red-500' : 'bg-purple-600'}`}
              style={{ width: `${Math.min(100, licenseUsage?.usage_percentage || 50)}%` }}
            />
          </div>
        </div>
      </div>

      {/* Early Warning Section: Deteksi Presensi Multi-Jam (Bolos Jam Siang & Sakit UKS) */}
      <div className="rounded-2xl border border-amber-200 bg-gradient-to-br from-amber-50/70 via-white to-orange-50/40 p-5 shadow-xs">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-3 border-b border-amber-200/60 pb-4">
          <div className="flex items-center gap-3">
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-amber-500 text-white shadow-xs">
              <AlertTriangle className="h-5 w-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-sm font-black text-slate-900">
                  Pusat Deteksi Anomali Presensi Multi-Jam (Cross-Check Sesi)
                </h3>
                <span className="rounded-full bg-red-100 px-2 py-0.5 text-[10px] font-extrabold text-red-800">
                  {attendanceAnomalies.length} Kasus Perlu Perhatian
                </span>
              </div>
              <p className="text-xs text-slate-600">
                Presensi dicatat langsung oleh guru mata pelajaran di setiap jam KBM. Sistem mendeteksi otomatis siswa yang hadir pagi namun tidak ada di jam siang atau izin ke UKS.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setActiveSessionFilter('ALL')}
              className={`rounded-xl px-3 py-1.5 text-xs font-bold transition-all ${
                activeSessionFilter === 'ALL'
                  ? 'bg-slate-900 text-white shadow-xs'
                  : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200'
              }`}
            >
              Semua Sesi ({classroomStatus.length})
            </button>
            <button
              onClick={() => setActiveSessionFilter('ANOMALY')}
              className={`rounded-xl px-3 py-1.5 text-xs font-bold transition-all ${
                activeSessionFilter === 'ANOMALY'
                  ? 'bg-amber-600 text-white shadow-xs'
                  : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200'
              }`}
            >
              Anomali Saja ({attendanceAnomalies.length})
            </button>
          </div>
        </div>

        {/* Anomaly Cards */}
        <div className="mt-4 grid grid-cols-1 gap-3 md:grid-cols-2">
          {attendanceAnomalies.map((anom) => (
            <div
              key={anom.id}
              className="rounded-xl border border-red-200/80 bg-white p-4 shadow-2xs hover:shadow-xs transition-shadow"
            >
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-start gap-3">
                  <div
                    className={`mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center rounded-lg ${
                      anom.type === 'BOLOS_SIANG'
                        ? 'bg-red-100 text-red-700'
                        : 'bg-amber-100 text-amber-700'
                    }`}
                  >
                    {anom.type === 'BOLOS_SIANG' ? (
                      <XCircle className="h-4 w-4" />
                    ) : (
                      <Stethoscope className="h-4 w-4" />
                    )}
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-extrabold text-xs text-slate-900">{anom.studentName}</span>
                      <span className="rounded-md bg-slate-100 px-1.5 py-0.5 text-[10px] font-mono text-slate-600">
                        {anom.nisn}
                      </span>
                      <span className="rounded-md bg-blue-50 px-1.5 py-0.5 text-[10px] font-bold text-blue-700">
                        {anom.className}
                      </span>
                    </div>
                    <div className="mt-1 text-xs font-bold text-red-700">{anom.title}</div>
                    <p className="mt-0.5 text-[11px] text-slate-600 leading-relaxed">{anom.description}</p>
                    <div className="mt-2 text-[10px] text-slate-400">
                      Wali Kelas: <strong>{anom.waliKelas}</strong> • Waktu Deteksi: {anom.time}
                    </div>
                  </div>
                </div>
              </div>

              <div className="mt-3 flex items-center justify-end gap-2 border-t border-slate-100 pt-2.5">
                <button
                  onClick={() =>
                    handleSendWA(
                      anom.parentPhone,
                      anom.studentName,
                      anom.type === 'BOLOS_SIANG'
                        ? 'Ananda tidak terdata di ruang kelas pada Jam Ke-3 (08.45 WIB) meskipun tercatat hadir pagi hari'
                        : 'Ananda saat ini sedang beristirahat di Ruang UKS sekolah'
                    )
                  }
                  className="flex items-center gap-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 px-2.5 py-1.5 text-[11px] font-bold text-white shadow-2xs transition-colors"
                >
                  <MessageCircle className="h-3.5 w-3.5" />
                  <span>Kirim Notifikasi Orang Tua</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* 4 Pilar Wakil Kepala Sekolah (Executive Switchboard) */}
      <div>
        <div className="flex items-center justify-between mb-3">
          <div>
            <h3 className="text-sm font-extrabold text-slate-900">
              Pusat Koordinasi 4 Pilar Wakil Kepala Sekolah (Waka)
            </h3>
            <p className="text-xs text-slate-500">
              Pantauan eksekutif dan sinkronisasi lintas bidang kepemimpinan sekolah secara terpadu.
            </p>
          </div>
          <span className="rounded-full bg-blue-50 px-2.5 py-1 text-[11px] font-bold text-blue-700 border border-blue-200">
            Sistem Terintegrasi
          </span>
        </div>

        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {/* Pilar 1: Waka Kurikulum */}
          <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-xs hover:border-blue-300 transition-all">
            <div className="flex items-center gap-3">
              <div className="rounded-xl bg-blue-50 p-2.5 text-blue-700">
                <BookOpen className="h-5 w-5" />
              </div>
              <div>
                <h4 className="text-xs font-black text-slate-900 uppercase">Waka Kurikulum</h4>
                <div className="text-[11px] text-slate-500">KBM, Inval & Supervisi</div>
              </div>
            </div>
            <div className="mt-4 space-y-2 text-xs">
              <div className="flex items-center justify-between rounded-lg bg-slate-50 p-2 text-slate-700">
                <span>Guru Inval Pengganti:</span>
                <strong className="text-blue-700">1 Bertugas</strong>
              </div>
              <div className="flex items-center justify-between rounded-lg bg-slate-50 p-2 text-slate-700">
                <span>Modul Ajar Guru:</span>
                <strong className="text-emerald-700">88% Lengkap</strong>
              </div>
            </div>
            <div className="mt-4 text-[11px] font-bold text-blue-600 flex items-center gap-1 hover:underline cursor-pointer">
              <span>Buka Modul Kurikulum</span>
              <ChevronRight className="h-3 w-3" />
            </div>
          </div>

          {/* Pilar 2: Waka Kesiswaan */}
          <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-xs hover:border-amber-300 transition-all">
            <div className="flex items-center gap-3">
              <div className="rounded-xl bg-amber-50 p-2.5 text-amber-700">
                <Award className="h-5 w-5" />
              </div>
              <div>
                <h4 className="text-xs font-black text-slate-900 uppercase">Waka Kesiswaan</h4>
                <div className="text-[11px] text-slate-500">Disiplin, Prestasi & Ekskul</div>
              </div>
            </div>
            <div className="mt-4 space-y-2 text-xs">
              <div className="flex items-center justify-between rounded-lg bg-slate-50 p-2 text-slate-700">
                <span>Buku Saku Terbuka:</span>
                <strong className="text-amber-700">2 Siswa</strong>
              </div>
              <div className="flex items-center justify-between rounded-lg bg-slate-50 p-2 text-slate-700">
                <span>Prestasi Baru:</span>
                <strong className="text-emerald-700">3 Piagam</strong>
              </div>
            </div>
            <div className="mt-4 text-[11px] font-bold text-amber-700 flex items-center gap-1 hover:underline cursor-pointer">
              <span>Buka Modul Kesiswaan</span>
              <ChevronRight className="h-3 w-3" />
            </div>
          </div>

          {/* Pilar 3: Waka Sarpras */}
          <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-xs hover:border-emerald-300 transition-all">
            <div className="flex items-center gap-3">
              <div className="rounded-xl bg-emerald-50 p-2.5 text-emerald-700">
                <Wrench className="h-5 w-5" />
              </div>
              <div>
                <h4 className="text-xs font-black text-slate-900 uppercase">Waka Sarpras</h4>
                <div className="text-[11px] text-slate-500">Fasilitas & Pemeliharaan</div>
              </div>
            </div>
            <div className="mt-4 space-y-2 text-xs">
              <div className="flex items-center justify-between rounded-lg bg-slate-50 p-2 text-slate-700">
                <span>Kesiapan Lab & Kelas:</span>
                <strong className="text-emerald-700">98.5% Siap</strong>
              </div>
              <div className="flex items-center justify-between rounded-lg bg-slate-50 p-2 text-slate-700">
                <span>Tiket Perbaikan:</span>
                <strong className="text-blue-700">1 Dalam Proses</strong>
              </div>
            </div>
            <div className="mt-4 text-[11px] font-bold text-emerald-700 flex items-center gap-1 hover:underline cursor-pointer">
              <span>Buka Modul Sarpras</span>
              <ChevronRight className="h-3 w-3" />
            </div>
          </div>

          {/* Pilar 4: Waka Humas */}
          <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-xs hover:border-purple-300 transition-all">
            <div className="flex items-center gap-3">
              <div className="rounded-xl bg-purple-50 p-2.5 text-purple-700">
                <HeartHandshake className="h-5 w-5" />
              </div>
              <div>
                <h4 className="text-xs font-black text-slate-900 uppercase">Waka Humas / DUDI</h4>
                <div className="text-[11px] text-slate-500">Kemitraan Industri & Magang</div>
              </div>
            </div>
            <div className="mt-4 space-y-2 text-xs">
              <div className="flex items-center justify-between rounded-lg bg-slate-50 p-2 text-slate-700">
                <span>MoU Industri Aktif:</span>
                <strong className="text-purple-700">3 Perusahaan</strong>
              </div>
              <div className="flex items-center justify-between rounded-lg bg-slate-50 p-2 text-slate-700">
                <span>Kuota PKL/Magang:</span>
                <strong className="text-slate-800">45 Siswa</strong>
              </div>
            </div>
            <div className="mt-4 text-[11px] font-bold text-purple-700 flex items-center gap-1 hover:underline cursor-pointer">
              <span>Buka Modul Humas</span>
              <ChevronRight className="h-3 w-3" />
            </div>
          </div>
        </div>
      </div>

      {/* Live Classroom Monitor Grid */}
      <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 border-b border-slate-100 pb-4">
          <div>
            <h3 className="text-sm font-extrabold text-slate-900">
              Pantauan Langsung Seluruh Ruang Kelas (Live Rombel Grid)
            </h3>
            <p className="text-xs text-slate-500">
              Status pengajar jam ini, ruangan, dan presensi terkini di masing-masing kelas.
            </p>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold text-slate-400">Total:</span>
            <span className="rounded-lg bg-slate-100 px-2.5 py-1 text-xs font-extrabold text-slate-800">
              {classroomStatus.length} Rombel Terpantau
            </span>
          </div>
        </div>

        <div className="mt-4 grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-4">
          {filteredClassrooms.map((cls) => (
            <div
              key={cls.id}
              className={`rounded-xl border p-4 transition-all ${
                cls.hasAnomaly
                  ? 'border-amber-300 bg-amber-50/40'
                  : 'border-slate-200 bg-white hover:border-slate-300'
              }`}
            >
              <div className="flex items-center justify-between">
                <span className="font-black text-sm text-slate-900">{cls.name}</span>
                <span
                  className={`rounded-full px-2 py-0.5 text-[10px] font-extrabold ${
                    cls.attendanceRate === 100
                      ? 'bg-emerald-100 text-emerald-800'
                      : cls.attendanceRate >= 95
                      ? 'bg-blue-100 text-blue-800'
                      : 'bg-amber-100 text-amber-800'
                  }`}
                >
                  {cls.attendanceRate}% Hadir
                </span>
              </div>

              <div className="mt-2 text-xs font-bold text-blue-700">{cls.currentSubject}</div>
              <div className="text-[11px] text-slate-600 flex items-center gap-1 mt-0.5">
                <GraduationCap className="h-3 w-3 text-slate-400 shrink-0" />
                <span className="truncate">{cls.currentTeacher}</span>
              </div>

              <div className="mt-3 flex items-center justify-between text-[10px] text-slate-400 border-t border-slate-100 pt-2">
                <span>{cls.room}</span>
                <span>
                  {cls.totalPresent}/{cls.totalCapacity} Siswa
                </span>
              </div>

              {cls.isInval && (
                <div className="mt-2 rounded-md bg-indigo-50 px-2 py-1 text-[10px] font-bold text-indigo-700 border border-indigo-200">
                  Diajar Guru Inval Resmi
                </div>
              )}

              {cls.hasAnomaly && (
                <div className="mt-2 rounded-md bg-amber-100 px-2 py-1 text-[10px] font-bold text-amber-800 border border-amber-300">
                  {cls.anomalyNote}
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
