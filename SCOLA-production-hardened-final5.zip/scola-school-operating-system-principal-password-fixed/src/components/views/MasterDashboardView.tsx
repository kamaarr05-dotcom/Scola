import React, { useState, useEffect } from 'react';
import {
  Building2,
  Users,
  CreditCard,
  Plus,
  Search,
  ShieldCheck,
  CheckCircle2,
  XCircle,
  Sliders,
  UserPlus,
  RefreshCw,
  Eye,
  DollarSign,
  AlertTriangle,
} from 'lucide-react';
import { Tenant, UserProfile, LicenseUsage } from '../../types';
import { tenantRepository } from '../../repositories/tenantRepository';
import { userRepository } from '../../repositories/userRepository';
import { teacherLicenseService } from '../../services/teacherLicenseService';
import { teacherAccountService } from '../../services/teacherAccountService';
import { principalAccountService } from '../../services/principalAccountService';
import { TEACHER_LICENSE_PRICE_PER_MONTH } from '../../lib/quotaValidator';

interface MasterDashboardViewProps {
  currentUser: UserProfile;
}

export const MasterDashboardView: React.FC<MasterDashboardViewProps> = ({ currentUser }) => {
  const [tenants, setTenants] = useState<Tenant[]>([]);
  const [usages, setUsages] = useState<Record<string, LicenseUsage>>({});
  const [principals, setPrincipals] = useState<Record<string, UserProfile>>({});
  const [searchTerm, setSearchTerm] = useState('');
  const [filterType, setFilterType] = useState<'ALL' | 'SMA' | 'SMK'>('ALL');
  const [loading, setLoading] = useState(true);

  // Quota Edit Modal State
  const [quotaModalOpen, setQuotaModalOpen] = useState(false);
  const [selectedTenantForQuota, setSelectedTenantForQuota] = useState<Tenant | null>(null);
  const [newQuotaInput, setNewQuotaInput] = useState<number>(20);
  const [quotaReasonInput, setQuotaReasonInput] = useState<string>('');
  const [quotaSubmitting, setQuotaSubmitting] = useState(false);

  // Create Tenant Modal State
  const [createTenantModalOpen, setCreateTenantModalOpen] = useState(false);
  const [newSchoolName, setNewSchoolName] = useState('');
  const [newNpsn, setNewNpsn] = useState('');
  const [newSchoolType, setNewSchoolType] = useState<'SMA' | 'SMK'>('SMA');
  const [newAccreditation, setNewAccreditation] = useState<'A' | 'B' | 'C'>('A');
  const [newProvince, setNewProvince] = useState('DKI Jakarta');
  const [newCity, setNewCity] = useState('Jakarta Selatan');
  const [newAddress, setNewAddress] = useState('');
  const [newPhone, setNewPhone] = useState('');
  const [newEmail, setNewEmail] = useState('');
  const [newInitialQuota, setNewInitialQuota] = useState(30);
  const [createTenantSubmitting, setCreateTenantSubmitting] = useState(false);

  // Create Principal Modal State
  const [createPrincipalModalOpen, setCreatePrincipalModalOpen] = useState(false);
  const [targetTenantForPrincipal, setTargetTenantForPrincipal] = useState<Tenant | null>(null);
  const [principalName, setPrincipalName] = useState('');
  const [principalEmail, setPrincipalEmail] = useState('');
  const [principalPhone, setPrincipalPhone] = useState('');
  const [principalNip, setPrincipalNip] = useState('');
  const [principalPassword, setPrincipalPassword] = useState('');
  const [principalPasswordConfirm, setPrincipalPasswordConfirm] = useState('');
  const [principalSubmitting, setPrincipalSubmitting] = useState(false);
  const [showPrincipalPassword, setShowPrincipalPassword] = useState(false);

  // Create Teacher Modal State
  const [createTeacherModalOpen, setCreateTeacherModalOpen] = useState(false);
  const [targetTenantForTeacher, setTargetTenantForTeacher] = useState<Tenant | null>(null);
  const [teacherName, setTeacherName] = useState('');
  const [teacherEmail, setTeacherEmail] = useState('');
  const [teacherPassword, setTeacherPassword] = useState('');
  const [teacherPasswordConfirm, setTeacherPasswordConfirm] = useState('');
  const [teacherPhone, setTeacherPhone] = useState('');
  const [teacherNip, setTeacherNip] = useState('');
  const [teacherNuptk, setTeacherNuptk] = useState('');
  const [teacherGender, setTeacherGender] = useState<'L' | 'P'>('L');
  const [teacherEmploymentType, setTeacherEmploymentType] = useState<'PNS' | 'PPPK' | 'GTY' | 'GTT'>('GTY');
  const [teacherSpecialty, setTeacherSpecialty] = useState('Matematika');
  const [teacherSubmitting, setTeacherSubmitting] = useState(false);
  const [showTeacherPassword, setShowTeacherPassword] = useState(false);

  // Feedback Notification
  const [notification, setNotification] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  const loadData = async () => {
    setLoading(true);
    try {
      const tenantList = await tenantRepository.getAll();
      setTenants(tenantList);

      const usageList = await teacherLicenseService.getAllTenantsLicenseUsage();
      const usageMap: Record<string, LicenseUsage> = {};
      usageList.forEach((u) => {
        usageMap[u.tenant_id] = u;
      });
      setUsages(usageMap);

      const principalMap: Record<string, UserProfile> = {};
      for (const t of tenantList) {
        const p = await userRepository.getPrincipalByTenant(t.id);
        if (p) principalMap[t.id] = p;
      }
      setPrincipals(principalMap);
    } catch (err: any) {
      setNotification({ type: 'error', message: err.message || 'Gagal memuat data master' });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const totalTenants = tenants.length;
  const totalActiveTenants = tenants.filter((t) => t.is_active).length;
  const totalActiveTeachers: number = (Object.values(usages) as LicenseUsage[]).reduce(
    (acc: number, u: LicenseUsage) => acc + (u?.used_licenses || 0),
    0
  );
  const totalAllocatedQuota: number = tenants.reduce((acc: number, t: Tenant) => acc + (t.teacher_quota || 0), 0);
  const totalMonthlyRevenue: number = totalActiveTeachers * TEACHER_LICENSE_PRICE_PER_MONTH;

  // Handle Quota Update
  const handleOpenQuotaModal = (tenant: Tenant) => {
    setSelectedTenantForQuota(tenant);
    setNewQuotaInput(tenant.teacher_quota);
    setQuotaReasonInput('');
    setQuotaModalOpen(true);
  };

  const handleSaveQuota = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedTenantForQuota) return;
    setQuotaSubmitting(true);
    try {
      await teacherLicenseService.updateTenantQuota({
        tenantId: selectedTenantForQuota.id,
        newQuota: Number(newQuotaInput),
        actor: currentUser,
        reason: quotaReasonInput || 'Penyesuaian kuota lisensi oleh Master',
      });
      setNotification({
        type: 'success',
        message: `Kuota lisensi ${selectedTenantForQuota.name} berhasil diperbarui menjadi ${newQuotaInput} guru.`,
      });
      setQuotaModalOpen(false);
      await loadData();
    } catch (err: any) {
      setNotification({ type: 'error', message: err.message || 'Gagal mengubah kuota guru.' });
    } finally {
      setQuotaSubmitting(false);
    }
  };

  // Handle Toggle Tenant Active Status
  const handleToggleTenantStatus = async (tenant: Tenant) => {
    const newStatus = !tenant.is_active;
    const actionWord = newStatus ? 'mengaktifkan kembali' : 'menonaktifkan';
    const reasonPrompt = window.prompt(
      `Masukkan alasan ${actionWord} layanan sekolah "${tenant.name}":`,
      newStatus ? 'Reaktivasi layanan langganan' : 'Penangguhan operasional berkala'
    );
    if (reasonPrompt === null) return;

    try {
      await tenantRepository.toggleTenantStatus(tenant.id, newStatus, currentUser, reasonPrompt);
      setNotification({
        type: 'success',
        message: `Sekolah "${tenant.name}" berhasil ${newStatus ? 'diaktifkan' : 'dinonaktifkan'}. Data historis tetap utuh.`,
      });
      await loadData();
    } catch (err: any) {
      setNotification({ type: 'error', message: err.message || 'Gagal mengubah status tenant.' });
    }
  };

  const handleOpenCreateTeacher = (tenant: Tenant) => {
    setTargetTenantForTeacher(tenant);
    setTeacherName('');
    setTeacherEmail('');
    setTeacherPassword('');
    setTeacherPasswordConfirm('');
    setTeacherPhone('');
    setTeacherNip('');
    setTeacherNuptk('');
    setTeacherGender('L');
    setTeacherEmploymentType('GTY');
    setTeacherSpecialty('Matematika');
    setShowTeacherPassword(false);
    setCreateTeacherModalOpen(true);
  };

  const handleSaveTeacher = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!targetTenantForTeacher) return;
    if (teacherPassword.length < 8) {
      setNotification({ type: 'error', message: 'Password minimal 8 karakter.' });
      return;
    }
    if (teacherPassword !== teacherPasswordConfirm) {
      setNotification({ type: 'error', message: 'Konfirmasi password tidak sama.' });
      return;
    }

    setTeacherSubmitting(true);
    try {
      await teacherAccountService.createTeacherAccount(
        {
          tenant_id: targetTenantForTeacher.id,
          full_name: teacherName,
          email: teacherEmail,
          password: teacherPassword,
          phone: teacherPhone || undefined,
          nip: teacherNip || undefined,
          nuptk: teacherNuptk || undefined,
          gender: teacherGender,
          employment_type: teacherEmploymentType,
          subject_specialty: teacherSpecialty ? [teacherSpecialty] : ['Umum'],
          assignments: [],
        },
        currentUser
      );

      setNotification({
        type: 'success',
        message: `Akun guru "${teacherName}" berhasil dibuat untuk ${targetTenantForTeacher.name}, status ACTIVE, dan siap login dengan email serta password yang didaftarkan.`,
      });
      setCreateTeacherModalOpen(false);
      await loadData();
    } catch (err: any) {
      setNotification({ type: 'error', message: err.message || 'Gagal membuat akun guru.' });
    } finally {
      setTeacherSubmitting(false);
    }
  };

  // Handle Create Tenant
  const handleCreateTenant = async (e: React.FormEvent) => {
    e.preventDefault();
    setCreateTenantSubmitting(true);
    try {
      const created = await tenantRepository.createTenant(
        {
          name: newSchoolName,
          npsn: newNpsn,
          type: newSchoolType,
          accreditation: newAccreditation,
          province: newProvince,
          city: newCity,
          address: newAddress,
          phone: newPhone,
          email: newEmail,
          teacher_quota: Number(newInitialQuota),
        },
        currentUser
      );
      setNotification({
        type: 'success',
        message: `Tenant sekolah baru "${created.name}" (NPSN: ${created.npsn}) berhasil didaftarkan!`,
      });
      setCreateTenantModalOpen(false);
      setNewSchoolName('');
      setNewNpsn('');
      setNewAddress('');
      setNewPhone('');
      setNewEmail('');
      await loadData();
    } catch (err: any) {
      setNotification({ type: 'error', message: err.message || 'Gagal membuat tenant baru.' });
    } finally {
      setCreateTenantSubmitting(false);
    }
  };

  // Handle Create Principal
  const handleOpenCreatePrincipal = (tenant: Tenant) => {
    setTargetTenantForPrincipal(tenant);
    setPrincipalName('');
    setPrincipalEmail(`kepsek@${tenant.slug}.sch.id`);
    setPrincipalPhone('');
    setPrincipalNip('');
    setPrincipalPassword('');
    setPrincipalPasswordConfirm('');
    setShowPrincipalPassword(false);
    setCreatePrincipalModalOpen(true);
  };

  const handleSavePrincipal = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!targetTenantForPrincipal) return;
    setPrincipalSubmitting(true);
    try {
      if (principalPassword.length < 8) {
        throw new Error('Password minimal 8 karakter.');
      }
      if (principalPassword !== principalPasswordConfirm) {
        throw new Error('Konfirmasi password tidak sama.');
      }
      const p = await principalAccountService.createPrincipalAccount(
        {
          tenant_id: targetTenantForPrincipal.id,
          full_name: principalName,
          email: principalEmail,
          password: principalPassword,
          phone: principalPhone,
          nip: principalNip,
        },
        currentUser
      );
      setNotification({
        type: 'success',
        message: `Akun Kepala Sekolah "${p.full_name}" (${p.email}) berhasil dibuat dan dihubungkan ke ${targetTenantForPrincipal.name}.`,
      });
      setCreatePrincipalModalOpen(false);
      await loadData();
    } catch (err: any) {
      setNotification({ type: 'error', message: err.message || 'Gagal membuat akun Kepala Sekolah.' });
    } finally {
      setPrincipalSubmitting(false);
    }
  };

  const filteredTenants = tenants.filter((t) => {
    const matchesSearch =
      t.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      t.npsn.includes(searchTerm) ||
      t.city.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesType = filterType === 'ALL' || t.type === filterType;
    return matchesSearch && matchesType;
  });

  return (
    <div className="space-y-6">
      {/* Top Banner / Hero */}
      <div className="rounded-2xl bg-gradient-to-r from-slate-900 via-blue-950 to-indigo-950 p-6 text-white shadow-xl">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-2 rounded-full bg-blue-500/20 px-3 py-1 text-xs font-semibold text-blue-300 border border-blue-400/30">
              <ShieldCheck className="h-3.5 w-3.5" />
              <span>Super Master Platform</span>
            </div>
            <h1 className="mt-2 text-2xl font-extrabold tracking-tight sm:text-3xl">
              Pusat Kendali Multi-Tenant & Lisensi
            </h1>
            <p className="mt-1 text-sm text-slate-300 max-w-2xl">
              Pengawasan menyeluruh ekosistem sekolah SMA/SMK, pengelolaan kuota lisensi guru berbayar (Rp15.000/guru aktif/bln), dan administrasi hak akses.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => setCreateTenantModalOpen(true)}
              className="flex items-center gap-2 rounded-xl bg-blue-600 hover:bg-blue-500 px-4 py-2.5 text-xs font-bold text-white shadow-lg transition-all"
            >
              <Plus className="h-4 w-4" />
              <span>Tambah Sekolah Baru</span>
            </button>
            <button
              onClick={loadData}
              className="rounded-xl bg-white/10 hover:bg-white/20 p-2.5 text-white transition-colors"
              title="Segarkan Data"
            >
              <RefreshCw className={`h-4 w-4 ${loading ? 'animate-spin' : ''}`} />
            </button>
          </div>
        </div>
      </div>

      {/* Notification toast */}
      {notification && (
        <div
          className={`flex items-center justify-between rounded-xl p-4 text-xs font-medium ${
            notification.type === 'success'
              ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
              : 'bg-red-50 text-red-800 border border-red-200'
          }`}
        >
          <span>{notification.message}</span>
          <button
            onClick={() => setNotification(null)}
            className="font-bold underline hover:opacity-80"
          >
            Tutup
          </button>
        </div>
      )}

      {/* Metric Cards Grid */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {/* Card 1: Total Sekolah */}
        <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-xs">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-xs font-semibold uppercase tracking-wider">Total Tenant Sekolah</span>
            <div className="rounded-xl bg-blue-50 p-2 text-blue-700">
              <Building2 className="h-5 w-5" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl font-bold text-slate-900">{totalTenants}</span>
            <span className="text-xs text-emerald-600 font-semibold">
              ({totalActiveTenants} Aktif)
            </span>
          </div>
          <div className="mt-2 text-xs text-slate-400">SMA & SMK Terakreditasi</div>
        </div>

        {/* Card 2: Total Guru Aktif */}
        <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-xs">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-xs font-semibold uppercase tracking-wider">Total Guru Aktif</span>
            <div className="rounded-xl bg-indigo-50 p-2 text-indigo-700">
              <Users className="h-5 w-5" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl font-bold text-slate-900">{totalActiveTeachers}</span>
            <span className="text-xs text-slate-500">/ {totalAllocatedQuota} Slot Kuota</span>
          </div>
          <div className="mt-2 text-xs text-slate-400">Dihitung dari akun Guru status ACTIVE</div>
        </div>

        {/* Card 3: Utilisasi Lisensi */}
        <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-xs">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-xs font-semibold uppercase tracking-wider">Tingkat Utilisasi</span>
            <div className="rounded-xl bg-purple-50 p-2 text-purple-700">
              <CreditCard className="h-5 w-5" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl font-bold text-slate-900">
              {totalAllocatedQuota > 0
                ? Math.round((totalActiveTeachers / totalAllocatedQuota) * 100)
                : 0}
              %
            </span>
            <span className="text-xs text-purple-600 font-semibold">Global Platform</span>
          </div>
          <div className="mt-2 text-xs text-slate-400">Kapasitas lisensi terpakai</div>
        </div>

        {/* Card 4: Estimasi Pendapatan Lisensi */}
        <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-xs">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-xs font-semibold uppercase tracking-wider">Estimasi Omset Lisensi</span>
            <div className="rounded-xl bg-emerald-50 p-2 text-emerald-700">
              <DollarSign className="h-5 w-5" />
            </div>
          </div>
          <div className="mt-3">
            <span className="text-xl font-bold text-emerald-700">
              Rp {totalMonthlyRevenue.toLocaleString('id-ID')}
            </span>
            <span className="text-xs text-slate-500"> / bulan</span>
          </div>
          <div className="mt-2 text-xs text-slate-400">Rp15.000 x {totalActiveTeachers} guru aktif</div>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3 rounded-2xl border border-slate-200 bg-white p-4 shadow-xs">
        <div className="relative w-full sm:w-80">
          <Search className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
          <input
            type="text"
            placeholder="Cari sekolah, NPSN, atau kota..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full rounded-xl border border-slate-200 pl-9 pr-3 py-2 text-xs text-slate-800 placeholder:text-slate-400 focus:border-blue-500 focus:outline-hidden"
          />
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto">
          <div className="flex rounded-xl bg-slate-100 p-1 text-xs">
            <button
              onClick={() => setFilterType('ALL')}
              className={`rounded-lg px-3 py-1 font-medium transition-all ${
                filterType === 'ALL' ? 'bg-white text-blue-700 shadow-xs font-bold' : 'text-slate-600'
              }`}
            >
              Semua ({tenants.length})
            </button>
            <button
              onClick={() => setFilterType('SMA')}
              className={`rounded-lg px-3 py-1 font-medium transition-all ${
                filterType === 'SMA' ? 'bg-white text-blue-700 shadow-xs font-bold' : 'text-slate-600'
              }`}
            >
              SMA ({tenants.filter((t) => t.type === 'SMA').length})
            </button>
            <button
              onClick={() => setFilterType('SMK')}
              className={`rounded-lg px-3 py-1 font-medium transition-all ${
                filterType === 'SMK' ? 'bg-white text-blue-700 shadow-xs font-bold' : 'text-slate-600'
              }`}
            >
              SMK ({tenants.filter((t) => t.type === 'SMK').length})
            </button>
          </div>
        </div>
      </div>

      {/* Tenant List Table / Cards */}
      <div className="space-y-4">
        {filteredTenants.map((tenant) => {
          const usage = usages[tenant.id] || {
            used_licenses: tenant.active_teacher_count || 0,
            total_quota: tenant.teacher_quota,
            available_licenses: Math.max(0, tenant.teacher_quota - (tenant.active_teacher_count || 0)),
            usage_percentage: Math.min(
              100,
              Math.round(((tenant.active_teacher_count || 0) / tenant.teacher_quota) * 100)
            ),
            is_full: (tenant.active_teacher_count || 0) >= tenant.teacher_quota,
            estimated_monthly_cost: (tenant.active_teacher_count || 0) * TEACHER_LICENSE_PRICE_PER_MONTH,
          };
          const principal = principals[tenant.id];

          return (
            <div
              key={tenant.id}
              className={`rounded-2xl border transition-all ${
                tenant.is_active
                  ? 'border-slate-200 bg-white hover:border-blue-300 shadow-xs'
                  : 'border-red-200 bg-red-50/20 opacity-80'
              } p-5`}
            >
              <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
                {/* Left: School identity */}
                <div className="flex items-start gap-4">
                  <div
                    className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl font-bold text-white shadow-sm"
                    style={{ backgroundColor: tenant.brand_color || '#1e40af' }}
                  >
                    {tenant.type}
                  </div>
                  <div>
                    <div className="flex items-center gap-2 flex-wrap">
                      <h3 className="text-base font-bold text-slate-900">{tenant.name}</h3>
                      <span
                        className={`rounded-full px-2 py-0.5 text-[10px] font-bold ${
                          tenant.is_active
                            ? 'bg-emerald-100 text-emerald-800'
                            : 'bg-red-100 text-red-800'
                        }`}
                      >
                        {tenant.is_active ? 'OPERASIONAL AKTIF' : 'NONAKTIF / SUSPEND'}
                      </span>
                      <span className="rounded-md bg-slate-100 px-2 py-0.5 text-[10px] font-semibold text-slate-600">
                        NPSN: {tenant.npsn}
                      </span>
                      <span className="rounded-md bg-blue-50 px-2 py-0.5 text-[10px] font-bold text-blue-700">
                        Akreditasi {tenant.accreditation}
                      </span>
                    </div>

                    <div className="mt-1 flex items-center gap-4 text-xs text-slate-500">
                      <span>{tenant.address}, {tenant.city}, {tenant.province}</span>
                      <span>•</span>
                      <span>Telp: {tenant.phone}</span>
                    </div>

                    {/* Principal Info */}
                    <div className="mt-2 flex items-center gap-2 text-xs">
                      <span className="font-semibold text-slate-600">Kepala Sekolah:</span>
                      {principal ? (
                        <span className="text-slate-800 font-medium">
                          {principal.full_name} ({principal.email})
                        </span>
                      ) : (
                        <span className="text-amber-600 font-medium flex items-center gap-1">
                          <AlertTriangle className="h-3 w-3" />
                          Belum terhubung dengan akun Kepala Sekolah
                        </span>
                      )}
                    </div>
                  </div>
                </div>

                {/* Center: Quota Meter */}
                <div className="min-w-[240px] rounded-xl bg-slate-50 p-3 border border-slate-100">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-bold text-slate-700">Kuota Lisensi Guru:</span>
                    <span className="font-extrabold text-blue-700">
                      {usage.used_licenses} / {usage.total_quota} Slot
                    </span>
                  </div>

                  {/* Progress Bar */}
                  <div className="mt-2 h-2 w-full rounded-full bg-slate-200 overflow-hidden">
                    <div
                      className={`h-full rounded-full transition-all ${
                        usage.is_full
                          ? 'bg-red-600'
                          : usage.usage_percentage > 80
                          ? 'bg-amber-500'
                          : 'bg-blue-600'
                      }`}
                      style={{ width: `${Math.min(100, usage.usage_percentage)}%` }}
                    />
                  </div>

                  <div className="mt-2 flex items-center justify-between text-[11px] text-slate-500">
                    <span>
                      Sisa: <strong className="text-slate-700">{usage.available_licenses} slot</strong>
                    </span>
                    <span className="font-medium text-emerald-700">
                      Rp {usage.estimated_monthly_cost.toLocaleString('id-ID')}/bln
                    </span>
                  </div>
                </div>

                {/* Right: Actions */}
                <div className="flex items-center gap-2 flex-wrap">
                  <button
                    onClick={() => handleOpenQuotaModal(tenant)}
                    className="flex items-center gap-1.5 rounded-xl border border-blue-200 bg-blue-50 hover:bg-blue-100 px-3 py-2 text-xs font-semibold text-blue-800 transition-colors"
                    title="Ubah Alokasi Kuota Lisensi Guru (Hanya MASTER)"
                  >
                    <Sliders className="h-3.5 w-3.5" />
                    <span>Ubah Kuota</span>
                  </button>

                  <button
                    onClick={() => handleOpenCreateTeacher(tenant)}
                    disabled={!tenant.is_active}
                    className="flex items-center gap-1.5 rounded-xl border border-emerald-200 bg-emerald-50 hover:bg-emerald-100 disabled:cursor-not-allowed disabled:opacity-50 px-3 py-2 text-xs font-semibold text-emerald-800 transition-colors"
                    title="Daftarkan akun Guru untuk sekolah ini"
                  >
                    <UserPlus className="h-3.5 w-3.5" />
                    <span>Daftar Guru</span>
                  </button>

                  {!principal && (
                    <button
                      onClick={() => handleOpenCreatePrincipal(tenant)}
                      className="flex items-center gap-1.5 rounded-xl border border-indigo-200 bg-indigo-50 hover:bg-indigo-100 px-3 py-2 text-xs font-semibold text-indigo-800 transition-colors"
                      title="Buat Akun Kepala Sekolah"
                    >
                      <UserPlus className="h-3.5 w-3.5" />
                      <span>Buat Akun Kepsek</span>
                    </button>
                  )}

                  <button
                    onClick={() => handleToggleTenantStatus(tenant)}
                    className={`flex items-center gap-1.5 rounded-xl px-3 py-2 text-xs font-semibold transition-colors ${
                      tenant.is_active
                        ? 'border border-red-200 bg-red-50 text-red-700 hover:bg-red-100'
                        : 'border border-emerald-200 bg-emerald-50 text-emerald-700 hover:bg-emerald-100'
                    }`}
                    title={tenant.is_active ? 'Nonaktifkan Sekolah' : 'Aktifkan Kembali'}
                  >
                    {tenant.is_active ? (
                      <>
                        <XCircle className="h-3.5 w-3.5" />
                        <span>Nonaktifkan</span>
                      </>
                    ) : (
                      <>
                        <CheckCircle2 className="h-3.5 w-3.5" />
                        <span>Aktifkan</span>
                      </>
                    )}
                  </button>
                </div>
              </div>
            </div>
          );
        })}

        {filteredTenants.length === 0 && (
          <div className="rounded-2xl border border-dashed border-slate-300 bg-white p-12 text-center text-slate-500">
            <Building2 className="mx-auto h-12 w-12 text-slate-300" />
            <div className="mt-3 text-sm font-semibold text-slate-700">
              Tidak ada sekolah yang cocok dengan pencarian
            </div>
            <p className="text-xs text-slate-400 mt-1">
              Ubah filter atau tambahkan sekolah baru dengan tombol di atas.
            </p>
          </div>
        )}
      </div>

      {/* ================= MODAL: EDIT QUOTA ================= */}
      {quotaModalOpen && selectedTenantForQuota && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 p-4 backdrop-blur-xs">
          <div className="w-full max-w-md rounded-2xl bg-white p-6 shadow-2xl border border-slate-200">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2">
                <Sliders className="h-5 w-5 text-blue-600" />
                <h3 className="text-base font-bold text-slate-900">Ubah Kuota Lisensi Guru</h3>
              </div>
              <button
                onClick={() => setQuotaModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 text-lg font-bold"
              >
                &times;
              </button>
            </div>

            <form onSubmit={handleSaveQuota} className="mt-4 space-y-4">
              <div>
                <label className="text-xs font-semibold text-slate-600">Sekolah Sasaran</label>
                <div className="mt-1 rounded-xl bg-slate-50 p-2.5 text-xs font-bold text-slate-800 border border-slate-200">
                  {selectedTenantForQuota.name}
                </div>
              </div>

              <div>
                <div className="flex justify-between text-xs">
                  <label className="font-semibold text-slate-600">Jumlah Kuota Baru (Slot Guru)</label>
                  <span className="text-slate-500 font-medium">
                    Guru Aktif Saat Ini: <strong>{selectedTenantForQuota.active_teacher_count}</strong>
                  </span>
                </div>
                <input
                  type="number"
                  min={selectedTenantForQuota.active_teacher_count || 1}
                  max={500}
                  required
                  value={newQuotaInput}
                  onChange={(e) => setNewQuotaInput(parseInt(e.target.value) || 0)}
                  className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-sm font-bold text-slate-900 focus:border-blue-500 focus:outline-hidden"
                />
                <p className="mt-1 text-[11px] text-slate-400">
                  Batas minimal: {selectedTenantForQuota.active_teacher_count} slot (tidak boleh lebih kecil dari guru aktif).
                </p>
              </div>

              {/* Price Calculation Box */}
              <div className="rounded-xl bg-blue-50 p-3 text-xs text-blue-900 border border-blue-100">
                <div className="flex items-center justify-between">
                  <span>Biaya Lisensi Terhitung:</span>
                  <span className="font-bold text-blue-800">
                    Rp {(newQuotaInput * TEACHER_LICENSE_PRICE_PER_MONTH).toLocaleString('id-ID')} / bulan
                  </span>
                </div>
                <div className="text-[10px] text-blue-600 mt-1">
                  Aturan bisnis terkunci: Rp15.000 / slot guru / bulan
                </div>
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-600">Alasan Perubahan Kuota (Audit Log)</label>
                <input
                  type="text"
                  required
                  placeholder="Contoh: Penambahan rombel baru semester genap"
                  value={quotaReasonInput}
                  onChange={(e) => setQuotaReasonInput(e.target.value)}
                  className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-xs text-slate-800 focus:border-blue-500 focus:outline-hidden"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setQuotaModalOpen(false)}
                  className="rounded-xl border border-slate-200 bg-white px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-50"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  disabled={quotaSubmitting}
                  className="rounded-xl bg-blue-700 hover:bg-blue-800 px-4 py-2 text-xs font-semibold text-white shadow-xs"
                >
                  {quotaSubmitting ? 'Menyimpan...' : 'Simpan Kuota Baru'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ================= MODAL: CREATE TENANT ================= */}
      {createTenantModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 p-4 backdrop-blur-xs">
          <div className="w-full max-w-xl max-h-[90vh] overflow-y-auto rounded-2xl bg-white p-6 shadow-2xl border border-slate-200">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2">
                <Building2 className="h-5 w-5 text-blue-600" />
                <h3 className="text-base font-bold text-slate-900">Tambah Tenant Sekolah Baru</h3>
              </div>
              <button
                onClick={() => setCreateTenantModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 text-lg font-bold"
              >
                &times;
              </button>
            </div>

            <form onSubmit={handleCreateTenant} className="mt-4 space-y-3.5">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-semibold text-slate-700">Nama Sekolah</label>
                  <input
                    type="text"
                    required
                    placeholder="SMA Negeri 2 Maju"
                    value={newSchoolName}
                    onChange={(e) => setNewSchoolName(e.target.value)}
                    className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-xs focus:border-blue-500 focus:outline-hidden"
                  />
                </div>
                <div>
                  <label className="text-xs font-semibold text-slate-700">NPSN</label>
                  <input
                    type="text"
                    required
                    maxLength={10}
                    placeholder="20109999"
                    value={newNpsn}
                    onChange={(e) => setNewNpsn(e.target.value)}
                    className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-xs focus:border-blue-500 focus:outline-hidden"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="text-xs font-semibold text-slate-700">Tipe Sekolah</label>
                  <select
                    value={newSchoolType}
                    onChange={(e) => setNewSchoolType(e.target.value as 'SMA' | 'SMK')}
                    className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-xs focus:border-blue-500 focus:outline-hidden"
                  >
                    <option value="SMA">SMA (Umum)</option>
                    <option value="SMK">SMK (Kejuruan/Vokasi)</option>
                  </select>
                </div>
                <div>
                  <label className="text-xs font-semibold text-slate-700">Akreditasi</label>
                  <select
                    value={newAccreditation}
                    onChange={(e) => setNewAccreditation(e.target.value as 'A' | 'B' | 'C')}
                    className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-xs focus:border-blue-500 focus:outline-hidden"
                  >
                    <option value="A">Akreditasi A</option>
                    <option value="B">Akreditasi B</option>
                    <option value="C">Akreditasi C</option>
                  </select>
                </div>
                <div>
                  <label className="text-xs font-semibold text-slate-700">Kuota Awal Guru</label>
                  <input
                    type="number"
                    min={5}
                    max={200}
                    required
                    value={newInitialQuota}
                    onChange={(e) => setNewInitialQuota(parseInt(e.target.value) || 20)}
                    className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-xs focus:border-blue-500 focus:outline-hidden"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-semibold text-slate-700">Provinsi</label>
                  <input
                    type="text"
                    required
                    value={newProvince}
                    onChange={(e) => setNewProvince(e.target.value)}
                    className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-xs focus:border-blue-500 focus:outline-hidden"
                  />
                </div>
                <div>
                  <label className="text-xs font-semibold text-slate-700">Kota / Kabupaten</label>
                  <input
                    type="text"
                    required
                    value={newCity}
                    onChange={(e) => setNewCity(e.target.value)}
                    className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-xs focus:border-blue-500 focus:outline-hidden"
                  />
                </div>
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-700">Alamat Lengkap</label>
                <textarea
                  rows={2}
                  required
                  placeholder="Jl. Pendidikan No. 12"
                  value={newAddress}
                  onChange={(e) => setNewAddress(e.target.value)}
                  className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-xs focus:border-blue-500 focus:outline-hidden"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-semibold text-slate-700">No. Telepon Sekolah</label>
                  <input
                    type="tel"
                    required
                    placeholder="021-7890123"
                    value={newPhone}
                    onChange={(e) => setNewPhone(e.target.value)}
                    className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-xs focus:border-blue-500 focus:outline-hidden"
                  />
                </div>
                <div>
                  <label className="text-xs font-semibold text-slate-700">Email Sekolah</label>
                  <input
                    type="email"
                    required
                    placeholder="info@sman2maju.sch.id"
                    value={newEmail}
                    onChange={(e) => setNewEmail(e.target.value)}
                    className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-xs focus:border-blue-500 focus:outline-hidden"
                  />
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setCreateTenantModalOpen(false)}
                  className="rounded-xl border border-slate-200 bg-white px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-50"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  disabled={createTenantSubmitting}
                  className="rounded-xl bg-blue-700 hover:bg-blue-800 px-4 py-2 text-xs font-semibold text-white shadow-xs"
                >
                  {createTenantSubmitting ? 'Mendaftarkan...' : 'Daftarkan Tenant Sekolah'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ================= MODAL: CREATE TEACHER ================= */}
      {createTeacherModalOpen && targetTenantForTeacher && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 p-4 backdrop-blur-xs overflow-y-auto">
          <div className="w-full max-w-xl rounded-2xl bg-white p-6 shadow-2xl border border-slate-200 my-8">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2">
                <div className="rounded-xl bg-emerald-100 p-2 text-emerald-700">
                  <UserPlus className="h-5 w-5" />
                </div>
                <div>
                  <h3 className="text-base font-extrabold text-slate-900">Registrasi Akun Guru</h3>
                  <p className="text-[11px] text-slate-500">Master membuat akun guru langsung ACTIVE untuk sekolah yang dipilih.</p>
                </div>
              </div>
              <button onClick={() => setCreateTeacherModalOpen(false)} className="text-slate-400 hover:text-slate-600 text-xl font-bold">&times;</button>
            </div>

            <form onSubmit={handleSaveTeacher} className="mt-4 space-y-3.5">
              <div>
                <label className="text-xs font-semibold text-slate-600">Sekolah</label>
                <div className="mt-1 rounded-xl bg-slate-50 p-2.5 text-xs font-bold text-slate-800 border border-slate-200">
                  {targetTenantForTeacher.name} · {targetTenantForTeacher.type}
                </div>
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-700">Nama Lengkap & Gelar</label>
                <input type="text" required value={teacherName} onChange={(e) => setTeacherName(e.target.value)} placeholder="Drs. H. Ahmad Dahlan, M.Pd." className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-xs focus:border-emerald-500 focus:outline-hidden" />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-semibold text-slate-700">Email Login</label>
                  <input type="email" required value={teacherEmail} onChange={(e) => setTeacherEmail(e.target.value)} placeholder="guru@sekolah.sch.id" className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-xs focus:border-emerald-500 focus:outline-hidden" />
                </div>
                <div>
                  <label className="text-xs font-semibold text-slate-700">No. WhatsApp</label>
                  <input type="tel" value={teacherPhone} onChange={(e) => setTeacherPhone(e.target.value)} placeholder="08123456789" className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-xs focus:border-emerald-500 focus:outline-hidden" />
                </div>
              </div>

              <div className="rounded-xl border border-emerald-200 bg-emerald-50/60 p-3">
                <div className="flex items-center justify-between gap-2">
                  <div>
                    <label className="text-xs font-bold text-emerald-900">Password Login</label>
                    <p className="mt-0.5 text-[10px] text-emerald-700">Password dibuat oleh Master dan langsung aktif untuk login.</p>
                  </div>
                  <button type="button" onClick={() => setShowTeacherPassword((v) => !v)} className="text-[10px] font-bold text-emerald-700 hover:text-emerald-900">
                    {showTeacherPassword ? 'Sembunyikan' : 'Tampilkan'}
                  </button>
                </div>
                <div className="mt-2 grid grid-cols-2 gap-3">
                  <input type={showTeacherPassword ? 'text' : 'password'} required minLength={8} autoComplete="new-password" placeholder="Minimal 8 karakter" value={teacherPassword} onChange={(e) => setTeacherPassword(e.target.value)} className="w-full rounded-xl border border-emerald-200 bg-white px-3 py-2 text-xs focus:border-emerald-500 focus:outline-hidden" />
                  <input type={showTeacherPassword ? 'text' : 'password'} required minLength={8} autoComplete="new-password" placeholder="Ulangi password" value={teacherPasswordConfirm} onChange={(e) => setTeacherPasswordConfirm(e.target.value)} className="w-full rounded-xl border border-emerald-200 bg-white px-3 py-2 text-xs focus:border-emerald-500 focus:outline-hidden" />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-semibold text-slate-700">NIP (Opsional)</label>
                  <input value={teacherNip} onChange={(e) => setTeacherNip(e.target.value)} placeholder="1980..." className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-xs focus:border-emerald-500 focus:outline-hidden" />
                </div>
                <div>
                  <label className="text-xs font-semibold text-slate-700">NUPTK (Opsional)</label>
                  <input value={teacherNuptk} onChange={(e) => setTeacherNuptk(e.target.value)} placeholder="12345678..." className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-xs focus:border-emerald-500 focus:outline-hidden" />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="text-xs font-semibold text-slate-700">Jenis Kelamin</label>
                  <select value={teacherGender} onChange={(e) => setTeacherGender(e.target.value as 'L' | 'P')} className="mt-1 w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs">
                    <option value="L">Laki-laki</option><option value="P">Perempuan</option>
                  </select>
                </div>
                <div>
                  <label className="text-xs font-semibold text-slate-700">Status Kepegawaian</label>
                  <select value={teacherEmploymentType} onChange={(e) => setTeacherEmploymentType(e.target.value as 'PNS' | 'PPPK' | 'GTY' | 'GTT')} className="mt-1 w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs">
                    <option value="PNS">PNS</option><option value="PPPK">PPPK</option><option value="GTY">GTY</option><option value="GTT">GTT / Honorer</option>
                  </select>
                </div>
                <div>
                  <label className="text-xs font-semibold text-slate-700">Mapel Utama</label>
                  <input value={teacherSpecialty} onChange={(e) => setTeacherSpecialty(e.target.value)} placeholder="Matematika" className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-xs focus:border-emerald-500 focus:outline-hidden" />
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
                <button type="button" onClick={() => setCreateTeacherModalOpen(false)} className="rounded-xl border border-slate-200 bg-white px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-50">Batal</button>
                <button type="submit" disabled={teacherSubmitting} className="rounded-xl bg-emerald-600 hover:bg-emerald-700 px-4 py-2 text-xs font-semibold text-white shadow-xs disabled:opacity-60">
                  {teacherSubmitting ? 'Membuat Akun...' : 'Simpan & Aktifkan Guru'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ================= MODAL: CREATE PRINCIPAL ================= */}
      {createPrincipalModalOpen && targetTenantForPrincipal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 p-4 backdrop-blur-xs">
          <div className="w-full max-w-md rounded-2xl bg-white p-6 shadow-2xl border border-slate-200">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2">
                <UserPlus className="h-5 w-5 text-indigo-600" />
                <h3 className="text-base font-bold text-slate-900">Buat Akun Kepala Sekolah</h3>
              </div>
              <button
                onClick={() => setCreatePrincipalModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 text-lg font-bold"
              >
                &times;
              </button>
            </div>

            <form onSubmit={handleSavePrincipal} className="mt-4 space-y-3.5">
              <div>
                <label className="text-xs font-semibold text-slate-600">Sekolah</label>
                <div className="mt-1 rounded-xl bg-slate-50 p-2.5 text-xs font-bold text-slate-800 border border-slate-200">
                  {targetTenantForPrincipal.name}
                </div>
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-700">Nama Lengkap & Gelar</label>
                <input
                  type="text"
                  required
                  placeholder="Dr. H. Bambang Sudrajat, M.Pd."
                  value={principalName}
                  onChange={(e) => setPrincipalName(e.target.value)}
                  className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-xs focus:border-indigo-500 focus:outline-hidden"
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-700">Email Login</label>
                <input
                  type="email"
                  required
                  value={principalEmail}
                  onChange={(e) => setPrincipalEmail(e.target.value)}
                  className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-xs focus:border-indigo-500 focus:outline-hidden"
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-700">NIP (Opsional)</label>
                <input
                  type="text"
                  placeholder="19800101..."
                  value={principalNip}
                  onChange={(e) => setPrincipalNip(e.target.value)}
                  className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-xs focus:border-indigo-500 focus:outline-hidden"
                />
              </div>

              <div>
                <div className="flex items-center justify-between">
                  <label className="text-xs font-semibold text-slate-700">Password Login</label>
                  <button type="button" onClick={() => setShowPrincipalPassword((v) => !v)} className="text-[10px] font-bold text-indigo-600 hover:text-indigo-800">
                    {showPrincipalPassword ? 'Sembunyikan' : 'Tampilkan'}
                  </button>
                </div>
                <input
                  type={showPrincipalPassword ? 'text' : 'password'}
                  required
                  minLength={8}
                  autoComplete="new-password"
                  placeholder="Minimal 8 karakter"
                  value={principalPassword}
                  onChange={(e) => setPrincipalPassword(e.target.value)}
                  className="mt-1 w-full rounded-xl border border-indigo-200 bg-indigo-50/30 px-3 py-2 text-xs focus:border-indigo-500 focus:outline-hidden"
                />
                <input
                  type={showPrincipalPassword ? 'text' : 'password'}
                  required
                  minLength={8}
                  autoComplete="new-password"
                  placeholder="Ulangi password"
                  value={principalPasswordConfirm}
                  onChange={(e) => setPrincipalPasswordConfirm(e.target.value)}
                  className="mt-2 w-full rounded-xl border border-indigo-200 bg-indigo-50/30 px-3 py-2 text-xs focus:border-indigo-500 focus:outline-hidden"
                />
                <p className="mt-1 text-[10px] text-slate-500">Akun dibuat ACTIVE dan siap login menggunakan email dan password ini.</p>
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-700">No. Handphone / WhatsApp</label>
                <input
                  type="tel"
                  placeholder="081234567890"
                  value={principalPhone}
                  onChange={(e) => setPrincipalPhone(e.target.value)}
                  className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-xs focus:border-indigo-500 focus:outline-hidden"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setCreatePrincipalModalOpen(false)}
                  className="rounded-xl border border-slate-200 bg-white px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-50"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  disabled={principalSubmitting}
                  className="rounded-xl bg-indigo-700 hover:bg-indigo-800 px-4 py-2 text-xs font-semibold text-white shadow-xs"
                >
                  {principalSubmitting ? 'Memproses...' : 'Buat Akun Kepala Sekolah'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
