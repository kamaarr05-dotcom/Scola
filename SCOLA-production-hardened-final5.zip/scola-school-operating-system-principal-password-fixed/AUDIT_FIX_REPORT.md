# SCOLA — Final Hardening & Audit Report
Tanggal: 2026-09-17

## Perbaikan yang dilakukan

1. **TenantRepository Live Mode**
   - create tenant, update profile, toggle status, dan quota sekarang memakai Supabase secara strict ketika Live.
   - Error Supabase tidak lagi diam-diam fallback ke memory.
   - Counter guru Live memakai RPC reservation/release.

2. **TeacherRepository Live Mode**
   - update ACTIVE/INACTIVE membaca dan menulis guru dari Supabase.
   - Aktivasi menggunakan reservation quota atomik.
   - Status user_profiles ikut disinkronkan.
   - Rollback kompensasi dilakukan bila update profil gagal.

3. **UserRepository Live Mode**
   - getPrincipals, getPrincipalByTenant, getUsersByTenant membaca Supabase.
   - add/update/status memeriksa error Supabase secara strict.
   - akun orang tua dummy browser diblokir pada Live agar tidak membuat identitas palsu.

4. **Tahun ajaran**
   - ditambahkan tabel `academic_years`, index, RLS, dan persistence Live.
   - pemilihan tahun aktif kini dilakukan di database.

5. **Penugasan guru**
   - ditambahkan tabel `teacher_assignments`, index, RLS, dan persistence Live.
   - Wali Kelas juga memperbarui rombel di Supabase.

6. **Privasi RLS**
   - siswa SISWA hanya dapat membaca data siswa sendiri.
   - ORANG_TUA dibatasi pada siswa yang terhubung melalui `linked_students`.
   - presensi dan nilai juga dibatasi berdasarkan kepemilikan siswa untuk SISWA/ORANG_TUA.

7. **Integritas data siswa**
   - ditambahkan unique index NIS dan NISN per tenant.
   - migration dibuat idempotent.

8. **SQL Setup**
   - `students.updated_at` tetap dijamin.
   - `academic_years` dan `teacher_assignments` ditambahkan.
   - policy utama dibuat aman untuk dijalankan ulang.

## Audit setelah perbaikan

- ZIP integrity: **PASS** (`unzip -t`).
- Tidak ditemukan `USING (true)` atau `WITH CHECK (true)`: **PASS**.
- Tidak ada service-role key di source frontend: **PASS**.
- Repository yang diperbaiki tidak lagi melakukan fallback Supabase ke memory pada operasi Live utama: **PASS**.
- Classroom demo/statik pada Kepsek tetap ada hanya pada mode offline/demo (`isSupabaseConfigured() ? [] : [...]`): **PASS**.
- Tidak ditemukan error TypeScript internal pada repository/service yang diperbaiki ketika dikompilasi dengan `tsc`; kegagalan keseluruhan `tsc` berasal dari dependency `node_modules` yang belum terpasang serta runtime Deno Edge Function typings.

## Yang masih sengaja diblokir di Live

Beberapa modul besar yang belum memiliki schema + repository Supabase lengkap masih mengeluarkan error terkontrol di Live, bukan menyimpan data ke memory. Ini berlaku untuk sebagian modul BK, Sarpras, PKL/BKK, surat, ekstrakurikuler, beasiswa, MoU, tugas/submission dan fitur sejenis yang belum dimigrasikan penuh.

Ini adalah perilaku aman: data produksi tidak boleh terlihat berhasil tetapi hilang setelah refresh.

## Status build

`npm install` tidak selesai karena timeout lingkungan, sehingga build Vite penuh belum dapat diverifikasi di lingkungan ini. `tsc` global berhasil melewati file repository/service yang dimodifikasi tanpa error internal; error yang tersisa berasal dari dependency yang tidak terinstal dan tipe Deno Edge Function yang memang memerlukan toolchain Supabase.

## SHA-256

`67ca8ea328b1d19ea2e37024af92bb8dbf178232fae3dfc06e44a994142a1c53`


## Final Repair Pass (2026-09-17)
- Fixed Live student registration to load classes and duplicate checks from Supabase.
- Made teacher_assignments authoritative for student registration/approval and synchronized teacher JSON assignments.
- Fixed browser access to atomic teacher quota RPCs with server-side role/tenant checks.
- Corrected academic_years RLS precedence and completed SQL modal schema ordering.
- Fixed live user update/status methods to query Supabase instead of local mock state.
- Hydrated live teacher assignments into AuthService session state.
- Live audit write failures now surface as errors instead of silent fallback.
- Tightened Edge Function CORS fallback to localhost instead of wildcard.
